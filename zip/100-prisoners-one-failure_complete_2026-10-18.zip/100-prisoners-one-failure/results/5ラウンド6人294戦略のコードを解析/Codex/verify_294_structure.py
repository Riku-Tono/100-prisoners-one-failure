"""Independent exhaustive audit of the n=6, m=3, >=5-success strategy.

Run: python -X utf8 verify_294_structure.py --csv analysis_294_all720.csv
Only the exception table is transcribed from the supplied verify_294.py.
The simulation, CF comparison, cycle decomposition, and structural assertions
are implemented here independently. Python standard library only.
"""

from __future__ import annotations

import argparse
import csv
from collections import Counter
from itertools import permutations
from pathlib import Path


N = 6
LIMIT = 3
THRESHOLD = 5
ANCHORS = (1, 4, 5)

# Key: (prisoner, first observed number). Value: second box.
SECOND = {(1, 4): 5, (4, 5): 1, (5, 1): 4}

# Key: (prisoner, first observed number, second observed number).
# Nine entries set the same box as ordinary CF; retaining them documents the
# source rule table exactly. An entry is consulted only if the prisoner has
# not already found their own number.
THIRD = {
    (1, 2, 4): 5, (1, 3, 4): 5, (1, 4, 2): 2, (1, 4, 3): 3,
    (1, 4, 5): 2, (1, 4, 6): 6, (1, 5, 4): 2, (1, 6, 4): 5,
    (4, 2, 5): 1, (4, 3, 5): 1, (4, 5, 1): 2, (4, 5, 2): 2,
    (4, 5, 3): 3, (4, 5, 6): 6, (4, 6, 5): 1, (5, 1, 2): 2,
    (5, 1, 3): 3, (5, 1, 4): 6, (5, 1, 6): 6, (5, 2, 1): 4,
    (5, 3, 1): 4, (5, 6, 1): 4,
}


def trace(prisoner: int, placement: tuple[int, ...], modified: bool):
    """Return (found, ((box, observed number), ...), decisions).

    placement[b-1] is the number in box b. Decisions record consulted
    exceptions, including entries that have the same target as CF.
    """
    history: list[tuple[int, int]] = []
    decisions: list[tuple[str, tuple[int, ...], int]] = []
    for step in range(LIMIT):
        if step == 0:
            box = prisoner
        elif step == 1:
            key = (prisoner, history[0][1])
            box = SECOND.get(key, history[-1][1]) if modified else history[-1][1]
            if modified and key in SECOND:
                decisions.append(("second", key, box))
        else:
            key = (prisoner, history[0][1], history[1][1])
            box = THIRD.get(key, history[-1][1]) if modified else history[-1][1]
            if modified and key in THIRD:
                decisions.append(("third", key, box))
        assert 1 <= box <= N
        assert box not in (b for b, _ in history), (prisoner, placement, history, box)
        observed = placement[box - 1]
        history.append((box, observed))
        if observed == prisoner:
            return True, tuple(history), tuple(decisions)
    return False, tuple(history), tuple(decisions)


def cycles_of(placement: tuple[int, ...]) -> tuple[tuple[int, ...], ...]:
    unseen = set(range(1, N + 1))
    cycles: list[tuple[int, ...]] = []
    while unseen:
        start = min(unseen)
        current = start
        cycle: list[int] = []
        while current in unseen:
            unseen.remove(current)
            cycle.append(current)
            current = placement[current - 1]
        assert current == start
        cycles.append(tuple(cycle))
    return tuple(cycles)


def rescue_cycle(cycles: tuple[tuple[int, ...], ...]):
    """The positive orientation: insert x into an edge of (1,4,5)."""
    for cycle in cycles:
        if len(cycle) != 4 or not set(ANCHORS) <= set(cycle):
            continue
        j = cycle.index(1)
        rotated = cycle[j:] + cycle[:j]
        if tuple(a for a in rotated if a in ANCHORS) == ANCHORS:
            return rotated
    return None


def path_string(outcomes):
    return " | ".join(
        f"{i}:" + ">".join(f"{box}:{seen}" for box, seen in outcome[1])
        for i, outcome in enumerate(outcomes, 1)
    )


def audit():
    class_count = Counter()
    by_cycle_type = Counter()
    strategy_success_count = Counter()
    rescued_cycles = Counter()
    shared_losses = Counter()
    rows = []

    for placement in permutations(range(1, N + 1)):
        cf = tuple(trace(i, placement, False) for i in range(1, N + 1))
        strategy = tuple(trace(i, placement, True) for i in range(1, N + 1))
        cycles = cycles_of(placement)
        cf_count = sum(outcome[0] for outcome in cf)
        strategy_count = sum(outcome[0] for outcome in strategy)
        cf_win = cf_count >= THRESHOLD
        strategy_win = strategy_count >= THRESHOLD
        classification = (
            "both" if cf_win and strategy_win else
            "CF_only" if cf_win else
            "294_only" if strategy_win else "neither"
        )
        gained = tuple(i for i in range(1, N + 1)
                       if not cf[i - 1][0] and strategy[i - 1][0])
        lost = tuple(i for i in range(1, N + 1)
                     if cf[i - 1][0] and not strategy[i - 1][0])
        cycle_type = tuple(sorted((len(c) for c in cycles), reverse=True))
        positive = rescue_cycle(cycles)

        # The CF criterion is checked through a separate combinatorial route.
        assert cf_win == (max(cycle_type) <= LIMIT)
        assert (classification == "294_only") == (positive is not None)
        if classification == "294_only":
            assert (cf_count, strategy_count, gained, lost) == (2, 5, ANCHORS, ())
            rescued_cycles[positive] += 1
        if classification == "both":
            assert len(lost) <= 1
            shared_losses[lost] += 1

        class_count[classification] += 1
        by_cycle_type[(cycle_type, classification)] += 1
        strategy_success_count[strategy_count] += 1
        rows.append({
            "placement_boxes_1_to_6": "".join(map(str, placement)),
            "cycles": " ".join("(" + " ".join(map(str, c)) + ")" for c in cycles),
            "cycle_type": "+".join(map(str, cycle_type)),
            "CF_successes": cf_count,
            "strategy_294_successes": strategy_count,
            "class": classification,
            "gained_prisoners": " ".join(map(str, gained)),
            "lost_prisoners": " ".join(map(str, lost)),
            "CF_paths_box_colon_content": path_string(cf),
            "strategy_paths_box_colon_content": path_string(strategy),
        })

    assert len(rows) == 720
    assert all(class_count[name] == expected for name, expected in
               (("both", 276), ("CF_only", 0), ("294_only", 18), ("neither", 426)))
    assert strategy_success_count[5] + strategy_success_count[6] == 294
    assert len(rescued_cycles) == 9 and set(rescued_cycles.values()) == {2}
    assert sum(shared_losses.values()) == 276
    return rows, class_count, by_cycle_type, strategy_success_count, rescued_cycles, shared_losses


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, help="Write all 720 records as UTF-8 BOM CSV")
    args = parser.parse_args()
    rows, counts, by_type, success_counts, rescued, losses = audit()
    print("class counts:", dict(counts))
    print("strategy success counts:", dict(sorted(success_counts.items())))
    print("cycle type: both, CF_only, 294_only, neither")
    for kind in sorted({k for k, _ in by_type}, reverse=True):
        print("+".join(map(str, kind)), *(by_type[(kind, c)] for c in
              ("both", "CF_only", "294_only", "neither")))
    print("rescued 4-cycles (two placements each):")
    for cycle in sorted(rescued):
        print(" ", "(" + " ".join(map(str, cycle)) + ")", rescued[cycle])
    print("CF-winning placements by lost prisoner(s):",
          {str(k): losses[k] for k in sorted(losses)})
    if args.csv:
        args.csv.parent.mkdir(parents=True, exist_ok=True)
        with args.csv.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        print("wrote:", args.csv.resolve())
    print("ALL 720 ASSERTIONS PASSED")


if __name__ == "__main__":
    main()
