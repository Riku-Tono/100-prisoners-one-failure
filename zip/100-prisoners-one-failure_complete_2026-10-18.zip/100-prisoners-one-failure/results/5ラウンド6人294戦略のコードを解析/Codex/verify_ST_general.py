"""Independent audit of Claude's S_T, n=2m, m>=3.

Standard library only. Run:
  python -X utf8 verify_ST_general.py --m 3 4
  python -X utf8 verify_ST_general.py --m 5

The action simulator is deliberately separate from Claude's next_box code.
Fallback: choose the least unopened box when a post-deviation CF step repeats.
This does not test the secondary single-trigger or solver claims.
"""

import argparse
from collections import Counter
from itertools import permutations
from math import factorial
from time import perf_counter


def cycle_data(p):
    n = len(p)
    lengths = [0] * n
    cycles = []
    for start in range(n):
        if lengths[start]:
            continue
        cycle = []
        j = start
        while j not in cycle:
            cycle.append(j)
            j = p[j]
        assert j == start
        for j in cycle:
            lengths[j] = len(cycle)
        cycles.append(tuple(cycle))
    return lengths, cycles


def prepare(m, core):
    n = 2 * m
    outsiders = tuple(i for i in range(n) if i not in core)
    specs = {}
    for k, a in enumerate(core):
        prefix = tuple(core[(k + d) % m] for d in range(1, m - 1))
        final_patterns = frozenset(
            prefix[:d] + (x,) + prefix[d:]
            for d in range(m - 2) for x in outsiders
        )
        specs[a] = (prefix, final_patterns, core[(k - 1) % m])
    return specs


def play_anchor(a, p, m, spec):
    prefix, patterns, predecessor = spec
    opened = []
    seen = []
    box = a
    deviated = False
    for step in range(m):
        if step == m - 2 and not deviated and tuple(seen) == prefix:
            box = predecessor
            deviated = True
        elif step == m - 1 and not deviated and tuple(seen) in patterns:
            box = predecessor
            deviated = True
        if box in opened:
            assert deviated
            box = next(b for b in range(2 * m) if b not in opened)
        assert box not in opened
        opened.append(box)
        number = p[box]
        seen.append(number)
        if number == a:
            return True
        box = number
    return False


def insertion_pattern(cycles, core, m):
    for cycle in cycles:
        if len(cycle) != m + 1 or not all(a in cycle for a in core):
            continue
        j = cycle.index(core[0])
        rotated = cycle[j:] + cycle[:j]
        return tuple(a for a in rotated if a in core) == core
    return False


def audit(m):
    if m < 3:
        raise ValueError('The audited theorem requires m>=3')
    n = 2 * m
    core = tuple(range(m))
    specs = prepare(m, core)
    classes = Counter()
    individual_losses = Counter()
    start = perf_counter()
    for number, p in enumerate(permutations(range(n)), 1):
        lengths, cycles = cycle_data(p)
        cf = [length <= m for length in lengths]
        modified = cf.copy()
        for a in core:
            modified[a] = play_anchor(a, p, m, specs[a])
        old = all(cf)
        new = sum(modified) >= n - 1
        classification = ('both' if old and new else 'CF_only' if old else
                          'ST_only' if new else 'neither')
        classes[classification] += 1
        losses = sum(before and not after for before, after in zip(cf, modified))
        assert losses <= 1, (m, p, cf, modified)
        individual_losses[losses] += 1
        assert (not old and new) == insertion_pattern(cycles, core, m), (m, p)
        if number % 500000 == 0:
            print(f'm={m}: checked {number}/{factorial(n)}', flush=True)

    total = factorial(n)
    expected_cf = total - sum(total // k for k in range(m + 1, n + 1))
    expected_gain = m * factorial(m)
    assert number == total
    assert classes['both'] == expected_cf
    assert classes['CF_only'] == 0
    assert classes['ST_only'] == expected_gain
    assert classes['neither'] == total - expected_cf - expected_gain
    result = {k: classes[k] for k in ('both', 'CF_only', 'ST_only', 'neither')}
    print(f'm={m}, n={n}: {result}; wins={expected_cf+expected_gain}; '
          f'loss_histogram={dict(individual_losses)}; '
          f'seconds={perf_counter()-start:.2f}', flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--m', nargs='+', type=int, default=[3, 4])
    args = parser.parse_args()
    for m in args.m:
        audit(m)
    print('ALL CHECKS PASSED', flush=True)


if __name__ == '__main__':
    main()
