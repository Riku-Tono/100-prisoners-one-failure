"""S_T 定理の全列挙による照合（Python 3、標準ライブラリのみ）。

実行:
    python -X utf8 verify_ST_theorem.py          # n=4, 6, 8（十数秒）
    python -X utf8 verify_ST_theorem.py --m5     # n=10 も追加（数分）

番号・箱は 1..n。placement[b-1] が箱 b の中身。
S_T の例外表は make_rules() だけで定義し、294 戦略の表は verify_294.py から転記した。
検査はすべて assert で行い、最後に ALL ASSERTIONS PASSED を表示する。
"""
from __future__ import annotations

import argparse
import time
from collections import Counter
from fractions import Fraction
from itertools import permutations, product
from math import factorial


# ---------------------------------------------------------------- 戦略の定義

def make_rules(T: tuple[int, ...], n: int) -> dict:
    """順序つき S_T の例外表: (囚人, 見た番号の列) -> 開ける箱。"""
    m = len(T)
    A = set(T)
    X = [x for x in range(1, n + 1) if x not in A]
    rules = {}
    for k, a in enumerate(T):
        def nx(t, k=k):
            return T[(k + t) % m]
        target = nx(-1)                                   # p(a)
        rules[(a, tuple(nx(t) for t in range(1, m - 1)))] = target          # (L)
        for d in range(m - 2):
            for x in X:
                key = (tuple(nx(t) for t in range(1, d + 1)) + (x,)
                       + tuple(nx(t) for t in range(d + 1, m - 1)))
                rules[(a, key)] = target                                    # (X)
    return rules


def table_rule(rules: dict):
    return lambda i, seen: rules.get((i, seen))


def relaxed_rule(T: tuple[int, ...]):
    """順序を問わない版: p(a) 以外の錨をすべて見て、p(a) をまだ見ていなければ箱 p(a)。"""
    m = len(T)
    A = set(T)
    pred = {T[k]: T[(k - 1) % m] for k in range(m)}

    def rule(i, seen):
        if i not in A:
            return None
        p = pred[i]
        if p not in seen and (A - {i, p}) <= set(seen):
            return p
        return None
    return rule


def no_rule(i, seen):
    return None


def fb_lowest(i, seen, opened, n):
    return min(b for b in range(1, n + 1) if b not in opened)


def fb_return(i, seen, opened, n):
    """飛ばした箱（見たが未開封の番号）へ戻る。なければ最小番号。"""
    for c in seen:
        if c not in opened:
            return c
    return fb_lowest(i, seen, opened, n)


def fb_forbidden(i, seen, opened, n):
    raise AssertionError("fallback must not be used here")


def run(i, placement, m, rule, fallback):
    """囚人 i の (成功したか, 開けた箱の列)。例外は高々1回、その後は CF。"""
    n = len(placement)
    opened, seen = [], []
    deviated = False
    for _ in range(m):
        cf = i if not seen else seen[-1]
        box = None
        if not deviated:
            b = rule(i, tuple(seen))
            if b is not None:
                assert b not in opened and b != cf, (i, placement, seen, b)
                box, deviated = b, True
        if box is None:
            box = cf
            if box in opened:
                box = fallback(i, tuple(seen), opened, n)
        assert box not in opened, (i, placement, opened, box)
        opened.append(box)
        c = placement[box - 1]
        seen.append(c)
        if c == i:
            return True, tuple(opened)
    return False, tuple(opened)


# ---------------------------------------------------------------- 巡回の道具

def cycles_of(placement):
    n = len(placement)
    done = [False] * (n + 1)
    out = []
    for s in range(1, n + 1):
        if not done[s]:
            c, x = [], s
            while not done[x]:
                done[x] = True
                c.append(x)
                x = placement[x - 1]
            out.append(tuple(c))
    return out


def in_RT(cycles, T, m):
    A = set(T)
    for c in cycles:
        if len(c) == m + 1 and A <= set(c):
            k = c.index(T[0])
            rot = c[k:] + c[:k]
            return tuple(x for x in rot if x in A) == tuple(T)
    return False


def W_formula(n):
    m = n // 2
    return int(factorial(n) * (1 - sum(Fraction(1, k) for k in range(m + 1, n + 1))))


# ---------------------------------------------------------------- 定理の照合

def audit(T, n, rule, fallback, simulate_all=True):
    """定理 B・C と補題 2・3 を全配置で検査し、4分類の個数を返す。"""
    m = n // 2
    A = set(T)
    pred = {T[k]: T[(k - 1) % m] for k in range(m)}
    cls = Counter()
    for placement in permutations(range(1, n + 1)):
        cyc = cycles_of(placement)
        cl = {x: c for c in cyc for x in c}
        in_W = max(map(len, cyc)) <= m
        in_R = (not in_W) and in_RT(cyc, T, m)
        succ, losses = 0, []
        for i in range(1, n + 1):
            cf_ok = len(cl[i]) <= m
            if simulate_all:
                assert run(i, placement, m, no_rule, fb_forbidden)[0] == cf_ok   # CF の基準
                ok = run(i, placement, m, rule, fallback)[0]
            else:
                ok = run(i, placement, m, rule, fallback)[0] if i in A else cf_ok
            succ += ok
            if cf_ok and not ok:
                losses.append(i)
        for a in losses:                                   # 補題2
            assert a in A and (A - {pred[a]}) <= set(cl[a]) and pred[a] not in cl[a]
        assert len(losses) <= 1                            # 補題3・定理B（全配置）
        st_win = succ >= n - 1
        assert st_win == (in_W or in_R)                    # 定理C
        cls["both" if in_W and st_win else "CF_only" if in_W else
            "ST_only" if st_win else "neither"] += 1
    W = W_formula(n)
    assert cls["both"] == W and cls["CF_only"] == 0
    assert cls["ST_only"] == m * factorial(m)              # 系 |R_T| = m·m!
    assert sum(cls.values()) == factorial(n)
    return cls


# ---------------------------------------------------------------- 294 戦略との対応

SECOND = {(1, 4): 5, (4, 5): 1, (5, 1): 4}
THIRD = {
    (1, 2, 4): 5, (1, 3, 4): 5, (1, 4, 2): 2, (1, 4, 3): 3, (1, 4, 5): 2,
    (1, 4, 6): 6, (1, 5, 4): 2, (1, 6, 4): 5, (4, 2, 5): 1, (4, 3, 5): 1,
    (4, 5, 1): 2, (4, 5, 2): 2, (4, 5, 3): 3, (4, 5, 6): 6, (4, 6, 5): 1,
    (5, 1, 2): 2, (5, 1, 3): 3, (5, 1, 4): 6, (5, 1, 6): 6, (5, 2, 1): 4,
    (5, 3, 1): 4, (5, 6, 1): 4,
}


def run_294(i, placement):
    """verify_294.py の規則をそのまま実行し、開けた箱の列を返す。"""
    s = lambda b: placement[b - 1]
    opened = [i]
    c1 = s(i)
    if c1 == i:
        return True, tuple(opened)
    b2 = SECOND.get((i, c1), c1)
    opened.append(b2)
    c2 = s(b2)
    if c2 == i:
        return True, tuple(opened)
    b3 = THIRD.get((i, c1, c2), c2)
    opened.append(b3)
    return s(b3) == i, tuple(opened)


def check_294():
    T, n, m = (1, 4, 5), 6, 3
    rules = make_rules(T, n)
    assert len(rules) == m + m * m * (m - 2) == 12
    extended = dict(rules)
    extended[(1, (5, 4))] = 2                              # 効果のない例外
    fb_table = {(1, (4, 5)): 2, (4, (5, 1)): 2, (5, (1, 4)): 6}

    def fb294(i, seen, opened, n):
        return fb_table.get((i, seen), fb_lowest(i, seen, opened, n))

    paths = 0
    for placement in permutations(range(1, n + 1)):
        for i in range(1, n + 1):
            assert run_294(i, placement) == run(i, placement, m, table_rule(extended), fb294)
            paths += 1
    assert paths == 4320

    # 代替箱 64 通り（各錨で箱 a, p(a) 以外の4箱）
    pred = {1: 5, 4: 1, 5: 4}
    succ_of = {1: 4, 4: 5, 5: 1}
    choices = {a: [b for b in range(1, 7) if b not in (a, pred[a])] for a in T}
    win_counts = Counter()
    for f1, f4, f5 in product(choices[1], choices[4], choices[5]):
        chosen = {(1, (succ_of[1], pred[1])): f1, (4, (succ_of[4], pred[4])): f4,
                  (5, (succ_of[5], pred[5])): f5}

        def fb(i, seen, opened, n, chosen=chosen):
            assert (i, seen) in chosen, (i, seen)        # 代替箱はこの3場面だけ
            return chosen[(i, seen)]
        cls = audit(T, n, table_rule(rules), fb)
        win_counts[cls["both"] + cls["ST_only"]] += 1
    assert win_counts == Counter({294: 64})
    return paths, win_counts


def check_m2():
    """m=2 では S_T が破綻する。"""
    T, n, m = (1, 2), 4, 2
    rule = table_rule(make_rules(T, n))
    placement = (3, 4, 1, 2)                               # (1 3)(2 4)
    assert max(map(len, cycles_of(placement))) <= m       # CF では勝ち
    for a in T:                                            # 代替箱を使わずに失敗
        assert run(a, placement, m, rule, fb_forbidden)[0] is False
    lost = rescued = 0
    for p in permutations(range(1, n + 1)):
        cyc = cycles_of(p)
        cl = {x: c for c in cyc for x in c}
        succ = sum(run(i, p, m, rule, fb_lowest)[0] for i in range(1, n + 1))
        in_W = max(map(len, cyc)) <= m
        lost += in_W and succ < n - 1
        rescued += (not in_W) and succ >= n - 1
    return lost, rescued


def check_superposition():
    """n=6: 異なる2つの T の例外を併せると、どの組・どちらを優先しても旧勝ちを失う。"""
    n, m = 6, 3
    temps = []
    for a in range(1, 7):
        for b in range(1, 7):
            for c in range(1, 7):
                if len({a, b, c}) == 3 and a == min(a, b, c):
                    temps.append((a, b, c))
    assert len(temps) == 40
    data = []
    for placement in permutations(range(1, n + 1)):
        cyc = cycles_of(placement)
        data.append((placement, max(map(len, cyc)) <= m))
    best = 0
    pairs = 0
    for T1 in temps:
        for T2 in temps:
            if T1 == T2:
                continue
            rules = dict(make_rules(T1, n))
            rules.update(make_rules(T2, n))              # キーが衝突したら T2 を優先
            rule = table_rule(rules)
            wins = lost = 0
            for placement, in_W in data:
                succ = sum(run(i, placement, m, rule, fb_lowest)[0] for i in range(1, n + 1))
                wins += succ >= n - 1
                lost += in_W and succ < n - 1
            assert lost > 0, (T1, T2)
            best = max(best, wins)
            pairs += 1
    assert pairs == 1560
    return pairs, best


# ---------------------------------------------------------------- 実行

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--m5", action="store_true", help="n=10 も全列挙する（数分）")
    args = ap.parse_args()
    t0 = time.time()

    paths, wins = check_294()
    print(f"294 = S_T(3)+効果のない例外+代替箱: 経路一致 {paths}/4320, 代替箱64通りの勝ち数 {dict(wins)}")
    lost, rescued = check_m2()
    print(f"m=2 (n=4): (1 3)(2 4) で錨1・2が失敗。最小番号の代替箱では旧勝ち {lost} を失い {rescued} を救済")
    pairs, best = check_superposition()
    print(f"n=6 で T を2つ重ねる: 順序つきの組 {pairs} 個すべてで旧勝ちを喪失、最大 {best} 勝")

    cases = [
        (6, (1, 4, 5), "順序つき", "最小番号"),
        (6, (1, 4, 5), "順序つき", "戻る"),
        (6, (1, 4, 5), "順序なし", "最小番号"),
        (8, (1, 2, 3, 4), "順序つき", "最小番号"),
        (8, (1, 2, 3, 4), "順序つき", "戻る"),
        (8, (2, 7, 4, 5), "順序つき", "最小番号"),
        (8, (1, 2, 3, 4), "順序なし", "最小番号"),
    ]
    if args.m5:
        cases += [(10, (1, 2, 3, 4, 5), "順序つき", "最小番号"),
                  (10, (1, 2, 3, 4, 5), "順序なし", "最小番号")]
    print("n  T              版      代替箱    両方成功  CFのみ  S_Tのみ  両方失敗")
    for n, T, variant, fbname in cases:
        rule = table_rule(make_rules(T, n)) if variant == "順序つき" else relaxed_rule(T)
        fb = fb_lowest if fbname == "最小番号" else fb_return
        cls = audit(T, n, rule, fb, simulate_all=(n <= 8))
        print(f"{n:<2} {str(T):<14} {variant:<6} {fbname:<6} {cls['both']:>9} {cls['CF_only']:>6} "
              f"{cls['ST_only']:>7} {cls['neither']:>9}")
    print(f"ALL ASSERTIONS PASSED ({time.time() - t0:.0f}s)")


if __name__ == "__main__":
    main()
