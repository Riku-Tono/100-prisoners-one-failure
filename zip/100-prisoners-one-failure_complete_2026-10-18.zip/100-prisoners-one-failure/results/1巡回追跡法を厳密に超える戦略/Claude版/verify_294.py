"""6 prisoners, 6 boxes, 3 boxes each, win if >= 5 find their own number.
Standalone check of a strategy with 294/720 wins (cycle-following: 276/720).
Everything is 1-indexed. sigma[b] = number inside box b.

Rule: prisoner i opens box i, then the box whose label is the number just seen
(cycle-following), EXCEPT in the cases listed below.
  EXC2[(i, c1)]     = 2nd box of prisoner i when box i contained c1
  EXC3[(i, c1, c2)] = 3rd box of prisoner i when the 1st box contained c1 and the 2nd contained c2
"""
import itertools
from collections import Counter
EXC2 = {(1, 4): 5, (4, 5): 1, (5, 1): 4}
EXC3 = {(1, 2, 4): 5, (1, 3, 4): 5, (1, 4, 2): 2, (1, 4, 3): 3, (1, 4, 5): 2, (1, 4, 6): 6, (1, 5, 4): 2, (1, 6, 4): 5, (4, 2, 5): 1, (4, 3, 5): 1, (4, 5, 1): 2, (4, 5, 2): 2, (4, 5, 3): 3, (4, 5, 6): 6, (4, 6, 5): 1, (5, 1, 2): 2, (5, 1, 3): 3, (5, 1, 4): 6, (5, 1, 6): 6, (5, 2, 1): 4, (5, 3, 1): 4, (5, 6, 1): 4}

def succeeds(i, sigma):
    c1 = sigma[i]
    if c1 == i: return True
    b2 = EXC2.get((i, c1), c1)
    c2 = sigma[b2]
    if c2 == i: return True
    b3 = EXC3.get((i, c1, c2), c2)
    assert b3 not in (i, b2)          # never re-opens a box
    return sigma[b3] == i

def cycle_following_wins(sigma):
    return all(sigma[i] == i or sigma[sigma[i]] == i or sigma[sigma[sigma[i]]] == i for i in range(1, 7))

dist = Counter(); wins = base = lost = 0
for p in itertools.permutations(range(1, 7)):
    sigma = dict(zip(range(1, 7), p))
    t = sum(succeeds(i, sigma) for i in range(1, 7))
    dist[t] += 1
    w = t >= 5; cf = cycle_following_wins(sigma)
    wins += w; base += cf; lost += (cf and not w)
print("number of successes -> number of arrangements:", dict(sorted(dist.items())))
print("cycle-following wins:", base, "/ 720")
print("this strategy wins  :", wins, "/ 720")
print("arrangements won by cycle-following but lost here:", lost)
