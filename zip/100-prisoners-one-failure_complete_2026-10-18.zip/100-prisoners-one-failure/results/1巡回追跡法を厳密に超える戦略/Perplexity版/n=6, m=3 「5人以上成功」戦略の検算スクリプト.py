"""n=6, m=3, 5人以上成功の確率を 6! = 720 通りの全列挙で検算する（Python 3 標準ライブラリのみ）。
表記: 箱・番号・囚人はすべて 1..6。p[b] = 箱 b に入っている番号。
基本はサイクル追跡（自分の番号の箱から開け、出た番号の箱を次に開ける）。
ただし EXC に載っている履歴に到達したときだけ、指定の箱を開ける。
履歴は ((開けた箱, 中の番号), ...) の並び。"""
import itertools
from fractions import Fraction

N, M, K = 6, 3, 5
EXC = {
 1: {((1,6),): 2, ((1,4),(4,6)): 3, ((1,5),(5,6)): 3,
     ((1,6),(2,2)): 3, ((1,6),(2,4)): 3, ((1,6),(2,5)): 3},
 2: {((2,1),(1,6)): 3, ((2,3),(3,1)): 6},
 3: {((3,1),(1,4)): 6, ((3,1),(1,5)): 6, ((3,1),(1,6)): 2, ((3,2),(2,1)): 4},
 4: {((4,6),(6,3)): 1},
 5: {((5,6),(6,3)): 1},
 6: {((6,3),(3,2)): 1, ((6,4),(4,3)): 1},
}

def play(i, p, exc):
    h, opened = (), set()
    for _ in range(M):
        b = exc.get(i, {}).get(h, i if not h else h[-1][1])
        assert b not in opened, (i, p, h, b)   # 同じ箱を2回開けていないことを確認
        opened.add(b)
        if p[b] == i:
            return True
        h += ((b, p[b]),)
    return False

def evaluate(exc):
    dist = [0] * (N + 1)
    for perm in itertools.permutations(range(1, N + 1)):
        p = dict(zip(range(1, N + 1), perm))
        dist[sum(play(i, p, exc) for i in range(1, N + 1))] += 1
    return dist

for name, exc in [("サイクル追跡のみ", {}), ("改良戦略", EXC)]:
    d = evaluate(exc)
    win = d[5] + d[6]
    print(f"{name}: 成功人数0..6の分布 = {d}")
    print(f"  P(5人以上) = {win}/720 = {Fraction(win,720)} = {win/720:.6f}")
    print(f"  P(6人全員) = {Fraction(d[6],720)},  P(ちょうど5人) = {Fraction(d[5],720)}")
