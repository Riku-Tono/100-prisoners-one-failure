"""n=6,m=3,5人以上成功: 長さ4巡回を救う例外戦略の検算（標準ライブラリのみ）。
基本はサイクル追跡。例外は (囚人, 1箱目→中身, 2箱目→中身) ⇒ 3箱目 の形だけ。
4巡回 (q1 q2 q3 q4) の囚人 q1 が q1→q2, q2→q3 と見たら、q3 ではなく q4 を開ける。"""
import itertools
from fractions import Fraction
RESCUES = [  # (4巡回, 救う3人)
    ((1,4,2,5),(1,4,2)), ((1,4,3,5),(1,4,3)), ((1,5,2,4),(1,5,2)),
    ((1,5,3,4),(1,5,3)), ((1,5,4,6),(1,4,6)), ((1,6,4,5),(1,6,5)),
]
def build(rescues):
    E = {}
    for c, who in rescues:
        for j in range(4):
            i,a,b,d = c[j],c[(j+1)%4],c[(j+2)%4],c[(j+3)%4]
            if i in who:
                key=(i,((i,a),(a,b))); assert key not in E; E[key]=d
    return E
def play(i,p,E):
    h,op=(),set()
    for _ in range(3):
        b=E.get((i,h), i if not h else h[-1][1]); assert b not in op; op.add(b)
        if p[b]==i: return 1
        h+=((b,p[b]),)
    return 0
def wins(E):
    W=set();d=[0]*7
    for pm in itertools.permutations(range(1,7)):
        p=dict(zip(range(1,7),pm)); s=sum(play(i,p,E) for i in range(1,7)); d[s]+=1
        if s>=5: W.add(pm)
    return W,d
W0,_=wins({})
for k in range(len(RESCUES)+1):
    E=build(RESCUES[:k]); W,d=wins(E)
    print(f"救済{k}個 例外{len(E)}: 勝ち{len(W)} = {Fraction(len(W),720)}  276勝を保持:{W0<=W}  新規:{len(W-W0)}  分布{d}")
