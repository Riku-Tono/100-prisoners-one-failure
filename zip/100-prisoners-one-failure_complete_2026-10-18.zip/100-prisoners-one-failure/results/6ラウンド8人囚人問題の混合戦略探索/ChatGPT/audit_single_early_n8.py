"""Eight-prisoner mixed-strategy baseline audit (Python standard library only).

Input: 100prisoners_README_round4.zip, containing the nested Perplexity
Round 4 package with out/ilp_m4_rescue_capNone.json.

Usage:
  python audit_single_early_n8.py --archive 100prisoners_README_round4.zip

Scope: Exactly one early CF-prefix rule (second or third box), optionally
repairing OLD-W conflicts by deleting the *forced* conflicting late rules.
The 51-cycle late-only baseline is held fixed apart from those deletions.
This does NOT establish optimality for more general mixed strategies.
"""
from pathlib import Path
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--archive', type=Path,
                    default=Path(__file__).with_name('100prisoners_README_round4.zip'),
                    help='Path to previously supplied round-4 ZIP archive')
args=parser.parse_args()
if not args.archive.is_file():
    parser.error(f'Archive not found: {args.archive}. Put it next to this script or pass --archive.')
import io,zipfile,json,itertools,collections,time
start=time.time()
with zipfile.ZipFile(args.archive) as z:
    outer=next(n for n in z.namelist() if n.endswith('.zip') and '第4' in n)
    with zipfile.ZipFile(io.BytesIO(z.read(outer))) as w:
        j=json.loads(w.read('round4_cycle_packing/out/ilp_m4_rescue_capNone.json'))
base={(i,tuple(h)):b for i,h,b in j['rules']}

def simulate_one(i,p,rule=None):
    seen=[]; opened=[]; jumped=False
    for k in range(4):
        cf=i if not seen else seen[-1]
        if rule and not jumped and k==len(rule[0]) and tuple(seen)==rule[0]:
            b=rule[1];jumped=True
        elif k==3 and not jumped:
            b=base.get((i,tuple(seen)),cf)
        else:
            b=cf
        if b in opened:
            b=next(k for k in range(1,9) if k not in opened)
        opened.append(b)
        obs=p[b-1];seen.append(obs)
        if obs==i:
            return True
    return False

def maxcyc(p):
    known=set();lengths=[]
    for i in range(1,9):
        if i not in known:
            cyc=[];u=i
            while u not in known:
                known.add(u);cyc.append(u);u=p[u-1]
            lengths.append(len(cyc))
    return max(lengths)

perms=list(itertools.permutations(range(1,9)))
base_result=[]; byhist=collections.defaultdict(list)
for idx,p in enumerate(perms):
    ok=tuple(simulate_one(i,p) for i in range(1,9))
    cyc=maxcyc(p)
    base_result.append((sum(ok),ok,cyc))
    for i in range(1,9):
        si=[]; node=i
        for t in (1,2):
            q=p[node-1]
            si.append(q)
            if q==i: break
            byhist[(i,tuple(si))].append(idx)
            node=q
assert len(base)==204 and len(perms)==40320
assert sum(k>=7 for k,_,_ in base_result)==15042
assert sum(c<=4 for _,_,c in base_result)==14736
assert not any(c<=4 and k<7 for k,_,c in base_result)
print('baseline:',sum(k>=7 for k,_,_ in base_result),'CF old:',sum(c<=4 for _,_,c in base_result),'rules:',len(base),'perms:',len(perms))

best=[]; valid=0; better=0; score_counts=collections.Counter();unsafe_count=0
for (i,h), ids in byhist.items():
    t=len(h)
    opened={i,*h[:-1]}
    cf=h[-1]
    for b in range(1,9):
        if b in opened or b==cf:continue
        delta=0; W_lost=0; bylen=collections.Counter(); flip=0
        for idx in ids:
            k,ok,cyc=base_result[idx]
            new=simulate_one(i,perms[idx],(h,b))
            old=ok[i-1]
            if new==old:continue
            flip+=1
            nk=k+int(new)-int(old)
            if (k>=7)!=(nk>=7):
                inc=1 if nk>=7 else -1
                delta+=inc;bylen[cyc]+=inc
                if cyc<=4 and inc<0:W_lost+=1
        if W_lost:unsafe_count+=1
        else:
            valid+=1
            score_counts[delta]+=1
            if delta>0:
                better+=1
            best.append((delta,i,h,b,flip,dict(bylen)))
best.sort(reverse=True)
assert (valid+unsafe_count,valid,unsafe_count)==(2016,0,2016)
print('candidates:',valid+unsafe_count,'safe:',valid,'unsafe:',unsafe_count,'single-rule-better:',better,'score_distribution:',dict(sorted(score_counts.items())))
print('best-safe-rules:')
for v in best[:15]:print(v)
print('elapsed-s:',round(time.time()-start,2))
# Exact minimal-repair experiment. For every early jump, remove each old final-box rule
# that creates the second loser in any old-CF-winning placement. This is a forced
# deletion set for a one-jump-plus-rule-deletions search.
N=len(perms)
full=(1<<N)-1
succ_mask=[0]*8
W_mask=0
fail_rulekey={}
rule_flip=collections.defaultdict(int)
for idx,p in enumerate(perms):
    k,ok,cyc=base_result[idx]
    bit=1<<idx
    if cyc<=4:
        W_mask|=bit
        if k==7:
            j=1+next(z for z,v in enumerate(ok) if not v)
            temp=[p[j-1]]
            temp.append(p[temp[-1]-1]);temp.append(p[temp[-1]-1])
            rkey=(j,tuple(temp))
            if rkey not in base: raise AssertionError(('bad-W-failer',idx,j,rkey))
            fail_rulekey[idx]=rkey
    for i in range(1,9):
        if ok[i-1]:succ_mask[i-1]|=bit
        cur=i; h=[]; early_end=False
        for t in range(3):
            cur=p[cur-1];h.append(cur)
            if cur==i:
                early_end=True;break
        if not early_end:
            rkey=(i,tuple(h))
            if rkey in base:
                cf_b=cur
                # The original CF would open box cur fourth.
                cfok=p[cf_b-1]==i
                if bool(ok[i-1]) !=cfok:
                    rule_flip[rkey]|=bit

def winners_mask(succ):
    z=full; o=0
    for s in succ:
        f=full^s
        o=(o&s)|(z&f)
        z &=s
    return o|z
assert winners_mask(succ_mask).bit_count()==15042
best_repaired=[]; n_better=0; n_same=0
for (i,h),ids in byhist.items():
    opened={i,*h[:-1]};cf=h[-1]
    for b in range(1,9):
        if b in opened or b==cf:continue
        flip_i=0; repair=set(); nWconflicts=0
        for idx in ids:
            k,ok,cyc=base_result[idx]
            new=simulate_one(i,perms[idx],(h,b))
            old=ok[i-1]
            if new==old: continue
            flip_i|=1<<idx
            if cyc<=4 and old and not new and k==7:
                repair.add(fail_rulekey[idx]);nWconflicts+=1
        s=succ_mask.copy()
        s[i-1]^=flip_i
        for key in repair:
            assert key[0]!=i
            s[key[0]-1]^=rule_flip.get(key,0)
        wins=winners_mask(s)
        nWlost=(W_mask&~wins).bit_count()
        if nWlost:
            raise AssertionError(('forced-repair-failed',i,h,b,nWlost))
        count=wins.bit_count()
        if count>15042: n_better+=1
        if count==15042: n_same+=1
        best_repaired.append((count,i,h,b,len(repair),nWconflicts,sorted(repair)))
best_repaired.sort(reverse=True)
assert len(best_repaired)==2016 and best_repaired[0][0]==15030 and n_better==0 and n_same==0
print('minimal-repair single-rule scan:', 'tested=',len(best_repaired),'above-baseline=',n_better,'ties=',n_same,'best=',best_repaired[:5])
print('elapsed-total-s:',round(time.time()-start,2))
