# Post-Round 8 reproduction and evidence boundaries

This is the **complete 2026-10-18 distribution**, combining the Round 7 base,
Round 8 update, historical logs 1–14, and the recovered post-Round 8 sources.
Extract the ZIP once. No earlier ZIP, shared-chat login, or file on the original
author's computer is needed for the supported verification commands.

## 日本語の実行案内

Python 3.10以上を使い、展開したフォルダーを開いて実行する。

    python -X utf8 repro/check_integrity.py
    python -X utf8 repro/run_post_round8_verification.py

通常検査は標準ライブラリで動く。原資料を一時コピーへ移して検査するため、
保存された証拠・ハッシュを変更しない。検査結果は verification/post-round8/ に出る。

913代表すべての補完再検算と、支持向き全列挙まで実行する場合：

    python -X utf8 repro/run_post_round8_verification.py --extended --orientation

--orientation の支持screenはWindowsのPowerShellと同梱C#を使う。
--extended は全seedを再生成し、Linux用実行ファイルの代わりにPython補完器で
913代表・2,938核心を全検査する。終了まで数分かかる場合がある。

通常検査の成功は、全戦略の最適性や、非star排除の全ソルバー計算を再証明した
という意味ではない。正確な有理数証明の検査、有限全列挙、保存ソルバー結果、
未決のUNKNOWNを区別する。重いソルバー部分は下記の別runnerで扱う。

## Supported verification commands

The current source/hash manifest covers immutable distribution files. Generated
verification outputs can change when rerun and are intentionally excluded from
that immutable hash list. The package manifest separately records the shipped
verification snapshots.

    python -X utf8 repro/check_integrity.py
    python -X utf8 repro/run_post_round8_verification.py
    python -X utf8 repro/run_post_round8_verification.py --extended --orientation

The default run checks five construction tables independently on all 40,320
placements each; the general-law implementations; standard-three-flip structure,
local lemmas and all 248 triangle completion cases; all 48 four-flip triangles
and 21,097 compound cores; canonical six-window core generation; 1,372 exact
rational dual certificates plus five capacity-feasible integer witnesses; and the
seven-flip 9/15 local bound. Hash checking establishes source identity, not the
truth of an archived claim.

The extended run adds fresh witness/seed regeneration and every one of the 913
pair representatives, comprising 2,938 completion cores. The orientation option
regenerates the 6,250,496-assignment screen and the 1,378 independent S8 orbit
member sets. No CP-SAT solver is used by this runner. The rational verifier
explicitly identifies the separate CBC-only case rather than accepting its
stored status as a rational certificate.

Historical suites are also included and were rerun for this release:

    python -X utf8 repro/run_verification.py
    python -X utf8 repro/run_round8_verification.py

They have 13 and eight tasks respectively. These suites concern their recorded
families and do not search for better strategies.

## Optional completed solver computations

List the supported advanced stages and their dependencies:

    python -X utf8 repro/post-round8/run_nonstar_reproduction.py --list

The advanced runner uses installed OR-Tools for selected solver stages.
Its own help identifies the exact stages it repeats. Historical results were
produced by the versions recorded in their logs; rerunning a finite time-limited
model can return UNKNOWN on another machine. Only completed INFEASIBLE results
support that stage's exclusion. A timeout does not inherit the old conclusion.

The raw archive is a research record. Some older exploratory scripts retain
absolute path hints and were not standalone entry points. Use the supported
runners, which copy the inputs, connect local dependencies, and isolate outputs.
The supplemental external/ directory preserves recovered small earlier exchange
files and controls, with its own provenance list. It is not an installed package.

See the [source map](post-round8-sources.md) for omissions and audit status,
and the [general proof supplement](post-round8-general-laws.en.md) for statements
whose basis is an all-m argument rather than finite enumeration.

---


# Finite evidence after Round 8

The best verified attainable score remains **15,051 / 40,320**. The new 210-rule certificate has `(R5,R6,R7,R8)=(52,1,1,0)`. The earlier 208-rule baseline and a 210-rule neutral variant both have `(52,0,3,0)`. Direct opening simulation verifies all three on every placement, with zero lost cycle-following wins. Their preserved inputs are:

* `repro/post-round8/work/inputs/baseline15051.rules.json`
* `repro/post-round8/work/inputs/new15051.rules.json`
* `repro/post-round8/work/inputs/neutral15051.rules.json`

The received `chatgpt_15050_received.rules.json` separately attains 15,050 with `(52,0,2,0)` in the standard-three-flip orientation. It does not improve the overall record.

## Run the packaged checks

From the repository root:

```powershell
python repro/run_post_round8_verification.py
python repro/run_post_round8_verification.py --extended
python repro/run_post_round8_verification.py --orientation
python repro/post-round8/run_nonstar_reproduction.py --list
```

The default run performs the quick certificate and finite checks. `--extended` adds the complete standard-three-flip witness/core rerun. `--orientation` adds the Windows all-orientation screen and its independent S8 partition. The final command lists optional solver replays and their dependencies. These stages are different: checking a saved certificate, regenerating a finite set, and rerunning an optimizer have different reproducibility requirements.

The packaged runners use scratch copies. Archived research scripts often write beside their own source files. For manual commands below, first copy `repro/post-round8/work/` to a writable scratch directory and work there; copy `repro/post-round8/audit_c3_python.py` beside that scratch directory's `claude_desktop_continuation3/` folder. Preserve the archived inputs and original result files.

## Standard-three-flip finite completion

The bounded claim is: first three openings follow CF, only the final box changes, all CF wins are preserved, the standard-three-flip support orientation is fixed, `R5=52`, and at most210 rules. In its `R6=0` branch, `R7>=4` is excluded. This does not assert that15,051 is attainable in this particular branch.

From the scratch `work` directory, use:

```powershell
Push-Location claude_desktop_continuation3
python c3_basic_checks.py
python c3_lemmas.py
python c3_witness.py
python ../audit_c3_python.py --source . --control ../chatgpt_15050_received.rules.json
python ../audit_c3_python.py --source . --triangles
python ../audit_c3_python.py --source . --lo 0 --hi 913
Pop-Location
```

The Python completion engine replaces the archived Linux C executable and needs no optimizer or compiler. Expected results are:

| Check | Expected result | Observed time in the preparation audit |
|---|---|---:|
| Structure |210 words;1,896 blocks;12 special covers;stabilizer36 |<1s |
| Extra-rule local lemmas |2,808 and29,844 cases;zero feasible counterexamples |<1s |
| Witness regeneration |144 cycles;648 witnesses;32,076 edges;913 pair orbits;248 triangle orbits |about2min |
| Completion positive control |13 missing blocks recovered from33 fixed blocks |<1s |
| Triangle completion |248 `EXHAUSTED`;71,402 nodes |about2s |
| Pair/core completion |913 representatives;2,938 cores;all `EXHAUSTED`;4,190 nodes |about4min |

The regenerated seed file was byte-identical to the archived file. The new Python engine's per-seed option/core counts, statuses and node totals agree with the archived independent C implementation. The shared-correct-rule bound of one applies within a single seven-label set; it must not be transferred across different seven-label sets.

## All non-full-star orientations: finite stages

The broader conclusion remains limited to **52 disjoint four-rule five-cycle blocks plus at most two extras, complementary support orientations, CF preservation, final-box-only changes, and `R6=0`**. Within that model every non-full-star orientation has `R7<=3`. A full star is the family of all35 four-subsets avoiding one chosen label, including its relabelings.

The following scripts are the exact finite stages used by the packaged orientation/advanced runners. Run them from a scratch copy of the preserved `work` directory:

```powershell
python canonical_six_witness_independent_review_20261018.py
python independent_allcore_support_screen_20261018.py
python independent_orientation_S8_partition_20261018.py
python canonical_support_fraction_certificate_verify.py
python fourflip_triangle_pure_completion.py
python fourflip_independent_regenerate_cover.py
python sevenflip_independent_rulepair_bound.py
python canonical_orientation_logical_chain_review.py
```

| Stage | Expected result | Observed time |
|---|---|---:|
| Normalized suppliers |15,625 assignments;70 cores with extras histogram4/21/45;exact exported-set match |about1s |
| Actual-block support screen |6,250,496 assignments;53,392 accepted pairs;27,423 distinct orientations |about9s |
| Independent S8 partition |22,610 minimum-degree>=8 masks;1,378 exact orbit member sets |about5s |
| Exact capacity certificates |1,372 rational-dual exclusions and5 integer positive witnesses verified |about1s |
| Four-flip triangles |48 exhausted;158,683 nodes;zero unresolved |about9s including regeneration |
| Four-flip compound cores |21,097 regenerated and exhausted;41,029 nodes;positive control passes |about10s |
| Seven-flip9/15 |finite rule-pair/forced-anchor checks yield `R7<=3` |<1s |
| Static implication chain |all4,812 low-degree nonstar masks map to earlier families |about2s |

Times are examples, not limits or acceptance criteria. The support screen uses Python's standard library plus the included C# loop compiled by Windows PowerShell. The partition, Fraction verifier and pure-cover checks need only Python's standard library. The new `audit_unrestricted_two_extra.py` independently checks the wider all-[7] marginal lemma:2,520 blocks,12 useful second rules,432 omitted-window pairs, zero feasible joint local packings and positive controls.

Keep the `canonical_six_witness_cores/`70 files, the three `canonical_orientation_capacity_*.json` inputs, the S8 classification, exact Fraction certificate data, the four-flip full enumeration and pair representatives, the two seven-flip orientation records, and their local generator modules together. These are data dependencies, not interchangeable summaries.

## Saved solver evidence and open scope

The nonstar chain still uses saved completed optimizer results:8 low-degree-six candidates,12 low-degree-seven candidates, the integer-capacity case1267, and five high-degree survivor orientations. The five survivors have primary and independent presence/iff models ending `INFEASIBLE`. Earlier direct-supplier retries include `UNKNOWN`; those attempts are preserved and are not exclusion evidence. Case1267 has integer-engine infeasibility evidence, not one of the1,372 exact rational dual certificates.

`claude_desktop_continuation3/audit_status.json` records `AUDIT_PASS` for the standard-three-flip913 audit. The separate nonstar Claude audit is `PARTIAL`; do not describe it as completed Claude certification of every orientation. These are reproducible finite computations and scoped solver results, not a formal proof-assistant certificate.

The full-star family remains open beyond one fixed18-block branch. `R5<=51`, other `R6>0` branches, earlier-opening changes, arbitrary strategies and global optimality remain unresolved. The eight-person exclusions do not establish the optimum of the100-person/99-success problem.

## Advanced stages verified for this release

All eight named computational stage types were tested successfully on 2026-10-18. The [combined record](../verification/post-round8-advanced/summary.json) links the per-stage results and transcripts. This includes fresh CBC case 1267, five independently formulated survivor exclusions, and all eight six-flip plus twelve seven-flip solver cases. The fixed-18 full-star branch remains an archived bounded result; its 3,735 cases were not rerun for this release. Its input enumeration, terminal ledgers, controls and code are preserved. Written structural reductions remain mathematical proof dependencies.

To repeat every named advanced stage in one invocation, install the optional version listed in repro/post-round8/requirements.txt, then run:

    python -X utf8 repro/post-round8/run_nonstar_reproduction.py --stage all --with-solvers
