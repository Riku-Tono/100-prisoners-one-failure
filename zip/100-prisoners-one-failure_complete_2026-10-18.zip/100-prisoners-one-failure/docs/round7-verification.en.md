# Round 7: 52 Directed Cycles — Proof, Certificate, and Verification

[Main README](../README.md) · [Reproduction guide](reproduction.md) · [Japanese independent audit](../repro/round7_52_independent_audit.md)

English publication supplement updated **2026-10-12**, based on the Round 7 research and audit dated **2026-10-09**. This document presents the central proof and certificate semantics needed to assess and reproduce the result. It is a scoped synthesis rather than a translation of every source lemma, search observation, or conversation.

## 1. Claim and scope

There are eight prisoners, eight boxes, at most four box openings per prisoner, and the group wins if at least seven prisoners actually see their own number. A placement is a permutation $\sigma$, where $\sigma(b)$ is the number inside box $b$.

The result is:

> Among strategies that follow CF for their first three openings, change only the fourth box, and preserve every CF winning placement, the maximum number of rescued directed 5-cycles is **52**. Explicit 208-rule certificates achieve this number and win exactly **15,048 of 40,320 placements**, losing no CF wins.

The maximum **total** number of winning placements within all final-box strategies is unknown, because other strategies may rescue length-6 or length-7 cycles. Optimality over unrestricted adaptive strategies is also unknown. The proof of the 52-cycle bound uses counting and a finite explicit certificate, not a solver's `OPTIMAL` status.

## 2. Final-box rules and directed cycle words

Prisoner $i$ starts at box $i$ and follows the observed number for the first three openings, stopping immediately upon finding $i$. If still unsuccessful, an exceptional rule may select a different fourth box based on the ordered observed history $h=(h_1,h_2,h_3)$.

A rule has the form

$$
r=(i;h_1,h_2,h_3\to b).
$$

There is at most one rule for each key $(i,h)$. Its target $b$ must be unopened and must differ from CF's ordinary next box $h_3$. On a reachable unsuccessful CF history, the four labels $i,h_1,h_2,h_3$ are distinct; the already opened boxes are $i,h_1,h_2$, so the target requirement is equivalent to $b\notin\{i,h_1,h_2,h_3\}$.

Associate to the rule its **loss word**, the directed 4-cycle

$$
D(r)=(i\ h_1\ h_2\ h_3).
$$

Directed cycles are identified up to cyclic rotation, but not reversal. The **support** of a word is its set of labels. On any four-label support there are $3!=6$ different directed 4-cycle words. All eight labels therefore give $\binom84\cdot6=420$ words.

Let $W$ be CF's winning set: placements whose cycle lengths are all at most four. Its size is $|W|=14736$.

## 3. Exact condition for preserving CF wins

**Lemma.** On a placement in $W$, a prisoner fails under a final-box strategy exactly when they lie on a directed 4-cycle that is the loss word of one of their rules.

**Proof.** If the prisoner's cycle length is at most three, they find their number before a final-box rule can be used. If it is four, the observed history is $(\sigma(i),\sigma^2(i),\sigma^3(i))$. CF next opens box $\sigma^3(i)$, which contains $i$. A changed target differs from that box, and the permutation has only one copy of $i$, so the changed target fails. With no rule, CF succeeds. These are all possibilities in $W$. $\square$

**Proposition.** A final-box rule set preserves all group wins in $W$ if and only if both conditions hold:

1. Distinct rules have distinct directed loss words.
2. No two loss words have complementary four-label supports in $\{1,\ldots,8\}$.

**Proof.** A placement in $W$ has at most two 4-cycles. If there are two, their supports are complementary. Under the two conditions, the lemma gives at most one failing prisoner, so the group still wins.

Conversely, if two distinct rules share a loss word, their prisoners must differ: a common prisoner and rotated cycle would give the same history key, which has only one rule. Put that directed 4-cycle in a placement and make the remaining labels fixed points. This is a CF win with at least two failures under the new rules. If instead two loss supports are complementary, the placement formed by their two directed 4-cycles gives two failures. Either violation loses an old win. $\square$

This necessary-and-sufficient condition permits losing one individual's success on an old placement, while keeping the group win. It does not require every individual CF success to survive.

## 4. How a rule rescues a 5-cycle

Let $C$ be a directed 5-cycle in a placement. Its other three labels are in cycles of length at most three and therefore succeed before any final-box exception. For a prisoner $a\in C$, the first three observations are $\sigma(a),\sigma^2(a),\sigma^3(a)$. They can find $a$ with their fourth box exactly when their rule targets its unique location

$$
b=\operatorname{pred}_C(a)=\sigma^4(a).
$$

Consequently, **a directed 5-cycle is rescued if and only if at least four of its five prisoners have the correct rules**. This condition is independent of the arrangement of the other three labels, so rescuing a cycle wins all $3!=6$ placements containing it.

Moreover, the rule $(a;h_1,h_2,h_3\to b)$ is correct for exactly one directed 5-cycle,

$$
C(r)=(b\ a\ h_1\ h_2\ h_3).
$$

Its loss word is obtained by deleting $b$ from that cycle. In a four-rule rescue, denote the prisoner without a correct rule by the **omitted prisoner** $o$, and write $w=\operatorname{pred}_C(o)$ for the **skipped point**. The four used loss words are

$$
B^*(C,w)=\{\delta_v(C):v\in C\setminus\{w\}\},
$$

where $\delta_v$ removes label $v$ and retains the directed order. The skipped point and omitted prisoner are distinct notions: $o=\operatorname{succ}_C(w)$.

## 5. Counting proof of the upper bound 52

There are $\binom84/2=35$ pairs of complementary four-label supports. By the preservation proposition, rule loss words can occupy only one side of each pair. Each occupied side supplies at most six words. Since loss words are distinct, the total number of rules is at most

$$
35\cdot6=210.
$$

Every rescued directed 5-cycle needs at least four correct rules. A rule is correct for only one such cycle, so these rule contributions cannot be shared between rescued 5-cycles. Therefore

$$
4N_5\le |R|\le210,
\qquad
N_5\le\left\lfloor\frac{210}{4}\right\rfloor=52.
$$

This holds even if the final-box strategy has other rules intended to rescue longer cycles. It bounds the **number of rescued 5-cycles**, not the total number of winning placements.

The following finite certificates have exactly 208 rules, each used in one four-rule rescue. Combined with the bound, their checked existence proves that **52 is attained and optimal for this objective**.

## 6. The symmetric certificate, in 13 representatives

The [primary symmetric JSON](../repro/best52_costar_Z4_n8.json) uses no rules for prisoner 8. Its selected support family is

$$
F=\{S\subseteq\{1,\ldots,7\}:|S|=4\}.
$$

These are 35 supports, exactly one from each complementary pair on eight labels, supplying $35\cdot6=210$ words. Every loss word lies on this family.

Let

$$
g=(1\ 2\ 3\ 4)(5\ 6),
$$

fixing labels 7 and 8. Apply $g^0,g^1,g^2,g^3$ to each representative below, including its skipped point. This gives **13 disjoint orbits of size four**, hence 52 cycle/skip blocks. The representatives and skipped points below are copied from the JSON certificate; the omitted prisoner is derived as the skipped point's successor.

| # | Directed 5-cycle representative $C$ | Skipped point $w$ | Omitted prisoner $o$ |
| --- | --- | ---: | ---: |
| 1 | $(1\ 2\ 3\ 6\ 5)$ | 6 | 5 |
| 2 | $(1\ 2\ 3\ 7\ 5)$ | 5 | 1 |
| 3 | $(1\ 2\ 4\ 6\ 5)$ | 4 | 6 |
| 4 | $(1\ 2\ 6\ 3\ 7)$ | 6 | 3 |
| 5 | $(1\ 2\ 7\ 4\ 3)$ | 2 | 7 |
| 6 | $(1\ 3\ 2\ 5\ 7)$ | 1 | 3 |
| 7 | $(1\ 3\ 7\ 4\ 5)$ | 4 | 5 |
| 8 | $(1\ 3\ 7\ 6\ 2)$ | 1 | 3 |
| 9 | $(1\ 4\ 3\ 2\ 6)$ | 6 | 1 |
| 10 | $(1\ 4\ 7\ 5\ 6)$ | 6 | 1 |
| 11 | $(1\ 5\ 3\ 6\ 7)$ | 1 | 5 |
| 12 | $(1\ 5\ 4\ 6\ 7)$ | 4 | 6 |
| 13 | $(1\ 6\ 4\ 5\ 7)$ | 5 | 7 |

For each block $(C,w)$, add the rule

$$
(a;\operatorname{succ}_C(a),\operatorname{succ}_C^2(a),
\operatorname{succ}_C^3(a)\to\operatorname{pred}_C(a))
$$

for each $a\ne o=\operatorname{succ}_C(w)$. The result is $52\cdot4=208$ rules.

The independent certificate audit verifies that all 208 loss words are distinct, none has a complementary occupied support, and the 13 representative orbits reconstruct the exact JSON block list. The only unused words are

$$
(1\ 2\ 3\ 4),\qquad(1\ 4\ 3\ 2).
$$

The support $\{1,2,3,4\}$ uses four of its six words; each of the other 34 supports uses all six.

**Why symmetry leaves precisely these words.** No directed 5-cycle on $\{1,\ldots,7\}$ is fixed by $g^2=(1\ 3)(2\ 4)$. An automorphism of a directed 5-cycle is a rotation; its order divides five, so an automorphism whose order divides two must fix each point. However, $g^2$ fixes only the three labels 5, 6, and 7 in this seven-point universe. Thus every cycle orbit under $g$ has size four. If a used loss word were fixed by $g$, its rule's orbit would use that same word more than once, violating uniqueness. The only directed 4-cycle words fixed by $g$ are the two displayed words on $\{1,2,3,4\}$. They must be unused, and the count $210-208=2$ leaves no others.

## 7. Matching formulation and the fixed-anchor distinction

Fix a family $F$ choosing one support from each complementary pair. Construct a **4-uniform hypergraph** whose 210 vertices are directed 4-cycle words on $F$. A hyperedge is a block $(C,w)$ whose four deletion words $B^*(C,w)$ all belong to $F$.

A matching consists of disjoint hyperedges, so its blocks have distinct loss words. The support condition already excludes complementary supports. The preservation and rescue lemmas therefore convert such a matching directly into a safe strategy. Conversely, selecting four correct rules for each rescued 5-cycle of a safe strategy produces such a matching for its selected support family. The optimum cycle count is thus the maximum matching size, also optimized over $F$.

The 52-block construction uses 208 of 210 vertices. A perfect matching is impossible because four does not divide 210. This is a partial-deletion packing of directed circular words with distinct symbols; treating it as an ordinary linear deletion code requires extra structure.

For example, the **fixed-anchor** family chooses $F=\{S:p\in S\}$ for one anchor $p$. A usable 5-cycle must include $p$, and its only deletion not containing $p$ must be the skipped deletion. Hence $w=p$ and the omitted prisoner is the successor of $p$. Reading each cycle from $p$ gives a length-4 linear word on the other seven labels. Its four loss words correspond exactly to its four single-symbol deletions.

This anchored family has a stronger bound of **49**, proved as follows. Fix an ordered pair of its seven labels. Exactly 15 length-3 words contain this pair in order: choose the third label in five ways and its position relative to the pair in three ways. Every selected length-4 word containing the pair produces two such length-3 deletion words. Since deletion words cannot repeat, at most $\lfloor15/2\rfloor=7$ selected words contain a given ordered pair. There are 42 ordered pairs and each length-4 word contains six, so

$$
6N\le42\cdot7,
\qquad N\le49.
$$

The Round 4 49-word certificate attains this bound. The unrestricted choice of omitted prisoner per cycle is what distinguishes the 52-cycle construction from that anchored family.

## 8. Other checked certificates and exact win counts

Three constructions were freshly rechecked with both direct simulation implementations:

| Certificate | Rules | Rescued 5-cycles | Wins / 40,320 | Lost CF wins | Unused-word pattern |
| --- | ---: | ---: | ---: | ---: | --- |
| [Seven-point, symmetric](../repro/best52_costar_Z4_n8.json) | 208 | 52 | 15,048 | 0 | Two words on the same support; 13 orbits |
| [Seven-point, split unused words](../repro/best52_costar_splitY_n8.json) | 208 | 52 | 15,048 | 0 | $(1\ 4\ 2\ 3)$ and $(2\ 6\ 3\ 7)$, on distinct supports |
| [Weighted threshold family](../repro/best52_threshold_n8.json) | 208 | 52 | 15,048 | 0 | A different support family |

The weighted certificate uses weights $(0,1,1,2,2,3,3,3)$ on labels 1 through 8 and selects four-label sets with weight at least eight. The total weight is 15, so exactly one member of each complementary pair has weight at least eight.

The certificate argument guarantees at least $14736+52\cdot6=15048$ wins. Exact direct simulation additionally verifies that these constructions win **no** placements whose maximum cycle length is 6, 7, or 8:

| Maximum permutation cycle length | Winning placements |
| ---: | ---: |
| 1 | 1 |
| 2 | 763 |
| 3 | 5,152 |
| 4 | 8,820 |
| 5 | 312 |
| 6 | 0 |
| 7 | 0 |
| 8 | 0 |

The first four rows sum to CF's 14,736 old wins. The fifth is $52\cdot3!=312$. The probability is exactly $15048/40320=209/560$, approximately 37.321429%.

## 9. Machine-readable strategy semantics

The authoritative executable content is the JSON `rules` array. Each entry is

```text
[prisoner, ordered_observed_history, next_box]
```

For instance, `[1, [2, 3, 6], 5]` tells prisoner 1 to open box 5 next after observing the ordered sequence 2, 3, 6. Under the three initial CF openings these observations came from boxes 1, 2, and 3. The associated loss word is $(1\ 2\ 3\ 6)$ and the unique 5-cycle correctly handled by this rule is $(5\ 1\ 2\ 3\ 6)$.

The `mixed-n8-v1` schema supports a broader class that includes early jumps. Its semantics are:

1. Start at the prisoner's own-number box and stop immediately upon finding their number.
2. Consult rules using the exact ordered observations so far. The earliest applicable rule takes priority.
3. Use at most one exceptional jump per prisoner; after a jump, suppress later exceptional rules and follow observed numbers.
4. If a next box has already been opened, use the lowest-numbered unopened box.
5. Open no more than four distinct boxes and count success only when the prisoner's number is actually observed.

For the three 52-cycle certificates every history has length three. They therefore have **208 final-box rules and zero early rules**. Their exceptional targets are unopened, so their final-box jumps do not need the fallback.

The `blocks` and `orbit_representatives` fields store `(cycle, skipped_point)`, not `(cycle, omitted_prisoner)`. The latter is the successor of the former. These fields and saved `evaluation` values are metadata: the independent audit derives the loss words and rescued cycles directly from the rule table, then checks the metadata against those derived sets. `baseline_sha256` identifies the historical Round 4 204-rule baseline used for comparisons; it is not an optimality certificate.

## 10. What the additional searches establish

**The old 51-cycle solution is maximal under one-cycle extension.** The supplied [exact extension program](../repro/round7-original/round7_52/extend51_exact.py) was rerun over 2,265 additional cycle candidates. It retains the 51 cycles and allows reassignment of their omitted prisoners; none can be added. This is a finite result for that extension operation, obtained by rerunning the supplied implementation rather than independently re-proving its algorithm.

A relabeling of the symmetric 52 solution, exchanging labels 1 and 8, has the same 35-support family as the old 51 solution. Its [saved rule table](../repro/best52_sameF_round4_n8.json) and [historical direct verification](../repro/verification_round7_best52_sameF_round4_n8.json) are included. It is not one of the three freshly simulated certificates in the 13-task runner. Thus reaching 52 may require reorganizing existing cycles, even while keeping the support family.

**52 solutions do not contain all wins of the old 51 solution.** For example, the symmetric construction adds 312 placements relative to that baseline and loses 306, for a net gain of six. Neither set inclusion nor simple addition of another independent exception describes the change.

**The two-word local scan is exhaustive only for its stated variables.** Keeping the existing 208 rules fixed, each unused loss word offers no rule or one of $4\cdot4$ choices of failing prisoner and external target. Each construction therefore has $17^2=289$ cases, giving 867 across three constructions. The [scan](../repro/audit_round7_fill_two_unused.py) and [results](../repro/round7_fill_two_unused_audit.json) show no increase above 15,048. This does not bound changes that replace existing rules or introduce earlier jumps.

**The wider heuristic searches are observations.** The archived 52-start search evaluated 212,963 states without improving 15,048. Its saved best strategy actually using an early jump wins 15,036 with zero lost CF wins. The current suite directly verifies that [saved strategy](../repro/best_explored_from52_n8.json), but does not rerun the heuristic search. Round 6's 15,030 early-jump and 15,038 six-cycle constructions are also freshly simulated; they remain lower-bound examples, not global upper bounds.

## 11. General counting bound

For $n=2m$, $m\ge2$, consider the analogous family: CF for the first $m-1$ openings, an unopened changed final box, and preservation of all CF group wins. On an old winning placement, only prisoners on directed $m$-cycles can be harmed. Distinct rule loss words must be distinct, and their supports cannot be complementary: a common loss cycle or a pair of complementary loss cycles would cause two failures in an old winning placement.

The available word count is therefore at most

$$
L_m=\frac12\binom{2m}{m}(m-1)!
=\frac{(2m-1)!}{m!}.
$$

Rescuing a directed $(m+1)$-cycle requires correct rules for at least $m$ prisoners. Each rule identifies a unique such cycle, giving

$$
N_{m+1}\le
\left\lfloor\frac{L_m}{m}\right\rfloor
=\left\lfloor\frac{(2m-1)!}{m\,m!}\right\rfloor.
$$

Each rescued cycle gives $(m-1)!$ placements, so their probability contribution obeys

$$
\frac{N_{m+1}(m-1)!}{(2m)!}
\le\frac1{2m^3}.
$$

This is a bound for rescuing cycles of length $m+1$ in the specified family. Rules targeting other cycle lengths, early jumps, and the total gain of broader strategies are outside this bound. Attainment for general $m\ge5$ is open; the larger-instance numerical observations in the Japanese source were not independently audited for this release.

## 12. Verification record and reproduction

From the repository root:

```powershell
python -X utf8 repro/run_verification.py
```

The runner uses Python 3's standard library and writes the current transcripts to `verification/`. The [current summary](../verification/current_checks.json) records 13 passing tasks. The central evidence is:

- [Independent certificate audit](../repro/audit_round7_certificate.py) and [derived certificate results](../repro/round7_certificate_audit.json): 208 distinct loss words, no complementary supports, 52 four-rule rescues, and correct orbit expansion.
- [Direct simulator](../repro/verify_mixed_n8.py), which does not import the search evaluator: complete prisoner-by-prisoner simulation of all 40,320 placements. Current outputs: [symmetric](../verification/best52_costar_Z4_n8.json), [split words](../verification/best52_costar_splitY_n8.json), [threshold](../verification/best52_threshold_n8.json).
- [Second implementation](../repro/round7-original/round7_52/verify_52_n8.py) from the Round 7 source bundle, rerun for all three certificates: [symmetric transcript](../verification/best52_costar_Z4_n8-second-implementation.txt), [split transcript](../verification/best52_costar_splitY_n8-second-implementation.txt), [threshold transcript](../verification/best52_threshold_n8-second-implementation.txt).
- [Local scan transcript](../verification/unused-two-words-local-scan.txt) and [51-cycle extension transcript](../verification/51-cycles-cannot-be-extended.txt).

No CP-SAT run or reported search time is needed to certify 52. The fresh suite does not independently validate every lemma, source table, literature claim, or larger-instance search observation in the Japanese report. See the [reproduction guide](reproduction.md) for commands, dependencies, and the distinction between current outputs and historical records.
