# General one-failure mechanisms and a final-box upper bound

Audited 2026-10-18. This supplement distinguishes proofs for every integer
`m >= 2` from finite implementation checks. These are mathematical arguments,
not certificates produced by a formal proof assistant. Literature novelty and
historical attribution have not been established.

The model has `n = 2m` prisoners and boxes, a uniformly random permutation `p`
with card `p(x)` in box `x`, and at most `m` openings per prisoner. Prisoners
cannot communicate after starting. Success requires actually finding one's
card. The group wins with at least `2m-1` successful prisoners. Write `W` for
the placements won by ordinary cycle following (CF).

## 1. What allowing one failure changes

A prisoner following CF succeeds exactly when their permutation cycle has
length at most `m`. A failing cycle therefore has at least `m+1` members, all
of whom fail. Two such long cycles cannot coexist on `2m` labels. Consequently,
CF's failure count is either zero or the length of one long cycle. CF has
exactly the same winning set under the all-success and one-failure objectives:

$$P_{CF}=1-\sum_{k=m+1}^{2m}\frac1k.$$

The formula follows because a uniform permutation has expected number `1/k`
of directed `k`-cycles, and the events with `k > m` are mutually exclusive.

For an arbitrary adaptive strategy, an individual's success probability is at
most `m/(2m) = 1/2`. Conditional on any local transcript that has not revealed
their card, its position is uniform among the unopened boxes. A strategy that
continues opening new boxes until success or `m` attempts therefore misses
with probability

$$\prod_{j=0}^{m-1}\frac{2m-j-1}{2m-j}=\frac12.$$

Repeating a box or stopping before success cannot improve on continuing with
new boxes. Independent private or shared random choices can be conditioned on,
so the same bound holds for randomized strategies. If `X` is the number of
successful prisoners, linearity of expectation and Markov's inequality give

$$\mathbb E[X]\le m,\qquad
  \Pr(X\ge2m-1)\le\frac{m}{2m-1}.$$

This is a weak upper bound for all strategies, not an attainable probability
or an optimality theorem. A CF improvement can leave every individual's
success probability exactly `1/2`. It changes which prisoners fail together.
In particular, preserving `W` under one allowed failure means avoiding two
simultaneous losses, while permitting an isolated loss.

## 2. A general loss-witness coexistence criterion

Fix a deterministic adaptive strategy. Decisions may use the prisoner's label
and their own previous observations. Decisions to stop can be included in the
strategy; there are at most `m` box openings.

For each placement in `W` where prisoner `a` fails, form a witness consisting
of (i) the directed CF cycle containing `a` in that placement and (ii) the
observed box-to-card arrows for the first `m-1` openings of the failed run, or
all the observed arrows if fewer than `m` openings occur. Duplicate observations
add no new arrows. The original CF cycle fixes the unique box containing `a`.

Every completion of this witness makes `a` fail in the same way. The observations
before the last opening reproduce the decisions, and the fixed box containing
`a` proves that the last chosen box also fails. If the run stops early, all its
observations and the stopping decision are reproduced.

Take the union of witnesses belonging to two distinct prisoners. If it assigns
different cards to one box, or the same card to different boxes, it has no
permutation completion. Otherwise it is a partial injection. Its directed
components are cycles, paths, and isolated vertices. It has a completion in `W`
if and only if **every component has at most `m` vertices**. Necessity follows
because each component lies in a cycle of any completion. For sufficiency,
close each path to a cycle and each isolated vertex to a fixed point; the
existing cycles already satisfy the length bound.

It follows that the strategy preserves every placement of `W` as a group win
if and only if no pair of witnesses for distinct prisoners admits such a
short-cycle completion. One direction uses the completed placement, which
would have two failures. For the other, any placement in `W` with two failures
itself completes their two witnesses.

This is an exact structural criterion for pointwise preservation of `W`, not
an efficient procedure for listing all witnesses, a construction theorem, or
an upper bound for strategies that trade some old CF wins for new wins.

## 3. Final-box modifications: exact preservation conditions

Now restrict to CF for the first `m-1` openings, with only the final opening
changed. A relevant unsuccessful history can be written

$$h=(a_0,a_1,\ldots,a_{m-1}),\qquad
  p(a_j)=a_{j+1}\quad(0\le j<m-1),$$

where all labels are distinct. Prisoner `a_0` would normally open `a_{m-1}`
last. A proper exception chooses a target `t` outside the history. Previously
opened boxes can be replaced by the ordinary CF choice without decreasing
any prisoner's success on any placement; already successful histories are
irrelevant. Thus restricting the upper-bound argument to proper exceptions
loses no possible improvement.

The exception's **loss cycle** is the directed `m`-cycle
`(a_0,a_1,...,a_{m-1})`, considered up to cyclic rotation. In a placement in
`W`, it causes a new failure exactly when that cycle is present. Shorter
cycles succeed before the final step.

Pointwise preservation of `W` is therefore equivalent to both conditions:

1. Each directed loss `m`-cycle carries at most one exception.
2. For each complementary pair of `m`-element supports, at most one support
   has any exceptions.

For necessity, put a doubly used cycle beside fixed points, or put two active
complementary cycles together. Either placement belongs to `W` but loses two
prisoners. For sufficiency, a placement in `W` has at most two `m`-cycles; if
there are two, their supports are complementary. The two conditions permit
at most one loss in total.

## 4. A fixed block and the checksum construction

Fix a directed `(m+1)`-cycle `C`. Give its prisoners the correct final-box
exceptions for `C`, omitting any one of the `m+1` exceptions. There are `m`
remaining rules. Their loss supports are distinct `m`-subsets of `C` and
intersect, so the preceding conditions hold. On a placement containing `C`,
exactly one member of `C` fails and all `m-1` outside prisoners succeed.

There are exactly `(m-1)!` such placements. No longer cycle can be rescued
because at most `m` prisoners have exceptions. A rescued `(m+1)`-cycle must
use these rules; even one correct rule determines its entire directed cycle.
The gain of this single block is therefore exactly

$$\Delta P=\frac{(m-1)!}{(2m)!}>0.$$

This proves that CF is strictly improvable for the one-failure objective for
every `m >= 2`. It is independent of any eight-person record.

For a larger construction, fix an anchor `a` and label the other `N=2m-1`
prisoners `0,...,N-1`. Use injective length-`m` words `w=(p_1,...,p_m)` to
represent cycles `(a,p_1,...,p_m)`. For each selected cycle, omit only the
exception of `p_1`, the anchor's successor.

Deleting the predecessor of an exception's owner from its `(m+1)`-cycle gives
its loss cycle. Because the exception of `p_1` was omitted, this deletion never
removes `a`. All loss cycles contain `a`, so distinct ones cannot coexist. If
no two selected words have a common one-symbol deletion, all these loss cycles
are distinct as well, and the rules preserve `W`.

Use the fixed checksum class

$$\mathcal C_{s,t}=\left\{w:
 \sum_{j=1}^m p_j\equiv s\pmod N,\quad
 \sum_{j=1}^{m-1}j[p_j>p_{j+1}]\equiv t\pmod m\right\}.$$

Here is a self-contained proof that it corrects one deletion.

1. If two words in the class delete to the same word `u`, their deleted
   symbols have the same residue modulo `N` and hence are the same symbol `x`.
2. Let the descent signature of a word be the bit sequence
   `[p_j > p_{j+1}]`. Deleting a symbol deletes one bit from its signature:
   the two comparisons surrounding an interior deletion merge to a comparison
   equal to one of them. If they were equal, transitivity forces that value.
3. A binary sequence of length `ell` is uniquely recoverable from any
   one-bit deletion and its weighted sum modulo `ell+1`. To prove this, let
   `y` be the shorter sequence with `q` ones, and let `D` be the change in
   weighted sum on insertion. Inserting zero gives `D = number of ones to
   its right`, in `[0,q]`. Inserting one gives
   `D = q+1 + number of zeros to its left`, in `[q+1,ell]`. The residue
   determines the unique `D` in `[0,ell]`, its bit, and the resulting sequence.
   Different positions inside a run of identical bits give the same sequence.
   Apply this with `ell=m-1` to conclude that the two descent signatures agree.
4. Inserting the same missing symbol `x` into different gaps of an injective
   word gives different descent signatures. If the gaps bracket
   `u_r,...,u_s`, equality would require
   `[x>u_r]=[u_r>u_{r+1}]=...=[u_s>x]`. All these strict comparisons cannot
   have the same truth value. Thus the insertion gaps, and the words, agree.

Every checksum class has **exactly**

$$|\mathcal C_{s,t}|=\frac{(2m-2)!}{m!}$$

words; choosing a largest class is unnecessary. For the first checksum,
translating an `m`-subset by one modulo `N` changes its sum by `m`.
Since `gcd(m,N)=1`, the subset-sum residues have equal counts. For a fixed
subset, replace every letter by the next in its rank order, wrapping maximum
to minimum. Only comparisons adjacent to the old maximum change, and their
weighted-sum change is `-1` modulo `m` (including either endpoint). This
bijection makes the second residues uniform among its permutations. Multiply
`binom(N,m)/N` subsets by `(m-1)!` permutations per second residue.

A selected cycle adds `(m-1)!` placements, and distinct long cycles cannot
coexist. There are no other new wins: every correct exception's `m`-label
history window contains `a`; in a cycle of length `L >= m+2`, at most `m`
windows contain `a`, too few to provide `L-1` successes. For `L=m+1`, one
correct rule identifies its selected cycle. Thus each fixed class, including
`(s,t)=(0,0)`, has exactly

$$\Delta P=\frac{|\mathcal C_{s,t}|(m-1)!}{(2m)!}
          =\frac1{2m^2(2m-1)}.$$

This is an exact gain for this explicit strategy and a lower bound for the
unknown optimum.

There is no need to store all the selected words. At the final decision,
rotate the history cycle to start with `a` and remove `a` to obtain `u`.
If the history does not contain `a`, use CF. Otherwise the only possible
missing label is `x = -sum(u) mod N`. Reject it if already present. Try the
`m` insertion gaps and retain the word with second checksum zero, if one
exists. The deletion property gives at most one. Use box `x` precisely if
the reconstructed cycle places the acting prisoner immediately after `x`;
otherwise use CF. This takes `O(m^2)` comparisons in a direct implementation.

## 5. An upper bound covering every long-cycle length

The rest of this section assumes **CF for the first `m-1` openings, only the
final box changed, and pointwise preservation of every placement in `W`**.
It requires no anchor, symmetry, support orientation, block decomposition,
or fixed number such as 208 rules.

Let `M` be the number of proper exceptions. The two preservation conditions
give

$$M\le\frac12\binom{2m}{m}(m-1)!.$$

For a fixed rule `(a_0,...,a_{m-1};t)` to succeed in a long `k`-cycle,
`m+1 <= k <= 2m`, the cycle must contain the segment
`t -> a_0 -> ... -> a_{m-1}`. Choose and order
`q=k-m-1` additional labels between the end and `t`, then permute all
outside labels. The exact number of placements is

$$\binom{m-1}{q}q!(2m-k)!=(m-1)!.$$

If `N_k` counts new winning **placements** with a long `k`-cycle, at least
`k-1` members of that cycle must use correct exceptions. Double-counting
rule-placement incidences gives

$$(k-1)N_k\le M(m-1)!.$$

Full `2m`-cycles cannot be rescued. In such a cycle, the history support of
each position is complementary to the history support of the opposite
position, so at most one of each pair can have a proper exception. At most
`m` prisoners succeed, fewer than `2m-1` for `m>=2`. Therefore `N_(2m)=0`.

Sum the incidence inequality for `k=m+1,...,2m-1` and divide by `(2m)!`:

$$\boxed{\Delta P\le
 \frac{H_{2m-2}-H_{m-1}}{2m^2}}\qquad(m\ge2).$$

The bound is generally not sharp: incidences in placements that still lose
are included in its right-hand side. At `m=2` it gives `1/16`; integer
rounding improves the bound to `1/24` in this restricted class. The condition
`m>=2` matters: at `m=1`, changing one prisoner to the other box preserves
the original win and wins both permutations, a gain of `1/2`.

Considering only `k=m+1` instead gives the older contribution bound

$$\Delta P_{m+1}\le\frac1{2m^3}.$$

That shorter-cycle contribution bound also bounds the **total** gain of the
anchored deletion-code construction, which cannot rescue longer cycles. For
general final-box modifications it is only a contribution bound. The harmonic
bound covers all long-cycle lengths in the stated preserving class.

The harmonic bound is `log(2)/(2m^2) + O(m^-3)`. It does not show that one
allowed failure has a vanishing effect for arbitrary strategies. Earlier
changes or exchanges of old wins fall outside this proof. Randomization is
covered if every placement in `W` is preserved with probability one: there
are finitely many placements, so almost every fixed random seed preserves
all of them, and the deterministic bound can be averaged.

## 6. Numerical consequences for 100 prisoners

The audit script evaluates these values using exact rational arithmetic and
60-digit decimal conversion:

| Quantity | Probability, or probability gain |
| --- | ---: |
| Ordinary CF | `0.311827820689804796755354...` |
| Fixed checksum-class gain | `1/495000 = 0.000002020202020202...` |
| Fixed checksum-class total | `0.311829840891824998775556...` |
| All-long-cycle gain upper bound, restricted final-box class | `0.000137614233841837020446...` |
| Total upper bound, same restricted class | `0.311965434923646633775801...` |
| General expectation upper bound, all strategies | `50/99 = 0.505050505050...` |

The checksum strategy reaches about **31.1829841%**. Its increase over CF is
about **0.0002020202 percentage points**. The restricted final-box class has
total probability at most about **31.1965435%**, with gain at most about
**0.0137614234 percentage points**. The upper endpoint is not an attained
construction. No `100!` enumeration was performed.

## 7. Reproduction and precise evidence boundary

In the assembled reproducible package, run from its repository root:

```powershell
python -X utf8 repro/post-round8/audit_general.py --output verification/post-round8/general_audit.json
```

The output is `verification/post-round8/general_audit.json`. The program uses only Python's standard
library, reads no historical files, and executes no solver or optimizer.
It checks:

- All partial injections on four and six labels against independently
  enumerated CF-winning completions.
- Every checksum class and its deletion collision condition for `m=2,...,5`;
  the binary deletion-checksum lemma for lengths 1 through 10.
- Agreement of the local zero-class decoder and the explicit rule table on
  every relevant history for `m=2,3,4`.
- Direct opening-by-opening simulation on every permutation for both the
  single-block and fixed-zero-class strategies for four, six, and eight
  prisoners. The zero-class win counts are **11/24, 284/720, 14916/40320**;
  the single-block counts are **11/24, 278/720, 14742/40320**. Every old CF win
  is preserved and every individual succeeds on exactly half the placements.
- The exact `(m-1)!` incidence count for every proper exception and every
  long-cycle length on those same finite instances, and the full-cycle
  success limit for these supplied strategies.

The last finite check does not enumerate all possible preserving rule tables;
the general full-cycle exclusion is proved above. Finite checks support
implementation accuracy, not arbitrary-`m` validity. The proofs provide the
general validity.

## 8. What is new relative to the 2026-10-13 README

That README already records the CF failure-count gap, strict single-cycle
improvement, the checksum lower bound, and the `(m+1)`-cycle contribution
upper bound. These are reconfirmed here, not new numerical records. The
post-Round-8 additions are the explicit distinction between marginal success
and joint failures; the general loss-witness completion criterion; a proof
that **every** checksum class has equal size, allowing a fixed class and
local decoding; and the harmonic upper bound covering **all** long-cycle
lengths within the CF-preserving final-box class.

The best saved eight-person count remains a separate construction result.
Nothing here proves total-win optimality for six, eight, or 100 prisoners,
or transports the eight-person 15,051/15,052 boundary to the 100-person case.
