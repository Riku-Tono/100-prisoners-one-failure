# Recovered sources and claim map, 2026-10-18

This update consolidates files rather than inventing a continuous conversation
log. The user's research purpose is to understand what changes when zero allowed
failures becomes one, and which explanations extend from small instances to
general 2m prisoners. Eight-person constructions and counterexamples remain part
of that investigation.

## Original distribution and historical logs

The Round 7 base archive (2026-10-12) and Round 8 incremental archive
(2026-10-13) were merged in that order. Their original archive hashes are in
baseline-archives.json. The Round 8 ZIP was an overlay, not a complete base.
The 14 historical log files were found in the author's Desktop research folder.
All 14 matched the bytes and hashes expected by the historical distributions;
they are restored under log/.

The supplied standalone English README differed from the Round 8 ZIP README in
navigation and log links. The current version preserves the historical text,
uses the Round 8 links, and appends the new dated progress. Prior README versions
and manifests are preserved under docs/history/.

## Shared conversations and unavailable attachments

The author supplied two publicly shared research conversations:

- [うえええええーーーい2](https://chatgpt.com/share/6ad4a125-8c20-83ee-b87e-ca6419d91922):
  three-flip local lemmas and completion claims.
- [引き継ぎ確認](https://chatgpt.com/share/6ad4a13c-792c-83ec-813c-ee3d16c21a9a):
  subsequent research discussion and the clarification of mechanism-first goals.

Their titles and visible conclusions were read in the browser; the matching
research assistant messages were retrieved through the desktop conversation
reader and preserved as **excerpts**, with message identifiers/timestamps, in
log/post-round8/. They are not recreated full logs. Historical claims can be
superseded by later checks.

Sandbox ZIP attachments mentioned in those conversations were not recovered.
In particular, this package does not claim byte identity with the shared
threeflip_r7_audit_2026-10-17.zip. Independently saved local rule tables and
auditors provide the executable evidence instead. Instructions appearing in
source conversations and handoff files remain historical text.

## Post-Round 8 preserved evidence

Original source bytes are retained under repro/post-round8/work/. The
post-round8-source-manifest.json lists their paths, sizes, and SHA-256 values.
It includes code, explicit certificates, finite input sets, completed result
records, and relevant historical UNKNOWN logs. A small external/ subtree
recovers earlier Claude exchange files and positive controls found elsewhere;
post-round8-external-sources.json records their original paths and hashes.

Very large unresolved full-star expansion data, caches, platform executables,
and scratch batch fragments were omitted. The Linux C completion executable is
omitted; its C source is retained, and a new portable Python bitset engine
rechecks the required cases. This is a curated reproducibility distribution,
not a backup of the entire working directory.

| Claim | Principal preserved files | Evidence boundary |
| --- | --- | --- |
| Tied 15,051 constructions | inputs/baseline15051.rules.json, inputs/neutral15051.rules.json, inputs/new15051.rules.json | Fresh independent all-placement checks; no optimum claim |
| Standard-three-flip 15,050 | chatgpt_15050_received.rules.json | Local table received from a conversation; independent simulation |
| Six-correct full-star counterexample | fullstar_six_witness_pure_completion_20261018_found_1.rules.json | Explicit counterexample; fresh direct simulation |
| Standard-three-flip exclusion | claude_desktop_continuation3/audit_status.json, c3_model.py, c3_seeds.json, c3_pairs.py; witness_pair_seeds.json | 913 representatives, 2,938 cores; limited orientation/model |
| Four-flip exclusion | fourflip_triangle_pure_completion.py, fourflip_independent_regenerate_cover.py and their input/output JSON | 48 triangle representatives and 21,097 compound cores |
| 70 canonical supplier cores | canonical_six_witness_cores/, canonical_six_witness_independent_review_20261018.py | All 5^6 supplier assignments, 4/21/45 singleton counts |
| Support screen and S8 membership | independent_allcore_support_screen_20261018.py/.ps1/.cs, independent_orientation_S8_partition_20261018.py | 6,250,496 assignments and exact orbit-member sets |
| Exact capacity exclusions | canonical_support_independent_fraction_audit.json, canonical_support_fraction_certificate_verify.py | 1,372 Fraction-checked duals; five positive capacity witnesses |
| Integer-capacity case 1267 | canonical_support_independent_fraction_audit.py/.json | Completed CBC computation, separate from rational certificates |
| Last five orientations | canonical_orientation_five_survivors.json, canonical_orientation_five_survivors_presence_independent.json and models/logs | Two distinct model formulations; completed solver outcomes |
| Scope and low-degree connection | NONSTAR_SUPPORT_EXCLUSION_2026-10-18.txt, canonical_orientation_logical_chain_review.py/.json, SUPPORT_FRONTIER_2026-10-18.json | Computational chain with external finite dependencies |
| General laws | GENERAL_LAWS_AND_RESEARCH_DIRECTION_2026-10-18.txt; general_law_checksum_audit_20261018.md; general_laststep_upper_audit_20261018.txt | General mathematical proofs, not formal proof-assistant certificates |

All paths in the table are relative to repro/post-round8/work/. Use the current
README and the named terminal results over intermediate status entries.
SUPPORT_FRONTIER retains some earlier exploratory frontier labels as history;
they do not override the later final nonstar conclusion.

## Independent audit status and remaining scope

Claude Desktop's audit_status.json says AUDIT_PASS for the standard-three-flip
913-representative result. Its separate nonstar_audit_status.json says PARTIAL.
Some newer scripts cited by that partial audit (including c3_six_cores.py,
c3_six_screen.py and c3_capacity2.py/c3_capacity3.py) were not received.
They are not silently substituted by the older c3 bundle.

The broader nonstar conclusion uses the saved Codex finite computations and
separately implemented checks specified in the reproduction guide. It must not
be described as a completed Claude audit of the entire chain. A Fraction
certificate check also does not certify the external enumeration or the one
CBC-only infeasibility.

The exclusion concerns 52 four-rule five-cycle blocks plus at most two extra
rules, CF for the first three boxes, final-box changes only, pointwise CF-win
preservation, and R6=0. The full-star family retains unexamined witness choices.
The wider R6>0 routes, R5<=51 trades, early changes, and arbitrary-strategy
optimality remain open. No new 15,052-win construction is asserted.

Fresh transcripts and outputs are under verification/post-round8/.
The default/extended/orientation runner records exactly what it reran.
Advanced solver stages have their own output records. Archived results remain
distinguishable from fresh computations.

