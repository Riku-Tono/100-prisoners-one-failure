"""Try early rules capable of restoring losers of the best 6-cycle package."""
from pathlib import Path
from itertools import combinations, product
import importlib.util, json, sys, time
root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("mixed_search", root / "outputs" / "mixed_search_n8.py")
mod = importlib.util.module_from_spec(spec); sys.modules[spec.name] = mod; spec.loader.exec_module(mod)
ctx = mod.Context(root / "outputs" / "round4_baseline_n8.json")
ctx.build_early_candidates()
strategy = json.loads((root / "outputs" / "six_cycle_probe_strategy.json").read_text())
rules = {(i, tuple(h)): b for i,h,b in strategy["rules"]}
mods = {k: rules.get(k,0) for k in ctx.late if rules.get(k) != ctx.late[k]}
mods.update({k:v for k,v in rules.items() if k not in ctx.late})
base = mod.State((), tuple(sorted(mods.items())))
lost = ctx.base_wins_mask & ~ctx.evaluate(base)[2]
options = {}
for i in (2,3,5):
    options[i] = []
    for cid,c in enumerate(ctx.early_candidates):
        if c.i != i or not (c.activation & lost):
            continue
        state = ctx.with_early(base,cid)
        masks = ctx.success_masks(state)
        if (masks[i-1] & lost) == lost:
            options[i].append(cid)
    print("prisoner",i,"rescuing early choices",[(ctx.early_candidates[c].h,ctx.early_candidates[c].b) for c in options[i]],flush=True)
best = (15038,base)
counts = {"tested":0,"safe":0,"five_cycle_restored":0}
for people in combinations((2,3,5),2):
    for choices in product(*(options[i] for i in people)):
        state=base
        for cid in choices:
            state=ctx.with_early(state,cid)
        counts["tested"] += 1
        score,wlost,wins=ctx.evaluate(state)
        if wlost: continue
        counts["safe"] += 1
        if wins & lost: counts["five_cycle_restored"] += 1
        if score>best[0]: best=(score,state)
for choices in product(*(options[i] for i in (2,3,5))):
    state=base
    for cid in choices:
        state=ctx.with_early(state,cid)
    counts["tested"] += 1
    score,wlost,wins=ctx.evaluate(state)
    if wlost: continue
    counts["safe"] += 1
    if wins & lost: counts["five_cycle_restored"] += 1
    if score>best[0]: best=(score,state)
print(counts,"best",best[0],flush=True)
if best[0]>15038:
    (root/"work"/"rescue_lost_five_best.json").write_text(json.dumps({"rules":ctx.rule_list(best[1])},indent=2),encoding="utf-8")
