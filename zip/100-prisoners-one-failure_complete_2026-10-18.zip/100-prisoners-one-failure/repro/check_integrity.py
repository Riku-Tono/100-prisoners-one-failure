"""Verify the distributed file hashes before rerunning the research scripts."""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    records = (ROOT / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines()
    for record in records:
        expected, relative = record.split('  ', 1)
        path = (ROOT / relative).resolve()
        if not path.is_relative_to(ROOT):
            raise ValueError(f'Path outside repository: {relative}')
        if not path.is_file():
            raise SystemExit(f'MISSING: {relative}')
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise SystemExit(f'HASH MISMATCH: {relative}')
    print(f'ALL {len(records)} FILE HASHES PASS')


if __name__ == '__main__':
    main()
