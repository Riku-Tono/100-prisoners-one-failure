"""Combinatorial model of the free-omission final-box family, n=8, m=4.

Objects
  word  : directed 4-cycle on a 4-subset S of [8], canonical (min first).
  cycle : directed 5-cycle on a 5-subset U, canonical (min first).
  del(C, x) : directed 4-cycle obtained from C by deleting x (x in C).
A rescued cycle C with skip w uses the 4 words del(C, x), x in C - {w}.
(Skip w = predecessor of the omitted prisoner; the loser of word del(C,x) is
succ_C(x), the prisoner whose final-box rule jumps to box x.)
"""
from itertools import combinations, permutations

P = tuple(range(1, 9))


def canon(c):
    c = tuple(c)
    k = c.index(min(c))
    return c[k:] + c[:k]


def dcycles(S):
    S = sorted(S)
    return [(S[0],) + q for q in permutations(S[1:])]


def delete(C, x):
    return canon(tuple(v for v in C if v != x))


FOUR = [frozenset(S) for S in combinations(P, 4)]
FIVE = [frozenset(U) for U in combinations(P, 5)]
WORDS = [w for S in FOUR for w in dcycles(S)]
CYCLES = [c for U in FIVE for c in dcycles(U)]
WID = {w: k for k, w in enumerate(WORDS)}
CID = {c: k for k, c in enumerate(CYCLES)}
assert len(WORDS) == 420 and len(CYCLES) == 1344


def comp(S):
    return frozenset(P) - frozenset(S)


PAIRS = []  # 35 complementary pairs (S, S^c) with 1 in S
for S in FOUR:
    if 1 in S:
        PAIRS.append((S, comp(S)))
assert len(PAIRS) == 35


def cycles_from_csv(path):
    import csv
    out = []
    with open(path, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            C = tuple(int(t) for t in row["cycle"].strip("()").split(","))
            om = [int(t) for t in row["omitted_prisoners"].strip("[]").split(",") if t.strip()]
            succ = {C[i]: C[(i + 1) % 5] for i in range(5)}
            pred = {v: k for k, v in succ.items()}
            if len(om) == 1:
                skip = pred[om[0]]  # word del(C, skip) is the one not used
            else:
                skip = None
            out.append((canon(C), skip))
    return out


def used_words(sol):
    ws = []
    for C, skip in sol:
        for x in C:
            if x != skip:
                ws.append(delete(C, x))
    return ws
