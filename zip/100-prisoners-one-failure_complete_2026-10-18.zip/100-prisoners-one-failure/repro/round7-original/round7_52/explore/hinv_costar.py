import sys, json, time
from ortools.sat.python import cp_model
from model import *
from symF import closure
from lattice import blocks4
F = {S for S in FOUR if 1 not in S}
B = blocks4(F); bid = {b: j for j, b in enumerate(B)}
def tr(*cycles):
    mp = {x: x for x in P}
    for c in cycles:
        for k in range(len(c)): mp[c[k]] = c[(k + 1) % len(c)]
    return tuple(mp[x] for x in P)
def act(g, b):
    C, w = b
    return (canon(tuple(g[x - 1] for x in C)), g[w - 1])
def solveH(gens, secs, target=52):
    G = closure(gens) if gens else {tuple(P)}
    md = cp_model.CpModel()
    xs = [md.NewBoolVar("") for _ in B]
    byword = {}
    for j, (C, w) in enumerate(B):
        for x in C:
            if x != w: byword.setdefault(delete(C, x), []).append(xs[j])
    for vs in byword.values(): md.AddAtMostOne(vs)
    for j, b in enumerate(B):
        for g in G:
            k = bid[act(g, b)]
            if k > j: md.Add(xs[j] == xs[k])
    md.Add(sum(xs) >= target)
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = secs; s.parameters.num_workers = 2
    st = s.Solve(md)
    sol = [B[j] for j in range(len(B)) if st in (cp_model.OPTIMAL, cp_model.FEASIBLE) and s.Value(xs[j])]
    return s.StatusName(st), len(G), sol
tests = {
 "(2345)(67)": [tr((2, 3, 4, 5), (6, 7))],
 "(2345)": [tr((2, 3, 4, 5))],
 "(23)(45)": [tr((2, 3), (4, 5))],
 "(23)(45)(67)": [tr((2, 3), (4, 5), (6, 7))],
 "(23)": [tr((2, 3))],
 "D4": [tr((2, 3, 4, 5)), tr((2, 5), (3, 4))],
 "Z4xZ2": [tr((2, 3, 4, 5)), tr((6, 7))],
 "D4(67)": [tr((2, 3, 4, 5), (6, 7)), tr((2, 5), (3, 4))],
 "Z2^2": [tr((2, 3), (4, 5)), tr((2, 4), (3, 5))],
 "Z2^2b": [tr((2, 3), (4, 5)), tr((2, 4), (3, 5), (6, 7))],
 "Syl16": [tr((2, 3, 4, 5)), tr((2, 5), (3, 4)), tr((6, 7))],
 "(2345)(6789)?": [tr((2, 3, 4, 5), (6, 7))],
}
for nm in sys.argv[2:]:
    t = time.time()
    st, order, sol = solveH(tests[nm], float(sys.argv[1]))
    print(f"{nm:14s} |H|={order:2d} {st:10s} {len(sol)} {time.time()-t:.1f}s", flush=True)
    if sol:
        fn = "costar52_H_" + "".join(ch for ch in nm if ch.isalnum()) + ".json"
        json.dump({"H": nm, "blocks": [[list(C), w] for C, w in sol]}, open(fn, "w"))
