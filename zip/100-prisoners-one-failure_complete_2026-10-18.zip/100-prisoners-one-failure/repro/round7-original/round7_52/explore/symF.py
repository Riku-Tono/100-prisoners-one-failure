"""Enumerate G-invariant families F (one 4-set per complementary pair) for a group G,
compute LP bound and exact ILP (fixed F)."""
import sys, itertools
from collections import Counter
from model import *
from lp_survey import lp_bound
from ilp_fixedF import solve

def closure(gens):
    idp = tuple(P)
    G = {idp}; frontier = [idp]
    while frontier:
        new = []
        for g in frontier:
            for h in gens:
                gh = tuple(h[g[i]-1] for i in range(8))  # apply g then h
                if gh not in G:
                    G.add(gh); new.append(gh)
        frontier = new
    return G

def orbits4(G):
    seen = {}; orbs = []
    for S in FOUR:
        if S in seen: continue
        orb = {frozenset(g[x-1] for x in S) for g in G}
        for T in orb: seen[T] = len(orbs)
        orbs.append(frozenset(orb))
    return orbs, seen

def invariant_families(G):
    orbs, idx = orbits4(G)
    pairs = []; done = set()
    for k, O in enumerate(orbs):
        if k in done: continue
        S = next(iter(O)); kc = idx[comp(S)]
        if kc == k: return None, orbs
        done |= {k, kc}; pairs.append((k, kc))
    fams = []
    for bits in itertools.product((0, 1), repeat=len(pairs)):
        F = set()
        for b, (k, kc) in zip(bits, pairs):
            F |= orbs[k if b == 0 else kc]
        fams.append((bits, F))
    return fams, orbs

def perm_from_map(mp):
    return tuple(mp[x] for x in P)

if __name__ == "__main__":
    pass
