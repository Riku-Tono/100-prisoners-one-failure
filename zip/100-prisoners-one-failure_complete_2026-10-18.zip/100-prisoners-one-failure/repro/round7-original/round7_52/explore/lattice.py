"""Mod-p left kernel of the block/word incidence (plus block-count row) for a fixed F.
Tests whether (1 - 1_Y, 52) can lie in the Z-span of the 4-blocks, for every |Y|=2."""
import sys, itertools
import numpy as np
from model import *
from lp_survey import star, costar

def blocks4(F):
    Fs = set(F); out = []
    for C in CYCLES:
        U = frozenset(C)
        for w in C:
            if all(U - {x} in Fs for x in C if x != w):
                out.append((C, w))
    return out

def left_kernel_mod_p(M, p):
    """M: rows x cols int matrix. return basis of {l : l M = 0 mod p} as rows."""
    A = (M.T % p).astype(np.int64)  # cols x rows; kernel of A (right) = left kernel of M
    r, c = A.shape
    A = A.copy(); piv = []; row = 0
    for col in range(c):
        pr = None
        for i in range(row, r):
            if A[i, col] % p: pr = i; break
        if pr is None: continue
        A[[row, pr]] = A[[pr, row]]
        inv = pow(int(A[row, col]), p - 2, p)
        A[row] = (A[row] * inv) % p
        for i in range(r):
            if i != row and A[i, col]:
                A[i] = (A[i] - A[i, col] * A[row]) % p
        piv.append(col); row += 1
        if row == r: break
    free = [j for j in range(c) if j not in piv]
    basis = []
    for f in free:
        v = np.zeros(c, dtype=np.int64); v[f] = 1
        for i, pc in enumerate(piv):
            v[pc] = (-A[i, f]) % p
        basis.append(v)
    return np.array(basis, dtype=np.int64).reshape(len(basis), c)

def analyze(F, primes=(2, 3, 5, 7), N=52):
    words = [D for S in F for D in dcycles(S)]
    wid = {D: k for k, D in enumerate(words)}
    B = blocks4(F)
    M = np.zeros((len(words) + 1, len(B)), dtype=np.int64)
    for j, (C, w) in enumerate(B):
        for x in C:
            if x != w: M[wid[delete(C, x)], j] = 1
        M[-1, j] = 1
    out = {}
    for p in primes:
        K = left_kernel_mod_p(M, p)
        if len(K) == 0:
            out[p] = ("kernel 0", None); continue
        t0 = (K[:, :-1].sum(axis=1) + K[:, -1] * N) % p  # functional on (1, N)
        cols = K[:, :-1] % p
        # need some Y (|Y|=2) with sum of cols over Y == t0 (mod p)
        ok = []
        colmap = {}
        for i in range(cols.shape[1]):
            colmap.setdefault(tuple(cols[:, i]), []).append(i)
        for i in range(cols.shape[1]):
            need = tuple((t0 - cols[:, i]) % p)
            for j in colmap.get(need, []):
                if j > i: ok.append((words[i], words[j]))
        out[p] = (f"kernel dim {len(K)}", len(ok), ok[:4])
    return out

if __name__ == "__main__":
    for name, F in (("star", star(1)), ("costar", costar(1))):
        print(name, analyze(F))
