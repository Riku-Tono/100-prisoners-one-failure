"""Convert blocks [[C, skip],...] to final-box rules and a strategy JSON."""
import json, sys
def rules_of(blocks):
    rules = []
    for C, w in blocks:
        C = tuple(C)
        for j in range(5):
            if C[(j - 1) % 5] != w:       # member C[j] jumps to its predecessor C[j-1]
                rules.append([C[j], [C[(j + s) % 5] for s in (1, 2, 3)], C[(j - 1) % 5]])
    return sorted(rules)
if __name__ == "__main__":
    src, dst = sys.argv[1], sys.argv[2]
    d = json.load(open(src))
    blocks = d["blocks"] if isinstance(d, dict) else d
    out = {"blocks": blocks, "rules": rules_of(blocks)}
    if isinstance(d, dict): out.update({k: v for k, v in d.items() if k not in out})
    json.dump(out, open(dst, "w"))
    print(len(out["rules"]), "rules ->", dst)
