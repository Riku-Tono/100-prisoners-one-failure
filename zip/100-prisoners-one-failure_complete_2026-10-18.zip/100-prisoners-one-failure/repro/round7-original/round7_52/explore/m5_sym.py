import sys
from general_m import solve
h = {1: 2, 2: 3, 3: 4, 4: 1, 5: 6, 6: 7, 7: 8, 8: 5, 9: 9, 10: 10}
g5 = {1: 2, 2: 3, 3: 4, 4: 5, 5: 1, 6: 6, 7: 7, 8: 8, 9: 9, 10: 10}
which = sys.argv[1]; secs = float(sys.argv[2])
gens = {"h4": [h], "c5": [g5]}[which]
sol = solve(5, "costar", secs, None, gens)
