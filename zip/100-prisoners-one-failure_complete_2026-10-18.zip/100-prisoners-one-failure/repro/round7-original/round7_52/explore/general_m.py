"""Free-omission final-box family for general m (n=2m): rescue (m+1)-cycles.
F fixed as co-star (all m-subsets of {1..2m-1}) or star (all m-sets containing 2m).
Block = ((m+1)-cycle C, skip w): uses deletions of all members except w; words = directed m-cycles."""
import sys, time
from itertools import combinations, permutations
from math import comb, factorial
from ortools.sat.python import cp_model

def canon(c):
    c = tuple(c); k = c.index(min(c)); return c[k:] + c[:k]
def dcycles(S):
    S = sorted(S); return [(S[0],) + q for q in permutations(S[1:])]
def delete(C, x): return canon(tuple(v for v in C if v != x))

def build(m, fam):
    n = 2 * m; pts = range(1, n + 1)
    if fam == "costar": F = {frozenset(S) for S in combinations(range(1, n), m)}
    else: F = {frozenset(S) | {n} for S in combinations(range(1, n), m - 1)}
    blocks = []
    for U in combinations(pts, m + 1):
        U = frozenset(U)
        ok = [x for x in U if U - {x} in F]
        if len(ok) < m: continue
        for C in dcycles(U):
            for w in C:
                if all(x in ok for x in C if x != w): blocks.append((C, w))
    return F, blocks

def solve(m, fam, secs, target=None, gens=None):
    F, B = build(m, fam)
    W = len(F) * factorial(m - 1)
    md = cp_model.CpModel(); xs = [md.NewBoolVar("") for _ in B]
    byword = {}
    for j, (C, w) in enumerate(B):
        for x in C:
            if x != w: byword.setdefault(delete(C, x), []).append(xs[j])
    for vs in byword.values(): md.AddAtMostOne(vs)
    if gens:
        bid = {b: j for j, b in enumerate(B)}
        for g in gens:
            for j, (C, w) in enumerate(B):
                k = bid[(canon(tuple(g[x] for x in C)), g[w])]
                md.Add(xs[j] == xs[k])
    if target: md.Add(sum(xs) >= target)
    else: md.Maximize(sum(xs))
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = secs; s.parameters.num_workers = 2
    t = time.time(); st = s.Solve(md)
    val = sum(s.Value(x) for x in xs) if st in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None
    print(f"m={m} {fam}: words={W} bound={W // m} blocks={len(B)} status={s.StatusName(st)} value={val} "
          f"objbound={s.BestObjectiveBound() if not target else '-'} {time.time()-t:.1f}s", flush=True)
    sol = [B[j] for j in range(len(B)) if val and s.Value(xs[j])]
    return sol

if __name__ == "__main__":
    m = int(sys.argv[1]); fam = sys.argv[2]; secs = float(sys.argv[3])
    target = int(sys.argv[4]) if len(sys.argv) > 4 and sys.argv[4] != "-" else None
    solve(m, fam, secs, target)
