"""Sample diverse 52-solutions for a fixed F (random objective weights / seeds); report Y structure."""
import sys, random, json
from collections import Counter
from ortools.sat.python import cp_model
from model import *
from lattice import blocks4
which = sys.argv[1]; reps = int(sys.argv[2]); secs = float(sys.argv[3])
if which == "costar": F = {S for S in FOUR if 8 not in S}
else:
    W = {1: 0, 2: 1, 3: 1, 4: 2, 5: 2, 6: 3, 7: 3, 8: 3}
    F = {S for S in FOUR if sum(W[x] for x in S) >= 8}
B = blocks4(F)
words = [D for S in F for D in dcycles(S)]
stats = Counter(); found = []
for rep in range(reps):
    rng = random.Random(rep)
    md = cp_model.CpModel()
    xs = [md.NewBoolVar("") for _ in B]
    byword = {}
    for j, (C, w) in enumerate(B):
        for x in C:
            if x != w: byword.setdefault(delete(C, x), []).append(xs[j])
    for vs in byword.values(): md.AddAtMostOne(vs)
    md.Add(sum(xs) >= 52)
    # random preference: penalize covering two random words -> diversify Y
    D1, D2 = rng.sample(words, 2)
    md.Add(sum(byword.get(D1, [])) == 0) if rng.random() < 0.5 else None
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = secs; s.parameters.num_workers = 2
    s.parameters.random_seed = rep
    st = s.Solve(md)
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol = [B[j] for j in range(len(B)) if s.Value(xs[j])]
        used = {delete(C, x) for C, w in sol for x in C if x != w}
        Y = [D for D in words if D not in used]
        same = len({frozenset(D) for D in Y}) == 1
        stats["same_set" if same else "different_sets"] += 1
        found.append([[list(D) for D in Y], same]); json.dump({"blocks": [[list(C), w] for C, w in sol]}, open(f"sample52_{which}_{rep}.json", "w"))
        print(rep, s.StatusName(st), "Y=", Y, "same set" if same else "DIFFERENT sets", flush=True)
    else:
        stats[s.StatusName(st)] += 1
        print(rep, s.StatusName(st), "forced-uncovered", D1, flush=True)
print(stats)
