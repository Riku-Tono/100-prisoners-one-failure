import random, sys, time
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix, csr_matrix
from model import *

def blocks_for(F):
    """feasible (C, skip) blocks: skip None means 5 words."""
    Fs = set(F)
    out = []
    for C in CYCLES:
        U = frozenset(C)
        ok = [x for x in C if U - {x} in Fs]
        if len(ok) == 5:
            for w in C:
                out.append((C, w))
            out.append((C, None))
        elif len(ok) == 4:
            w = [x for x in C if x not in ok][0]
            out.append((C, w))
    return out

def lp_bound(F, include5=True):
    B = blocks_for(F)
    if not include5:
        B = [b for b in B if b[1] is not None]
    if not B: return 0.0, 0
    A = lil_matrix((420, len(B)))
    for j, (C, w) in enumerate(B):
        for x in C:
            if x != w:
                A[WID[delete(C, x)], j] = 1
    A = csr_matrix(A)
    res = linprog(-np.ones(len(B)), A_ub=A, b_ub=np.ones(420), bounds=(0, 1), method="highs")
    return -res.fun, len(B)

def star(p): return [S for S in FOUR if p in S]
def costar(p): return [S for S in FOUR if p not in S]

if __name__ == "__main__":
    print("star", lp_bound(star(1)))
    print("costar", lp_bound(costar(1)))
    rng = random.Random(1)
    vals = []
    t = time.time()
    for k in range(int(sys.argv[1]) if len(sys.argv) > 1 else 50):
        F = [S if rng.random() < .5 else Sc for S, Sc in PAIRS]
        vals.append(round(lp_bound(F)[0], 3))
    print(sorted(vals)[-10:], max(vals), time.time() - t)
