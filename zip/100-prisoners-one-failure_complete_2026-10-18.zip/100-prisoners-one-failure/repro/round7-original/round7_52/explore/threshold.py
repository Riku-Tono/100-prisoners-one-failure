import sys, itertools, json
from collections import Counter
from model import *
from lp_survey import lp_bound
from ilp_fixedF import solve
K = int(sys.argv[1]); secs = float(sys.argv[2])
fams = {}
for w in itertools.combinations_with_replacement(range(K + 1), 8):
    if sum(w) % 2 == 0: continue
    wt = dict(zip(P, w))
    F = frozenset(S for S in FOUR if 2 * sum(wt[x] for x in S) > sum(w))
    if F not in fams: fams[F] = w
print(len(fams), "distinct threshold families (sorted weights, max", K, ")", flush=True)
res = []
for F, w in fams.items():
    lp = lp_bound(F)[0]
    if lp < 52 - 1e-6:
        continue
    st, obj, bd, t, sol = solve(F, secs)
    aut_sym = Counter(w)
    print(w, f"LP={lp:.2f}", st, obj, bd, t, flush=True)
    res.append((w, lp, st, obj, bd))
json.dump(res, open(f"threshold_K{K}.json", "w"))
