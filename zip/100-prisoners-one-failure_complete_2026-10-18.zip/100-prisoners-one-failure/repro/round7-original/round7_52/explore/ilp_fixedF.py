"""Exact ILP for a fixed family F: maximize number of blocks (C,w) [and 5-blocks]
with distinct words.  Usage: python ilp_fixedF.py pickle idx seconds"""
import sys, pickle, time
from ortools.sat.python import cp_model
from model import *
from lp_survey import blocks_for, star, costar

def solve(F, seconds=60, target=None, workers=2, hint=None, log=False):
    B = blocks_for(F)
    md = cp_model.CpModel()
    xs = [md.NewBoolVar(f"b{j}") for j in range(len(B))]
    byword = {}
    for j, (C, w) in enumerate(B):
        for x in C:
            if x != w:
                byword.setdefault(delete(C, x), []).append(xs[j])
    for D, vs in byword.items():
        md.AddAtMostOne(vs)
    # at most one block per cycle (choosing two skips for same cycle is pointless & would double count)
    bycyc = {}
    for j, (C, w) in enumerate(B):
        bycyc.setdefault(C, []).append(xs[j])
    for vs in bycyc.values():
        md.AddAtMostOne(vs)
    if target is not None:
        md.Add(sum(xs) >= target)
    else:
        md.Maximize(sum(xs))
    s = cp_model.CpSolver()
    s.parameters.max_time_in_seconds = seconds
    s.parameters.num_workers = workers
    s.parameters.log_search_progress = log
    t = time.time()
    st = s.Solve(md)
    sol = [B[j] for j in range(len(B)) if st in (cp_model.OPTIMAL, cp_model.FEASIBLE) and s.Value(xs[j])]
    return s.StatusName(st), (s.ObjectiveValue() if target is None and sol else len(sol)), s.BestObjectiveBound() if target is None else None, round(time.time() - t, 1), sol

if __name__ == "__main__":
    which = sys.argv[1]
    secs = float(sys.argv[2])
    if which == "star": F = set(star(1))
    elif which == "costar": F = set(costar(1))
    else:
        found = pickle.load(open(which, "rb"))
        F = set(found[int(sys.argv[3])][1])
    st, obj, bd, t, sol = solve(F, secs)
    print(which, st, obj, bd, t)
