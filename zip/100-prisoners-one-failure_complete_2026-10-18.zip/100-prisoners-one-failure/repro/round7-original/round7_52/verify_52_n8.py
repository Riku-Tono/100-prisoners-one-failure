"""52巡回（自由省略型・最終箱族, n=8, m=4）の独立検算。Python 3 標準ライブラリのみ。

    python -X utf8 verify_52_n8.py best52_costar_Z4_n8.json

二つの独立な経路で確かめる。

[A] 証明書の検査（補題1-4の条件を直接確認）
    - 各規則 (i; h1,h2,h3 -> b) は b が未開封かつ CF の行き先 h3 と異なる。
    - 損失4巡回 (i h1 h2 h3) が規則間ですべて異なる（命題2(a)）。
    - 損失4巡回の台集合に補集合の対が含まれない（命題2(b)）。
    - 救済対象の各5巡回について、5人中4人以上が正しい規則を持つ（補題3）。
    → 旧勝ち14,736を保持し、救済5巡回1個につき6配置を追加で勝つ。

[B] 全40,320配置の直接シミュレーション（[A]の論証を使わない）。

どちらも assert で検査し、最後に ALL CHECKS PASSED を表示する。
"""
import json
import sys
from itertools import permutations, combinations

N, LIMIT = 8, 4


def canon(c):
    c = tuple(c)
    k = c.index(min(c))
    return c[k:] + c[:k]


def load(path):
    data = json.loads(open(path, encoding="utf-8").read())
    rules = {}
    for i, h, b in data["rules"]:
        h = tuple(h)
        key = (i, h)
        assert len(h) == 3 and len({i, *h}) == 4, ("history is not a CF prefix", key)
        assert b not in (i, h[0], h[1]) and b != h[2], ("illegal or CF target", key, b)
        assert key not in rules, ("duplicate key", key)
        rules[key] = b
    return data, rules


def certificate(data, rules):
    loss = {}
    for (i, h), b in rules.items():
        D = canon((i,) + h)
        assert D not in loss, ("two rules share a loss 4-cycle", D)   # 命題2(a)
        loss[D] = (i, h, b)
    supports = {frozenset(D) for D in loss}
    full = frozenset(range(1, N + 1))
    for S in supports:
        assert full - S not in supports, ("complementary loss sets", sorted(S))  # 命題2(b)
    # 救済される5巡回：規則 (i;h->b) は5巡回 (b i h1 h2 h3) に対して正しい（補題4）
    correct = {}
    for (i, h), b in rules.items():
        C = canon((b, i) + h)
        correct.setdefault(C, set()).add(i)
    rescued = sorted(C for C, members in correct.items() if len(members) >= 4)
    return loss, supports, rescued


def simulate(rules):
    wins = cf_wins = cf_lost = 0
    by_len = {}
    for p in permutations(range(1, N + 1)):           # p[b-1] = 箱 b の中身
        succ = 0
        for i in range(1, N + 1):
            box, seen, opened = i, [], set()
            for step in range(LIMIT):
                if step == LIMIT - 1:
                    box = rules.get((i, tuple(seen)), box)
                assert box not in opened
                opened.add(box)
                v = p[box - 1]
                if v == i:
                    succ += 1
                    break
                seen.append(v)
                box = v
        seen_pts, longest = set(), 0
        for s in range(1, N + 1):
            L, x = 0, s
            while x not in seen_pts:
                seen_pts.add(x); L += 1; x = p[x - 1]
            longest = max(longest, L)
        win = succ >= N - 1
        wins += win
        cf_wins += longest <= LIMIT
        cf_lost += longest <= LIMIT and not win
        if win:
            by_len[longest] = by_len.get(longest, 0) + 1
    return wins, cf_wins, cf_lost, dict(sorted(by_len.items()))


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "best52_costar_Z4_n8.json"
    data, rules = load(path)
    loss, supports, rescued = certificate(data, rules)
    print(f"[A] rules={len(rules)}  distinct loss 4-cycles={len(loss)}  "
          f"loss supports={len(supports)} (no complementary pair)  rescued 5-cycles={len(rescued)}")
    print(f"    => by Prop.2 + Lemma 3: wins >= 14736 + 6*{len(rescued)} = {14736 + 6 * len(rescued)}")
    if "blocks" in data:
        listed = sorted(canon(C) for C, _ in data["blocks"])
        assert listed == rescued, "listed blocks differ from rescued cycles"
    wins, cf_wins, cf_lost, by_len = simulate(rules)
    print(f"[B] wins={wins}/40320  CF wins={cf_wins}  CF wins lost={cf_lost}  wins by longest cycle={by_len}")
    assert cf_wins == 14736 and cf_lost == 0
    assert by_len.get(5, 0) == 6 * len(rescued)      # 救済5巡回1個につきちょうど6配置
    assert wins == 14736 + sum(v for L, v in by_len.items() if L >= 5)
    print("ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
