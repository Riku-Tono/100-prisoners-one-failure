"""Evaluate the Round-7 necessary conditions (Cor.6, Lemma 7-9) on a saved 52-solution.
Standard library only.   python check_cuts_on_solution.py best52_costar_Z4_n8.json"""
import json, sys
from itertools import combinations, permutations
from collections import Counter
P = tuple(range(1, 9)); FULL = frozenset(P)
def canon(c):
    c = tuple(c); k = c.index(min(c)); return c[k:] + c[:k]
def dcycles(S):
    S = sorted(S); return [(S[0],) + q for q in permutations(S[1:])]
d = json.load(open(sys.argv[1]))
rules = {(i, tuple(h)): b for i, h, b in d["rules"]}
loss = Counter(canon((i,) + h) for (i, h) in rules)
assert max(loss.values()) == 1
sets_used = {frozenset(D) for D in loss}
F = set()
for S in map(frozenset, combinations(P, 4)):
    if 1 in S:
        a, b = S in sets_used, (FULL - S) in sets_used
        assert not (a and b)
        F.add(S if a or not b else FULL - S)
# rescued cycles and skips (serving rules = 4 correct rules; if 5, skip chosen arbitrarily)
correct = {}
for (i, h), b in rules.items():
    correct.setdefault(canon((b, i) + h), set()).add(i)
resc = {C: m for C, m in correct.items() if len(m) >= 4}
N = len(resc)
skip = {}
for C, mem in resc.items():
    pred = {C[k]: C[k - 1] for k in range(5)}
    omitted = [a for a in C if a not in mem] or [C[0]]
    skip[C] = pred[omitted[0]]
serving = {canon(tuple(v for v in C if v != pred_)) for C in resc for pred_ in C if pred_ != skip[C]}
Y = [D for S in F for D in dcycles(S) if D not in serving]
print("N =", N, " rules =", len(rules), " |Y| =", len(Y), " Y =", Y)
# Cor.6
c = Counter(frozenset(D) for D in loss)
print("pairs with a used side:", sum(1 for S in F if c[S] > 0), "/ 35;  usage profile:", sorted(Counter(c[S] for S in F).items()))
assert all(c[S] >= 4 * N - 204 for S in F) and sum(6 - c[S] for S in F) <= 210 - 4 * N
# Lemma 7 / 8
fval = lambda U: sum(1 for x in U if U - {x} in F)
r = Counter(frozenset(C) for C in resc)
for U, k in r.items():
    assert fval(U) >= 4 and k <= (6 if fval(U) == 4 else 7)
    if fval(U) == 4:
        u0 = next(x for x in U if U - {x} not in F)
        assert all(skip[C] == u0 for C in resc if frozenset(C) == U)
print("5-set check: f(U) of used 5-sets:", sorted(Counter(fval(U) for U in r).items()), " r(U):", sorted(Counter(r.values()).items()))
# Lemma 9: s(x)+y(x) = 0 mod 3, pair version mod 2, exact identity 6a(x) = 3deg + s + y
for x in P:
    a = sum(1 for S in F if x in S); deg = sum(1 for C in resc if x in C)
    s = sum(1 for C in resc if skip[C] == x); y = sum(1 for D in Y if x in D)
    assert 6 * a == 3 * deg + s + y, x
for x, z in combinations(P, 2):
    b = sum(1 for S in F if x in S and z in S); deg = sum(1 for C in resc if x in C and z in C)
    s = sum(1 for C in resc if x in C and z in C and skip[C] in (x, z)); y = sum(1 for D in Y if x in D and z in D)
    assert 6 * b == 2 * deg + s + y, (x, z)
print("Lemma 9 identities (point: 6a=3deg+s+y, pair: 6b=2deg+s+y) hold for all points and pairs")
print("ALL NECESSARY CONDITIONS SATISFIED")
