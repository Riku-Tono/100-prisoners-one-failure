"""Round 4 の51巡回解が、同じ族 F のまま1巡回だけ追加できるかを全探索する（標準ライブラリのみ）。

    python -X utf8 extend51_exact.py ilp_m4_rescue_capNone_cycles.csv

入力 CSV は第4ラウンド ZIP の out/ilp_m4_rescue_capNone_cycles.csv（cycle, omitted_prisoners 列）。
- F は51解の損失4巡回の台集合から決まる側（この解では「囚人1を含まない4人集合」35個）。
- 既存51巡回は残し、各巡回の省略者（スキップ）は選び直してよい。
- 追加する5巡回とスキップの組を全候補試し、既存51巡回のスキップ割当が存在するかを
  単位伝播つきバックトラックで判定する。ソルバーは使わない。
"""
import csv
import sys
from itertools import combinations, permutations

P = tuple(range(1, 9))
FULL = frozenset(P)


def canon(c):
    c = tuple(c); k = c.index(min(c)); return c[k:] + c[:k]


def dcycles(S):
    S = sorted(S); return [(S[0],) + q for q in permutations(S[1:])]


def delete(C, x):
    return canon(tuple(v for v in C if v != x))


def load(path):
    out = []
    with open(path, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            C = tuple(int(t) for t in row["cycle"].strip("()").split(","))
            o = int(row["omitted_prisoners"].strip("[]"))
            pred = {C[(k + 1) % 5]: C[k] for k in range(5)}
            out.append((canon(C), pred[o]))          # (cycle, skip = pred(omitted))
    return out


def main():
    sol = load(sys.argv[1] if len(sys.argv) > 1 else "ilp_m4_rescue_capNone_cycles.csv")
    used = [delete(C, x) for C, w in sol for x in C if x != w]
    assert len(used) == len(set(used)) == 4 * len(sol)
    supports = {frozenset(D) for D in used}
    F = set()
    for S in map(frozenset, combinations(P, 4)):
        if 1 in S:
            a, b = S in supports, (FULL - S) in supports
            assert not (a and b)
            F.add(S if a else FULL - S)                  # every pair is used in this solution
    assert len(F) == 35
    cycles = [C for C, _ in sol]
    opts0 = {C: {w: frozenset(delete(C, x) for x in C if x != w)
                 for w in C if all(frozenset(C) - {x} in F for x in C if x != w)} for C in cycles}

    def feasible(opts, taken):
        opts = {C: {w: ws for w, ws in o.items() if not (ws & taken)} for C, o in opts.items()}
        while True:
            if any(not o for o in opts.values()):
                return False
            units = [C for C, o in opts.items() if len(o) == 1]
            if not units:
                break
            C = units[0]; (w, ws), = opts[C].items(); taken = taken | ws
            del opts[C]
            opts = {D: {v: s for v, s in o.items() if not (s & ws)} for D, o in opts.items()}
        if not opts:
            return True
        C = min(opts, key=lambda C: len(opts[C]))
        rest = {D: o for D, o in opts.items() if D != C}
        return any(feasible(rest, taken | ws) for ws in opts[C].values())

    assert feasible(opts0, frozenset())                  # the saved 51 itself
    free = [D for S in F for D in dcycles(S) if D not in set(used)]
    print("free words with the saved omissions:", free)
    cand = []
    for U in map(frozenset, combinations(P, 5)):
        for C in dcycles(U):
            if C in set(cycles):
                continue
            for w in C:
                if all(U - {x} in F for x in C if x != w):
                    cand.append((C, w))
    ext = [(C, w) for C, w in cand
           if feasible(opts0, frozenset(delete(C, x) for x in C if x != w))]
    print(f"candidate extra (cycle, skip) pairs: {len(cand)}   extendable: {len(ext)}")
    print("RESULT:", "the 51-cycle solution is maximal (cannot be extended)" if not ext else ext[:5])


if __name__ == "__main__":
    main()
