"""CP-SAT model for the free-omission final-box family (n=8, m=4), written in the
variable style of Round 4 `ilp.py` (z[D,i,y], u[D], t[pair], y[C]) plus the
additional constraints proposed in Round 7.  Requires ortools.

    python cpsat_52_model.py --side costar --sym Z4 --target 52 --seconds 60
    python cpsat_52_model.py --side costar --target 52 --cuts --seconds 300
    python cpsat_52_model.py --side free   --target 52 --cuts --seconds 600

Options
  --side   free | costar | threshold   fix the complementary-pair sides t (C1)
  --sym    none | Z4                   orbit equalities under g=(1 2 3 4)(5 6) (C2)
  --target K                           require >= K rescued 5-cycles (C3)
  --cuts                               add the valid cuts C4-C6 (valid when K >= 52)
"""
import argparse
import json
import time
from itertools import combinations, permutations
from ortools.sat.python import cp_model

P = tuple(range(1, 9))


def canon(c):
    c = tuple(c); k = c.index(min(c)); return c[k:] + c[:k]


def dcycles(S):
    S = sorted(S); return [(S[0],) + q for q in permutations(S[1:])]


def rule_of(C, j):
    """final-box rule that rescues member C[j] of the 5-cycle C: key (i, hist) -> target"""
    i = C[j]
    return i, tuple(C[(j + s) % 5] for s in (1, 2, 3)), C[(j - 1) % 5]


ap = argparse.ArgumentParser()
ap.add_argument("--side", default="free", choices=["free", "costar", "threshold"])
ap.add_argument("--sym", default="none", choices=["none", "Z4"])
ap.add_argument("--target", type=int, default=None)
ap.add_argument("--cuts", action="store_true")
ap.add_argument("--seconds", type=float, default=60)
ap.add_argument("--workers", type=int, default=2)
ap.add_argument("--out", default="cpsat_52_solution.json")
ap.add_argument("--fix", default=None, help="strategy JSON whose rules are fixed (sanity check of the cuts)")
a = ap.parse_args()

md = cp_model.CpModel()
FOUR = [frozenset(S) for S in combinations(P, 4)]
z, u = {}, {}
for S in FOUR:
    for D in dcycles(S):
        u[D] = md.NewBoolVar("")
        vs = []
        for i in D:
            for y in P:
                if y not in D:
                    z[(D, i, y)] = md.NewBoolVar(""); vs.append(z[(D, i, y)])
        md.Add(sum(vs) <= u[D])                       # one rule per loss 4-cycle (Prop. 2a)

# side[S] = 1 iff S is the chosen side of its complementary pair (Prop. 2b)
side = {}
for S in FOUR:
    if 1 in S:
        t = md.NewBoolVar(""); side[S] = t; side[frozenset(P) - S] = t.Not()
for S in FOUR:
    for D in dcycles(S):
        md.AddImplication(u[D], side[S])

# (C1) fix the sides
W = {"costar": {x: (0 if x == 8 else 1) for x in P},            # F = 4-subsets of {1..7}
     "threshold": {1: 0, 2: 1, 3: 1, 4: 2, 5: 2, 6: 3, 7: 3, 8: 3}}.get(a.side)
if W:
    for S in FOUR:
        if 1 in S:
            md.Add(side[S] == (1 if 2 * sum(W[x] for x in S) > sum(W.values()) else 0))

# rescue indicators for 5-cycles (equivalence as in ilp.py)
y = {}
for U in combinations(P, 5):
    for C in dcycles(U):
        zs = []
        for j in range(5):
            i, h, tgt = rule_of(C, j)
            zs.append(z[(canon((i,) + h), i, tgt)])
        y[C] = md.NewBoolVar("")
        md.Add(4 * y[C] <= sum(zs))
        md.Add(sum(zs) <= 3 + 2 * y[C])
N5 = sum(y.values())

# (C2) symmetry g = (1 2 3 4)(5 6): orbit equalities on z (and hence y)
if a.sym == "Z4":
    g = {1: 2, 2: 3, 3: 4, 4: 1, 5: 6, 6: 5, 7: 7, 8: 8}
    for (D, i, tgt), v in z.items():
        md.Add(v == z[(canon(tuple(g[x] for x in D)), g[i], g[tgt])])

# (C3) target
if a.target:
    md.Add(N5 >= a.target)
else:
    md.Maximize(N5)

if a.cuts and a.target and a.target >= 52:
    # (C4) at least 4*K rules; every pair keeps >= 4 of its 6 words; total slack <= 210 - 4K
    md.Add(sum(u.values()) >= 4 * a.target)
    for S in FOUR:
        if 1 in S:
            Sc = frozenset(P) - S
            # slack sum_pairs (6 - c(pair)) <= 210 - 4K  =>  c(pair) >= 6 - (210 - 4K) = 4K - 204
            md.Add(sum(u[D] for D in dcycles(S)) + sum(u[D] for D in dcycles(Sc)) >= 4 * a.target - 204)
    # (C5) a rescued cycle on U needs >= 4 of the five 4-subsets of U on the chosen side (Lemma 7)
    for U in combinations(P, 5):
        U = frozenset(U)
        f = sum(side[U - {x}] for x in U)
        for C in dcycles(U):
            md.Add(f >= 4).OnlyEnforceIf(y[C])
        # (C6) local caps (Lemma 8): r(U) <= 7, and r(U) <= 6 unless all five subsets are chosen
        rU = sum(y[C] for C in dcycles(U))
        usable = md.NewBoolVar("")                    # usable <=> f(U) >= 4
        md.Add(f >= 4).OnlyEnforceIf(usable)
        md.Add(f <= 3).OnlyEnforceIf(usable.Not())
        md.Add(rU <= 7 * usable)
        md.Add(rU <= 6 + (f - 4)).OnlyEnforceIf(usable)

if a.fix:
    given = {(i, tuple(h), b) for i, h, b in json.load(open(a.fix))["rules"]}
    for (D, i, tgt), v in z.items():
        k = D.index(i)
        md.Add(v == (1 if (i, tuple(D[(k + s) % 4] for s in (1, 2, 3)), tgt) in given else 0))

s = cp_model.CpSolver()
s.parameters.max_time_in_seconds = a.seconds
s.parameters.num_workers = a.workers
t0 = time.time()
st = s.Solve(md)
print(f"side={a.side} sym={a.sym} target={a.target} cuts={a.cuts}: {s.StatusName(st)} "
      f"N5={sum(s.Value(v) for v in y.values()) if st in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None} "
      f"time={time.time() - t0:.1f}s")
if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
    rules = [[i, [D[(D.index(i) + k) % 4] for k in (1, 2, 3)], tgt] for (D, i, tgt), v in z.items() if s.Value(v)]
    json.dump({"rules": sorted(rules)}, open(a.out, "w"))
    print("saved", a.out, len(rules), "rules")
