# 第7ラウンド成果物：8人囚人問題・52巡回（2026-10-09）

> 2026-10-12公開用補記：元の説明にある `blocks` の「省略者」は正確には削除を省く点（skip）です。`blocks` と `orbit_representatives` の第2要素はskipで、省略する囚人本人はその点の巡回上の次の人です。最新の証明・実行手順は[英語検証資料](../../../docs/round7-verification.en.md)と[再現ガイド](../../../docs/reproduction.md)を参照してください。

自由省略型・最終箱族で長さ5巡回を52個救う戦略（15,048/40,320勝、CF旧勝ち14,736の喪失0）と、その検算・解析コード。
本文（補題と証明、符号理論との対応、一般 m、CP-SAT 制約）は Claude の文書「第7ラウンド：8人囚人問題・52巡回の構造解析」にある。

## 戦略ファイル（schema mixed-n8-v1、基準は第4ラウンド204規則 SHA-256 3c27c3…）

| ファイル | 族 F | 内容 |
| --- | --- | --- |
| best52_costar_Z4_n8.json | {1..7} の4元部分集合全体（囚人8は規則なし） | g=(1 2 3 4)(5 6) 不変、13軌道代表、非使用語 (1 2 3 4),(1 4 3 2) |
| best52_threshold_n8.json | 重み (0,1,1,2,2,3,3,3) の多数決族 {S : w(S) ≥ 8} | 非同型な別解 |
| best52_costar_splitY_n8.json | {1..7} の4元部分集合全体 | 非使用2語が別々の4人集合にある解 |

各ファイルの `rules` は [囚人, [h1,h2,h3], 4箱目] の208本。`rescued_cycles`/`blocks` は救済5巡回と省略者。

## 検算（Python 3 標準ライブラリのみ）

```
python -X utf8 verify_52_n8.py best52_costar_Z4_n8.json          # [A] 証明書検査 + [B] 全40320配置
python -X utf8 verify_mixed_n8.py best52_costar_Z4_n8.json --baseline round4_baseline_n8.json
python -X utf8 check_cuts_on_solution.py best52_costar_Z4_n8.json # 系6・補題7-9の条件
python -X utf8 extend51_exact.py ilp_m4_rescue_capNone_cycles.csv  # 第4ラウンド51解は延長不可
```

`verification_best52_*.json` は添付 `verify_mixed_n8.py` の出力（3解とも wins=15048, CF_old_wins_lost=0）。

## 探索（ortools 9.15）

```
python cpsat_52_model.py --side costar --sym Z4 --target 52 --seconds 60     # 約1秒で52
python cpsat_52_model.py --side threshold --target 52 --cuts --fix best52_threshold_n8.json   # 制約の妥当性確認
```

`explore/` は解析に使った補助スクリプト（F 固定のブロック型 CP-SAT、LP 調査、対称解探索、一般 m、mod p 格子計算）。
これらの出力は計算観察であり、証明としては扱わない。
