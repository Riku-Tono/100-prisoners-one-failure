"""Exhaustive local packages that rescue one directed 6-cycle.

For five of its six prisoners, choose a direct jump to the predecessor after
one, two, or three CF observations. This is a restricted package family; the
scan says nothing about unrestricted mixed strategies.
"""
from itertools import combinations, permutations, product
from pathlib import Path
import importlib.util
import json
import sys
import time

root = Path(__file__).resolve().parents[1]
source = root / "outputs" / "mixed_search_n8.py"
spec = importlib.util.spec_from_file_location("mixed_search", source)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

start = time.monotonic()
ctx = mod.Context(root / "outputs" / "round4_baseline_n8.json")
ctx.build_early_candidates()
early_index = {(c.i, c.h, c.b): k for k, c in enumerate(ctx.early_candidates)}
perm_index = {p: idx for idx, p in enumerate(ctx.perms)}
counts = {"cycles": 0, "packages": 0, "pairwise_safe": 0,
          "old_W_safe": 0, "target_rescued": 0}
best_score = -1
best_info = None
best_state = None
best_by_early = {}
late_activation_cache = {}


def repair_overlaps(i, unavoidable):
    return tuple((key, unavoidable & mask)
                 for key, mask in ctx.base_loser_rule_masks.items()
                 if key[0] != i and unavoidable & mask)

for nodes in combinations(range(1, 9), 6):
    for tail in permutations(nodes[1:]):
        cycle = (nodes[0],) + tail
        counts["cycles"] += 1
        nxt = {cycle[k]: cycle[(k + 1) % 6] for k in range(6)}
        prev = {cycle[k]: cycle[(k - 1) % 6] for k in range(6)}
        placement = list(range(1, 9))
        for i in cycle:
            placement[i - 1] = nxt[i]
        target_bit = 1 << perm_index[tuple(placement)]
        options = {}
        for i in cycle:
            h1 = (nxt[i],)
            h2 = (nxt[i], nxt[nxt[i]])
            h3 = (nxt[i], nxt[nxt[i]], nxt[nxt[nxt[i]]])
            a = early_index[(i, h1, prev[i])]
            b = early_index[(i, h2, prev[i])]
            key = (i, h3)
            late_flip = ctx.late_effect(key, prev[i])
            if key not in late_activation_cache:
                late_activation_cache[key] = sum(1 << idx for idx in ctx.prefix_ids[key])
            late_activation = late_activation_cache[key]
            late_loss = ctx.W & late_activation & ~(ctx.base_success[i - 1] ^ late_flip)
            loss_a = ctx.W & ctx.early_candidates[a].activation & ~(
                ctx.base_success[i - 1] ^ ctx.early_candidates[a].flip)
            loss_b = ctx.W & ctx.early_candidates[b].activation & ~(
                ctx.base_success[i - 1] ^ ctx.early_candidates[b].flip)
            options[i] = [
                (a, None, loss_a, repair_overlaps(i, loss_a)),
                (b, None, loss_b, repair_overlaps(i, loss_b)),
                (None, (key, prev[i]), late_loss, repair_overlaps(i, late_loss)),
            ]
        for omitted in cycle:
            chosen = tuple(i for i in cycle if i != omitted)
            selected = set(chosen)
            for stages in product((0, 1, 2), repeat=5):
                counts["packages"] += 1
                chosen_options = [options[i][stage] for i, stage in zip(chosen, stages)]
                losses = 0
                compatible = True
                for _, _, loss, _ in chosen_options:
                    if loss & losses:
                        compatible = False
                        break
                    losses |= loss
                if not compatible:
                    continue
                counts["pairwise_safe"] += 1
                early = []
                mods = {}
                for early_id, late_mod, _, _ in chosen_options:
                    if early_id is not None:
                        early.append(early_id)
                    if late_mod is not None:
                        key, value = late_mod
                        if ctx.late.get(key) != value:
                            mods[key] = value
                pre_repair = mod.State(tuple(sorted(early)), tuple(sorted(mods.items())))
                person_success = ctx.success_masks(pre_repair)
                chosen_final_keys = set(mods)
                for i, option in zip(chosen, chosen_options):
                    for key, overlap in option[3]:
                        j = key[0]
                        if overlap & ~person_success[j - 1]:
                            if key in chosen_final_keys:
                                raise AssertionError(("chosen final rule also needs deletion", cycle, key))
                            mods[key] = 0
                state = mod.State(tuple(sorted(early)), tuple(sorted(mods.items())))
                score, old_lost, winners = ctx.evaluate(state)
                if old_lost:
                    raise AssertionError((cycle, omitted, stages, old_lost))
                counts["old_W_safe"] += 1
                if not winners & target_bit:
                    continue
                counts["target_rescued"] += 1
                n_early = len(early)
                best_by_early[n_early] = max(score, best_by_early.get(n_early, -1))
                if score > best_score:
                    best_score = score
                    best_info = {"cycle": cycle, "omitted": omitted,
                                 "stages": stages, "early_rules": n_early}
                    best_state = state
    if counts["cycles"] % 840 == 0:
        print(counts, "best", best_score, flush=True)

result = {**counts, "best_score": best_score, "best": best_info,
          "best_by_early": best_by_early,
          "elapsed_seconds": round(time.monotonic() - start, 2)}
if best_state is not None:
    result["best_rules"] = ctx.rule_list(best_state)
output = root / "outputs" / "six_cycle_mixed_probe_result.json"
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(result | {"best_rules": f"{len(result.get('best_rules', []))} rules"}, flush=True)
