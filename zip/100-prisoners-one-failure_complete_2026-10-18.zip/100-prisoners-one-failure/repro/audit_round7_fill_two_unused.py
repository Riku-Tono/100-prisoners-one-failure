"""Exhaust all additions at the two unused loss cycles of each 52 solution.

Keep every one of the 208 original rules.  For each unused oriented 4-cycle,
choose no rule or one of its 4 rotations times 4 outside destinations.  The
result is a 17 x 17 exact local search, not a global final-box optimum.
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("round7_search", ROOT / "mixed_search_from52_n8.py")
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)


def options(word):
    word = tuple(word)
    outside = sorted(set(range(1, 9)) - set(word))
    return [(None, None)] + [((rotation[0], rotation[1:]), target)
            for shift in range(4)
            for rotation in [word[shift:] + word[:shift]]
            for target in outside]


def main():
    results = []
    for name in ("best52_costar_Z4_n8.json", "best52_costar_splitY_n8.json",
                 "best52_threshold_n8.json"):
        ctx = module.Context(ROOT / name)
        loss_cycles = set()
        for (i, h) in ctx.late:
            cycle = (i,) + h
            point = cycle.index(min(cycle))
            loss_cycles.add(cycle[point:] + cycle[:point])
        supports = {frozenset(cycle) for cycle in loss_cycles}
        available = set()
        from itertools import permutations
        for support in supports:
            support = sorted(support)
            available.update((support[0],) + tail for tail in permutations(support[1:]))
        unused = sorted(available - loss_cycles)
        assert len(unused) == 2
        best = (ctx.base_wins, module.State())
        wins_histogram = {}
        for first in options(unused[0]):
            for second in options(unused[1]):
                mods = []
                if first[0] is not None:
                    mods.append(first)
                if second[0] is not None:
                    mods.append(second)
                state = module.State((), tuple(sorted(mods)))
                score, old_lost, winners = ctx.evaluate(state)
                assert old_lost == 0
                wins_histogram[score] = wins_histogram.get(score, 0) + 1
                if score > best[0]:
                    best = score, state
        results.append({
            "strategy": name,
            "unused_loss_cycles": [list(word) for word in unused],
            "states_exhausted": sum(wins_histogram.values()),
            "best_wins": best[0],
            "best_new_rules": [[i, list(h), b] for (i, h), b in best[1].mods],
            "score_histogram": dict(sorted(wins_histogram.items())),
        })
    destination = ROOT / "round7_fill_two_unused_audit.json"
    destination.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for result in results:
        print({k: v for k, v in result.items() if k != "score_histogram"})


if __name__ == "__main__":
    main()
