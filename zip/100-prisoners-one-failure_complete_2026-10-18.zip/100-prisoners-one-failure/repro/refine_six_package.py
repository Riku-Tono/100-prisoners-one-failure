"""Focused one- and two-move refinements of the verified 6-cycle package."""
from pathlib import Path
import importlib.util
import json
import sys
import time

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("mixed_search", root / "outputs" / "mixed_search_n8.py")
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

start = time.monotonic()
ctx = mod.Context(root / "outputs" / "round4_baseline_n8.json")
ctx.build_early_candidates()
data = json.loads((root / "outputs" / "six_cycle_probe_strategy.json").read_text())
rules = {(i, tuple(h)): b for i, h, b in data["rules"]}
mods = {k: rules.get(k, 0) for k in ctx.late if rules.get(k) != ctx.late[k]}
mods.update({k: v for k, v in rules.items() if k not in ctx.late})
base = mod.State((), tuple(sorted(mods.items())))
assert ctx.evaluate(base)[:2] == (15038, 0)
base_winners = ctx.evaluate(base)[2]
lost = ctx.base_wins_mask & ~base_winners
lost_items = []
for idx in range(mod.TOTAL):
    if lost & (1 << idx):
        person = ctx.success_masks(base)
        losers = [i for i in range(1, 9) if not person[i-1] & (1 << idx)]
        lost_items.append({"permutation": ctx.perms[idx], "losers": losers})
print("lost baseline placements", lost_items, flush=True)

best_score = 15038
best = base
best_early = (15038, None)
single_safe = 0
top = []
for cid in range(len(ctx.early_candidates)):
    state = ctx.with_early(base, cid)
    if state is None:
        continue
    score, wlost, wins = ctx.evaluate(state)
    if wlost:
        continue
    single_safe += 1
    top.append((score, state))
    if score > best_early[0]:
        best_early = (score, cid)
    if score > best_score:
        best_score, best = score, state
top.sort(key=lambda x: x[0], reverse=True)
print("single early", single_safe, "best", best_early, flush=True)

late_keys = [key for key in ctx.prefix_ids if len(key[1]) == 3]
late_candidates = []
for key in late_keys:
    i, h = key
    opened = {i, *h[:-1]}
    for target in [0] + [b for b in range(1, 9) if b not in opened and b != h[-1]]:
        state = ctx.with_mod(base, key, target)
        if state == base:
            continue
        score, wlost, wins = ctx.evaluate(state)
        if wlost:
            continue
        late_candidates.append((score, state))
        if score > best_score:
            best_score, best = score, state
late_candidates.sort(key=lambda x: x[0], reverse=True)
print("single late", len(late_candidates), "best", late_candidates[0][0], flush=True)

# For the strongest single early states, try one more early rule. This permits
# a score-decreasing bridge and forced removal of conflicting late rules.
pair_safe = 0
for score0, state0 in top[:80]:
    for cid in range(len(ctx.early_candidates)):
        state = ctx.with_early(state0, cid)
        if state is None:
            continue
        score, wlost, wins = ctx.evaluate(state)
        if wlost:
            continue
        pair_safe += 1
        if score > best_score:
            best_score, best = score, state
print("pair early", pair_safe, "best", best_score, flush=True)

result = {"single_early_safe": single_safe,
          "single_early_best": best_early[0],
          "single_late_safe": len(late_candidates),
          "single_late_best": late_candidates[0][0],
          "pair_early_safe": pair_safe,
          "best_score": best_score,
          "best_rules": ctx.rule_list(best),
          "lost_items_from_package": lost_items,
          "states_evaluated": ctx.eval_count,
          "elapsed_seconds": round(time.monotonic() - start, 2)}
(root / "outputs" / "refine_six_package_result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print({k:v for k,v in result.items() if k != "best_rules"}, flush=True)
