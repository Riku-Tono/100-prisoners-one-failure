"""Recheck the saved strategies with Python's standard library.

Run from the repository root: python -X utf8 repro/run_verification.py
This verifies saved constructions; it does not rerun heuristic or CP-SAT searches.
"""
from __future__ import annotations

import json
import platform
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parent
OUTPUT = REPOSITORY / 'verification'


def main():
    OUTPUT.mkdir(exist_ok=True)
    original = ROOT / 'round7-original' / 'round7_52'
    round4 = ROOT / 'round4' / 'round4_cycle_packing'
    tasks = [
        ('round4-suite', round4, ['run_checks.py'], 'ALL CHECKS PASSED'),
        ('round7-certificates', ROOT, ['audit_round7_certificate.py'], 'CERTIFICATES PASS'),
    ]
    names = ['best52_costar_Z4_n8.json', 'best52_costar_splitY_n8.json', 'best52_threshold_n8.json']
    for name in names:
        label = name.removesuffix('.json')
        tasks.append((label + '-direct', ROOT,
                      ['verify_mixed_n8.py', name, '--output', f'../verification/{label}.json'],
                      '"wins": 15048'))
        tasks.append((label + '-second-implementation', original,
                      ['verify_52_n8.py', name], 'ALL CHECKS PASSED'))
    tasks += [
        ('round6-early-jump', ROOT,
         ['verify_mixed_n8.py', 'best_explored_mixed_n8.json', '--output', '../verification/round6-early-jump.json'],
         '"wins": 15030'),
        ('round6-six-cycle', ROOT,
         ['verify_mixed_n8.py', 'six_cycle_probe_strategy.json', '--output', '../verification/round6-six-cycle.json'],
         '"wins": 15038'),
        ('round7-early-jump', ROOT,
         ['verify_from52_n8.py', 'best_explored_from52_n8.json', '--output', '../verification/round7-early-jump.json'],
         '"wins": 15036'),
        ('unused-two-words-local-scan', ROOT, ['audit_round7_fill_two_unused.py'], "'best_wins': 15048"),
        ('51-cycles-cannot-be-extended', original,
         ['extend51_exact.py', str(Path('../../round4/round4_cycle_packing/out/ilp_m4_rescue_capNone_cycles.csv'))],
         'extendable: 0'),
    ]
    records = []
    for label, cwd, args, expected in tasks:
        print(f'RUN {label}', flush=True)
        start = time.perf_counter()
        completed = subprocess.run([sys.executable, '-X', 'utf8', *args], cwd=cwd,
                                   text=True, encoding='utf-8', capture_output=True)
        output = (completed.stdout + completed.stderr).replace(str(REPOSITORY), '<repository>')
        success = completed.returncode == 0 and (expected is None or expected in output)
        (OUTPUT / f'{label}.txt').write_text(output, encoding='utf-8')
        records.append({'check': label, 'passed': success,
                        'working_directory': cwd.relative_to(REPOSITORY).as_posix(),
                        'arguments': args, 'seconds': round(time.perf_counter() - start, 3),
                        'transcript': f'{label}.txt'})
        (OUTPUT / 'current_checks.json').write_text(json.dumps({
            'python': platform.python_version(),
            'checks': records,
            'all_passed': all(r['passed'] for r in records),
        }, indent=2) + '\n', encoding='utf-8')
        if not success:
            print(output)
            raise SystemExit(f'FAILED: {label}')
        print(f'PASS {label}', flush=True)
    for name in names:
        result = json.loads((OUTPUT / name).read_text(encoding='utf-8'))
        assert (result['placements'], result['wins'], result['CF_old_wins_lost'],
                result['late_rule_count'], result['early_rule_count']) == (40320, 15048, 0, 208, 0)
        assert result['wins_by_max_cycle_length'].get('5') == 312
    local = json.loads((ROOT / 'round7_fill_two_unused_audit.json').read_text(encoding='utf-8'))
    assert sum(r['states_exhausted'] for r in local) == 867
    assert all(r['best_wins'] == 15048 for r in local)
    print('ALL BUNDLE CHECKS PASSED', flush=True)


if __name__ == '__main__':
    main()
