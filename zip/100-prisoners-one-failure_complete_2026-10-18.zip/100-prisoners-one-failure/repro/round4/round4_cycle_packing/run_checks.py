"""Run the standard-library verification suite and save a reproducible transcript."""
import ast
import json
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def main():
    tasks=[
        ["anchor_graph.py","verify"],
        ["anchor_graph.py","audit"],
        ["same_set_n6.py"],
        ["build_evidence.py"],
        ["verify_solutions.py","out/ilp_m4_rescue_capNone.json",
         "out/ilp_m3_full_capNone.json","out/ilp_m3_long_capNone.json"],
    ]
    logs=[]
    for t in tasks:
        cmd=[sys.executable,"-X","utf8",*t]
        p=subprocess.run(cmd,cwd=ROOT,text=True,encoding="utf-8",capture_output=True)
        logs.append("$ python -X utf8 "+" ".join(t)+"\n"+p.stdout+p.stderr)
        if p.returncode:
            print(logs[-1]);raise SystemExit(p.returncode)
    # Reuse only function definitions and imports from the supplied verifier,
    # not its top-level experiments; compare to our saved strategies.
    script=ROOT/"inputs"/"packing_audit_Windows.py"
    tree=ast.parse(script.read_text(encoding="utf-8-sig"))
    defs=ast.Module(body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))],type_ignores=[])
    ns={}
    exec(compile(defs,str(script),"exec"),ns)
    for label in ["requested_pair","anchor_m4","ilp_m4_rescue_capNone"]:
        saved=json.loads((ROOT/"out"/(label+".json")).read_text(encoding="utf-8"))
        rd={(i,tuple(h)):y for i,h,y in saved["rules"]}
        m=saved["m"]
        cycles=[tuple(c) for c in saved.get("cycles",saved.get("rescued",[]))]
        observed=ns["evaluate"](2*m,m,rd,cycles)
        expected={ "requested_pair":(276,280,0,4,4),
                   "anchor_m4":(14736,15030,0,294,294),
                   "ilp_m4_rescue_capNone":(14736,15042,0,306,306)}[label]
        assert observed==expected,(label,observed,expected)
        logs.append(f"Supplied verifier cross-check {label}: {observed}\n")
    text="\n".join(logs)
    (ROOT/"out"/"verification_transcript.txt").write_text(text,encoding="utf-8")
    print(text)
    print("ALL CHECKS PASSED")


if __name__=="__main__":
    main()
