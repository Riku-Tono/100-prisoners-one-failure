"""Deletion-word graph for fixed-anchor packing. Standard library for verification.

python anchor_graph.py verify
python anchor_graph.py solve 3 --seconds 30
python anchor_graph.py solve 3 --force-pair --seconds 30
python anchor_graph.py solve 4 --seconds 120 --hint out/claude_anchor_m4.json

Only solve needs ortools==9.15.6755. All labels are 1-based, anchor=2m.
No early-box changes, no overwriting of incompatible keys.
"""
import argparse
import csv
import json
from collections import Counter, defaultdict
from itertools import combinations, permutations
from math import factorial, perm
from pathlib import Path

from core import rule_of, rules_dict, loss_cycle, brute_force, cycles_of, simulate

OUT = Path(__file__).resolve().parent / "out"
OUT.mkdir(exist_ok=True)


def deletions(w):
    return [w[:j] + w[j + 1:] for j in range(len(w))]


def anchor_rules(m, words):
    rs = []
    for w in words:
        c = (2*m,) + tuple(w)
        rs += [rule_of(c, j, m) for j in range(m+1) if j != 1]
    rules_dict(rs)  # reject conflicting keys, never silently overwrite
    return rs


def verify(m, words, label, save=True):
    words = [tuple(w) for w in words]
    ds = [d for w in words for d in deletions(w)]
    assert len(ds) == len(set(ds))
    rs = anchor_rules(m, words)
    assert len(rs) == len(rules_dict(rs))
    cf, wins, lost = brute_force(m, rules_dict(rs))
    assert lost == 0 and wins-cf == len(words)*factorial(m-1)
    ret = dict(label=label, m=m, words=words, cycles=[(2*m,)+w for w in words],
               rules=rs, cycle_count=len(words), cf=cf, wins=wins, lost=lost,
               support_multiplicity=dict(Counter(Counter(tuple(sorted(w)) for w in words).values())))
    if save:
        (OUT / (label+".json")).write_text(json.dumps(ret, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{label}: cycles={len(words)} rules={len(rs)} CF={cf} wins={wins} lost={lost}", flush=True)
    return ret


def graph(m, export=True):
    words = list(permutations(range(1, 2*m), m))
    buckets = defaultdict(list)
    for j, w in enumerate(words):
        for k, d in enumerate(deletions(w)):
            buckets[d].append((j, k))
    edges = defaultdict(list)
    for d, uses in buckets.items():
        for (j,k), (l,h) in combinations(uses, 2):
            # Deleted letter is the target; next letter (or anchor) is the loser.
            ij = words[j][k+1] if k+1 < m else 2*m
            il = words[l][h+1] if h+1 < m else 2*m
            kind = "key_conflict" if ij == il else "two_losers"
            edges[j,l].append((d,kind,ij,il,words[j][k],words[l][h]))
    if export:
        with (OUT/f"anchor_m{m}_vertices.csv").open("w",newline="",encoding="utf-8-sig") as f:
            wr=csv.writer(f); wr.writerow(["id","word","cycle","deletions"])
            for j,w in enumerate(words): wr.writerow([j,w,(2*m,)+w,deletions(w)])
        with (OUT/f"anchor_m{m}_edges.csv").open("w",newline="",encoding="utf-8-sig") as f:
            wr=csv.writer(f); wr.writerow(["vertex_A","vertex_B","shared_word","type","loser_A","loser_B","target_A","target_B"])
            for (j,l), causes in sorted(edges.items()):
                for d,kind,ij,il,x,y in causes: wr.writerow([j,l,d,kind,ij,il,x,y])
    return words, buckets, edges


def solve(m, seconds, force_pair, hint):
    import ortools
    from ortools.sat.python import cp_model
    words,buckets,edges=graph(m)
    model=cp_model.CpModel()
    xs=[model.new_bool_var(f"word_{j}") for j in range(len(words))]
    for uses in buckets.values():
        model.add(sum(xs[j] for j,k in uses) <= 1)
    # Equivalent to all pairwise graph constraints, using deletion-word cliques.
    if force_pair:
        assert m == 3
        for w in [(1,2,3),(3,2,1)]: model.add(xs[words.index(w)] == 1)
    if hint:
        h=json.loads(Path(hint).read_text(encoding="utf-8"))
        hw={tuple(w) for w in h["words"]}
        for j,w in enumerate(words): model.add_hint(xs[j],int(w in hw))
    model.maximize(sum(xs))
    model.export_to_file(str(OUT/(f"anchor_m{m}"+("_forced_pair" if force_pair else "")+".pbtxt")))
    solver=cp_model.CpSolver()
    solver.parameters.max_time_in_seconds=seconds
    solver.parameters.num_search_workers=2
    solver.parameters.random_seed=20261008
    log=[]
    solver.parameters.log_search_progress=True
    solver.parameters.log_to_stdout=False
    solver.log_callback=log.append
    status=solver.solve(model)
    label=f"anchor_m{m}"+("_forced_pair" if force_pair else "")
    (OUT/(label+"_solver.log")).write_text("\n".join(log),encoding="utf-8")
    result=dict(m=m, family="fixed_anchor", status=solver.status_name(status),
                objective=solver.objective_value, bound=solver.best_objective_bound,
                seconds=solver.wall_time, time_limit=seconds, workers=2,
                seed=20261008, ortools_version=ortools.__version__,
                vertices=len(words), edges=len(edges), deletion_cliques=len(buckets),
                counting_bound=perm(2*m-1,m-1)//m, force_pair=force_pair)
    if status in (cp_model.OPTIMAL,cp_model.FEASIBLE):
        chosen=[w for j,w in enumerate(words) if solver.value(xs[j])]
        result.update(verify(m,chosen,label,save=False))
        chosen_idx={j for j in range(len(words)) if solver.value(xs[j])}
        assert not any(a in chosen_idx and b in chosen_idx for a,b in edges)
    (OUT/(label+".json")).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k not in ("words","cycles","rules")},ensure_ascii=False),flush=True)


def checks():
    pair=[(1,2,3),(3,2,1)]
    result=verify(3,pair,"requested_pair")
    rd=rules_dict(anchor_rules(3,pair))
    new=[]
    for p in permutations(range(1,7)):
        if max(map(len,cycles_of(p))) > 3 and simulate(p,3,rd)>=5:
            new.append(dict(permutation=p,cycles=cycles_of(p)))
    assert len(new)==4
    (OUT/"requested_pair_new_wins.json").write_text(json.dumps(new,indent=2),encoding="utf-8")
    with (OUT/"requested_pair_rules.csv").open("w",newline="",encoding="utf-8-sig") as f:
        wr=csv.writer(f);wr.writerow(["prisoner","observed_contents","third_box","loss_cycle"])
        for r in anchor_rules(3,pair):wr.writerow([r[0],r[1],r[2],loss_cycle(r)])
    for m in (3,4):
        words,buckets,edges=graph(m)
        same=[w for w in words if set(w)==set(range(1,m+1))]
        # Direct exhaustive independent sets for six-vertex same-E anchored graph.
        if m==3:
            safe=[]
            for bits in range(1<<len(same)):
                selected=[w for j,w in enumerate(same) if bits>>j&1]
                ds=[d for w in selected for d in deletions(w)]
                if len(set(ds))==len(ds):safe.append(selected)
            assert max(map(len,safe))==2
            (OUT/"same_E_anchored_n6.json").write_text(json.dumps(dict(words=same,safe_sets=safe),indent=2),encoding="utf-8")
        print(f"anchor graph m={m}: vertices={len(words)}, edges={len(edges)}, deletion cliques={len(buckets)}",flush=True)
    # Keep all three anchor exceptions, no modification: a conflicting pair loses old wins.
    unsafe=anchor_rules(3,[(1,2,3),(1,3,2)])
    print("unsafe 123+132:",brute_force(3,rules_dict(unsafe)),flush=True)


def audit_saved():
    """Reverify every saved anchored solution and the ordered-pair upper bound."""
    for label in ("requested_pair","anchor_m3","anchor_m3_forced_pair","anchor_m4"):
        p=OUT/(label+".json")
        if not p.exists(): continue
        saved=json.loads(p.read_text(encoding="utf-8"))
        checked=verify(saved["m"],saved["words"],label,save=False)
        assert saved["wins"]==checked["wins"]
        if saved["m"]==4:
            counts=Counter((w[i],w[j]) for w in saved["words"]
                           for i in range(4) for j in range(i+1,4))
            assert len(counts)==42 and set(counts.values())=={7}
            deleted=[d for w in saved["words"] for d in deletions(tuple(w))]
            unused=set(permutations(range(1,8),3))-set(deleted)
            assert len(unused)==14
            missing_pairs=Counter((u[i],u[j]) for u in unused
                                  for i in range(3) for j in range(i+1,3))
            assert len(missing_pairs)==42 and set(missing_pairs.values())=={1}
            (OUT/"anchor_m4_unused_triples.json").write_text(json.dumps(sorted(unused),indent=2),encoding="utf-8")
            print("m=4 ordered pairs: all 42 appear in exactly 7 codewords; 14 unused triples, each ordered pair once.")


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("mode",choices=["verify","solve","audit"])
    p.add_argument("m",type=int,nargs="?",default=3)
    p.add_argument("--seconds",type=float,default=120)
    p.add_argument("--force-pair",action="store_true")
    p.add_argument("--hint")
    a=p.parse_args()
    if a.mode=="verify": checks()
    elif a.mode=="audit":audit_saved()
    else:solve(a.m,a.seconds,a.force_pair,a.hint)
