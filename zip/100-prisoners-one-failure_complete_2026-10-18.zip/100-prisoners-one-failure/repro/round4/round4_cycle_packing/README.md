# Round 4: cycle packing verification package

Read `REPORT.md` for the Japanese report. The key distinction is fixed-anchor
packing versus free omission of one prisoner per rescued cycle.

## Verified main results

| Family | n,m | Rescued cycles | Wins | CF losses |
|---|---|---:|---:|---:|
| Requested pair (6123,6321) | 6,3 | 2 | 280 | 0 |
| Keep that pair, fixed anchor | 6,3 | 4 (optimal in family) | 284 | 0 |
| Fixed anchor, unrestricted words | 6,3 | 6 (optimal in family) | 288 | 0 |
| Densify original Codex supports | 8,4 | 42 | 14988 | 0 |
| Fixed anchor, unrestricted words | 8,4 | 49 (optimal in family) | 15030 | 0 |
| Free omission, unrestricted supports | 8,4 | 51 (not proven optimal; bound 52) | 15042 | 0 |

For m=4 the fixed-anchor upper bound 49 has a short counting proof in the report.
It is not an upper bound for free-omission strategies.

## Verification without a solver

Run from this directory. Python standard library is sufficient:

```text
python -X utf8 run_checks.py
```

This runs the checks below and cross-checks the 280-, 15030-, and 15042-win
strategies using functions from the user-supplied verifier. A transcript is
saved to `out/verification_transcript.txt`. Individual commands:

```text
python -X utf8 anchor_graph.py verify
python -X utf8 anchor_graph.py audit
python -X utf8 same_set_n6.py
python -X utf8 build_evidence.py
python -X utf8 verify_solutions.py out/ilp_m4_rescue_capNone.json
python -X utf8 verify_solutions.py out/ilp_m3_full_capNone.json out/ilp_m3_long_capNone.json
```

`anchor_graph.py verify` exports the conflict graphs and checks all 720 placements
for the requested pair. `audit` checks saved anchor solutions, including all
40320 placements for the 49-cycle solution, and verifies its pair-count equality.

`same_set_n6.py` checks all 65536 safe rule subsets on E={1,2,3,4}.
`E1236_all24_rules.csv` uses the latest requested labels instead.

`build_evidence.py` verifies the original Codex supports densified to 42 cycles,
seven cycles on one fixed 5-element support, and two length-6 cycles for n=8.

## Solver

Only searches need `ortools==9.15.6755`. Install in a fresh virtual environment,
not into an existing system Python environment.

```text
python -m venv .venv
.venv\Scripts\python -m pip install ortools==9.15.6755
.venv\Scripts\python -X utf8 anchor_graph.py solve 4 --seconds 120 --hint out/anchor_m4.json
```

On Linux/macOS use `.venv/bin/python`. Search results may vary by environment.
Saved anchor JSONs record status, objective, bound, version, time, seed, workers
and the full solution. `.pbtxt` files contain the models and `*_solver.log` the
search logs. Anchor objectives count cycles; legacy `ilp_m*` objectives count
new winning placements. Verification does not depend on reproducing a search.

## Data

- `out/requested_pair*`: six rules, strategy and four newly won placements.
- `out/E1236*`: all 24 potential rules and their conflicts.
- `out/anchor_m3*`, `out/anchor_m4*`: vertices, edges, solutions, models, logs.
- `out/anchor_m4_unused_triples.json`: 14 unused deletion words.
- `out/ilp_m4_rescue_capNone*`: 51-cycle feasible strategy, no optimality claim.
- `out/ilp_m3_full_capNone*`: 290-win strategy, no optimality claim.
- `out/ilp_m3_long_capNone*`: four rescued 5-cycles.
- `out/per_set_m4.json`: witness for seven cycles on one support, before conversion
  to explicit final-box rules in `out/free_E12345_seven_cycles.json`.
- `inputs/`: unmodified copies of user-supplied Python scripts.

Japanese CSVs use UTF-8 BOM. Source files and Markdown use UTF-8.
Using `python -X utf8` is recommended on Windows.

Older capped-search intermediate files are deliberately not included.
`ilp.py` now enforces both directions of the rescue-indicator equivalence,
so a cap cannot be evaded by not counting an incidental rescue.
