"""戦略族 F_last（CF＋最終箱の例外のみ）の厳密な整数計画。要 ortools（/home/user/ortenv）。
  /home/user/ortenv/bin/python ilp.py M MODE [CAP] [TIME]
    M    : 3 または 4（n=2M）
    MODE : full   … 勝ち数そのもの（長さ m+1..2m の巡回すべて）を最大化
           rescue … 長さ m+1 の巡回の救済数だけを最大化
           long   … 長さ m+2 の巡回の救済数だけを最大化
    CAP  : 同じ (m+1) 元集合 E 上で救える (m+1) 巡回の上限（既定 none）
    TIME : 秒（既定 600）
モデル（core.py の docstring 参照）：
  z[D,i,y]  … 損失巡回 D・敗者 i・行き先 y の規則を置く
  sum_{i,y} z[D,i,y] <= 1                     （型1と型2「同じ損失巡回」の禁止）
  D と D' の頂点集合が補集合なら両方は使わない （型2「互いに素な損失巡回」の禁止）
  y_C=1 ⇔ C の L 人のうち L-1 人以上の規則あり
  勝ち = CF勝ち + Σ (n-L)! y_C
上の2制約は系B（W(CF) 保持の必要十分条件）そのもの。長い巡回を含む配置の勝敗は y_C で厳密に表せる
（巡回の外の n-L <= m-1 人は CF で必ず成功し、例外は発動しない）。"""
import sys, os, json, time
from itertools import combinations
from math import factorial
sys.path.insert(0, os.path.dirname(__file__))
from core import *
from ortools.sat.python import cp_model

m = int(sys.argv[1]); mode = sys.argv[2]
cap = None if len(sys.argv) < 4 or sys.argv[3] == "none" else int(sys.argv[3])
tlim = float(sys.argv[4]) if len(sys.argv) > 4 else 600
n = 2 * m
N = range(1, n + 1)
md = cp_model.CpModel()
z, u, Dsets = {}, {}, {}
for S in combinations(N, m):
    for D in directed_cycles(S):
        u[D] = md.NewBoolVar(f"u{D}")
        Dsets[D] = frozenset(S)
        vs = []
        for i in D:
            for y in N:
                if y in D:
                    continue
                v = md.NewBoolVar(f"z{D}{i}{y}")
                z[(D, i, y)] = v; vs.append(v)
        md.Add(sum(vs) <= u[D])
side = {}
for S in combinations(N, m):
    Sc = tuple(x for x in N if x not in S)
    if S < Sc:
        t = md.NewBoolVar(f"t{S}")
        for D in directed_cycles(S):
            md.Add(u[D] <= t)
        for D in directed_cycles(Sc):
            md.Add(u[D] <= 1 - t)

def zvar(C, j):
    i, hist, y = rule_of(C, j, m)
    return z[(canon((i,) + hist), i, y)]

ycs, obj = {}, []
Ls = {"full": range(m + 1, n + 1), "rescue": [m + 1], "long": [m + 2]}[mode]
for L in Ls:
    for S in combinations(N, L):
        group = []
        for C in directed_cycles(S):
            yv = md.NewBoolVar(f"y{C}")
            successes = sum(zvar(C, j) for j in range(L))
            md.Add((L - 1) * yv <= successes)
            # Equivalence is essential when cap is imposed: merely not counting
            # an incidental rescue must not evade the cap.
            md.Add(successes <= L - 2 + 2 * yv)
            ycs[C] = yv; group.append(yv)
            obj.append(factorial(n - L) * yv)
        if L == m + 1 and cap is not None:
            md.Add(sum(group) <= cap)
md.Maximize(sum(obj))
if os.environ.get("HINT"):
    hr = {(r[0], tuple(r[1]), r[2]) for r in json.load(open(os.environ["HINT"]))["rules"]}
    for (D, i, y), v in z.items():
        h = (i, tuple(D[(D.index(i) + s) % m] for s in range(1, m)), y)
        md.AddHint(v, 1 if h in hr else 0)
sol = cp_model.CpSolver()
sol.parameters.max_time_in_seconds = tlim
sol.parameters.num_workers = 8
t0 = time.time()
st = sol.Solve(md)
if st not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
    print(f"No incumbent: status={sol.StatusName(st)}, bound={sol.BestObjectiveBound()}")
    sys.exit(2)
rules = [(i, tuple(D[(D.index(i) + s) % m] for s in range(1, m)), y)
         for (D, i, y), v in z.items() if sol.Value(v)]
res = dict(m=m, mode=mode, cap=cap, status=sol.StatusName(st), objective=sol.ObjectiveValue(),
           bound=sol.BestObjectiveBound(), seconds=round(time.time() - t0, 1),
           rescued=[C for C, v in ycs.items() if sol.Value(v)], rules=rules)
CF = CF_WINS[m]
extra = "" if mode != "full" else f"  → 勝ち {CF + int(res['objective'])}（上界 {CF + int(res['bound'])}）"
print(f"m={m} mode={mode} cap={cap}: status={res['status']} 目的値={res['objective']} 上界={res['bound']} "
      f"時間={res['seconds']}s 規則数={len(rules)}{extra}")
os.makedirs(os.path.join(os.path.dirname(__file__), "out"), exist_ok=True)
fn = os.path.join(os.path.dirname(__file__), "out", f"ilp_m{m}_{mode}_cap{cap}.json")
json.dump(res, open(fn, "w"), ensure_ascii=False, indent=1)
print("保存:", fn)
