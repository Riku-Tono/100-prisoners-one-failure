﻿"""安全な巡回詰め込み構成の検算（標準ライブラリのみ、番号は1始まり）。
n=2m 人、各人 m 箱、2m-1 人以上成功で釈放。戦略は「巡回追跡＋最終箱の例外」。
  python3 packing_audit.py        … m=2,3,4 の全配置で構成A・構成B・補題M・定理M を照合（数秒）
  python3 packing_audit.py --m5   … 定理M の戦略を n=10 の全 3628800 配置でも照合（約1分）
例外のキーは (囚人, 最初の m-1 箱で見た番号の列)、値は最後に開ける箱。"""
import itertools, random, sys
sys.stdout.reconfigure(encoding="utf-8")
from math import factorial, comb

def simulate(p, n, m, rules):
    """失敗した囚人の数（p[b] は箱 b の中の番号）"""
    fails = 0
    for i in range(1, n + 1):
        box, seen, opened, ok = i, [], set(), False
        for step in range(1, m + 1):
            if step == m: box = rules.get((i, tuple(seen)), box)
            assert box not in opened                      # 同じ箱を再度開けない
            opened.add(box); v = p[box]
            if v == i: ok = True; break
            seen.append(v); box = v
        fails += not ok
    return fails
def longest_cycle(p, n):
    seen, best = set(), 0
    for i in range(1, n + 1):
        L, j = 0, i
        while j not in seen: seen.add(j); j = p[j]; L += 1
        best = max(best, L)
    return best
def K_rule(K, v, m):
    """巡回 K の元 v の K 例外：K を m-1 歩たどった列がキー、K での直前の元の箱が行き先"""
    L, j = len(K), K.index(v)
    return (v, tuple(K[(j + t) % L] for t in range(1, m))), K[(j - 1) % L]
def contains(p, K): return all(p[K[t]] == K[(t + 1) % len(K)] for t in range(len(K)))
def evaluate(n, m, rules, cycles):
    cf = s = lost = new = new_in = 0
    for pm in itertools.permutations(range(1, n + 1)):
        p = dict(zip(range(1, n + 1), pm))
        old = longest_cycle(p, n) <= m
        win = simulate(p, n, m, rules) <= 1
        cf += old; s += win; lost += old and not win
        if win and not old: new += 1; new_in += any(contains(p, K) for K in cycles)
    return cf, s, lost, new, new_in
def anchor_rules(m, cycles):
    """錨つき設計：各巡回 K=(a p1 ... pm) で、a の次の p1 以外の m 人に K 例外。キーが矛盾したら None"""
    rules = {}
    for K in cycles:
        for v in K:
            if v == K[1]: continue
            k, t = K_rule(K, v, m)
            if rules.get(k, t) != t: return None
            rules[k] = t
    return rules
def deletions(w): return [w[:t] + w[t + 1:] for t in range(len(w))]
def code_condition(words):
    seen = set()
    for w in words:
        for u in deletions(w):
            if u in seen: return False
            seen.add(u)
    return True

rnd = random.Random(2026)
print("== 構成A：長さ L の巡回 K を1つ固定し、K の全員に K 例外 ==")
for m in (2, 3, 4):
    n = 2 * m
    for L in range(m + 1, 2 * m + 1):
        K = tuple(rnd.sample(range(1, n + 1), L))
        rules = dict(K_rule(K, v, m) for v in K)
        cf, s, lost, new, new_in = evaluate(n, m, rules, [K])
        note = "" if L < 2 * m else "  ← 範囲外（L=2m）"
        print(f"  m={m} L={L}: CF={cf} S={s} 喪失={lost} 新規={new} うちKを含む={new_in} (2m-L)!={factorial(n - L)}{note}")
        if L < 2 * m: assert lost == 0 and new == new_in == factorial(n - L)
        else: assert lost == m

print("== 構成B：錨 a、共通部分 m-1 以下の集合族、各集合に巡回順1つ（ランダム） ==")
for m in (2, 3, 4):
    n = 2 * m; a = rnd.randint(1, n)
    cand = [frozenset((a,) + r) for r in itertools.combinations([x for x in range(1, n + 1) if x != a], m)]
    rnd.shuffle(cand); fam = []
    for E in cand:
        if all(len(E & F) <= m - 1 for F in fam): fam.append(E)
    cycles = []
    for E in fam:
        rest = [x for x in E if x != a]; rnd.shuffle(rest); cycles.append((a,) + tuple(rest))
    rules = anchor_rules(m, cycles); assert rules is not None
    cf, s, lost, new, new_in = evaluate(n, m, rules, cycles)
    print(f"  m={m} a={a}: 集合{len(fam)} (貪欲の保証 {comb(2*m-1,m)/(1+m*(m-1)):.2f} 以上, 上限 {comb(2*m-1,m)//m}) 例外{len(rules)} CF={cf} S={s} 喪失={lost} 新規={new} うちK(E)を含む={new_in}")
    assert lost == 0 and new == new_in == len(fam) * factorial(m - 1)

print("== 補題M：符号条件 ⇔ 安全（n=6、ランダムな族200個） ==")
m, n, stat = 3, 6, {}
for trial in range(200):
    a = rnd.randint(1, n); others = [x for x in range(1, n + 1) if x != a]
    allw = list(itertools.permutations(others, m)); k = rnd.choice([2, 3, 4, 5, 6])
    if trial % 2: words = rnd.sample(allw, k)
    else:
        rnd.shuffle(allw); words, used = [], set()
        for w in allw:
            if not any(u in used for u in deletions(w)): words.append(w); used.update(deletions(w))
            if len(words) == k: break
    cond = code_condition(words); cycles = [(a,) + w for w in words]; rules = anchor_rules(m, cycles)
    if rules is None: out = "キーが矛盾"
    else:
        cf, s, lost, new, new_in = evaluate(n, m, rules, cycles)
        out = "安全" if lost == 0 else "W(CF)を失う"
        if lost == 0: assert new == new_in == len(words) * factorial(m - 1)
    stat[(cond, out)] = stat.get((cond, out), 0) + 1
    assert cond == (out == "安全")
print("  (符号条件, 結果) → 件数:", stat)

print("== 定理M：和 mod (2m-1) と Σ t*[p(t)>p(t+1)] mod m によるクラス分け ==")
best = {}
for m in (2, 3, 4, 5, 6):
    N = 2 * m - 1; cls = {}
    for w in itertools.permutations(range(N), m):
        cls.setdefault((sum(w) % N, sum(t * (w[t - 1] > w[t]) for t in range(1, m)) % m), []).append(w)
    assert all(code_condition(c) for c in cls.values())
    sizes = sorted(len(c) for c in cls.values()); best[m] = max(cls.values(), key=len)
    # 1つの集合の上：m 文字の順列を符号列のクラスに分ける
    one = {}
    for w in itertools.permutations(range(m)):
        one.setdefault(sum(t * (w[t - 1] > w[t]) for t in range(1, m)) % m, []).append(w)
    assert all(code_condition(c) for c in one.values()) and max(len(c) for c in one.values()) >= factorial(m - 1)
    print(f"  m={m}: 語{factorial(N)//factorial(m-1)} クラス{len(cls)} 全クラスが符号条件を満たす  クラスの大きさ {sizes[0]}〜{sizes[-1]}  (2m-2)!/m!={factorial(2*m-2)//factorial(m)}  上限{(factorial(N)//factorial(m))//m}  | 1集合上の最大クラス {max(len(c) for c in one.values())} = (m-1)! = {factorial(m-1)}")
for m in (3, 4) + ((5,) if "--m5" in sys.argv else ()):
    n = 2 * m; a = n
    cycles = [(a,) + tuple(x + 1 for x in w) for w in best[m]]
    rules = anchor_rules(m, cycles); assert rules is not None
    cf, s, lost, new, new_in = evaluate(n, m, rules, cycles)
    print(f"  戦略 m={m}: 巡回{len(cycles)} 例外{len(rules)} CF={cf} S={s} 喪失={lost} 新規={new} うちKを含む={new_in}  ΔP={new}/{factorial(n)} (1/(2m^2(2m-1)) = 1/{2*m*m*(2*m-1)})")
    assert lost == 0 and new == new_in == len(cycles) * factorial(m - 1) and new * 2 * m * m * (2 * m - 1) == factorial(n)

print("== 探索で得た大きい錨つき設計（錨は n） ==")
MAX3 = [(6, 1, 3, 2), (6, 2, 1, 5), (6, 2, 3, 4), (6, 3, 5, 1), (6, 4, 5, 2), (6, 5, 4, 3)]
MAX4 = [(8, 1, 3, 7, 2), (8, 1, 4, 3, 6), (8, 1, 5, 2, 6), (8, 1, 5, 7, 4), (8, 1, 6, 4, 2), (8, 1, 6, 7, 5), (8, 1, 7, 6, 3), (8, 2, 1, 4, 5), (8, 2, 3, 6, 5), (8, 2, 5, 1, 6), (8, 2, 5, 3, 7), (8, 2, 6, 1, 3), (8, 2, 6, 4, 7), (8, 2, 7, 4, 6), (8, 3, 2, 4, 1), (8, 3, 2, 7, 5), (8, 3, 4, 2, 6), (8, 3, 5, 1, 2), (8, 3, 5, 6, 4), (8, 3, 6, 1, 7), (8, 3, 7, 1, 6), (8, 4, 1, 2, 7), (8, 4, 1, 5, 3), (8, 4, 2, 3, 1), (8, 4, 3, 5, 7), (8, 4, 6, 2, 5), (8, 4, 6, 7, 1), (8, 4, 7, 3, 2), (8, 4, 7, 5, 6), (8, 5, 1, 4, 7), (8, 5, 2, 3, 4), (8, 5, 2, 7, 1), (8, 5, 4, 6, 3), (8, 5, 6, 7, 2), (8, 5, 7, 3, 6), (8, 6, 1, 2, 4), (8, 6, 2, 7, 3), (8, 6, 3, 1, 5), (8, 6, 3, 7, 4), (8, 6, 4, 5, 1), (8, 6, 5, 3, 2), (8, 7, 1, 2, 5), (8, 7, 1, 3, 4), (8, 7, 2, 4, 3), (8, 7, 4, 5, 2), (8, 7, 5, 3, 1), (8, 7, 6, 2, 1), (8, 7, 6, 5, 4)]
for m, cyc in ((3, MAX3), (4, MAX4)):
    n = 2 * m; cycles = [tuple(K) for K in cyc]
    assert code_condition([K[1:] for K in cycles])
    rules = anchor_rules(m, cycles); cf, s, lost, new, new_in = evaluate(n, m, rules, cycles)
    print(f"  m={m}: 巡回{len(cycles)} CF={cf} S={s} 喪失={lost} 新規={new} うちKを含む={new_in}")
    assert lost == 0 and new == new_in == len(cycles) * factorial(m - 1)
print("すべての照合が一致しました。")
