"""n=6, m=3, 5人以上成功：例外ルールの損失衝突の検算（標準ライブラリのみ、番号は1始まり）。
  python3 collision_check.py          … 主要な表を再現（数秒）
  python3 collision_check.py --all9   … 18例外から9個を選ぶ48620通りの喪失数分布も計算（1〜2分）
戦略は「巡回追跡＋例外」。例外のキーは (囚人, 履歴)、履歴は (箱, 中身) の列、値は次に開ける箱。"""
import itertools, sys
from collections import Counter, defaultdict
N, M = 6, 3
PERMS = [dict(zip(range(1, N+1), pm)) for pm in itertools.permutations(range(1, N+1))]

# ---- Perplexity版：4巡回 (q1 q2 q3 q4) を救う最終箱の例外 ----
RESCUES = [((1,4,2,5),(1,4,2)), ((1,4,3,5),(1,4,3)), ((1,5,2,4),(1,5,2)),
           ((1,5,3,4),(1,5,3)), ((1,5,4,6),(1,4,6)), ((1,6,4,5),(1,6,5))]
def build_px(rescues):
    E = {}
    for c, who in rescues:
        for j in range(4):
            i, a, b, d = c[j], c[(j+1)%4], c[(j+2)%4], c[(j+3)%4]
            if i in who: E[(i, ((i,a),(a,b)))] = d
    return E
# ---- Claude版（294）：2箱目の例外 EXC2 と3箱目の例外 EXC3 ----
EXC2 = {(1,4):5, (4,5):1, (5,1):4}
EXC3 = {(1,2,4):5,(1,3,4):5,(1,4,2):2,(1,4,3):3,(1,4,5):2,(1,4,6):6,(1,5,4):2,(1,6,4):5,(4,2,5):1,(4,3,5):1,(4,5,1):2,
        (4,5,2):2,(4,5,3):3,(4,5,6):6,(4,6,5):1,(5,1,2):2,(5,1,3):3,(5,1,4):6,(5,1,6):6,(5,2,1):4,(5,3,1):4,(5,6,1):4}
def build_claude():
    E = {}
    for (i,c1), b2 in EXC2.items(): E[(i, ((i,c1),))] = b2
    for (i,c1,c2), b3 in EXC3.items():
        b2 = EXC2.get((i,c1), c1)
        if b3 != c2: E[(i, ((i,c1),(b2,c2)))] = b3      # 既定動作（直前に見た番号の箱）と違うものだけ残す
    return E

def run(i, p, E):
    """囚人 i の履歴と成否"""
    h, opened = (), set()
    for _ in range(M):
        b = E.get((i, h), i if not h else h[-1][1])
        assert b not in opened
        opened.add(b); h += ((b, p[b]),)
        if p[b] == i: return h, True
    return h, False
def cyc(p, i):
    c = [i]; j = p[i]
    while j != i: c.append(j); j = p[j]
    return tuple(c)
def canon(c):
    k = c.index(min(c)); return c[k:] + c[:k]
WCF = [p for p in PERMS if all(len(cyc(p, i)) <= M for i in range(1, N+1))]
def losers(p, E): return [i for i in range(1, N+1) if not run(i, p, E)[1]]
def wins(E): return sum(1 for p in PERMS if len(losers(p, E)) <= 1)
def lost(E): return sum(1 for p in WCF if len(losers(p, E)) >= 2)
def contains(p, P): return all(p[b] == c for b, c in P)
def arrows(c): return frozenset((c[k], c[(k+1) % len(c)]) for k in range(len(c)))
def is_loss_cycle(i, z, E):
    """巡回 z を含むすべての配置で囚人 i が失敗するか（＝損失が巡回だけで決まるか）"""
    A = arrows(z); return all(not contains(p, A) or not run(i, p, E)[1] for p in PERMS)
def loss_structure(E):
    pure, hist = defaultdict(set), defaultdict(set)
    for p in WCF:
        for i in losers(p, E):
            z = canon(cyc(p, i))
            (pure if is_loss_cycle(i, z, E) else hist)[z].add(i)
    return pure, hist

EP, EC = build_px(RESCUES), build_claude()
print("W(CF) =", len(WCF))
for name, E in [("巡回追跡", {}), ("Perplexity版", EP), ("Claude版", EC),
                ("Claude版＋救済3,4,5", {**EC, **build_px(RESCUES[2:5])}),
                ("Claude版＋救済1,2,6", {**EC, **build_px([RESCUES[0], RESCUES[1], RESCUES[5]])}),
                ("Claude版＋18例外", {**EC, **EP})]:
    print(f"{name}: 例外{len(E)} 勝ち{wins(E)} W(CF)喪失{lost(E)}")
print("救済を3つ足したときの喪失:", sorted(lost({**EC, **build_px([RESCUES[j] for j in s])}) for s in itertools.combinations(range(6), 3)))

pp, hp = loss_structure(EP); pc, hc = loss_structure(EC)
print("\n損失巡回 -> 敗者   P版 / C版 / C版(履歴依存)")
for z in sorted(set(pp) | set(pc) | set(hc), key=lambda z: (len(z), tuple(sorted(z)), z)):
    print("  ", z, sorted(pp.get(z, [])), sorted(pc.get(z, [])), sorted(hc.get(z, [])))
sup = {tuple(sorted(z)) for z in set(pp) | set(pc) | set(hc)}
print("元の集合はすべて 1,4,5 のうち2つ以上を含む:", all(len({1,4,5} & set(s)) >= 2 for s in sup))

print("\nPerplexity版の例外を1個ずつ Claude版に足したときの喪失")
tot = 0
for r, (c, who) in enumerate(RESCUES, 1):
    for k, v in build_px([(c, who)]).items():
        E = dict(EC); E[k] = v; l = lost(E); tot += l
        i, h = k
        reach = any(run(i, p, EC)[0][:2] == h for p in PERMS)
        print(f"   救済{r} 囚人{i}: {h[0][0]}→{h[0][1]}, {h[1][0]}→{h[1][1]} ⇒ 箱{v}  損失巡回{canon((i, h[0][1], h[1][1]))}  喪失{l}  C版で到達可能:{reach}  C版の同キー:{EC.get(k)}")
print("   合計", tot)

# 衝突の型の内訳
def classify(E):
    pure, _ = loss_structure(E); cnt = Counter()
    for p in WCF:
        L = losers(p, E)
        if len(L) < 2: continue
        kinds = set()
        for i, k in itertools.combinations(L, 2):
            zi, zk = canon(cyc(p, i)), canon(cyc(p, k))
            if not (i in pure.get(zi, ()) and k in pure.get(zk, ())): kinds.add("履歴依存")
            elif zi == zk: kinds.add("同じ巡回")
            else: kinds.add("互いに素な巡回")
        cnt["+".join(sorted(kinds))] += 1
    return dict(cnt)
print("\n衝突の型  救済3,4,5:", classify({**EC, **build_px(RESCUES[2:5])}), " 18例外:", classify({**EC, **EP}))
E = dict(EC); E[(2, ((2,3),(3,6)))] = 1
print("Claude版＋(囚人2: 2→3, 3→6 ⇒ 箱1): 勝ち", wins(E), "喪失", lost(E), classify(E))

if "--all9" in sys.argv:
    keys = sorted(EP); cnt = Counter()
    for sub in itertools.combinations(range(18), 9):
        E = dict(EC); E.update({keys[j]: EP[keys[j]] for j in sub}); cnt[lost(E)] += 1
    print("\n9例外の選び方48620通りの喪失数の分布:", sorted(cnt.items()))
