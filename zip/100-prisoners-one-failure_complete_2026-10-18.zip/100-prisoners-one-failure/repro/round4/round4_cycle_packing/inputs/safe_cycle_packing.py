"""Construct and verify safe final-box exceptions for n=2m.

This script enumerates all permutations only for m=3 and m=4. The general
claims in the accompanying note have separate combinatorial proofs.
"""

from itertools import combinations, permutations
from math import factorial


def rule_for(K, i, m):
    index = K.index(i)
    L = len(K)
    history = tuple(K[(index + step) % L] for step in range(1, m))
    target = K[(index - 1) % L]
    return (i, history), target


def single_long_rules(m, L):
    K = tuple(range(1, L + 1))
    return {key: box for i in K for key, box in [rule_for(K, i, m)]}, K


def greedy_supports(m):
    n = 2 * m
    selected = []
    for rest in combinations(range(2, n + 1), m):
        E = frozenset((1, *rest))
        if all(len(E & other) <= m - 1 for other in selected):
            selected.append(E)
    return selected


def packed_rules(m):
    supports = greedy_supports(m)
    rules = {}
    cycles = []
    for E in supports:
        K = tuple(sorted(E))
        cycles.append(K)
        # Omit the successor of the anchor. The other m loss cycles all contain 1.
        for i in K:
            if i == K[1]:
                continue
            key, target = rule_for(K, i, m)
            assert key not in rules
            rules[key] = target
    return rules, cycles


def max_cycle_length(p):
    unseen = set(range(1, len(p) + 1))
    longest = 0
    while unseen:
        start = current = min(unseen)
        length = 0
        while current in unseen:
            unseen.remove(current)
            length += 1
            current = p[current - 1]
        assert current == start
        longest = max(longest, length)
    return longest


def success_count(p, m, rules):
    n = len(p)
    successes = 0
    for i in range(1, n + 1):
        box = i
        opened = set()
        seen = []
        for step in range(1, m + 1):
            if step == m:
                box = rules.get((i, tuple(seen)), box)
            assert box not in opened, (i, p, box)
            opened.add(box)
            value = p[box - 1]
            if value == i:
                successes += 1
                break
            seen.append(value)
            box = value
    return successes


def contains_cycle(p, K):
    return all(p[K[j] - 1] == K[(j + 1) % len(K)] for j in range(len(K)))


def audit(m, kind):
    n = 2 * m
    if kind == "long":
        rules, K = single_long_rules(m, m + 2)
        cycles = [K]
    else:
        rules, cycles = packed_rules(m)
    old_wins = new_wins = lost = guaranteed = 0
    for p in permutations(range(1, n + 1)):
        old = max_cycle_length(p) <= m
        new = success_count(p, m, rules) >= n - 1
        old_wins += old
        new_wins += new
        lost += old and not new
        guaranteed += (not old) and any(contains_cycle(p, K) for K in cycles)
    new_only = new_wins - old_wins + lost
    expected = len(cycles) * factorial(n - len(cycles[0]))
    assert lost == 0
    assert new_only >= expected
    assert guaranteed == expected
    print(f"m={m} {kind}: cycles={len(cycles)}, rules={len(rules)}, "
          f"CF={old_wins}, new={new_wins}, lost={lost}, "
          f"new_only={new_only}, guaranteed={expected}")
    if m == 3 and kind == "packing":
        print("selected cycles:", cycles)


if __name__ == "__main__":
    for m in (3, 4):
        audit(m, "long")
        audit(m, "packing")
