"""課題1〜4：n=6, m=3、固定した4元集合 E={1,2,3,4} 上の向きつき4巡回6種類。
  python3 same_set_n6.py
出力：救済に必要な例外と損失巡回の表、衝突グラフ（規則間・巡回間）、
      省略を許した安全な組合せの全列挙（65,536通り）と勝ち数、具体例の全配置検算。"""
import itertools, csv, os, sys
from collections import Counter, defaultdict
sys.path.insert(0, os.path.dirname(__file__))
from core import *

m, n = 3, 6
E = (1, 2, 3, 4)
OUT = os.path.join(os.path.dirname(__file__), "out")
os.makedirs(OUT, exist_ok=True)
Ks = directed_cycles(E)  # 6種類
name = {K: "K%d" % (t + 1) for t, K in enumerate(Ks)}
rev = lambda K: canon(K[::-1])

print("== 表1：各4巡回の救済例外と損失巡回 ==")
rules = []  # (Kname, j, rule)
rows = []
for K in Ks:
    for j in range(4):
        r = rule_of(K, j, m)
        omitted = r[2]  # 損失巡回に入らない E の元 = 行き先
        rules.append((K, j, r))
        rows.append([name[K], K, r[0], f"{r[0]}→{r[1][0]}, {r[1][0]}→{r[1][1]}", r[2],
                     loss_cycle(r), omitted])
        print(f"{name[K]} {K}  囚人{r[0]}: 箱{r[0]}→{r[1][0]}, 箱{r[1][0]}→{r[1][1]} ⇒ 箱{r[2]}"
              f"   損失巡回 {loss_cycle(r)}（敗者{r[0]}、E から {omitted} を抜いた順序）")
with open(os.path.join(OUT, "n6_E1234_rules.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["巡回名", "巡回", "囚人", "履歴", "行き先", "損失巡回", "抜いた元"]); w.writerows(rows)

print("\n逆向きの対:", [(name[K], name[rev(K)]) for K in Ks if K < rev(K)])

# ---- 衝突グラフ：規則間 ----
print("\n== 表2：規則間の衝突（24規則） ==")
edges = []
for (K, j, r), (K2, j2, r2) in itertools.combinations(rules, 2):
    if K == K2:
        continue
    same_key = key(r) == key(r2)
    same_D = loss_cycle(r) == loss_cycle(r2)
    disjoint = not (set(loss_cycle(r)) & set(loss_cycle(r2)))
    if same_key and r[2] != r2[2]:
        t = "型1:同キー別行き先"
    elif same_key:
        t = "同一規則"
    elif same_D:
        t = "型2:同じ損失巡回に別の敗者"
    elif disjoint:
        t = "型2:互いに素な損失巡回"
    else:
        continue
    edges.append((name[K], r, name[K2], r2, t))
cnt = Counter(e[4] for e in edges)
print("辺の種類:", dict(cnt))
for e in edges:
    print(f"  {e[0]} 囚人{e[1][0]} 損失{loss_cycle(e[1])}  ×  {e[2]} 囚人{e[3][0]} 損失{loss_cycle(e[3])}   [{e[4]}]")
with open(os.path.join(OUT, "n6_E1234_conflicts.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["巡回A", "囚人A", "損失巡回", "巡回B", "囚人B", "種類"])
    for e in edges:
        w.writerow([e[0], e[1][0], loss_cycle(e[1]), e[2], e[3][0], e[4]])

# ---- 巡回間：共有する「損失巡回スロット」 ----
print("\n== 表3：巡回間で共有する損失巡回（スロット） ==")
slots_of = {K: {loss_cycle(rule_of(K, j, m)): rule_of(K, j, m)[0] for j in range(4)} for K in Ks}
pair_share = {}
for K, K2 in itertools.combinations(Ks, 2):
    sh = sorted(set(slots_of[K]) & set(slots_of[K2]))
    pair_share[(K, K2)] = sh
    print(f"  {name[K]}{K} – {name[K2]}{K2}: 共有 {len(sh)}  {sh}"
          + ("  （逆向き）" if K2 == rev(K) else ""))
print("スロット（向きつき3巡回）数 =", len({d for K in Ks for d in slots_of[K]}),
      "／各スロットを使う巡回数 =", Counter(Counter(d for K in Ks for d in slots_of[K]).values()))

# ---- 省略を許した安全な組合せの全列挙 ----
# 安全（276勝保持）⇔ 各スロットを使う規則が高々1個（E 内では補集合の衝突はない）
by_slot = defaultdict(list)
for K, j, r in rules:
    by_slot[loss_cycle(r)].append((K, r))
slots = sorted(by_slot)
print("\n== 省略を許した組合せ ==")
dist = Counter()
best = []
for choice in itertools.product(*[[None] + by_slot[s] for s in slots]):
    chosen = [c for c in choice if c]
    nr = Counter(K for K, _ in chosen)
    rescued = tuple(sorted(name[K] for K in Ks if nr[K] >= 3))
    dist[len(rescued)] += 1
    if len(rescued) == 2:
        best.append((rescued, tuple(sorted((name[K], r[0]) for K, r in chosen))))
print("安全な組合せの総数:", sum(dist.values()), " 救済数の分布:", dict(sorted(dist.items())))
pairs = Counter(b[0] for b in best)
print("2巡回を救える組（巡回の対: 組合せ数）:", dict(pairs))

# 安全性の判定がシミュレーションと一致することを、全列挙の一部（各救済数から）で確認
print("\n== 具体例の全720配置検算 ==")
def check(label, rs):
    rd = rules_dict(rs)
    cf, new, lost = brute_force(m, rd)
    lw, lost2 = fast_eval(m, rs)
    assert (cf, lost) == (276, lost2) and new == 276 - lost + lw
    print(f"  {label}: 例外{len(rd)}  勝ち{new}  CF勝ちの喪失{lost}")
    return new, lost

K1 = (1, 2, 3, 4); K3 = (1, 3, 2, 4); K6 = (1, 4, 3, 2)
print("  K1, K3 が共有するスロット:", pair_share[(K1, K3)] if (K1, K3) in pair_share else pair_share[(K3, K1)])
full = lambda K, skip=(): [rule_of(K, j, m) for j in range(4) if K[j] not in skip]
check("K1 のみ全4規則", full(K1))
check("K1 と逆向き K6 を全4規則ずつ", full(K1) + full(K6))
# K1=(1 2 3 4) と K3=(1 3 2 4) は (1 2 4)(1 3 4) を共有。各自1つずつ省略
check("K1（囚人3省略）＋K3（囚人2省略）", full(K1, (3,)) + full(K3, (2,)))
check("K1, K3 を全規則（衝突させる）", full(K1) + full(K3))
check("K1, K6, K3 を各全規則（3巡回）", full(K1) + full(K6) + full(K3))
