"""3種類の衝突の区別（n=2m、戦略族 F_last、m+1 巡回の救済規則すべて）。
  python3 conflict_types.py 3     （m=4 も可）
規則 (K,x)：巡回 K で x の次の囚人が、最後の箱を x にする。損失巡回 D = K\\x、敗者 = succ_K(x)。
  型1  同じ履歴キー（同じ囚人・同じ履歴）に別の行き先   ⇔ D と敗者が同じで x が違う
  型2a 同じ配置で別の囚人が損をする（同じ損失巡回、敗者が違う）
  型2b 同じ配置で別の囚人が損をする（損失巡回の頂点集合が互いに補集合）
  型3  上書き・遮蔽：F_last では最後の箱より前は常に CF なので、遮蔽（到達不能化）は起きない。
       上書きは型1を「どちらか一方を採用」で解消した結果として現れ、損失は増えないが救済が消える。"""
import sys, os
from itertools import combinations
from collections import Counter
sys.path.insert(0, os.path.dirname(__file__))
from core import *
m = int(sys.argv[1]) if len(sys.argv) > 1 else 3
n = 2 * m
Ks = [K for S in combinations(range(1, n + 1), m + 1) for K in directed_cycles(S)]
by_D = {}
for K in Ks:
    for j in range(m + 1):
        r = rule_of(K, j, m)
        by_D.setdefault(loss_cycle(r), []).append((K, r))
cnt = Counter()
for D, lst in by_D.items():
    for (K, r), (K2, r2) in combinations(lst, 2):
        sameE = set(K) == set(K2)
        if key(r) == key(r2):
            t = "型1 同キー別行き先"
        else:
            t = "型2a 同じ損失巡回・別の敗者"
        cnt[(t, "同じE" if sameE else f"|E∩F|={len(set(K)&set(K2))}")] += 1
print(f"m={m}: (m+1)巡回 {len(Ks)}, 規則 {len(Ks)*(m+1)}, 損失巡回（スロット）{len(by_D)}")
print("  各スロットを使う規則数:", Counter(len(v) for v in by_D.values()))
for k, v in sorted(cnt.items()):
    print("  ", k, v)
# 型2b：補集合の損失巡回。同じ E 内では起きない（E 内の m 元集合はすべて交わる）
sameE_comp = 0
for K in Ks:
    Ds = [frozenset(loss_cycle(rule_of(K, j, m))) for j in range(m + 1)]
    sameE_comp += sum(1 for a, b in combinations(Ds, 2) if not a & b)
print("  同じ巡回内の型2b:", sameE_comp, "（m>=2 なら常に0）")
