"""Generate report tables and simple independent constructions; no solver needed."""
import csv
import json
from collections import Counter
from itertools import combinations, permutations, product
from pathlib import Path
from core import *
from anchor_graph import verify, anchor_rules, deletions

OUT=Path(__file__).resolve().parent/"out"


def save_strategy(label,m,rs,cycles):
    rd=rules_dict(rs)
    cf,wins,lost=brute_force(m,rd)
    ds=[loss_cycle(r) for r in rs]
    assert len(ds)==len(set(ds))
    assert all(set(a)&set(b) for a,b in combinations(ds,2))
    assert lost==0
    result=dict(label=label,m=m,rules=rs,cycles=cycles,cf=cf,wins=wins,lost=lost)
    (OUT/(label+".json")).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    print(label, "rules",len(rd),"CF",cf,"wins",wins,"lost",lost)
    return result


def densify_codex(m):
    # Exactly Codex's original greedy supports, anchor=1.
    supports=[]
    for rest in combinations(range(2,2*m+1),m):
        E=frozenset((1,)+rest)
        if all(len(E&F)<=m-1 for F in supports):supports.append(E)
    cycles=[]
    for E in supports:
        words=[w for w in permutations(sorted(E-{1}))
               if sum(j*(w[j-1]>w[j]) for j in range(1,m))%m==0]
        assert len(words)==factorial(m-1)
        cycles.extend((1,)+w for w in words)
    rs=[rule_of(c,j,m) for c in cycles for j in range(m+1) if j!=1]
    return save_strategy(f"codex_dense_m{m}",m,rs,cycles)


def same_set_tables():
    words=list(permutations((1,2,3)))
    cycles=[(6,)+w for w in words]
    rows=[]; rules=[]
    for z,c in enumerate(cycles,1):
        for j in range(4):
            r=rule_of(c,j,3)
            rules.append((z,j,r))
            rows.append([f"K{z}",c,r[0],r[1],r[2],loss_cycle(r),j!=1])
    with (OUT/"E1236_all24_rules.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f);w.writerow(["cycle_id","cycle","prisoner","history_values","target","loss_cycle","anchor_scheme_included"]);w.writerows(rows)
    with (OUT/"E1236_rule_conflicts.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f);w.writerow(["cycleA","prisonerA","cycleB","prisonerB","loss_cycle","type"])
        for (z,j,r),(zz,jj,s) in combinations(rules,2):
            if loss_cycle(r)==loss_cycle(s):
                assert r[0]!=s[0]
                w.writerow([z,r[0],zz,s[0],loss_cycle(r),"two_losers"])
    # Non-reverse anchored words that can coexist if the omitted prisoner is changed.
    a,b=cycles[0],cycles[1]
    for omit_a,omit_b in product(range(4),repeat=2):
        rs=[rule_of(a,j,3) for j in range(4) if j!=omit_a]
        rs += [rule_of(b,j,3) for j in range(4) if j!=omit_b]
        ds=[loss_cycle(r) for r in rs]
        if len(set(ds))==6:
            save_strategy("nonreverse_free_omission",3,rs,[a,b])
            print("non-reverse omitted prisoners:",a[omit_a],b[omit_b])
            break
    else:
        raise AssertionError("expected a non-reverse safe pair")


def free_single_support():
    p=json.loads((OUT/"per_set_m4.json").read_text())
    rs=[]
    for K,x in p["rules"]:
        j=(K.index(x)+1)%5
        rs.append(rule_of(K,j,4))
    result=save_strategy("free_E12345_seven_cycles",4,rs,p["chosen"])
    assert result["wins"]==14778


def export_candidates():
    for label in ("anchor_m4","ilp_m4_rescue_capNone","ilp_m3_full_capNone","ilp_m3_long_capNone"):
        p=json.loads((OUT/(label+".json")).read_text(encoding="utf-8"))
        rs=[(i,tuple(h),y) for i,h,y in p["rules"]]
        rd=rules_dict(rs);m=p["m"]
        with (OUT/(label+"_rules.csv")).open("w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f);w.writerow(["prisoner","observed_contents","last_box","loss_cycle"])
            for r in rs:w.writerow([r[0],r[1],r[2],loss_cycle(r)])
        with (OUT/(label+"_cycles.csv")).open("w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f);w.writerow(["cycle","length","successful_prisoners","omitted_prisoners"])
            for L in range(m+1,2*m+1):
                for S in combinations(range(1,2*m+1),L):
                    for C in directed_cycles(S):
                        good=[C[j] for j in range(L) if rd.get(key(rule_of(C,j,m)))==C[(j-1)%L]]
                        if len(good)>=L-1:w.writerow([C,L,good,[i for i in C if i not in good]])


if __name__=="__main__":
    same_set_tables()
    for m in (3,4):densify_codex(m)
    free_single_support()
    C=(1,2,3,4,5,6)
    Cs=[C,canon(C[::-1])]
    result=save_strategy("n8_two_six_cycles",4,[rule_of(c,j,4) for c in Cs for j in range(6)],Cs)
    assert result["wins"]==14740
    export_candidates()
