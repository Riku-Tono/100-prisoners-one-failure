"""第4ラウンド共通部品（標準ライブラリのみ）。n=2m、各人 m 箱、n-1 人以上成功で釈放。

戦略族 F_last：巡回追跡法（CF）に「最後の箱（m 箱目）だけを変える例外」を足したもの。
例外 r = (i, hist, y)：囚人 i が CF どおり i→c1→…→c_{m-1} を見たら（hist=(c1..c_{m-1})）、
m 箱目を箱 c_{m-1} ではなく箱 y にする。
  キー        key(r)  = (i, hist)
  損失巡回    D(r)    = (i c1 … c_{m-1})   （向きつき m 巡回。敗者は i）
  救済する道  y→i→c1→…→c_{m-1}           （この道を含む長さ m+1 以上の巡回で i が成功）
"""
from itertools import permutations, combinations
from math import factorial


def canon(c):
    c = tuple(c)
    k = c.index(min(c))
    return c[k:] + c[:k]


def directed_cycles(S):
    """集合 S 上の向きつき巡回（最小元始まりで正規化）"""
    S = sorted(S)
    a, rest = S[0], S[1:]
    return [(a,) + q for q in permutations(rest)]


def rule_of(K, j, m):
    """巡回 K の j 番目の囚人 v_j を救う最終箱例外 (i, hist, y)"""
    L = len(K)
    i = K[j]
    hist = tuple(K[(j + s) % L] for s in range(1, m))
    y = K[(j - 1) % L]
    return (i, hist, y)


def loss_cycle(r):
    i, hist, _ = r
    return canon((i,) + hist)


def key(r):
    return (r[0], r[1])


def rules_dict(rules):
    """規則の列を {key: 行き先} にする。同じキーに別の行き先があれば ValueError（衝突の型1）"""
    d = {}
    for r in rules:
        k = key(r)
        if k in d and d[k] != r[2]:
            raise ValueError(f"型1（同じ履歴キーに別の行き先）: {k} -> {d[k]} / {r[2]}")
        d[k] = r[2]
    return d


# ---------- 直接シミュレーション（検算用、規則表をそのまま実行） ----------
def simulate(p, m, rd):
    """p[b-1] = 箱 b の中身。rd = {key: box}。成功者数を返す。同じ箱の再開封は assert で禁止"""
    n = len(p)
    succ = 0
    for i in range(1, n + 1):
        box, opened, seen = i, set(), []
        for step in range(1, m + 1):
            if step == m:
                box = rd.get((i, tuple(seen)), box)
            assert box not in opened
            opened.add(box)
            v = p[box - 1]
            if v == i:
                succ += 1
                break
            seen.append(v)
            box = v
    return succ


def cycles_of(p):
    n = len(p)
    seen, out = set(), []
    for s in range(1, n + 1):
        if s in seen:
            continue
        c, x = [], s
        while x not in seen:
            seen.add(x); c.append(x); x = p[x - 1]
        out.append(tuple(c))
    return out


def brute_force(m, rd):
    """全 (2m)! 配置を直接シミュレーションして (CF勝ち, 新勝ち, CF勝ちの喪失) を返す"""
    n = 2 * m
    cf = new = lost = 0
    for p in permutations(range(1, n + 1)):
        old = max(len(c) for c in cycles_of(p)) <= m
        w = simulate(p, m, rd) >= n - 1
        cf += old; new += w; lost += old and not w
    return cf, new, lost


# ---------- 構造による高速評価（シミュレーションと照合済み） ----------
def fast_eval(m, rules):
    """rules: (i,hist,y) の集合（型1衝突なし前提）。
    返り値 (新勝ち, CF勝ちの喪失)。
    長さ L>=m+1 の巡回 C を含む配置では C の外は全員成功するので、
    C 上の L 人のうち L-1 人以上が成功すれば勝ち（(n-L)! 配置）。
    CF 勝ち配置では、m 巡回 D 上の囚人 i が負けるのは key=(i, D を i から読んだ履歴) の規則があるときだけ。"""
    n = 2 * m
    rd = rules_dict(rules)
    loser_of = {}  # 損失巡回 -> 敗者集合
    for (i, hist), y in rd.items():
        loser_of.setdefault(canon((i,) + hist), set()).add(i)
    # 長い巡回の勝ち
    long_wins = 0
    for L in range(m + 1, n + 1):
        w = factorial(n - L)
        for S in combinations(range(1, n + 1), L):
            for C in directed_cycles(S):
                ok = sum(1 for j in range(L) if rd.get(key(rule_of(C, j, m))) == C[(j - 1) % L])
                if ok >= L - 1:
                    long_wins += w
    # CF 勝ちの喪失：CF 勝ち配置のうち敗者が2人以上
    lost = 0
    if loser_of:
        for p in permutations(range(1, n + 1)):
            cs = cycles_of(p)
            if max(map(len, cs)) > m:
                continue
            losers = 0
            for c in cs:
                if len(c) == m:
                    cc = canon(c)
                    for i in loser_of.get(cc, ()):  # i が c 上で負けるのは、c を i から読んだ履歴の規則があるとき
                        losers += 1
            if losers >= 2:
                lost += 1
    cf_wins = sum(1 for p in permutations(range(1, n + 1)) if max(map(len, cycles_of(p))) <= m) if m <= 3 else None
    return long_wins, lost


CF_WINS = {3: 276, 4: 14736}
