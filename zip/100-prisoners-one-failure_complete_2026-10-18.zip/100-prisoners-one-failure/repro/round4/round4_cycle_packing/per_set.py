"""固定した (m+1) 元集合 E 上で、同時に救える向きつき (m+1) 巡回の最大数（戦略族 F_last）。
  /home/user/ortenv/bin/python per_set.py M
スロット = E 内の向きつき m 巡回（(m+1)(m-1)! 個）。巡回 K の規則 (K,x) はスロット K\\x を使う。
救済には m+1 個中 m 個が必要。E 内の m 元集合はどれも交わるので、制約は「スロットは1回まで」だけ。
上界 floor((m+1)(m-1)!/m)。"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
from core import *
from ortools.sat.python import cp_model
m = int(sys.argv[1]); E = tuple(range(1, m + 2))
Ks = directed_cycles(E)
def slot(K, x):
    return canon(tuple(v for v in K if v != x))
md = cp_model.CpModel()
w = {(K, x): md.NewBoolVar("") for K in Ks for x in K}
y = {K: md.NewBoolVar("") for K in Ks}
slots = {}
for (K, x), v in w.items():
    slots.setdefault(slot(K, x), []).append(v)
for s, vs in slots.items():
    md.Add(sum(vs) <= 1)
for K in Ks:
    md.Add(m * y[K] <= sum(w[(K, x)] for x in K))
md.Maximize(sum(y.values()))
sol = cp_model.CpSolver(); sol.parameters.max_time_in_seconds = 120; sol.parameters.num_workers = 8
st = sol.Solve(md)
chosen = [K for K in Ks if sol.Value(y[K])]
print(f"m={m}: 巡回{len(Ks)}種, スロット{len(slots)}個, 上界 {(m+1)*factorial(m-1)//m}, "
      f"status={sol.StatusName(st)} 最大={int(sol.ObjectiveValue())} 上界(ソルバー)={sol.BestObjectiveBound()}")
for K in chosen:
    om = [x for x in K if not sol.Value(w[(K, x)])]
    print("  ", K, "省略（抜く元 x、敗者は x の次）:", om)
used = {slot(K, x) for (K, x), v in w.items() if sol.Value(v)}
print("  使用スロット", len(used), "/", len(slots))
json.dump(dict(m=m, chosen=chosen, rules=[(K, x) for (K, x), v in w.items() if sol.Value(v)]),
          open(os.path.join(os.path.dirname(__file__), "out", f"per_set_m{m}.json"), "w"))
