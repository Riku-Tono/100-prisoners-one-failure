"""out/*.json の解を、規則表の直接シミュレーションで全配置検算する（標準ライブラリのみ）。
  python3 verify_solutions.py out/ilp_m3_rescue_capNone.json [...]
確認項目：型1（同じキーに別の行き先）なし／W(CF) の喪失 0／勝ち数／
          系B の条件（損失巡回の一意性・補集合なし）／同じ (m+1) 元集合上で救った巡回の個数分布。"""
import sys, os, json
from collections import Counter, defaultdict
sys.path.insert(0, os.path.dirname(__file__))
from core import *


def check_B(m, rules):
    """系B：損失巡回が重複しない（型2a）かつ頂点集合が補集合にならない（型2b）"""
    n = 2 * m
    Ds = [loss_cycle(r) for r in rules]
    dup = [d for d, c in Counter(Ds).items() if c > 1]
    sets = {frozenset(d) for d in Ds}
    comp = [s for s in sets if frozenset(range(1, n + 1)) - s in sets]
    return dup, comp


def report(fn):
    res = json.load(open(fn))
    m = res["m"]; n = 2 * m
    rules = [(r[0], tuple(r[1]), r[2]) for r in res["rules"]]
    rd = rules_dict(rules)  # 型1があれば例外
    dup, comp = check_B(m, rules)
    cf, new, lost = brute_force(m, rd)
    # 救済された長さ L の巡回を数え、(m+1) 巡回の集合ごとの個数を出す
    per_set = Counter(); byL = Counter()
    for L in range(m + 1, n + 1):
        for S in combinations(range(1, n + 1), L):
            for C in directed_cycles(S):
                ok = sum(1 for j in range(L) if rd.get(key(rule_of(C, j, m))) == C[(j - 1) % L])
                if ok >= L - 1:
                    byL[L] += 1
                    if L == m + 1:
                        per_set[S] += 1
    print(f"{os.path.basename(fn)}: 規則{len(rd)}  CF勝ち{cf}  新勝ち{new}  CF喪失{lost}  "
          f"系B違反(重複{len(dup)},補集合{len(comp)})  救済巡回(長さ:数){dict(sorted(byL.items()))}")
    print("    同じ集合上の (m+1) 巡回数の分布 {個数: 集合数}:", dict(sorted(Counter(per_set.values()).items())))
    assert lost == 0 and not dup and not comp
    return new


if __name__ == "__main__":
    for fn in sys.argv[1:]:
        report(fn)
