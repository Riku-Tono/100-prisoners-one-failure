"""Independent finite certificate audit for the three Round 7 rule tables.

This does not import Claude's verifier or the Round 6 direct simulator.  It
checks the directed-cycle packing certificate; use verify_mixed_n8.py for a
separate exhaustive placement simulation.
"""
from __future__ import annotations

import json
from collections import Counter, defaultdict
from itertools import combinations, permutations
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NODES = frozenset(range(1, 9))
FILES = (
    "best52_costar_Z4_n8.json",
    "best52_costar_splitY_n8.json",
    "best52_threshold_n8.json",
)


def canonical(cycle):
    cycle = tuple(cycle)
    position = cycle.index(min(cycle))
    return cycle[position:] + cycle[:position]


def four_cycles(support):
    support = sorted(support)
    return (tuple((support[0],) + tail)
            for tail in permutations(support[1:]))


def map_cycle(cycle, mapping):
    return canonical(mapping.get(x, x) for x in cycle)


def audit(path: Path):
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    rules = {}
    losses = set()
    supports = set()
    correct = defaultdict(set)
    for entry in data["rules"]:
        assert isinstance(entry, list) and len(entry) == 3
        i, history, target = entry
        history = tuple(history)
        assert i in NODES and target in NODES
        assert len(history) == 3 and len({i, *history}) == 4
        assert target not in {i, *history}
        key = (i, history)
        assert key not in rules
        rules[key] = target
        loss = canonical((i,) + history)
        assert loss not in losses
        losses.add(loss)
        supports.add(frozenset(loss))
        correct[canonical((target, i) + history)].add(i)

    for support in supports:
        assert NODES - support not in supports
    rescued = {cycle for cycle, members in correct.items() if len(members) >= 4}
    assert len(rules) == len(losses) == 208
    assert len(rescued) == 52
    assert all(len(correct[cycle]) == 4 for cycle in rescued)
    assert len(supports) == 35
    all_words = {cycle for support in supports for cycle in four_cycles(support)}
    assert len(all_words) == 210 and losses <= all_words
    uncovered = all_words - losses
    assert len(uncovered) == 2
    occupancy = Counter(frozenset(word) for word in losses)
    assert sorted(occupancy.values()) == [4] + [6] * 34 or sorted(occupancy.values()) == [5, 5] + [6] * 33

    # The block list is supplementary metadata: derive the rescue set from
    # rules first, then compare all listed cycles and skipped points.
    blocks = {(canonical(cycle), skip) for cycle, skip in data["blocks"]}
    assert len(blocks) == 52 and {cycle for cycle, _ in blocks} == rescued
    used_from_blocks = set()
    for cycle, skip in blocks:
        assert len(cycle) == 5 and skip in cycle
        for removed in cycle:
            if removed != skip:
                word = canonical(x for x in cycle if x != removed)
                assert word not in used_from_blocks
                used_from_blocks.add(word)
    assert used_from_blocks == losses

    if "costar" in path.name:
        expected = {frozenset(s) for s in combinations(range(1, 8), 4)}
        assert supports == expected
    if "threshold" in path.name:
        weights = {int(i): weight for i, weight in data["weights"].items()}
        expected = {frozenset(s) for s in combinations(range(1, 9), 4)
                    if sum(weights[i] for i in s) >= 8}
        assert supports == expected

    orbit_count = None
    if "Z4" in path.name:
        mapping = {1: 2, 2: 3, 3: 4, 4: 1, 5: 6, 6: 5}
        assert {(map_cycle(c, mapping), mapping.get(skip, skip)) for c, skip in blocks} == blocks
        reps = {(canonical(cycle), skip) for cycle, skip in data["orbit_representatives"]}
        assert len(reps) == 13
        generated = set()
        for rep in reps:
            current = rep
            orbit = set()
            for _ in range(4):
                orbit.add(current)
                cycle, skip = current
                current = map_cycle(cycle, mapping), mapping.get(skip, skip)
            assert len(orbit) == 4
            assert not (orbit & generated)
            generated.update(orbit)
        assert generated == blocks
        assert {canonical(word) for word in data["uncovered_words"]} == uncovered
        orbit_count = 13

    return {
        "strategy": path.name,
        "rules": len(rules),
        "distinct_loss_cycles": len(losses),
        "loss_supports": len(supports),
        "complementary_support_pairs": 0,
        "rescued_5_cycles": len(rescued),
        "uncovered_words": [list(word) for word in sorted(uncovered)],
        "support_occupancy_histogram": dict(sorted(Counter(occupancy.values()).items())),
        "orbit_count_under_Z4": orbit_count,
    }


def main():
    results = [audit(ROOT / name) for name in FILES]
    destination = ROOT / "round7_certificate_audit.json"
    destination.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for item in results:
        print(item)
    print("CERTIFICATES PASS")


if __name__ == "__main__":
    main()
