"""Search CF-preserving deterministic mixed strategies for the 8-prisoner game.

Standard library only. Rule [i, history, box] means prisoner i, after seeing
the exact history, opens box. Earlier rules take priority in time. A prisoner
uses at most one rule; after it fires, pointer following resumes. If the
pointer names an already opened box, use the lowest unopened box.

Example:
  python -X utf8 mixed_search_n8.py --seconds 180 --seed 20261009

The search is heuristic. Its score is always recomputed from all 40320
placements through per-prisoner bitsets. The saved strategy is later checked
by verify_mixed_n8.py, which has a separate simulator.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import combinations, permutations
from pathlib import Path

N = 8
M = 4
TOTAL = 40320
ROOT = Path(__file__).resolve().parent
BASELINE = ROOT / "round4_baseline_n8.json"
OUTPUT = ROOT / "best_mixed_n8.json"
Key = tuple[int, tuple[int, ...]]


def max_cycle_length(p: tuple[int, ...]) -> int:
    unseen = set(range(1, N + 1))
    out = 0
    while unseen:
        x = next(iter(unseen))
        size = 0
        while x in unseen:
            unseen.remove(x)
            size += 1
            x = p[x - 1]
        out = max(out, size)
    return out


def cf_history(p: tuple[int, ...], i: int) -> tuple[int, ...]:
    x = i
    seen = []
    for _ in range(3):
        x = p[x - 1]
        seen.append(x)
        if x == i:
            break
    return tuple(seen)


def simulate_person(
    p: tuple[int, ...], i: int, late: dict[Key, int],
    early_rule: tuple[tuple[int, ...], int] | None = None,
    late_override: tuple[Key, int | None] | None = None,
) -> bool:
    opened: list[int] = []
    seen: list[int] = []
    jumped = False
    for box_number in range(1, M + 1):
        default = i if not seen else seen[-1]
        b = default
        if not jumped:
            h = tuple(seen)
            if early_rule is not None and h == early_rule[0]:
                b = early_rule[1]
                jumped = True
            elif box_number == M:
                key = (i, h)
                if late_override is not None and key == late_override[0]:
                    alt = late_override[1]
                    if alt is not None:
                        b = alt
                        jumped = True
                elif key in late:
                    b = late[key]
                    jumped = True
        if b in opened:
            b = next(x for x in range(1, N + 1) if x not in opened)
        assert 1 <= b <= N and b not in opened
        opened.append(b)
        value = p[b - 1]
        seen.append(value)
        if value == i:
            return True
    return False


def winners_mask(success: list[int], full: int) -> int:
    zero_failures = full
    one_failure = 0
    for success_mask in success:
        failure = full ^ success_mask
        one_failure = (one_failure & ~failure) | (zero_failures & failure)
        zero_failures &= success_mask
    return zero_failures | one_failure


@dataclass(frozen=True)
class Early:
    i: int
    h: tuple[int, ...]
    b: int
    activation: int
    flip: int
    new_w_loss: int
    repairs: frozenset[Key]
    isolated_score: int


@dataclass(frozen=True)
class State:
    early: tuple[int, ...] = ()
    # A target of 0 removes a baseline rule. Other targets replace or add it.
    mods: tuple[tuple[Key, int], ...] = ()


class Context:
    def __init__(self, baseline_file: Path):
        self.baseline_file = baseline_file
        raw = baseline_file.read_bytes()
        self.baseline_sha256 = hashlib.sha256(raw).hexdigest()
        data = json.loads(raw)
        self.late: dict[Key, int] = {}
        for i, history, b in data["rules"]:
            key = (int(i), tuple(history))
            if key in self.late:
                raise ValueError(f"duplicate baseline rule {key}")
            self.check_target(key, int(b))
            self.late[key] = int(b)
        if len(self.late) != 204:
            raise ValueError(f"expected 204 baseline rules, got {len(self.late)}")
        self.perms = list(permutations(range(1, N + 1)))
        assert len(self.perms) == TOTAL
        self.full = (1 << TOTAL) - 1
        self.prefix_ids: dict[Key, list[int]] = defaultdict(list)
        self.cycle_lengths: list[int] = []
        self.W = 0
        self.base_success = [0] * N
        self.base_w_loser_key: dict[int, Key] = {}
        self.base_loser_rule_masks: dict[Key, int] = defaultdict(int)
        for idx, p in enumerate(self.perms):
            bit = 1 << idx
            length = max_cycle_length(p)
            self.cycle_lengths.append(length)
            if length <= M:
                self.W |= bit
            ok = []
            for i in range(1, N + 1):
                h = cf_history(p, i)
                for size in range(1, min(3, len(h)) + 1):
                    if h[size - 1] != i:
                        self.prefix_ids[(i, h[:size])].append(idx)
                answer = simulate_person(p, i, self.late)
                ok.append(answer)
                if answer:
                    self.base_success[i - 1] |= bit
            if length <= M:
                failures = [i for i in range(1, N + 1) if not ok[i - 1]]
                if len(failures) > 1:
                    raise AssertionError(("baseline loses CF W", idx, failures))
                if failures:
                    i = failures[0]
                    key = (i, cf_history(p, i))
                    if key not in self.late:
                        raise AssertionError(("baseline W loser lacks rule", idx, key))
                    self.base_w_loser_key[idx] = key
                    self.base_loser_rule_masks[key] |= bit
        self.base_wins_mask = winners_mask(self.base_success, self.full)
        self.base_wins = self.base_wins_mask.bit_count()
        if self.base_wins != 15042 or self.W.bit_count() != 14736:
            raise AssertionError((self.base_wins, self.W.bit_count()))
        self.late_effect_cache: dict[tuple[Key, int], int] = {}
        self.early_candidates: list[Early] = []
        self.eval_count = 0

    @staticmethod
    def check_target(key: Key, b: int) -> None:
        i, h = key
        if not (1 <= i <= N and 1 <= b <= N and len(h) in (1, 2, 3)):
            raise ValueError((key, b))
        if len(set((i,) + h)) != len(h) + 1:
            raise ValueError(("non-CF history", key))
        if b in (i,) + h[:-1] or b == h[-1]:
            raise ValueError(("illegal or ineffective target", key, b))

    def late_effect(self, key: Key, b: int) -> int:
        cache_key = (key, b)
        if cache_key in self.late_effect_cache:
            return self.late_effect_cache[cache_key]
        if b and b != self.late.get(key):
            self.check_target(key, b)
            if len(key[1]) != 3:
                raise ValueError(key)
        if b == self.late.get(key, 0):
            self.late_effect_cache[cache_key] = 0
            return 0
        flip = 0
        for idx in self.prefix_ids.get(key, ()):
            new = simulate_person(
                self.perms[idx], key[0], self.late,
                late_override=(key, b or None),
            )
            old = bool(self.base_success[key[0] - 1] & (1 << idx))
            if new != old:
                flip |= 1 << idx
        self.late_effect_cache[cache_key] = flip
        return flip

    def forced_repairs(self, i: int, new_w_loss: int) -> frozenset[Key]:
        return frozenset(
            key for key, mask in self.base_loser_rule_masks.items()
            if key[0] != i and mask & new_w_loss
        )

    def build_early_candidates(self) -> Counter:
        stats = Counter()
        for key, ids in sorted(self.prefix_ids.items()):
            i, h = key
            if len(h) not in (1, 2):
                continue
            opened = {i, *h[:-1]}
            for b in range(1, N + 1):
                if b in opened or b == h[-1]:
                    continue
                activation = flip = 0
                for idx in ids:
                    bit = 1 << idx
                    activation |= bit
                    new = simulate_person(
                        self.perms[idx], i, self.late, early_rule=(h, b)
                    )
                    old = bool(self.base_success[i - 1] & bit)
                    if new != old:
                        flip |= bit
                new_w_loss = self.W & ~(self.base_success[i - 1] ^ flip)
                repairs = self.forced_repairs(i, new_w_loss)
                state = State((len(self.early_candidates),),
                              tuple(sorted((key, 0) for key in repairs)))
                # Temporarily add the candidate, then score its repaired bundle.
                candidate = Early(i, h, b, activation, flip, new_w_loss,
                                  repairs, 0)
                self.early_candidates.append(candidate)
                score, lost, _ = self.evaluate(state)
                if lost:
                    raise AssertionError(("single repair is unsafe", i, h, b, lost))
                self.early_candidates[-1] = Early(
                    i, h, b, activation, flip, new_w_loss, repairs, score
                )
                stats["early_candidates"] += 1
                stats[f"isolated_score_{score}"] += 1
        if stats["early_candidates"] != 2016:
            raise AssertionError(stats["early_candidates"])
        return stats

    def success_masks(self, state: State) -> list[int]:
        early_flip = [0] * N
        shadow = [0] * N
        by_person: dict[int, list[tuple[int, ...]]] = defaultdict(list)
        for cid in state.early:
            candidate = self.early_candidates[cid]
            i = candidate.i - 1
            for h in by_person[i]:
                if h[:len(candidate.h)] == candidate.h or candidate.h[:len(h)] == h:
                    raise ValueError(("overlapping early prefixes", h, candidate.h))
            by_person[i].append(candidate.h)
            early_flip[i] ^= candidate.flip
            shadow[i] |= candidate.activation
        late_flip = [0] * N
        for key, target in state.mods:
            late_flip[key[0] - 1] ^= self.late_effect(key, target)
        return [
            self.base_success[i] ^ early_flip[i] ^ (late_flip[i] & ~shadow[i])
            for i in range(N)
        ]

    def evaluate(self, state: State) -> tuple[int, int, int]:
        self.eval_count += 1
        success = self.success_masks(state)
        winners = winners_mask(success, self.full)
        return (winners.bit_count(), (self.W & ~winners).bit_count(), winners)

    def with_early(self, state: State, cid: int) -> State | None:
        c = self.early_candidates[cid]
        if cid in state.early:
            return None
        for old_id in state.early:
            old = self.early_candidates[old_id]
            if old.i == c.i:
                a, b = old.h, c.h
                if a[:len(b)] == b or b[:len(a)] == a:
                    return None
        mods = dict(state.mods)
        for key in c.repairs:
            mods[key] = 0
        return State(tuple(sorted(state.early + (cid,))), tuple(sorted(mods.items())))

    def with_mod(self, state: State, key: Key, target: int) -> State:
        mods = dict(state.mods)
        if target == self.late.get(key, 0):
            mods.pop(key, None)
        else:
            mods[key] = target
        return State(state.early, tuple(sorted(mods.items())))

    def rule_list(self, state: State) -> list[list]:
        rules = dict(self.late)
        for key, target in state.mods:
            if target == 0:
                rules.pop(key, None)
            else:
                rules[key] = target
        for cid in state.early:
            c = self.early_candidates[cid]
            key = (c.i, c.h)
            if key in rules:
                raise AssertionError(("duplicate rule", key))
            rules[key] = c.b
        return [[i, list(h), b] for (i, h), b in sorted(rules.items())]


def local_st_seed(ctx: Context, i: int, p: int, b: int, c: int,
                  variant: str, replace_local: bool = False) -> State | None:
    anchors = {i, p, b, c}
    outsiders = tuple(x for x in range(1, N + 1) if x not in anchors)
    early_rules = [((b, c), p)] if variant == "ordered" else [((b, c), p), ((c, b), p)]
    early_index = {(x.i, x.h, x.b): k for k, x in enumerate(ctx.early_candidates)}
    ids = []
    for h, target in early_rules:
        key = (i, h, target)
        if key not in early_index:
            return None
        ids.append(early_index[key])
    mods: dict[Key, int] = (
        {key: 0 for key in ctx.late if key[0] == i} if replace_local else {}
    )
    for x in outsiders:
        if variant == "ordered":
            histories = [(x, b, c), (b, x, c)]
        else:
            histories = [(x, b, c), (x, c, b), (b, x, c), (c, x, b)]
        for h in histories:
            key = (i, h)
            if ctx.late.get(key) == p:
                mods.pop(key, None)
            else:
                mods[key] = p
    state = State(tuple(sorted(ids)), tuple(sorted(mods.items())))
    # Replacing one person's local policy can create W losses colliding with
    # baseline losses of others. Delete exactly those baseline late rules.
    masks = ctx.success_masks(state)
    w_loss_i = ctx.W & ~masks[i - 1]
    for key in ctx.forced_repairs(i, w_loss_i):
        mods[key] = 0
    return State(state.early, tuple(sorted(mods.items())))


def select_pool(ctx: Context, size: int, rng: random.Random) -> list[int]:
    ranked = sorted(range(len(ctx.early_candidates)),
                    key=lambda cid: (-ctx.early_candidates[cid].isolated_score,
                                     ctx.early_candidates[cid].i,
                                     ctx.early_candidates[cid].h,
                                     ctx.early_candidates[cid].b))
    chosen = []
    selected = set()
    per_person = max(8, size // 12)
    for i in range(1, N + 1):
        count = 0
        histories = Counter()
        for cid in ranked:
            c = ctx.early_candidates[cid]
            if c.i == i and histories[c.h] < 2:
                chosen.append(cid)
                selected.add(cid)
                histories[c.h] += 1
                count += 1
                if count == per_person:
                    break
    for cid in ranked:
        if len(chosen) >= size * 3 // 4:
            break
        if cid not in selected:
            chosen.append(cid)
            selected.add(cid)
    remaining = [cid for cid in ranked if cid not in selected]
    rng.shuffle(remaining)
    for cid in remaining:
        if len(chosen) >= size:
            break
        chosen.append(cid)
    return chosen[:size]


def search(ctx: Context, seconds: float, seed: int, beam_width: int,
           pool_size: int, depth: int, anneal_steps: int) -> tuple[State, State | None, dict]:
    start = time.monotonic()
    rng = random.Random(seed)
    stats: dict = {"seed": seed, "beam_width": beam_width,
                   "pool_size": pool_size, "depth": depth,
                   "seconds_requested": seconds, "baseline": ctx.base_wins}
    candidate_stats = ctx.build_early_candidates()
    stats["single_candidates"] = candidate_stats["early_candidates"]
    stats["single_repair_best"] = max(c.isolated_score for c in ctx.early_candidates)
    pool = select_pool(ctx, pool_size, rng)
    stats["pool_isolated_range"] = [min(ctx.early_candidates[c].isolated_score for c in pool),
                                    max(ctx.early_candidates[c].isolated_score for c in pool)]
    best = State()
    best_score = ctx.base_wins
    best_mixed = None
    best_mixed_score = -1
    beam: list[State] = [State()]
    seen_states = {State()}
    depth_log = []
    seeds = []
    for i in range(1, N + 1):
        others = [x for x in range(1, N + 1) if x != i]
        for p, b, c in permutations(others, 3):
            for variant in ("ordered", "set"):
                for replace_local in (False, True):
                    s = local_st_seed(ctx, i, p, b, c, variant, replace_local)
                    if s is None or s in seen_states:
                        continue
                    seen_states.add(s)
                    score, wlost, _ = ctx.evaluate(s)
                    if wlost == 0:
                        seeds.append((score, s, variant + ("_replace" if replace_local else "_overlay")))
                        if score > best_mixed_score:
                            best_mixed, best_mixed_score = s, score
                        if score > best_score:
                            best, best_score = s, score
    stats["st_seeds_safe"] = len(seeds)
    stats["st_seed_best"] = max((s for s, _, _ in seeds), default=None)
    seeds.sort(key=lambda item: item[0], reverse=True)
    seed_beam = [s for _, s, _ in seeds[:max(beam_width // 2, 10)]]
    # Combine different prisoners' complete S_T or S_T_set local templates.
    # These are multi-rule substitutions, beyond the single-early audit.
    pair_sources = [s for _, s, _ in seeds[:min(120, len(seeds))]]
    paired = []
    for a_idx, left in enumerate(pair_sources):
        for right in pair_sources[a_idx + 1:]:
            if time.monotonic() - start >= seconds:
                break
            if any(ctx.early_candidates[x].i == ctx.early_candidates[y].i
                   for x in left.early for y in right.early):
                continue
            mods = dict(left.mods)
            incompatible = any(k in mods and mods[k] != v for k, v in right.mods)
            if incompatible:
                continue
            mods.update(right.mods)
            new = State(tuple(sorted(left.early + right.early)),
                        tuple(sorted(mods.items())))
            if new in seen_states:
                continue
            seen_states.add(new)
            score, wlost, _ = ctx.evaluate(new)
            if wlost:
                continue
            paired.append((score, new))
            if score > best_mixed_score:
                best_mixed, best_mixed_score = new, score
            if score > best_score:
                best, best_score = new, score
    paired.sort(key=lambda item: item[0], reverse=True)
    stats["st_seed_pairs_safe"] = len(paired)
    stats["st_seed_pair_best"] = paired[0][0] if paired else None
    seed_beam += [s for _, s in paired[:max(beam_width // 2, 10)]]
    for d in range(1, depth + 1):
        if time.monotonic() - start >= seconds:
            break
        neighbors = []
        sources = beam + (seed_beam if d == 1 else [])
        for state in sources:
            for cid in pool:
                if time.monotonic() - start >= seconds:
                    break
                new = ctx.with_early(state, cid)
                if new is None or new in seen_states:
                    continue
                seen_states.add(new)
                score, wlost, _ = ctx.evaluate(new)
                if wlost:
                    continue
                neighbors.append((score, new))
                if new.early and score > best_mixed_score:
                    best_mixed, best_mixed_score = new, score
                if score > best_score:
                    best, best_score = new, score
        neighbors.sort(key=lambda x: x[0], reverse=True)
        if not neighbors:
            break
        beam = [s for _, s in neighbors[:beam_width]]
        # Reserve a few slots for score-diverse states; those can be bridges.
        if len(neighbors) > beam_width and beam_width >= 10:
            varied = rng.sample(neighbors[beam_width:min(len(neighbors), beam_width * 8)],
                                min(beam_width // 8, len(neighbors) - beam_width))
            beam[-len(varied):] = [s for _, s in varied]
        depth_log.append({"depth": d, "safe_states": len(neighbors),
                          "best_at_depth": neighbors[0][0], "best_overall": best_score})
        print(f"beam depth {d}: safe={len(neighbors)} stage_best={neighbors[0][0]} best={best_score}", flush=True)
    stats["beam"] = depth_log
    stats["best_mixed_during_beam"] = best_mixed_score

    # All 204 baseline final-box keys are eligible for deletion or a different
    # legal target. Iterative one-key moves can refine multi-early states.
    local_sources = [best, State()] + [s for _, s, _ in seeds[:5]] + beam[:8]
    if best_mixed is not None:
        local_sources.append(best_mixed)
    local_seen = set()
    local_log = []
    for pass_number in range(2):
        proposals = []
        for state in local_sources:
            for key in sorted(ctx.late):
                i, h = key
                opened = {i, *h[:-1]}
                choices = [0] + [b for b in range(1, N + 1)
                                 if b not in opened and b != h[-1]]
                for target in choices:
                    if time.monotonic() - start >= seconds:
                        break
                    new = ctx.with_mod(state, key, target)
                    if new == state or new in local_seen:
                        continue
                    local_seen.add(new)
                    score, wlost, _ = ctx.evaluate(new)
                    if wlost:
                        continue
                    proposals.append((score, new))
                    if new.early and score > best_mixed_score:
                        best_mixed, best_mixed_score = new, score
                    if score > best_score:
                        best, best_score = new, score
        proposals.sort(key=lambda x: x[0], reverse=True)
        local_sources = [s for _, s in proposals[:max(8, beam_width // 4)]]
        local_log.append({"pass": pass_number + 1,
                          "safe_states": len(proposals),
                          "best_at_pass": proposals[0][0] if proposals else None})
        print(f"late pass {pass_number+1}: safe={len(proposals)} best={best_score}", flush=True)
        if not proposals or time.monotonic() - start >= seconds:
            break
    stats["late_refinement"] = local_log
    # Random-restart annealing accepts safe score-decreasing transitions.
    # This reaches states missed by score-ranked beams and permits additions
    # at previously unused fourth-box histories after other rules are removed.
    late_keys = [key for key in ctx.prefix_ids if len(key[1]) == 3]
    anneal_evaluated = anneal_safe = 0
    anneal_best = best_score
    starts = [State(), best] + [s for _, s, _ in seeds[:10]]
    if best_mixed is not None:
        starts.append(best_mixed)
    restarts = 10
    per_restart = max(1, anneal_steps // restarts)
    for restart in range(restarts):
        state = starts[restart % len(starts)]
        current_score, current_lost, _ = ctx.evaluate(state)
        assert current_lost == 0
        for step in range(per_restart):
            if time.monotonic() - start >= seconds:
                break
            mode = rng.random()
            new = None
            if mode < 0.40 and len(state.early) < 16:
                cid = rng.choice(pool if rng.random() < 0.75 else range(len(ctx.early_candidates)))
                new = ctx.with_early(state, cid)
            elif mode < 0.55 and state.early:
                cid = rng.choice(state.early)
                new = State(tuple(x for x in state.early if x != cid), state.mods)
            else:
                key = rng.choice(late_keys if rng.random() < 0.55 else list(ctx.late))
                i, h = key
                opened = {i, *h[:-1]}
                choices = [0] + [b for b in range(1, N + 1)
                                 if b not in opened and b != h[-1]]
                target = rng.choice(choices)
                if len(state.mods) < 55 or key in dict(state.mods):
                    new = ctx.with_mod(state, key, target)
            if new is None or new == state:
                continue
            score, wlost, _ = ctx.evaluate(new)
            anneal_evaluated += 1
            if wlost:
                continue
            anneal_safe += 1
            if score > best_score:
                best, best_score = new, score
            if new.early and score > best_mixed_score:
                best_mixed, best_mixed_score = new, score
            anneal_best = max(anneal_best, score)
            temperature = 4.0 + 28.0 * (1.0 - step / per_restart)
            if score >= current_score or rng.random() < math.exp((score - current_score) / temperature):
                state, current_score = new, score
    stats["annealing"] = {"requested_steps": anneal_steps,
                          "evaluated": anneal_evaluated,
                          "safe": anneal_safe,
                          "best": anneal_best}
    stats["best_mixed"] = best_mixed_score
    stats["states_evaluated"] = ctx.eval_count
    stats["elapsed_seconds"] = round(time.monotonic() - start, 2)
    return best, best_mixed, stats


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--baseline", type=Path, default=BASELINE)
    ap.add_argument("--output", type=Path, default=OUTPUT)
    ap.add_argument("--mixed-output", type=Path,
                    default=ROOT / "best_explored_mixed_n8.json")
    ap.add_argument("--seconds", type=float, default=180)
    ap.add_argument("--seed", type=int, default=20261009)
    ap.add_argument("--beam-width", type=int, default=48)
    ap.add_argument("--pool-size", type=int, default=256)
    ap.add_argument("--depth", type=int, default=6)
    ap.add_argument("--anneal-steps", type=int, default=50000)
    args = ap.parse_args()
    ctx = Context(args.baseline)
    print(f"baseline={ctx.base_wins}/{TOTAL}, W={ctx.W.bit_count()}/{TOTAL}, rules={len(ctx.late)}", flush=True)
    state, mixed_state, stats = search(ctx, args.seconds, args.seed,
                                     args.beam_width, args.pool_size,
                                     args.depth, args.anneal_steps)
    score, W_lost, wins = ctx.evaluate(state)
    gained = (wins & ~ctx.base_wins_mask).bit_count()
    lost = (ctx.base_wins_mask & ~wins).bit_count()
    by_length = Counter(ctx.cycle_lengths[idx] for idx in range(TOTAL) if wins & (1 << idx))
    data = {
        "schema": "mixed-n8-v1", "n": N, "max_boxes": M,
        "required_successes": 7, "first_box": "own_number",
        "jump_limit_per_prisoner": 1,
        "after_jump": "follow_observed_number",
        "fallback": "lowest_unopened_box",
        "priority": "earliest_applicable_rule; later rules suppressed after jump",
        "baseline_sha256": ctx.baseline_sha256,
        "rules": ctx.rule_list(state),
        "evaluation": {
            "wins": score, "CF_old_wins_lost": W_lost,
            "new_vs_51_cycle_baseline": gained,
            "lost_vs_51_cycle_baseline": lost,
            "wins_by_max_cycle_length": dict(sorted(by_length.items())),
        },
        "search": stats,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if mixed_state is not None:
        mixed_score, mixed_W_lost, mixed_wins = ctx.evaluate(mixed_state)
        mixed_data = dict(data)
        mixed_data["rules"] = ctx.rule_list(mixed_state)
        mixed_data["evaluation"] = {
            "wins": mixed_score,
            "CF_old_wins_lost": mixed_W_lost,
            "new_vs_51_cycle_baseline": (mixed_wins & ~ctx.base_wins_mask).bit_count(),
            "lost_vs_51_cycle_baseline": (ctx.base_wins_mask & ~mixed_wins).bit_count(),
            "wins_by_max_cycle_length": dict(sorted(Counter(
                ctx.cycle_lengths[idx] for idx in range(TOTAL)
                if mixed_wins & (1 << idx)).items())),
        }
        args.mixed_output.write_text(json.dumps(mixed_data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"best={score}/{TOTAL}, W_lost={W_lost}, gained={gained}, lost={lost}", flush=True)
    print(f"saved={args.output}", flush=True)


if __name__ == "__main__":
    main()
