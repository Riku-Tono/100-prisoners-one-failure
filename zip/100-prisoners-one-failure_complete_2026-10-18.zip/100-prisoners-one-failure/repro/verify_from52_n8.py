"""Independent exhaustive verifier for an eight-prisoner rule-table strategy.

This module does not import mixed_search_from52_n8.py or use its bitset
evaluator. It enumerates all 8! placements and simulates each prisoner's
opened boxes directly. The default baseline is the Round 7 Z4 208-rule table.

Usage:
  python -X utf8 verify_from52_n8.py best_from52_n8.json
"""
from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from itertools import permutations
from pathlib import Path

N = 8
LIMIT = 4
ROOT = Path(__file__).resolve().parent


def read_rules(path: Path) -> tuple[dict, dict]:
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    rules = {}
    for entry in data["rules"]:
        if not (isinstance(entry, list) and len(entry) == 3):
            raise ValueError(("bad rule", entry))
        prisoner, history, destination = entry
        if not (isinstance(prisoner, int) and isinstance(destination, int)
                and isinstance(history, list)):
            raise ValueError(("bad types", entry))
        h = tuple(history)
        if not (1 <= prisoner <= N and 1 <= destination <= N and
                1 <= len(h) <= 3 and all(isinstance(x, int) and 1 <= x <= N for x in h)):
            raise ValueError(("out of range", entry))
        if len(set((prisoner,) + h)) != len(h) + 1:
            raise ValueError(("history cannot be a CF prefix", entry))
        if destination in (prisoner,) + h[:-1]:
            raise ValueError(("target already opened", entry))
        if destination == h[-1]:
            raise ValueError(("target equals normal pointer", entry))
        key = (prisoner, h)
        if key in rules:
            raise ValueError(("ambiguous duplicate history", entry))
        rules[key] = destination
    return data, rules


def run_one(placement: tuple[int, ...], prisoner: int, rules: dict) -> tuple[bool, tuple, tuple]:
    opened = []
    history = []
    jump_used = False
    events = []
    for step in range(1, LIMIT + 1):
        normal = prisoner if not history else history[-1]
        choice = normal
        if not jump_used:
            key = (prisoner, tuple(history))
            if key in rules:
                choice = rules[key]
                if choice in opened:
                    raise AssertionError(("rule reopens box", prisoner, history, choice))
                jump_used = True
                events.append(("early" if step < LIMIT else "late", step, key, choice))
        if choice in opened:
            choice = next(box for box in range(1, N + 1) if box not in opened)
            events.append(("fallback", step, choice))
        if choice in opened or len(opened) >= LIMIT:
            raise AssertionError(("opening violation", prisoner, placement, opened, choice))
        opened.append(choice)
        observed = placement[choice - 1]
        history.append(observed)
        if observed == prisoner:
            return True, tuple(opened), tuple(events)
    return False, tuple(opened), tuple(events)


def cycle_max(placement: tuple[int, ...]) -> int:
    visited = [False] * (N + 1)
    biggest = 0
    for start in range(1, N + 1):
        if not visited[start]:
            length = 0
            x = start
            while not visited[x]:
                visited[x] = True
                length += 1
                x = placement[x - 1]
            biggest = max(biggest, length)
    return biggest


def verify(strategy_path: Path, baseline_path: Path) -> dict:
    strategy_data, strategy = read_rules(strategy_path)
    baseline_data, baseline = read_rules(baseline_path)
    if strategy_data.get("schema") == "mixed-n8-v1":
        if (strategy_data.get("n"), strategy_data.get("max_boxes"),
            strategy_data.get("required_successes")) != (8, 4, 7):
            raise ValueError("strategy game metadata mismatch")
        if (strategy_data.get("first_box") != "own_number" or
            strategy_data.get("jump_limit_per_prisoner") != 1 or
            strategy_data.get("after_jump") != "follow_observed_number" or
            strategy_data.get("priority") !=
                "earliest_applicable_rule; later rules suppressed after jump"):
            raise ValueError("unsupported rule semantics")
        if strategy_data.get("fallback") != "lowest_unopened_box":
            raise ValueError("unsupported fallback")
        if strategy_data.get("baseline_sha256") != hashlib.sha256(
            baseline_path.read_bytes()
        ).hexdigest():
            raise ValueError("strategy was scored against another baseline")
    comparison = Counter()
    wins_by_length = Counter()
    base_wins_by_length = Counter()
    newly_won_by_length = Counter()
    newly_lost_by_length = Counter()
    old_w_fail_masks = [0] * N
    events = Counter()
    rule_activations = Counter()
    superseded_late_opportunities = 0
    winners = []
    base_winners = []
    cf_old_wins = 0
    cf_old_wins_lost = 0
    for idx, placement in enumerate(permutations(range(1, N + 1))):
        bit = 1 << idx
        length = cycle_max(placement)
        cf_old_wins += length <= LIMIT
        outcomes = []
        baseline_outcomes = []
        for prisoner in range(1, N + 1):
            ok, opened, trace = run_one(placement, prisoner, strategy)
            base_ok, _, base_trace = run_one(placement, prisoner, baseline)
            assert len(opened) <= LIMIT and len(set(opened)) == len(opened)
            outcomes.append(ok)
            baseline_outcomes.append(base_ok)
            if length <= LIMIT and not ok:
                old_w_fail_masks[prisoner - 1] |= bit
            for item in trace:
                events[item[0]] += 1
                if item[0] in ("early", "late"):
                    rule_activations[item[2]] += 1
            if any(item[0] == "early" for item in trace) and any(
                item[0] == "late" for item in base_trace
            ):
                superseded_late_opportunities += 1
        win = sum(outcomes) >= 7
        base_win = sum(baseline_outcomes) >= 7
        cf_old_wins_lost += length <= LIMIT and not win
        if win:
            winners.append(idx)
            wins_by_length[length] += 1
        if base_win:
            base_winners.append(idx)
            base_wins_by_length[length] += 1
        comparison[(base_win, win)] += 1
        if win and not base_win:
            newly_won_by_length[length] += 1
        if base_win and not win:
            newly_lost_by_length[length] += 1
        if length <= LIMIT and not base_win:
            raise AssertionError(("baseline lost CF W", idx, placement))
    overlap_pairs = []
    two_losses_mask = 0
    for i in range(N):
        for j in range(i + 1, N):
            overlap = old_w_fail_masks[i] & old_w_fail_masks[j]
            two_losses_mask |= overlap
            count = overlap.bit_count()
            if count:
                overlap_pairs.append([i + 1, j + 1, count])
    if two_losses_mask.bit_count() != cf_old_wins_lost:
        raise AssertionError("pairwise W-loss test disagrees with direct enumeration")
    result = {
        "strategy_sha256": hashlib.sha256(strategy_path.read_bytes()).hexdigest(),
        "baseline_sha256": hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
        "strategy_rules": len(strategy),
        "baseline_rules": len(baseline),
        "placements": 40320,
        "wins": len(winners),
        "baseline_wins": len(base_winners),
        "CF_old_wins": cf_old_wins,
        "CF_old_wins_lost": cf_old_wins_lost,
        "pairwise_old_W_loss_intersections": overlap_pairs,
        "both_win": comparison[(True, True)],
        "new_vs_baseline": comparison[(False, True)],
        "lost_vs_baseline": comparison[(True, False)],
        "both_lose": comparison[(False, False)],
        "wins_by_max_cycle_length": dict(sorted(wins_by_length.items())),
        "baseline_wins_by_max_cycle_length": dict(sorted(base_wins_by_length.items())),
        "new_vs_baseline_by_max_cycle_length": dict(sorted(newly_won_by_length.items())),
        "lost_vs_baseline_by_max_cycle_length": dict(sorted(newly_lost_by_length.items())),
        "early_activations": events["early"],
        "late_activations": events["late"],
        "fallback_activations": events["fallback"],
        "early_superseded_baseline_late_events": superseded_late_opportunities,
        "activated_rule_count": len(rule_activations),
        "early_rule_count": sum(len(h) < 3 for _, h in strategy),
        "late_rule_count": sum(len(h) == 3 for _, h in strategy),
    }
    if result["baseline_wins"] != 15048:
        raise AssertionError(("baseline score mismatch", result["baseline_wins"]))
    if result["CF_old_wins"] != 14736:
        raise AssertionError(("CF score mismatch", result["CF_old_wins"]))
    if result["CF_old_wins_lost"] and not overlap_pairs:
        raise AssertionError("W loss without a pairwise failure intersection")
    if strategy_data.get("schema") == "mixed-n8-v1":
        reported = strategy_data.get("evaluation", {})
        expected = {
            "wins": result["wins"],
            "CF_old_wins_lost": result["CF_old_wins_lost"],
            "new_vs_52_cycle_baseline": result["new_vs_baseline"],
            "lost_vs_52_cycle_baseline": result["lost_vs_baseline"],
        }
        for key, value in expected.items():
            if reported.get(key) != value:
                raise AssertionError(("reported result mismatch", key, reported.get(key), value))
    return result


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("strategy", nargs="?", type=Path,
                    default=ROOT / "best_from52_n8.json")
    ap.add_argument("--baseline", type=Path,
                    default=ROOT / "best52_costar_Z4_n8.json")
    ap.add_argument("--output", type=Path,
                    default=ROOT / "verification_from52_n8.json")
    args = ap.parse_args()
    result = verify(args.strategy, args.baseline)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in (
        "wins", "baseline_wins", "CF_old_wins_lost", "new_vs_baseline",
        "lost_vs_baseline", "early_rule_count", "late_rule_count",
    )}, ensure_ascii=False))
    print(f"saved={args.output}")


if __name__ == "__main__":
    main()
