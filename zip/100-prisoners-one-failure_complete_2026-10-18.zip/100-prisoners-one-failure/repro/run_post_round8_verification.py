"""Recheck post-Round8 certificates and finite lemmas without a solver.

Use --extended for all 913 pair seeds, and --orientation for the complete
6,250,496 support screen (Windows PowerShell/C#) and independent S8 partition.
All original source files run in an isolated temporary copy.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parent.parent
POST=ROOT/"repro/post-round8"
ARCHIVE=POST/"work"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def check_expected_outputs(out):
    basic=load(out/"c3_basic_checks.json")
    assert tuple(basic[k] for k in ("active_words","admissible_blocks_total","old_words","old_blocks","new_side_exact_covers"))==(210,1896,186,1584,12)
    lemma=load(out/"c3_lemmas.json")
    assert lemma["L2_feasible_local_witnesses"]==lemma["L3_feasible_local_witnesses"]==0
    assert lemma["L4_max_shared_correct_rules_[7]_seven_pairs"]==1
    cores=load(out/"canonical_six_witness_review.json")
    assert cores["status"]=="PASS" and cores["accepted_unique_cores"]==70
    assert cores["extras_histogram"]=={"0":4,"1":21,"2":45}
    assert load(out/"c3_python_control.json")["status"]=="PASS_FOUND_VALID_COVER"
    assert load(out/"c3_python_triangles.json")["status_counts"]=={"EXHAUSTED":248}
    triangle=load(out/"fourflip_triangles.json")
    assert triangle["counts"]=={"EXHAUSTED_NO_COMPLETION":48} and triangle["not_run"]==0
    four=load(out/"fourflip_cores.json")
    assert four["total"]==four["exhausted"]==21097 and four["found"]==four["unknown"]==0
    assert load(out/"unrestricted_two_extra_audit.json")["feasible_joint_packings"]==0

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path,default=ROOT/"verification/post-round8")
    p.add_argument("--extended",action="store_true")
    p.add_argument("--orientation",action="store_true")
    args=p.parse_args()
    out=args.output.resolve()
    if out==ARCHIVE or ARCHIVE in out.parents:
        p.error("--output must be outside the preserved work directory.")
    out.mkdir(parents=True,exist_ok=True)
    checks=[]
    env=dict(os.environ,PYTHONUTF8="1",PYTHONDONTWRITEBYTECODE="1")
    manifest=load(ROOT/"docs/post-round8-source-manifest.json")
    start=time.monotonic()
    for record in manifest["files"]:
        source=ARCHIVE/record["relative_path"]
        assert source.is_file(),str(source)
        assert hashlib.sha256(source.read_bytes()).hexdigest()==record["sha256"],str(source)
    checks.append(dict(task="original-source-integrity",status="PASS",files=len(manifest["files"]),
                       seconds=round(time.monotonic()-start,3)))
    with tempfile.TemporaryDirectory(prefix="post-round8-",dir=out) as temp:
        scratch=Path(temp)
        work=scratch/"work"
        shutil.copytree(ARCHIVE,work,ignore=shutil.ignore_patterns("__pycache__"))
        c3=work/"claude_desktop_continuation3"
        def task(name,script,arguments=(),cwd=work,artifacts=(),timeout=600):
            began=time.monotonic()
            log=out/(name+".txt")
            print("RUN",name,flush=True)
            with log.open("w",encoding="utf-8",newline="\n") as stream:
                proc=subprocess.run([sys.executable,"-X","utf8","-B",str(script),*map(str,arguments)],
                                    cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,
                                    timeout=timeout,check=False)
            if proc.returncode:
                print(log.read_text(encoding="utf-8"),flush=True)
                raise SystemExit("FAILED: "+name)
            for relative,target in artifacts:
                shutil.copy2(cwd/relative,out/target)
            checks.append(dict(task=name,status="PASS",returncode=proc.returncode,
                               seconds=round(time.monotonic()-began,3),transcript=log.name))
            print("PASS",name,flush=True)
        task("general-proof-implementation",POST/"audit_general.py",
             ["--output",out/"general_audit.json"])
        task("five-certificate-direct-simulation",POST/"audit_certificates.py",
             ["--work",work,"--output",out/"certificates.json"])
        task("standard3-structural-checks",c3/"c3_basic_checks.py",cwd=c3,
             artifacts=[("c3_basic_checks.json","c3_basic_checks.json")])
        task("standard3-extra-rule-lemmas",c3/"c3_lemmas.py",cwd=c3,
             artifacts=[("c3_lemmas.json","c3_lemmas.json")])
        task("unrestricted-local-two-extra-lemma",POST/"audit_unrestricted_two_extra.py",
             artifacts=[("unrestricted_two_extra_audit.json","unrestricted_two_extra_audit.json")])
        task("canonical-six-window-cores",work/"canonical_six_witness_independent_review_20261018.py",
             artifacts=[("canonical_six_witness_independent_review_20261018.json","canonical_six_witness_review.json")])
        task("exact-fraction-capacity-certificates",work/"canonical_support_fraction_certificate_verify.py",
             artifacts=[("canonical_support_fraction_certificate_verify.json","fraction_certificates.json")])
        task("python-completion-positive-control",POST/"audit_c3_python.py",
             ["--source",c3,"--control",work/"chatgpt_15050_received.rules.json"],
             artifacts=[("c3_python_control.json","c3_python_control.json")])
        task("standard3-all-triangle-completions",POST/"audit_c3_python.py",["--source",c3,"--triangles"],
             artifacts=[("c3_python_triangles.json","c3_python_triangles.json")])
        task("fourflip-all-triangle-completions",work/"fourflip_triangle_pure_completion.py",
             artifacts=[("fourflip_triangle_pure_completion.json","fourflip_triangles.json")])
        task("fourflip-all-compound-cores",work/"fourflip_independent_regenerate_cover.py",
             artifacts=[("fourflip_independent_regenerate_cover.json","fourflip_cores.json")])
        task("sevenflip-9-and-15-rulepair-bound",work/"sevenflip_independent_rulepair_bound.py",
             artifacts=[("sevenflip_independent_rulepair_bound.json","sevenflip_rulepair_bound.json")])
        if args.extended:
            seed_hash=hashlib.sha256((c3/"c3_seeds.json").read_bytes()).hexdigest()
            task("standard3-witness-seed-regeneration",c3/"c3_witness.py",cwd=c3,
                 artifacts=[("c3_witness.json","c3_witness.json")])
            assert hashlib.sha256((c3/"c3_seeds.json").read_bytes()).hexdigest()==seed_hash
            task("standard3-all-913-pair-completions",POST/"audit_c3_python.py",["--source",c3],
                 artifacts=[("c3_python_pairs_0_913.json","c3_python_pairs_0_913.json")],timeout=1800)
            pairs=load(out/"c3_python_pairs_0_913.json")
            assert len(pairs["records"])==913 and pairs["total_cores"]==2938
        if args.orientation:
            task("all-core-support-screen",work/"independent_allcore_support_screen_20261018.py",
                 artifacts=[("independent_allcore_support_screen_20261018.json","support_screen.json")])
            task("independent-S8-orbit-partition",work/"independent_orientation_S8_partition_20261018.py",
                 artifacts=[("independent_orientation_S8_partition_20261018.json","S8_partition.json")])
    check_expected_outputs(out)
    assert load(out/"general_audit.json")["status"]=="PASS"
    assert load(out/"certificates.json")["status"]=="PASS"
    assert load(out/"fraction_certificates.json")["counts"]=={
        "EXACT_FRACTION_DUAL_EXCLUSION":1372,"CBC_INTEGER_INFEASIBLE":1,"INTEGER_RELAXATION_SURVIVES":5}
    summary=dict(status="PASS",verification_date_jst=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(),
                 python=sys.version,checks_passed=len(checks),checks=checks,
                 options=dict(extended=args.extended,orientation=args.orientation),
                 original_source_files_preserved=True,solver_searches_rerun=False,
                 entire_nonstar_chain_reproved_by_this_command=False,
                 scope="Direct saved construction checks; the named exact finite audits and rational certificates. CBC infeasibility and complete-rule solver exclusions remain separate archived computations unless the advanced runner is used.",
                 total_win_optimality_proved=False)
    (out/"current_checks.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
    print("ALL POST-ROUND8 CHECKS PASSED",flush=True)
if __name__=="__main__":
    main()

