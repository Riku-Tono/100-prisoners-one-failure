"""Heuristic52-block recombination inside the union of six actual tables.

Use baseline15051 and the five newly found52-block tables(core8/24/30/32/59).
All3360 singleton choices remain. Only blocks outside their union are fixed
to0. No known7-cycle is fixed; any4 rescued7-cycles are allowed. Results
concern this block-pool family only, not all fullstar tables or global bounds.
Original tables and earlier result files are read-only inputs.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,time
from general_orientation_model import H,build,orientation_data,read_rules,cp_model,canon

PREFIX='fullstar_six_table_union_pool_20261018'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(path,obj):Path(path).write_text(json.dumps(obj,indent=2),encoding='utf-8')


def main():
    started=time.monotonic();data=orientation_data(())
    sources=[('baseline',H/'inputs/baseline15051.rules.json')]+[
        (f'core{i}',H/f'fullstar_priority62_screen1.core{i:03}.rules.json') for i in (8,24,30,32,59)]
    temporary=build((),3)
    controls=[];pool=set();rule_sets=[];selected_sets=[]
    for label,path in sources:
        raw=json.loads(path.read_text(encoding='utf-8-sig'));rules=read_rules(path)
        selected,extras=temporary.certificate_assignment(rules)
        assert len(selected)==52 and len(extras)<=2
        assert all(set(r[:4])<=set(range(1,8)) for r in rules)
        assert all(r in data.singles for r in rules)
        assert len({canon(r[:4]) for r in rules})==len(rules)
        actual=set().union(*(data.blocks[b] for b in selected))
        assert len(actual)==208 and actual|extras==rules and not actual&extras
        reported=raw.get('selected_block_ids')
        if reported is not None:assert selected==set(reported)
        reported_extras=raw.get('extra_rules')
        if reported_extras is not None:assert extras==set(map(tuple,reported_extras))
        controls.append(dict(label=label,path=str(path),sha256=sha(path),rules=len(rules),
                             selected_block_ids=sorted(selected),extras=sorted(extras),
                             serialized_ids_present=reported is not None,
                             serialized_ids_match_actual=True if reported is not None else None,
                             all_rules_in_fullstar=True))
        pool.update(selected);rule_sets.append(rules);selected_sets.append(selected)
    pool=sorted(pool);outside=set(range(2520))-set(pool)
    assert len(pool)<=312 and all(s<=set(pool) for s in selected_sets)
    catalogue_sha=hashlib.sha256(json.dumps([sorted(b) for b in data.blocks],separators=(',',':')).encode()).hexdigest()
    metadata=dict(scope=__doc__,status='PREPARED',source_tables=controls,
                  fullstar_blocks=2520,pool_size=len(pool),pool_block_ids=pool,
                  pool_actual_blocks=[sorted(data.blocks[b]) for b in pool],
                  pool_block_frequency_histogram=dict(Counter(sum(b in s for s in selected_sets) for b in pool)),
                  block_catalogue_sha256=catalogue_sha,workers=1,limit_seconds=180,
                  singleton_options_retained=3360,known_cycle_mandatory_constraints=0,
                  outside_pool_block_variables_fixed_zero=len(outside),R5=52,R6=0,R7_target=4,
                  bound_scope='Only52-block selections wholly inside this six-table union pool, with all3360 admissible singletons and<=2 extras.')
    save(H/f'{PREFIX}.preparation.json',metadata)

    positive=build((),3)
    for b in outside:positive.model.add(positive.blocks[b]==0)
    fixed=positive.fix_certificate(rule_sets[0])
    solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.max_time_in_seconds=15
    st=solver.solve(positive.model);assert st==cp_model.OPTIMAL
    positive_result=dict(status=solver.status_name(st),fixed=fixed,solve_seconds=solver.wall_time,
                         pool_size=len(pool),outside_pool_zero_constraints=len(outside))
    positive_result.update(positive.export_and_audit(solver,H/f'{PREFIX}.positive.rules.json'))
    assert positive_result['audit']['wins']==15051 and positive_result['audit']['rescued_cycles']=={'5':52,'6':0,'7':3,'8':0}
    save(H/f'{PREFIX}.positive.json',positive_result)

    model=build((),4)
    assert len(model.singles)==3360 and model.stats['seven_variable_flags']==720 and model.stats['eight_variable_flags']==0
    for b in outside:model.model.add(model.blocks[b]==0)
    assert not model.model.validate()
    model_path=H/f'{PREFIX}.model.pbtxt';model.model.export_to_file(str(model_path))
    result=dict(scope=__doc__,status='RUNNING',pool_size=len(pool),pool_block_ids=pool,
                source_tables=controls,positive_control=positive_result,model_stats=model.stats,
                workers=1,limit_seconds=180,outside_pool_zero_constraints=len(outside),
                all3360_singletons_retained=True,known_cycle_mandatory_constraints=0,
                target=4,model_proto=str(model_path),model_proto_sha256=sha(model_path),
                claim_boundary=metadata['bound_scope'])
    save(H/f'{PREFIX}.result.json',result)
    print('READY pool',len(pool),'outside-zero',len(outside),'singletons',len(model.singles),'positive',positive_result['status'],positive_result['audit']['wins'],flush=True)
    solve=cp_model.CpSolver();solve.parameters.num_search_workers=1
    solve.parameters.max_time_in_seconds=180;solve.parameters.random_seed=1
    solve.parameters.log_search_progress=True;solve.parameters.log_to_stdout=False
    with (H/f'{PREFIX}.log.txt').open('w',encoding='utf-8') as log:
        solve.log_callback=lambda line:log.write(line+'\n')
        st=solve.solve(model.model)
    result.update(status=solve.status_name(st),solve_seconds=solve.wall_time,response_stats=solve.response_stats(),
                  total_seconds=time.monotonic()-started)
    if st in (cp_model.OPTIMAL,cp_model.FEASIBLE):
        result.update(model.export_and_audit(solve,H/f'{PREFIX}.found.rules.json'))
        assert result['audit']['wins']>=15052
    for r in controls:assert sha(r['path'])==r['sha256']
    save(H/f'{PREFIX}.result.json',result)
    print('FINAL',result['status'],'seconds',result['solve_seconds'],'pool',len(pool),flush=True)
    if 'audit'in result:print('VERIFIED',result['audit']['wins'],result['audit']['rescued_cycles'],flush=True)


if __name__=='__main__':main()
