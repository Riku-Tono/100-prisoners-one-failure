"""Static actual-rule checks and exact scope of the63 priority witness cores.

No critical enumeration, completion solver or native executable is invoked.
The already-finished lexical independent enumerations are checked against
the corresponding primary actual-block sets. The21952 mother domain is
three specific cycles with block-only six-correct witnesses, not all fullstar.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import hashlib,json,sys,time

H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'claude_desktop_continuation3'))
from c3_model import cyc_rules,directed_cycles,word,rotmin


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    started=time.monotonic()
    allblocks=set()
    for s in combinations(range(1,8),5):
        for cycle in directed_cycles(s):
            rr=cyc_rules(cycle)
            for skipped in range(5):allblocks.add(frozenset(rr[:skipped]+rr[skipped+1:]))
    blocks=tuple(sorted(allblocks,key=lambda b:tuple(sorted(b))));lookup={b:i for i,b in enumerate(blocks)}
    catalogue_sha=hashlib.sha256(json.dumps([sorted(b) for b in blocks],separators=(',',':')).encode()).hexdigest()
    six=[frozenset(cyc_rules(c)) for s in combinations(range(1,8),6) for c in directed_cycles(s)]
    seven=[(c,frozenset(cyc_rules(c))) for c in directed_cycles(range(1,8))]
    manifest_path=H/'fullstar_priority63_preparation_20261018.json'
    manifest=json.loads(manifest_path.read_text());cycles=tuple(map(tuple,manifest['same_known_three_cycles']));cycle_set=set(cycles)
    assert len(cycle_set)==3
    static_rows=[]
    for i in (30,32,59):
        source=H/f'fullstar_priority63_prepared_core{i:03}.critical.json'
        output=H/f'fullstar_core{i:03}_critical_lexical_independent_20261018.json'
        d=json.loads(source.read_text());result=json.loads(output.read_text())
        assert d['block_catalogue_sha256']==catalogue_sha
        assert result['status']=='PASS_EXACT_CRITICAL_CORE_SET' and result['primary_sha256']==sha(source)
        fixed=frozenset(lookup[frozenset(map(tuple,b))] for b in d['fixed_actual_blocks'])
        assert len(fixed)==18 and sorted(fixed)==d['fixed_core']==result['fixed_blocks']
        seed=manifest['seeds'][i]
        assert fixed=={lookup[frozenset(map(tuple,b))] for b in seed['actual_blocks']}
        fixedrules=frozenset().union(*(blocks[b] for b in fixed))
        rescued={c for c,rr in seven if len(rr&fixedrules)>=6}
        assert rescued==cycle_set and max(len(rr&fixedrules) for rr in six)<=4
        assert [len(set(cyc_rules(c))&fixedrules) for c in cycles]==[6,6,6]
        expected=set()
        for row in d['records']:
            core=fixed|{lookup[frozenset(map(tuple,b))] for b in row['additional_actual_blocks']}
            assert sorted(core)==row['core_blocks']
            extras=frozenset(map(tuple,row['critical_extra_rules']))
            assert len(extras)==len(row['critical_extra_rules'])<=2
            assert all(len(r)==len(set(r))==5 and set(r)<=set(range(1,8)) for r in extras)
            rules=frozenset().union(*(blocks[b] for b in core))|extras
            assert len(rules)==4*len(core)+len(extras)
            assert len({word(r) for r in rules})==len(rules)
            assert all(tuple(c) not in cycle_set and len(set(cyc_rules(c))&rules)>=6 for c in row['fourth_cycles'])
            expected.add((tuple(sorted(core)),tuple(sorted(extras))))
        encoding=''.join(json.dumps([bs,es],separators=(',',':'))+'\n' for bs,es in sorted(expected)).encode('ascii')
        assert hashlib.sha256(encoding).hexdigest()==result['core_set_sha256']
        assert len(expected)==d['unique_critical_cores']==result['distinct_critical_cores']
        static_rows.append(dict(core_index=i,critical_count=len(expected),fourth_cycle_count=result['distinct_fourth_cycles'],
                                source_sha256=sha(source),independent_output_sha256=sha(output),
                                exact_actual_core_extra_set_sha256=result['core_set_sha256'],
                                actual_base_R6=0,actual_base_R7=3,actual_known_cycle_correct_counts=[6,6,6],
                                all_additional_actual_blocks_match_ids=True,all_extra_tuples_and_slots_valid=True,
                                independent_dfs_nodes=result['nodes'],primary_dfs_nodes=result['primary_nodes'],
                                independent_seconds=result['seconds']))

    # Every stabilizer element must send first directed cycle to one of3
    # target cycles, with one of7 rotations. This exhausts all21 possibilities.
    stabilizer=[]
    for target in cycles:
        for shift in range(7):
            perm={cycles[0][j]:target[(j+shift)%7] for j in range(7)}
            image={rotmin(tuple(perm[x] for x in c)) for c in cycles}
            if image==cycle_set:stabilizer.append(tuple(perm[x] for x in range(1,8)))
    assert set(stabilizer)=={tuple(range(1,8))}
    keys=set();extension_indices=[]
    for seed in manifest['seeds']:
        core=frozenset(lookup[frozenset(map(tuple,b))] for b in seed['actual_blocks'])
        assert len(core)==18 and tuple(sorted(core))==tuple(seed['blocks'])
        rules=frozenset().union(*(blocks[b] for b in core))
        assert {c for c,rr in seven if len(rr&rules)>=6}==cycle_set
        assert max(len(rr&rules) for rr in six)<=4
        assert [len(set(cyc_rules(c))&rules) for c in cycles]==[6,6,6]
        keys.add(tuple(sorted(core)));extension_indices.append(seed['expansion_representative_index'])
    assert len(keys)==len(set(extension_indices))==63
    assert manifest['source_all_threecycle_orbits']==28**3==21952
    assert manifest['previously_closed_orbits']==1
    assert manifest['other_unselected_unclosed_orbits']==21952-1-63==21888
    out=dict(status='PASS_STATIC_ACTUAL_SETS_AND_SCOPED63_SUBSET',scope=__doc__,
             already_finished_independent_critical_enumerations=static_rows,
             independent_enumerator_source_sha256=sha(H/'fullstar_core4_critical_independent.py'),
             independent_enumerator_imports=['c3_model','Python standard library'],
             primary_enumerator_or_completion_solver_imported=False,new_solver_or_enumerator_invoked=False,
             manifest_sha256=sha(manifest_path),block_catalogue_sha256=catalogue_sha,
             mother_domain=dict(known_directed_cycles=cycles,block_only_six_correct_witnesses_per_cycle=28,
                                compatible_triples=21952,distinct18block_unions=21952,
                                unordered_threecycle_set_S7_stabilizer=[list(x) for x in stabilizer],
                                stabilizer_order=1),
             selected_priority_subset=dict(description='Exactly one coordinate uses one of21 six-block witnesses outside its unique seven-correct pure-block template; other two coordinates equal the baseline six-witness choices.',
                                           per_changed_cycle=[21,21,21],count=63,distinct_actual_core_keys=63,
                                           mother_representative_indices=sorted(extension_indices)),
             nonisomorphism=dict(all63_partial_rule_sets_rescue_exactly_the_same3_cycles=True,
                                  S7_isomorphic_distinct_core_pairs=0,
                                  reason='Any label isomorphism between two partial cores maps their exactly3 rescued directed7-cycles to each other, hence stabilizes this unordered3-cycle set. Its stabilizer is identity, so distinct actual cores are not S7-isomorphic.',
                                  warning='Distinct or nonisomorphic cores need not define disjoint sets of completed tables; a completed table can contain multiple cores.'),
             unselected_complement=dict(exact_count=21888,formula='28^3 -1 baseline18core -63 priority cores',
                                        one_changed_coordinate_other_extendable_witnesses=3*6,
                                        two_changed_coordinates=3*27**2,
                                        three_changed_coordinates=27**3,
                                        sum=3*6+3*27**2+27**3,
                                        status_meaning='These are mother-domain cores outside the priority63 selection and the old closed baseline core. This is not a current global unresolved-strategy count; completion statuses of the selected63 are tracked elsewhere.'),
             boundaries=['All63 partial seeds require six correct rules per known cycle, not seven; completed tables may have6/7 or7/7 correct.',
                         'The21 nonextension witnesses per cycle are not subsets of the unique7-correct block template. This does not imply noncompletion to52 blocks, as an independently audited counterexample showed.',
                         'The mother21952 fixes three particular rescued cycles and requires block-only six-correct witnesses for all3. Other triples of rescued cycles and cycles aided by singleton rules are outside it.',
                         'A critical-core exact-match audit verifies local enumeration completeness for its fixed18 seed. It does not itself prove52-block completion infeasibility.',
                         'No global fullstar upper bound or global optimum follows from these63 or the mother21952.'],
             seconds=time.monotonic()-started)
    path=H/'fullstar_priority63_scope_and_critical3_audit_20261018.json'
    path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('PASS',[(r['core_index'],r['critical_count']) for r in static_rows],'63 distinct/nonisomorphic; unselected21888; seconds',out['seconds'],flush=True)


if __name__=='__main__':main()
