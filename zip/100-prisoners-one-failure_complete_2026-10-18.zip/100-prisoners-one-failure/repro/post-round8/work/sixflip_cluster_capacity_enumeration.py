"""Exhaustive small-integer support-capacity allocation, without any solver.

Variables count new four-rule blocks by exact support pattern. Eachsupport
has6cyclicwords. With6flips thereare174old and36newwords. A52blockpacking
uses208words, soatleast34newwords mustbeconsumed. Cyclicword compatibility,
R6 and R7 are not searched. Passing allocationsare necessary only.
"""
from pathlib import Path
from itertools import product
from collections import Counter,defaultdict
import json,time,hashlib
H=Path(__file__).resolve().parent;raw=(H/'sixflip_model_preparation_summary.json').read_bytes();data=json.loads(raw);start=time.monotonic();records=[]
for model in data['records']:
 pats=model['new_block_support_patterns'];supports=sorted({tuple(s)for p in pats for s in p['new_supports']+p['old_supports']});si={s:i for i,s in enumerate(supports)};cols=[[si[tuple(s)]for s in p['new_supports']+p['old_supports']]for p in pats];nc=[len(p['new_supports'])for p in pats];oc=[len(p['old_supports'])for p in pats];allocations=[];tested=0
 for x in product(range(7),repeat=len(pats)):
  tested+=1;newused=sum(c*n for c,n in zip(x,nc))
  if not 34<=newused<=36:continue
  resources=[0]*len(supports);valid=True
  for c,indexes in zip(x,cols):
   for j in indexes:
    resources[j]+=c
    if resources[j]>6:valid=False;break
   if not valid:break
  if not valid:continue
  b=sum(x);oldused=sum(c*n for c,n in zip(x,oc));oldblocks=52-b;assert 4*oldblocks+oldused<=174
  consumed={supports[i]:n for i,n in enumerate(resources)if n};fully_old=[list(s)for s,n in consumed.items()if 8 not in s and n==6]
  allocations.append({'pattern_block_counts':x,'new_blocks':b,'new_word_slots_used':newused,'new_word_holes':36-newused,'old_word_slots_used_by_new_blocks':oldused,'remaining_old_blocks':oldblocks,'old_word_holes_after52blocks':174-oldused-4*oldblocks,'fully_consumed_old_supports':fully_old,'support_word_usage':[{'support':list(s),'words':n}for s,n in sorted(consumed.items())]})
 rec={'orbit_index':model['orbit_index'],'flips':model['flips'],'patterns':pats,'integer_vectors_enumerated':tested,'necessary_allocation_count':len(allocations),'allocations':allocations,'passes_support_capacity_52_test':bool(allocations),'syntactic_model_validate_passed':model['validation_passed']}
 records.append(rec);print(rec['orbit_index'],'patterns',len(pats),'vectors',tested,'necessaryallocations',len(allocations),[a['pattern_block_counts']for a in allocations],flush=True)
out={'method':__doc__,'source_preparation_sha256':hashlib.sha256(raw).hexdigest(),'records':records,'passes_orbit_indices':[r['orbit_index']for r in records if r['passes_support_capacity_52_test']],'fails_orbit_indices':[r['orbit_index']for r in records if not r['passes_support_capacity_52_test']],'necessary_only':True,'solver_calls':0,'actual_rule_packing_search_performed':False,'seconds':time.monotonic()-start}
(H/'sixflip_cluster_capacity_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('FINAL',out['passes_orbit_indices'],out['fails_orbit_indices'],out['seconds'],flush=True)
