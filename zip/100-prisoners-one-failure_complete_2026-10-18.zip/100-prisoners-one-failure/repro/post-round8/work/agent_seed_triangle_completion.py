"""Complete each of the 248 triangle orbits with 46 old blocks + 2 holes.

Independent array-DLX backend permits at most two singleton columns. A leaf
must use exactly two of them, hence exactly 46 four-column rows overall.
The 18 mandatory rows are independently checked for pairwise disjointness.
"""
from completion_dlx_recheck import DLX, RULES, ROWS, WORDS, normalized_control
from pathlib import Path
from collections import Counter
import json,time,sys
H=Path(__file__).resolve().parent

class FlexibleDLX(DLX):
    def search_flexible(self, selected, holes, budget):
        self.nodes+=1
        if self.nodes % 10000==0 and time.monotonic()>self.deadline:raise TimeoutError
        if not self.right[0]:
            if budget:return False
            self.answer=selected[:];self.answer_holes=holes[:];return True
        c=self.right[0];j=self.right[c];zeros=[]
        while j:
            if self.size[j]<self.size[c]:c=j
            if self.size[j]==0:zeros.append(j)
            j=self.right[j]
        if len(zeros)>budget:return False
        if self.size[c]==0 and not budget:return False
        self.cover(c);i=self.down[c];found=False
        options=[]
        while i!=c:
            options.append(i);i=self.down[i]
        options.sort(key=lambda i:self.row[i] not in self.hint)
        for i in options:
            j=self.right[i]
            while j!=i:self.cover(self.col[j]);j=self.right[j]
            found=self.search_flexible(selected+[self.row[i]],holes,budget)
            j=self.left[i]
            while j!=i:self.uncover(self.col[j]);j=self.left[j]
            if found:break
        if not found and budget:
            found=self.search_flexible(selected,holes+[c],budget-1)
        self.uncover(c);return found
    def run_flexible(self, mandatory, seconds=30, hint=frozenset()):
        removed=[]
        for b in sorted(mandatory):removed.extend(self.force_row(b))
        self.nodes=0;self.answer=None;self.hint=hint
        self.deadline=time.monotonic()+seconds
        try:
            found=self.search_flexible([],[],2)
        except TimeoutError:
            # A timed-out mutable matrix is discarded, never reused.
            return 'UNKNOWN',self.nodes,None,None
        for c in reversed(removed):self.uncover(c)
        assert len(self.active)==186 and self.right[0]!=0
        holes=[WORDS[c-1] for c in self.answer_holes] if found else None
        return 'FOUND' if found else 'EXHAUSTED_NO_COMPLETION',self.nodes,self.answer,holes

def main():
    data=json.loads((H/'agent_seed_triangles.json').read_text())
    out={'scope':data['scope']+'; exactly46 old blocks and exactly2 unrestricted holes; no R6/R7 condition on completion','method':'array DLX with two singleton column branches','cases':[]}
    matrix=FlexibleDLX();control,singles=normalized_control()
    controlfixed=set(sorted(control)[:18])
    status,nodes,extra,holes=matrix.run_flexible(controlfixed,30,control)
    assert status=='FOUND'
    out['positive_control']={'status':status,'fixed_blocks':18,'additional_blocks':len(extra),'nodes':nodes}
    print('positive_control',out['positive_control'],flush=True)
    start=time.monotonic()
    timeout=float(sys.argv[1]) if len(sys.argv)>1 else 30
    for i,seed in enumerate(data['seeds']):
        mandatory=set(seed['block_ids'])
        used=[w for b in mandatory for w in ROWS[b]]
        assert len(used)==72 and len(set(used))==72
        status,nodes,extra,holes=matrix.run_flexible(mandatory,timeout)
        rec={'case':i,'status':status,'nodes':nodes}
        if status=='FOUND':
            allblocks=sorted(mandatory|set(extra)); used=[w for b in allblocks for w in ROWS[b]]
            assert len(allblocks)==46 and len(set(used))==184 and len(used)==184
            assert set(used)|set(holes)==set(WORDS)
            rec.update(block_ids=allblocks,holes=holes)
        if status=='UNKNOWN':matrix=FlexibleDLX()
        out['cases'].append(rec)
        out['counts']=dict(Counter(r['status'] for r in out['cases']))
        out['seconds']=time.monotonic()-start
        (H/'agent_seed_triangle_completion.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        print(i,status,nodes,'elapsed',round(out['seconds'],3),flush=True)
    print('FINAL',out['counts'],out['seconds'],flush=True)
if __name__=='__main__':main()
