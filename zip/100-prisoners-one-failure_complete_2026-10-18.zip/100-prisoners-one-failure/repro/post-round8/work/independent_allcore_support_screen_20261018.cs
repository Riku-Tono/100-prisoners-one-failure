using System;
using System.Collections.Generic;

public static class IndependentAllCoreSupportScreen20261018 {
    // req/value come from actual four-rule block supports, not five-set clusters.
    public static long[] Run(long[] req, long[] value, int[][] supportPatterns, int[] free) {
        var accepted = new List<long>();
        int total = 1 << free.Length;
        for (int k = 0; k < total; ++k) {
            long flips = 0;
            for (int j = 0; j < free.Length; ++j)
                if ((k & (1 << j)) != 0) flips |= 1L << free[j];
            bool pass = true;
            for (int j = 0; j < 35; ++j) {
                int activeSupport = j + (((flips & (1L << j)) != 0) ? 35 : 0);
                bool available = false;
                foreach (int p in supportPatterns[activeSupport]) {
                    if ((flips & req[p]) == value[p]) { available = true; break; }
                }
                if (!available) { pass = false; break; }
            }
            if (pass) accepted.Add(flips);
        }
        accepted.Sort();
        return accepted.ToArray();
    }
}
