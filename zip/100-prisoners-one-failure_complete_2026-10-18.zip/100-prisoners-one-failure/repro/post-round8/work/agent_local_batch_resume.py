"""Resume own seed range, retaining every exhaustive prior no-good."""
from pathlib import Path
import sys,json,time,contextlib,traceback
from collections import Counter,defaultdict
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H))
from agent_seed_local_completion import *
from independent_audit import audit

def run(index,seed,deadline):
 path=H/f'agent_seed_local_completion_{index}.json';prior=json.loads(path.read_text())if path.exists()else{}
 if prior.get('status')=='LOCAL_INFEASIBLE':return prior
 m,bs,ss,stats=build(seed,True);records=prior.get('records',[])
 for r in records:
  if r['status'].startswith('EXHAUSTED'):
   m.add_bool_or([bs[b].Not()for b in set(r['core_blocks'])-set(seed['blocks'])]+[ss[tuple(x)].Not()for x in r['extras']])
 solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.random_seed=index+1
 mat=NoSixDLX();start=time.monotonic();status='WITNESS_LIMIT'
 while len(records)<10000:
  remaining=deadline-time.monotonic()
  if remaining<=0:status='WALL_LIMIT';break
  solver.parameters.max_time_in_seconds=min(2,remaining);st=solver.solve(m)
  if st not in(cp_model.FEASIBLE,cp_model.OPTIMAL):status='LOCAL_'+solver.status_name(st);break
  selected=set(seed['blocks'])|{b for b,v in bs.items()if solver.value(v)};extras={r for r,v in ss.items()if solver.value(v)}
  supplied=set().union(*(RULES[b]for b in selected));newcycles=[rr for rr in CW[7]if sum(r in supplied for r in rr)<=5 and sum(r in supplied|extras for r in rr)>=6];assert len(newcycles)==2
  required={r for rr in newcycles for r in rr if r in supplied};core=set(seed['blocks'])|{b for b in selected if RULES[b]&required};assert len(core)<=22
  crules=set().union(*(RULES[b]for b in core));assert all(sum(r in crules|extras for r in rr)<=4 for rr in CW[6]);assert sum(sum(r in crules|extras for r in rr)>=6 for rr in CW[7])>=4
  remaining=deadline-time.monotonic()
  if remaining<=0:status='WALL_LIMIT';break
  status,nodes,additional=mat.run_nosix(core,extras,min(2,remaining))
  rec={'iteration':len(records),'local_cp_seconds':solver.wall_time,'status':status,'nodes':nodes,'core_blocks':sorted(core),'extras':sorted(extras)};records.append(rec)
  if status=='FOUND':
   allblocks=core|set(additional);assert len(allblocks)==46
   raw=json.loads((H/'inputs/new15051.rules.json').read_text());groups=defaultdict(set)
   for a,h,t in raw['rules']:
    r=(a,*h,t);groups[rotate_min((t,)+r[:4])].add(r)
   new=set().union(*(g for g in groups.values()if len(g)==4 and any(8 in r for r in g)));full=new|set().union(*(RULES[b]for b in allblocks))|extras
   cert=H/f'agent_resume_found_{index}.rules.json';cert.write_text(json.dumps({'n':8,'rules':[[r[0],list(r[1:4]),r[4]]for r in sorted(full)]},indent=2),encoding='utf-8');check=audit(cert);assert check['wins']>=15052 and check['lost_cf']==0 and check['rescued_cycles']['6']==0;rec['certificate']=str(cert);rec['direct_audit']=check;break
  if status=='UNKNOWN':status='COMPLETION_UNKNOWN';break
  assert status.startswith('EXHAUSTED');m.add_bool_or([bs[b].Not()for b in core-set(seed['blocks'])]+[ss[r].Not()for r in extras])
 out={'scope':__doc__,'seed_index':index,'stats':stats,'records':records,'completion_counts':dict(Counter(r['status']for r in records)),'seconds':prior.get('seconds',0)+time.monotonic()-start,'status':status,'resume_runs':prior.get('resume_runs',0)+1}
 path.write_text(json.dumps(out,indent=2),encoding='utf-8');return out

lo=int(sys.argv[1]);hi=int(sys.argv[2]);budget=float(sys.argv[3]);prefix=sys.argv[4];start=time.monotonic();seeds=json.loads((H/'witness_pair_seeds.json').read_text())['seeds'];pending=[];late=[]
for i in range(lo,hi+1):
 p=H/f'agent_seed_local_completion_{i}.json'
 if not p.exists():pending.append(i)
 elif json.loads(p.read_text())['status']!='LOCAL_INFEASIBLE':late.append(i)
pending+=late;processed=[]
for index in pending:
 remaining=budget-(time.monotonic()-start)
 if remaining<.1:break
 try:d=run(index,seeds[index],time.monotonic()+min(30,remaining));processed.append({'index':index,'status':d['status'],'cores':len(d['records']),'completion_counts':d['completion_counts'],'seconds':d['seconds']})
 except Exception as e:processed.append({'index':index,'status':'ERROR','exception':repr(e),'traceback':traceback.format_exc()})
 statuses={}
 for i in range(lo,hi+1):
  p=H/f'agent_seed_local_completion_{i}.json';statuses[i]=json.loads(p.read_text())['status']if p.exists()else'NOT_RUN'
 out={'method':__doc__,'seed_start':lo,'seed_end_inclusive':hi,'processed':processed,'statuses':statuses,'counts':dict(Counter(statuses.values())),'pending':[i for i,st in statuses.items()if st!='LOCAL_INFEASIBLE'],'seconds':time.monotonic()-start}
 (H/(prefix+'_summary.json')).write_text(json.dumps(out,indent=2),encoding='utf-8');print(index,processed[-1]['status'],processed[-1].get('cores'),round(out['seconds'],2),flush=True)
 if processed[-1]['status']=='FOUND':break
print('FINAL',out['counts'],out['seconds'],flush=True)
