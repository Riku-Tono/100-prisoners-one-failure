"""Prepare full-star block/witness data; no completion/construction search.

All 35 four-supports on [7] are allowed: 210 cyclic words, 2520 four-rule
blocks. Enumerate witnesses of one canonical seven-cycle and reduce under
its cyclic label stabilizer. This prepares a later target-four search only.
"""
from itertools import combinations,permutations
from collections import defaultdict,Counter
from pathlib import Path
import json,time
H=Path(__file__).resolve().parent
def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def correct(c):
    n=len(c);return frozenset((c[i],c[(i+1)%n],c[(i+2)%n],c[(i+3)%n],c[(i+n-1)%n]) for i in range(n))
WORDS=sorted({canon(p) for s in combinations(range(1,8),4) for p in permutations(s)})
blocks=set()
for s in combinations(range(1,8),5):
    for tail in permutations(s[1:]):
        rr=correct((s[0],)+tail)
        for omitted in rr:blocks.add(rr-{omitted})
RULES=sorted(blocks,key=lambda b:tuple(sorted(b)))
ROWS=[frozenset(canon(r[:4]) for r in rs) for rs in RULES]
lookup={rs:i for i,rs in enumerate(RULES)}
assert len(WORDS)==210 and len(RULES)==2520
inc=defaultdict(set)
for b,rs in enumerate(RULES):
    for r in rs:inc[r].add(b)
assert all(len(v)==4 for v in inc.values())

def witnesses(c,excluded=frozenset()):
    rr=correct(c);found=set()
    for ignore in rr:
        def dfs(todo,used,chosen):
            if not todo:found.add(frozenset(chosen));return
            opts=[]
            for r in todo:
                bs=[b for b in inc[r] if not ROWS[b]&used]
                if not bs:return
                opts.append((len(bs),r,bs))
            for b in min(opts)[2]:dfs(todo-RULES[b],used|ROWS[b],chosen|{b})
        dfs(rr-{ignore},excluded,frozenset())
    return found

def main():
    t0=time.monotonic();c=tuple(range(1,8));ws=witnesses(c)
    fullsets=set()
    def full_dfs(todo,used,chosen):
        if not todo:fullsets.add(frozenset(chosen));return
        opts=[(len(bs),r,bs) for r in todo for bs in [[b for b in inc[r] if not ROWS[b]&used]]]
        if not min(opts)[0]:return
        for b in min(opts)[2]:full_dfs(todo-RULES[b],used|ROWS[b],chosen|{b})
    full_dfs(correct(c),frozenset(),frozenset())
    rotations=[]
    for shift in range(7):
        mp={x:(x-1+shift)%7+1 for x in range(1,8)}
        rotations.append([lookup[frozenset(tuple(mp[x] for x in r) for r in rs)] for rs in RULES])
    reps={min(tuple(sorted(g[b] for b in w)) for g in rotations) for w in ws}
    for w in ws:
        used=[s for b in w for s in ROWS[b]]
        assert len(w)==6 and len(used)==len(set(used))==24
        assert sum(r in set().union(*(RULES[b] for b in w)) for r in correct(c))>=6
    out={'status':'PREPARED_NO_CONSTRUCTION_SEARCH','scope':__doc__,'slots':len(WORDS),'blocks':len(RULES),'rules':len(inc),'canonical_cycle':c,'canonical_cycle_witnesses':len(ws),'canonical_cycle_stabilizer_order':len(rotations),'witness_orbits':len(reps),'total_720_cycle_witnesses':len(ws)*720,'witness_size_histogram':dict(Counter(map(len,ws))),'all_seven_correct_block_sets':len(fullsets),'six_witness_full_extension_count_histogram':dict(Counter(sum(w<=u for u in fullsets) for w in ws)),'full_seven_templates':[sorted(w) for w in fullsets],'seconds':time.monotonic()-t0,'seeds':[{'blocks':list(w),'actual_rules':[sorted(RULES[b]) for b in w],'all_seven_correct_extension_count':sum(set(w)<=u for u in fullsets)} for w in sorted(reps)]}
    (H/'fullstar_prepare_basic.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print({k:v for k,v in out.items() if k not in ('seeds','scope')},flush=True)
if __name__=='__main__':main()
