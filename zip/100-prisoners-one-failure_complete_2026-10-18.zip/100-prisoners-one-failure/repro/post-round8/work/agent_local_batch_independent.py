"""Audit own batch excluded cores using separately regenerated bitset checker."""
from pathlib import Path
from collections import Counter
import json,time,sys,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H))
from agent_pair_local_independent import Checker,blocks,rules,cycles
prefix=sys.argv[1] if len(sys.argv)>1 else 'agent_local_batch_135'
p=H/(prefix+'_summary.json');raw=p.read_bytes();d=json.loads(raw);checker=Checker();start=time.monotonic();out={'method':'independent regenerated bitset exactcover + R6 prune; no local CP model imported','input_sha256':hashlib.sha256(raw).hexdigest(),'records':[]}
for summary in d['records']:
 index=summary['index'];seed=json.loads((H/f'agent_seed_local_completion_{index}.json').read_text())
 for rec in seed['records']:
  if rec['status']not in ('EXHAUSTED_NO_COMPLETION','EXHAUSTED_R6_CONFLICT'):continue
  mandatory=set(rec['core_blocks']);extras=set(map(tuple,rec['extras']));rs=set().union(*(blocks[b]for b in mandatory))|extras
  seven=sum(len(rs&rules(c))>=6 for c in cycles(7));six=sum(len(rs&rules(c))>=5 for c in cycles(6));assert seven>=4 and six==0
  found=checker.run(mandatory,extras);assert not found
  out['records'].append({'index':index,'iteration':rec['iteration'],'status':'EXHAUSTED_NO_COMPLETION','nodes':checker.nodes,'local_R7':seven})
out['cases']=len(out['records']);out['nodes']=sum(r['nodes']for r in out['records']);out['seconds']=time.monotonic()-start
(H/(prefix+'_independent.json')).write_text(json.dumps(out,indent=2),encoding='utf-8');print({k:v for k,v in out.items()if k!='records'})
