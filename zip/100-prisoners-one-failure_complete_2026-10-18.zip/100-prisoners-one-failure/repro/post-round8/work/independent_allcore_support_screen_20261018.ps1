$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'independent_allcore_support_screen_20261018.cs')
$doc = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'independent_allcore_support_screen_20261018.input.json') -Raw | ConvertFrom-Json
$records = [System.Collections.Generic.List[object]]::new()
$taskTimer = [System.Diagnostics.Stopwatch]::StartNew()
foreach ($core in $doc.cores) {
    $accepted = [IndependentAllCoreSupportScreen20261018]::Run([long[]]$doc.required, [long[]]$doc.value, [int[][]]$doc.supportPatterns, [int[]]$core.free)
    $records.Add(@{ core_index = [int]$core.core_index; accepted_masks = @($accepted); tested = (1 -shl $core.free.Count) })
    Write-Output "CORE $($core.core_index) accepted $($accepted.Count)"
}
$result = @{ records = @($records.ToArray()); seconds = $taskTimer.Elapsed.TotalSeconds; total_tested = $doc.total_tested }
$result | ConvertTo-Json -Depth 10 -Compress | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'independent_allcore_support_screen_20261018.csharp.json') -Encoding utf8
