"""Enumerate the four-flip 30-slot gadget only; no global strategy search.

The five labels are45678. Allfive four-supports are allowed. Count every
pairwise-disjoint block collection in the six necessary(b,k) cases,
where b is numberofgadgetblocks and k omitsold4567 (fournewwords).
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import Counter
from functools import lru_cache
import time,json
H=Path(__file__).resolve().parent;start=time.monotonic();L=(4,5,6,7,8)
def norm(w):
 w=tuple(w);i=w.index(min(w));return w[i:]+w[:i]
words=sorted({norm(p)for s in combinations(L,4)for p in permutations(s)});new=sorted(w for w in words if 8 in w);old=sorted(w for w in words if 8 not in w);ni={w:i for i,w in enumerate(new)};oi={w:i for i,w in enumerate(old)}
blocks=set()
for p in permutations(L[1:]):
 c=(L[0],)+p;rs=tuple((c[i],c[(i+1)%5],c[(i+2)%5],c[(i+3)%5],c[(i+4)%5])for i in range(5))
 for omit in range(5):blocks.add(frozenset(rs[:omit]+rs[omit+1:]))
blocks=sorted(blocks,key=lambda b:tuple(sorted(b)));data=[];allnew=[];groups=[[]for w in old]
for b,rs in enumerate(blocks):
 ws={norm(r[:4])for r in rs};nw=sum(1<<ni[w]for w in ws if w in ni);ow=sum(1<<oi[w]for w in ws if w in oi);assert nw.bit_count()+ow.bit_count()==4
 data.append((nw,ow))
 if not ow:allnew.append(b)
 else:assert ow.bit_count()==1;groups[ow.bit_length()-1].append(b)
assert len(blocks)==120 and len(allnew)==24 and all(len(g)==16 for g in groups)
packings={k:[]for k in range(1,7)}
def allnew_dfs(pos,used,chosen):
 if chosen:packings[len(chosen)].append((tuple(chosen),used))
 if len(chosen)==6:return
 for j in range(pos,len(allnew)):
  b=allnew[j]
  if not data[b][0]&used:allnew_dfs(j+1,used|data[b][0],chosen+[b])
allnew_dfs(0,0,[])
@lru_cache(maxsize=500000)
def count_mixed(used,remaining):
 if not remaining:return 1
 opts=None;best=None
 for group in range(6):
  if not remaining>>group&1:continue
  candidates=[b for b in groups[group]if not data[b][0]&used]
  if not candidates:return 0
  if opts is None or len(candidates)<len(opts):opts=candidates;best=group
 return sum(count_mixed(used|data[b][0],remaining^(1<<best))for b in opts)
def example_mixed(used,remaining):
 if not remaining:return[]
 choices=[([b for b in groups[g]if not data[b][0]&used],g)for g in range(6)if remaining>>g&1];opts,g=min(choices,key=lambda p:len(p[0]))
 for b in opts:
  if count_mixed(used|data[b][0],remaining^(1<<g)):return[b]+example_mixed(used|data[b][0],remaining^(1<<g))
 raise AssertionError
results=[]
for b,k in ((6,4),(6,5),(6,6),(7,1),(7,2),(7,3)):
 t=b-k;total=0;example=None;case_start=time.monotonic()
 for chosen,used in packings[k]:
  for oldgroups in combinations(range(6),t):
   gm=sum(1<<g for g in oldgroups);n=count_mixed(used,gm);total+=n
   if n and example is None:example=list(chosen)+example_mixed(used,gm)
 rec={'b':b,'k':k,'packings':total,'seconds':time.monotonic()-case_start,'example_block_ids':sorted(example)if example else None,'new_holes':24-3*b-k,'old_U_slots_used':b-k}
 results.append(rec);print(rec,flush=True)
out={'method':__doc__,'labels':L,'cyclic_word_slots':30,'new_slots':24,'old_U_slots':6,'blocks':120,'all_new_blocks':24,'mixed_blocks':96,'all_new_disjoint_packing_counts':{k:len(v)for k,v in packings.items()},'cases':results,'all_new_exact_covers':[list(chosen)for chosen,used in packings[6]],'block_definitions':[{'id':b,'rules':sorted(rs),'new_words':[new[j]for j in range(24)if data[b][0]>>j&1],'old_words':[old[j]for j in range(6)if data[b][1]>>j&1]}for b,rs in enumerate(blocks)],'cache_info':str(count_mixed.cache_info()),'construction_search_performed':False,'seconds':time.monotonic()-start}
(H/'support_orientation_four_flip_gadget_covers.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('FINAL',out['all_new_disjoint_packing_counts'],out['seconds'],out['cache_info'],flush=True)
