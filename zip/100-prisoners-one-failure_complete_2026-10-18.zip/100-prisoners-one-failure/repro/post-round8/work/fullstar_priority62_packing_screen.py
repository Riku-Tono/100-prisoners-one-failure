"""Short exact-R6 52-block packing screen of the remaining62 priority seeds.

EXHAUSTED closes the mandatory18 branch even if extras were allowed: adding
rules cannot repair R6 or a missing block packing. FOUND is only a52-block
completion until its independent40320 audit shows target4. UNKNOWN remains
unresolved. The closed original18 and newly closed core4 are never run.
"""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json,time
from fullstar_priority63_generic_completion import load_manifest,HighEngine,RULES,H,export_and_audit,save,CATALOGUE_SHA

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest',required=True);p.add_argument('--prefix',required=True)
    p.add_argument('--seconds-per-core',type=float,default=1);p.add_argument('--node-limit',type=int,default=1000000);a=p.parse_args()
    prefix=Path(a.prefix);target=prefix.with_suffix('.result.json')
    if target.exists():raise ValueError('Use a new prefix; prior raw results are preserved.')
    seeds,provenance=load_manifest(a.manifest)
    core4path=H/'fullstar_priority63_core4_complete_summary.json';core4raw=core4path.read_bytes();core4=json.loads(core4raw)
    assert core4['status']=='EXHAUSTED_NO_TARGET4_WITH_CORE4_MANDATORY18'
    assert core4['unknown']==core4['unprocessed']==core4['found']==0 and core4['all3812_verified_by_non_CP_cover']
    assert core4['block_catalogue_sha256']==CATALOGUE_SHA
    selected=[s for s in seeds if s['core_index']!=4]
    assert len(selected)==62
    source=H/'inputs/baseline15051.rules.json';doc=json.loads(source.read_text());knownrules={(x,*hist,t) for x,hist,t in doc['rules']}
    hint=frozenset(i for i,b in enumerate(RULES) if b<=knownrules);assert len(hint)==52
    start=time.monotonic();out=dict(scope=__doc__,provenance=provenance,block_catalogue_sha256=CATALOGUE_SHA,
             core4_closed_summary=dict(source=str(core4path),sha256=hashlib.sha256(core4raw).hexdigest()),
             seconds_per_core=a.seconds_per_core,node_limit=a.node_limit,hint_source=str(source),hint_is_not_a_constraint=True,
             status='RUNNING',records=[dict(core_index=s['core_index'],status='NOT_RUN',distance_from_closed=s['distance_from_closed']) for s in selected])
    def checkpoint():
        out['seconds']=time.monotonic()-start;out['counts']=dict(Counter(r['status'] for r in out['records']))
        out['strictly_closed_core_indices']=[r['core_index'] for r in out['records'] if r['status']=='EXHAUSTED_NO_52BLOCK_PACKING']
        out['unknown_core_indices']=[r['core_index'] for r in out['records'] if r['status'].startswith('UNKNOWN')]
        out['unprocessed_core_indices']=[r['core_index'] for r in out['records'] if r['status']=='NOT_RUN']
        out['found52_only_core_indices']=[r['core_index'] for r in out['records'] if r['status']=='FOUND_52PACKING_TARGET4_UNRESOLVED']
        save(target,out)
    checkpoint();engine=HighEngine()
    for pos,(seed_record,record) in enumerate(zip(selected,out['records'])):
        seed=seed_record['seed'];st,nodes,more,holes=engine.run(seed,[],a.seconds_per_core,a.node_limit,hint,True)
        record.update(engine_status=st,nodes=nodes,mandatory_blocks=sorted(seed),critical_extra_rules=[])
        if st=='EXHAUSTED_NO_COMPLETION':record['status']='EXHAUSTED_NO_52BLOCK_PACKING'
        elif st=='FOUND':
            path=Path(str(prefix)+f'.core{record["core_index"]:03d}.rules.json')
            checked=export_and_audit(path,seed,[],more,holes,15051)
            record.update(status='FOUND_TARGET4' if checked['wins']>=15052 else 'FOUND_52PACKING_TARGET4_UNRESOLVED',
                          certificate=str(path),direct_audit=checked,hint_block_ids=sorted(set(seed)|set(more)))
            if checked['wins']>=15052:
                out['status']='FOUND_TARGET4_INDEPENDENTLY_VERIFIED';checkpoint();print('FOUND_TARGET4',json.dumps(record),flush=True);break
        elif st.startswith('UNKNOWN'):record['status']=st
        else:raise ValueError(st)
        checkpoint();print(pos+1,'of62 core',record['core_index'],record['status'],'nodes',nodes,flush=True)
    else:out['status']='COMPLETE_PACKING_SCREEN_NO_TARGET4_FOUND'
    checkpoint();print('FINAL',out['status'],out['counts'],'seconds',out['seconds'],flush=True)

if __name__=='__main__':main()
