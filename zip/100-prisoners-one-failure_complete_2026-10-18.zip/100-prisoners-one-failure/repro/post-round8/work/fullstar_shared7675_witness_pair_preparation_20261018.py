"""Finite local witness preparation for two additional rescues above seed7675.

Enumerate six correct rules for each not-yet-rescued seven-cycle. Every
required nonconstant rule is supplied by an actual compatible block or its
singleton. Keep at most two singleton suppliers, disjoint cyclic words and
all partial six-cycle counts <=4. This imposes no52-block completion test.
Pair enumeration is exact only when all cross-cycle pairs are scanned;
otherwise a deterministic random sample is clearly labelled incomplete.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict,Counter
import hashlib,json,time,random,math

H=Path(__file__).resolve().parent
START=time.monotonic()
PREFIX=H/'fullstar_shared7675_witness_pair_preparation_20261018'

def norm(w):return min(w[i:]+w[:i] for i in range(len(w)))
def correct(c):return frozenset((c[i:]+c[:i])[:4]+((c[i:]+c[:i])[-1],) for i in range(len(c)))
def allcycles(k):return [(p,correct(p)) for p in permutations(range(1,8),k) if p[0]==min(p)]

def main():
 source=H/'fullstar_prepare_pairs.json';doc=json.loads(source.read_text());seed=doc['seeds'][7675]
 assert len(seed['blocks'])==11
 words=sorted({norm(p) for p in permutations(range(1,8),4)});wi={w:i for i,w in enumerate(words)}
 groups={correct(p) for p in permutations(range(1,8),5)}
 blocks=sorted({g-{r} for g in groups for r in g},key=lambda b:tuple(sorted(b)))
 assert len(words)==210 and len(blocks)==2520
 rm=[sum(1<<wi[norm(r[:4])] for r in b) for b in blocks]
 wordbit={r:1<<wi[norm(r[:4])] for b in blocks for r in b}
 fixed=set(seed['blocks']);fixedrules=set().union(*(blocks[b] for b in fixed))
 occupied=sum(rm[b] for b in fixed);assert occupied.bit_count()==44
 six=allcycles(6);seven=allcycles(7)
 sixinc=defaultdict(list)
 for k,(c,rr) in enumerate(six):
  for r in rr:sixinc[r].append(k)
 delta=[tuple(k for r in b for k in sixinc[r]) for b in blocks]
 assert all(len(d)==len(set(d))==8 for d in delta)
 basecounts=[len(rr&fixedrules) for c,rr in six];assert max(basecounts)<=4
 permitted=[b for b in range(2520) if not rm[b]&occupied and all(basecounts[k]<4 for k in delta[b])]
 inc=defaultdict(list)
 for b in permitted:
  for r in blocks[b]:inc[r].append(b)
 already={i for i,(c,rr) in enumerate(seven) if len(rr&fixedrules)>=6};assert len(already)==2
 potential=[i for i,(c,rr) in enumerate(seven) if i not in already and sum(r in fixedrules or not wordbit[r]&occupied for r in rr)>=6]
 assert len(potential)==417
 counts=basecounts[:];records=[];percycle=[];nodes=0
 for cid in potential:
  c,rs=seven[cid];solutions=set();cnodes=0
  def dfs(todo,used,selected,extras):
   nonlocal cnodes,nodes
   cnodes+=1;nodes+=1
   if not todo:
    solutions.add((tuple(sorted(selected)),tuple(sorted(extras))));return
   options=[]
   for r in todo:
    available=[b for b in inc[r] if not rm[b]&used and all(counts[k]<4 for k in delta[b])]
    single=(len(extras)<2 and not wordbit[r]&used and all(counts[k]<4 for k in sixinc[r]))
    if not available and not single:return
    options.append((len(available)+single,r,available,single))
   _,r,available,single=min(options)
   for b in available:
    for k in delta[b]:counts[k]+=1
    dfs(todo-blocks[b],used|rm[b],selected|{b},extras)
    for k in delta[b]:counts[k]-=1
   if single:
    for k in sixinc[r]:counts[k]+=1
    dfs(todo-{r},used|wordbit[r],selected,extras|{r})
    for k in sixinc[r]:counts[k]-=1
  for ignored in rs:
   required=rs-{ignored};todo=required-fixedrules
   if any(wordbit[r]&occupied for r in todo):continue
   dfs(todo,occupied,set(),set())
  assert counts==basecounts and len(solutions)<=490
  for bs,ex in sorted(solutions):
   actual=set().union(*(blocks[b] for b in bs)) if bs else set()
   actual.update(ex);mask=sum(rm[b] for b in bs)+sum(wordbit[r] for r in ex)
   assert not mask&occupied and mask.bit_count()==4*len(bs)+len(ex)
   assert len((actual|fixedrules)&rs)>=6
   change=Counter(k for r in actual for k in sixinc[r])
   assert all(basecounts[k]+v<=4 for k,v in change.items())
   records.append({'cycle_index':cid,'cycle':c,'additional_blocks':bs,'extras':ex,
                   'word_mask':mask,'six_delta':dict(change)})
  percycle.append({'cycle_index':cid,'cycle':c,'fixed_correct':len(rs&fixedrules),
                   'witness_count':len(solutions),'nodes':cnodes,
                   'extra_histogram':dict(sorted(Counter(len(e) for b,e in solutions).items()))})
 n=len(records);hist=Counter(r['cycle_index'] for r in records)
 totalpairs=(n*n-sum(v*v for v in hist.values()))//2
 result={'scope':__doc__,'seed_index':7675,'mandatory_blocks':sorted(fixed),
         'block_catalogue_sha256':hashlib.sha256(json.dumps([sorted(b) for b in blocks],separators=(',',':')).encode()).hexdigest(),
         'seed_input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
         'already_rescued_cycles':[seven[i][0] for i in sorted(already)],
         'potential_additional_cycles':len(potential),'all417_cycles_completed':True,
         'cycles_with_witness':len(hist),'total_witness_records':n,
         'unique_additional_core_count':len({(r['additional_blocks'],r['extras']) for r in records}),
         'extra_histogram':dict(sorted(Counter(len(r['extras']) for r in records).items())),
         'raw_cross_cycle_pairs':totalpairs,'nodes':nodes,'per_cycle':percycle,
         'witness_enumeration_seconds':time.monotonic()-START,
         'completion_Solve_called':False,'status':'WITNESS_ENUMERATION_COMPLETE'}
 PREFIX.with_suffix('.summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print('ALL417_WITNESSES',n,'cycles',len(hist),'rawpairs',totalpairs,'seconds',result['witness_enumeration_seconds'],flush=True)
 # Encode exact rule-level local witness cores without large internal masks.
 portable=[{k:v for k,v in r.items() if k not in ('word_mask','six_delta')} for r in records]
 PREFIX.with_suffix('.witnesses.json').write_text(json.dumps({'seed':7675,'mandatory_blocks':sorted(fixed),'witnesses':portable},indent=2),encoding='utf-8')

 def compatible(a,b):
  if a['cycle_index']==b['cycle_index']:return False,None
  ab=set(a['additional_blocks']);bb=set(b['additional_blocks']);ae=set(a['extras']);be=set(b['extras'])
  if len(ae|be)>2:return False,None
  sharedb=ab&bb;sharede=ae&be
  overlap=sum(rm[k] for k in sharedb)+sum(wordbit[r] for r in sharede)
  if a['word_mask']&b['word_mask']!=overlap:return False,None
  deltaunion=Counter(a['six_delta']);deltaunion.update(b['six_delta'])
  for bid in sharedb:
   for k in delta[bid]:deltaunion[k]-=1
  for r in sharede:
   for k in sixinc[r]:deltaunion[k]-=1
  if any(basecounts[k]+v>4 for k,v in deltaunion.items()):return False,None
  return True,(tuple(sorted(ab|bb)),tuple(sorted(ae|be)))

 complete=totalpairs<=1000000;tested=0;passing=0;paircores=set();sample_target=100000
 if complete:
  for i,a in enumerate(records):
   for b in records[i+1:]:
    if a['cycle_index']==b['cycle_index']:continue
    tested+=1;ok,core=compatible(a,b)
    if ok:passing+=1;paircores.add(core)
 else:
  rng=random.Random(7675);sample_target=min(sample_target,totalpairs)
  for _ in range(sample_target):
   while True:
    i,j=rng.sample(range(n),2)
    if records[i]['cycle_index']!=records[j]['cycle_index']:break
   tested+=1;ok,core=compatible(records[i],records[j])
   if ok:passing+=1;paircores.add(core)
 if complete:assert tested==totalpairs
 result.update(pair_enumeration_complete=complete,pair_tests=tested,compatible_pair_tests=passing,
               distinct_pair_union_cores_observed=len(paircores),
               compatibility_rate_observed=passing/tested if tested else 0,
               compatible_pair_count_estimate=passing if complete else totalpairs*passing/tested if tested else None,
               pair_sampling_with_replacement=not complete,sampling_seed=None if complete else 7675,
               status='FINITE_PAIR_PREPARATION_COMPLETE' if complete else 'WITNESSES_COMPLETE_PAIR_STATISTICS_PARTIAL',
               total_seconds=time.monotonic()-START)
 if not complete:
  p=passing/tested if tested else 0;se=math.sqrt(p*(1-p)/tested) if tested else None
  result['approximate_sampling_95pct_interval_pairs']=[max(0,p-1.96*se)*totalpairs,min(1,p+1.96*se)*totalpairs] if se is not None else None
 core_records=[{'mandatory_blocks':sorted(fixed),'additional_blocks':bs,'critical_extra_rules':ex,
                'all_core_blocks':sorted(fixed|set(bs))} for bs,ex in sorted(paircores)]
 PREFIX.with_suffix('.observed_pair_cores.json').write_text(json.dumps({'complete':complete,'seed':7675,'cores':core_records},indent=2),encoding='utf-8')
 PREFIX.with_suffix('.summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in result.items() if k!='per_cycle'},indent=2),flush=True)

if __name__=='__main__':main()
