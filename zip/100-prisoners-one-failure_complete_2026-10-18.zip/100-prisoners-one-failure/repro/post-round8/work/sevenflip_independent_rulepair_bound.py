"""Independent supply / shared-pair audit of the two unresolved7-flip cases.

Uses Desktop Claude's independent block generator. No CP model is imported.
Counts every directed7-cycle on8 labels. The within[7] marginal lemma is
referenced only on its original7-label domain, never across7-sets.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import sys,json,hashlib,time
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'claude_desktop_continuation3'))
from c3_model import Orientation,ALL,word,cyc_rules,directed_cycles

def main():
    started=time.monotonic()
    cycles=[c for s in combinations(range(1,9),7) for c in directed_cycles(s)]
    assert len(cycles)==5760
    pairs=Counter();pairs8=Counter()
    for c in cycles:
        for pair in combinations(sorted(cyc_rules(c)),2):
            pairs[pair]+=1
            if 8 in c:pairs8[pair]+=1
    maximum=max(pairs.values())
    both7maximum=max(n for pair,n in pairs8.items() if all(8 not in r for r in pair))
    assert maximum==2 and both7maximum==1
    out=dict(method=__doc__,all_seven_cycles=5760,max_seven_cycles_sharing_two_given_rules=maximum,max_8containing_seven_cycles_sharing_two_rules_both_in7=both7maximum,pair_multiplicity_histogram=dict(Counter(pairs.values())),orientations=[])
    for index in (9,15):
        src=H/f'post_audit_sevenflip_20261018_orbit{index}_target4.result.json'
        data=json.loads(src.read_text());F={frozenset(s) for s in data['flips']}
        active=[frozenset(s) for s in combinations(range(1,8),4) if frozenset(s) not in F]+[ALL-s for s in F]
        o=Orientation(active);available=set().union(*(set(b) for b in o.blocks))
        h0=Counter();h8=Counter()
        for c in cycles:
            (h8 if 8 in c else h0)[sum(r in available for r in cyc_rules(c))]+=1
        record=dict(orbit=index,flips=data['flips'],admissible_blocks=len(o.blocks),rule_union_size=len(available),max_block_suppliable_correct_without8=max(h0),max_block_suppliable_correct_with8=max(h8),hist_without8=dict(sorted(h0.items())),hist_with8=dict(sorted(h8.items())))
        no_base=max(h0)<=5 and max(h8)<=5
        if index==15:
            special={frozenset(s) for s in ((1,2,3,8),(1,3,6,8),(2,3,6,8))}
            anchor=frozenset((1,2,3,6))
            special_words={w for w in o.words if frozenset(w) in special}
            anchor_words={w for w in o.words if frozenset(w)==anchor}
            touched=[]
            for b,rr in enumerate(o.blocks):
                ww={word(r) for r in rr}
                if ww&special_words:
                    assert len(ww&special_words)==3 and len(ww&anchor_words)==1
                    touched.append(b)
            assert len(special_words)==18 and len(anchor_words)==6 and len(touched)==24
            # 52 disjoint blocks leave only2 of210 words unoccupied. Hence
            # >=16 of these18 special words are used, requiring >=6 touched
            # blocks. Anchor capacity gives <=6. All6 anchor words are used.
            permitted=[b for b,rr in enumerate(o.blocks) if b in touched or not any(word(r) in anchor_words for r in rr)]
            removed=set(range(len(o.blocks)))-set(permitted)
            assert len(permitted)==1200 and len(removed)==192
            assert all(all(8 not in r for r in o.blocks[b]) for b in removed)
            incidence={};masks=[];wwi={w:i for i,w in enumerate(o.words)}
            for b,rr in enumerate(o.blocks):
                masks.append(sum(1<<wwi[word(r)] for r in rr))
                if b in permitted:
                    for r in rr:incidence.setdefault(r,[]).append(b)
            nodes=0;eligible=0;witnesses=set()
            for c in directed_cycles(range(1,8)):
                rr=frozenset(cyc_rules(c))
                if sum(bool(incidence.get(r)) for r in rr)<6:continue
                eligible+=1
                for omit in rr:
                    needed=sorted(rr-{omit},key=lambda r:len(incidence.get(r,[])))
                    if any(not incidence.get(r) for r in needed):continue
                    def dfs(k,used,chosen):
                        nonlocal nodes
                        nodes+=1
                        if k==6:witnesses.add((c,tuple(sorted(chosen))));return
                        for b in incidence[needed[k]]:
                            if masks[b]&used:continue
                            dfs(k+1,used|masks[b],chosen+(b,))
                    dfs(0,0,())
            assert not witnesses and eligible==24
            record['forced_anchor']=dict(special_words=18,touched_blocks=24,words_per_touched_block=3,anchor_words_per_touched_block=1,anchor_word_capacity=6,minimum_touched_blocks=(18-2+2)//3,maximum_touched_blocks=6,excluded_old_blocks=192,permitted_blocks=1200,eligible_old_cycles=eligible,noncolliding_six_correct_witnesses=0,dfs_nodes=nodes,proof='208 of210 words used. At least16 of18 special words need6 touched blocks; six anchor words bound them by6. Thus every anchor word is already consumed.')
            no_base=True
        if no_base and max(h8)<=4:
            record.update(R7_upper_bound=3,R6_used=False,proof='No block-only seven rescue. Every8-containing rescue requires both extras. If both extras avoid8: <=2 old rescues by the unrestricted[7] marginal lemma and <=1 containing8 by the pair lemma. If an extra contains8: <=1 old rescue and <=2 containing8 by the pair lemma. Zero/one extras are included.')
        out['orientations'].append(record)
    lemma=H/'verify_two_rule_synergy.json'
    out['within7_marginal_lemma_source']=dict(file=str(lemma),sha256=hashlib.sha256(lemma.read_bytes()).hexdigest(),scope='all35 supports and2520 blocks on[7], independent Cartesian checker,12 useful second rules')
    assert json.loads(lemma.read_text())['status']=='PASS'
    out['seconds']=time.monotonic()-started
    (H/'sevenflip_independent_rulepair_bound.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2),flush=True)

if __name__=='__main__':main()
