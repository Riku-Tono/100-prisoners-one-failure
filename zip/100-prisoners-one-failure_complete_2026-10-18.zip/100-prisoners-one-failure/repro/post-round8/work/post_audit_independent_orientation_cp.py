"""Fresh CP formulation using Desktop Claude's independent block generator.

Does not import the generic orientation model. Rules are represented directly
by the sum of supplying block and singleton variables. Six-cycle exclusion is
direct; seven-cycle existence uses one-way positive flags, sufficient here.
R8=0 follows from the four pairs of complementary history supports, checked
again on all5040 directed8-cycles for every orientation.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict
import sys,json,time,hashlib,argparse
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'claude_desktop_continuation3'))
sys.path.insert(0,r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
from c3_model import Orientation,ALL,word,cyc_rules,directed_cycles,fivecycle
from ortools.sat.python import cp_model

def build(flips,target):
    removed={frozenset(s) for s in flips}
    active=[frozenset(s) for s in combinations(range(1,8),4) if frozenset(s) not in removed]
    active += [ALL-s for s in removed]
    o=Orientation(active)
    m=cp_model.CpModel()
    bs=[m.new_bool_var('b'+str(i)) for i in range(len(o.blocks))]
    singles={}
    for w in o.words:
        for j in range(4):
            h=w[j:]+w[:j]
            for t in sorted(ALL-set(w)):
                r=h+(t,)
                singles[r]=m.new_bool_var('e'+str(len(singles)))
    assert len(o.words)==210 and len(singles)==3360
    columns=defaultdict(list);terms=defaultdict(list)
    for b,v in zip(o.blocks,bs):
        for r in b:
            columns[word(r)].append(v);terms[r].append(v)
    for r,v in singles.items():
        columns[word(r)].append(v);terms[r].append(v)
    for w in o.words:m.add_at_most_one(columns[w])
    m.add(sum(bs)==52);m.add(sum(singles.values())<=2)
    counts={};zs=[]
    for k in (6,7):
        count=0
        for labels in combinations(range(1,9),k):
            for c in directed_cycles(labels):
                rr=[r for r in cyc_rules(c) if r in singles]
                if len(rr)<k-1:continue
                n=sum(v for r in rr for v in terms[r])
                if k==6:m.add(n<=4)
                else:
                    z=m.new_bool_var('z'+str(len(zs)))
                    m.add(n>=6*z);zs.append(z)
                count+=1
        counts[k]=count
    m.add(sum(zs)>=target)
    max8=max(sum(word(r) in o.wordset for r in cyc_rules(c)) for c in directed_cycles(range(1,9)))
    assert max8==4 and m.validate()==''
    return o,m,bs,singles,dict(blocks=len(bs),single_options=len(singles),nontrivial_six_constraints=counts[6],seven_flags=counts[7],max8_correct=4,variables=len(m.proto.variables),constraints=len(m.proto.constraints))

def load_rules(path):
    d=json.loads(path.read_text(encoding='utf-8-sig'))
    return {(a,*h,t) for a,h,t in d['rules']}

def fix(o,m,bs,ss,rules):
    groups=defaultdict(set)
    for r in rules:groups[fivecycle(r)].add(r)
    chosen=[]
    for rr in groups.values():
        if len(rr)>=4:
            chosen.append(next(i for i,b in enumerate(o.blocks) if set(b)<=rr))
    assert len(chosen)==52
    supplied=set().union(*(set(o.blocks[i]) for i in chosen))
    extra=rules-supplied
    assert len(supplied)==208 and len(extra)<=2 and rules<=ss.keys()
    for i,v in enumerate(bs):m.add(v==int(i in chosen))
    for r,v in ss.items():m.add(v==int(r in extra))

def solve(label,flips,target,seconds,fixed=None):
    o,m,bs,ss,stats=build(flips,target)
    if fixed is not None:fix(o,m,bs,ss,load_rules(fixed))
    p=H/f'post_audit_independent_{label}'
    m.export_to_file(str(p.with_suffix('.model.txt')))
    s=cp_model.CpSolver();s.parameters.num_search_workers=1
    s.parameters.max_time_in_seconds=seconds;s.parameters.random_seed=17
    st=s.solve(m)
    result=dict(label=label,flips=flips,target=target,status=s.status_name(st),seconds=s.wall_time,stats=stats,response=s.response_stats(),generator='Desktop Claude c3_model.py',formulation='direct supplier sums; no presence variables; positive existential7 flags',fixed_source=str(fixed) if fixed else None)
    if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):
        blocks=[i for i,v in enumerate(bs) if s.value(v)]
        extras={r for r,v in ss.items() if s.value(v)}
        rules=set().union(*(set(o.blocks[i]) for i in blocks))|extras
        cert=p.with_suffix('.rules.json')
        cert.write_text(json.dumps(dict(rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(rules)],flips=flips,independent_model_stats=stats),indent=2),encoding='utf-8')
        from independent_audit import audit
        checked=audit(cert)
        assert checked['placements']==40320 and checked['lost_cf']==0
        assert checked['rescued_cycles']['5']==52 and checked['rescued_cycles']['6']==0
        assert checked['rescued_cycles']['7']>=target and checked['rescued_cycles']['8']==0
        result['audit']=checked
    p.with_suffix('.result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(label,result['status'],round(s.wall_time,3),flush=True)
    return result

def main():
    assert json.loads((H/'claude_desktop_continuation3/audit_status.json').read_text())['status']=='AUDIT_PASS'
    std3=((1,2,3,4),(1,2,3,5),(1,2,3,6))
    out=dict(method=__doc__,generator_sha256=hashlib.sha256((H/'claude_desktop_continuation3/c3_model.py').read_bytes()).hexdigest(),controls=[],searches=[])
    controls=[('control_fullstar',(),3,H/'inputs/baseline15051.rules.json','OPTIMAL'),('control_standard3_15050',std3,2,H/'chatgpt_15050_received.rules.json','OPTIMAL'),('control_r6one_rejected',std3,1,H/'inputs/new15051.rules.json','INFEASIBLE')]
    for label,flips,target,path,expected in controls:
        r=solve(label,flips,target,10,path);assert r['status']==expected
        out['controls'].append(r)
    for item in json.loads((H/'sixflip_model_preparation_inputs.json').read_text()):
        out['searches'].append(solve('sixflip_orbit'+str(item['orbit_index']),item['flips'],4,120))
        (H/'post_audit_independent_orientation_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    out['searches'].append(solve('fourflip',std3+((1,2,3,7),),4,120))
    (H/'post_audit_independent_orientation_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')

if __name__=='__main__':main()
