"""Exhaustive radius <=2 block replacement with two freely refilled slots.
Scope: one fixed 208-rule certificate, not the whole strategy family.
"""
from itertools import combinations, permutations, product
from collections import defaultdict, Counter
from pathlib import Path
import json,time,sys

H=Path(__file__).parent
def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def correct(c):
    n=len(c)
    return frozenset((c[i],c[(i+1)%n],c[(i+2)%n],c[(i+3)%n],c[(i-1)%n]) for i in range(n))
def cycles(k):
    for s in combinations(range(1,9),k):
        for p in permutations(s[1:]):yield (s[0],)+p
source=sys.argv[1] if len(sys.argv)>1 else 'baseline15051'
max_radius=int(sys.argv[2]) if len(sys.argv)>2 else 2
raw=json.loads((H/f'inputs/{source}.rules.json').read_text())
original=frozenset((a,*h,t) for a,h,t in raw['rules'])
groups=defaultdict(set)
for r in original:groups[canon((r[-1],)+r[:4])].add(r)
groups={c:g for c,g in groups.items() if len(g)==4}
base=frozenset().union(*groups.values())
assert len(base)==208 and len(groups)==52 and all(len(g)==4 for g in groups.values())
active={frozenset(r[:4]) for r in original}
assert len(active)==35
words={c for c in cycles(4) if frozenset(c) in active}
def slots(rr):return frozenset(canon(r[:4]) for r in rr)
holes=words-slots(base);assert len(holes)==2
blocks=[]
for c in cycles(5):
    rr=correct(c)
    for omit in rr:
        b=rr-{omit};w=slots(b)
        if w<=words:blocks.append((b,w))
old=list(map(frozenset,groups.values()));oldwords=list(map(slots,old))
data=[];inc=defaultdict(list)
for k in range(5,9):
    for c in cycles(k):
        rr=correct(c);i=len(data);data.append((k,len(rr&base)))
        for r in rr:inc[r].append(i)
baseR=Counter(k for k,n in data if n>=k-1)
best=dict(wins=14736+sum({5:6,6:2,7:1,8:1}[k]*v for k,v in baseR.items()),R=dict(baseR),rules=base)
seen=set();hist=Counter();representatives={};t0=time.monotonic();packings=fillings=0
for radius in range(max_radius+1):
    for removed in combinations(range(52),radius):
        pool=holes|frozenset().union(*(oldwords[i] for i in removed))
        opts=[(b,w) for b,w in blocks if w<=pool]
        removedrules=frozenset().union(*(old[i] for i in removed))
        for chosen in combinations(range(len(opts)),radius):
            used=set();replacement=set()
            for j in chosen:
                b,w=opts[j]
                if used&w:break
                used.update(w);replacement.update(b)
            else:
                remaining=sorted(pool-used)
                assert len(remaining)==2
                candidate=(base-removedrules)|replacement
                if candidate in seen:continue
                seen.add(candidate);packings+=1
                delta=Counter()
                for r in base-candidate:
                    for i in inc[r]:delta[i]-=1
                for r in candidate-base:
                    for i in inc[r]:delta[i]+=1
                choices=[]
                for w in remaining:
                    choices.append([None]+[w[j:]+w[:j]+(t,) for j in range(4) for t in range(1,9) if t not in w])
                for extras in product(*choices):
                    change=delta.copy()
                    for r in extras:
                        if r is not None:
                            for i in inc[r]:change[i]+=1
                    R=baseR.copy()
                    for i,d in change.items():
                        k,n=data[i];R[k]+=int(n+d>=k-1)-int(n>=k-1)
                    assert R[5]==52
                    wins=14736+6*R[5]+2*R[6]+R[7]+R[8]
                    key=(R[6],R[7],R[8],wins)
                    hist[key]+=1;fillings+=1
                    if key not in representatives:
                        representatives[key]=candidate|{r for r in extras if r is not None}
                    if wins>best['wins']:
                        best=dict(wins=wins,R=dict(R),rules=candidate|{r for r in extras if r is not None})
                        print('IMPROVED',wins,dict(R),flush=True)
    print('radius',radius,'packings',packings,'fillings',fillings,'seconds',time.monotonic()-t0,flush=True)
out=dict(scope=source+f'; remove at most {max_radius} of its 52 four-rule blocks, repack the freed slots plus two original holes with equally many blocks, freely fill two remaining slots',status='EXHAUSTED',max_radius=max_radius,packings=packings,fillings=fillings,seconds=time.monotonic()-t0,best={k:v for k,v in best.items() if k!='rules'},histogram=[dict(R6=k[0],R7=k[1],R8=k[2],wins=k[3],count=v) for k,v in sorted(hist.items())])
(H/f'local_block_trades_{source}.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
certificate=dict(raw);certificate['rules']=[[r[0],list(r[1:4]),r[4]] for r in sorted(best['rules'])]
(H/f'local_block_trades_{source}_best.rules.json').write_text(json.dumps(certificate,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
from independent_audit import audit
checks=[]
for key,rr in representatives.items():
    path=H/f'local_trade_{source}_{key[0]}_{key[1]}.rules.json'
    path.write_text(json.dumps(dict(n=8,rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(rr)])),encoding='utf-8')
    checked=audit(path)
    assert checked['wins']==key[3] and checked['lost_cf']==0
    assert all(checked['rescued_cycles'][str(k)]==v for k,v in zip((5,6,7,8),(52,*key[:3])))
    checks.append(checked)
(H/f'local_block_trades_{source}_direct_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print('Direct 40320-placement checks PASS:',len(checks),flush=True)
