"""Separate bitset recheck of48 four-flip triangle completion exclusions.
Regenerates blocks from four-word+extra-label, translates actual rule tuples.
Two unrestricted holes,52 blocks; no six-cycle constraints or CP/DLX imports.
"""
from pathlib import Path
from itertools import permutations
from collections import Counter
import json,time,hashlib
H=Path(__file__).resolve().parent
FLIPS=((1,2,3,4),(1,2,3,5),(1,2,3,6),(1,2,3,7))
def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def rules(c):
    return frozenset((c[i],c[(i+1)%5],c[(i+2)%5],c[(i+3)%5],c[(i+4)%5]) for i in range(5))
def bits(mask):
    while mask:
        bit=mask&-mask;mask^=bit;yield bit.bit_length()-1
def regenerate(flips):
    labels=set(range(1,9));active={frozenset(p) for p in permutations(range(1,8),4)}
    for f in flips:active.remove(frozenset(f));active.add(frozenset(labels-set(f)))
    words=tuple(sorted({canon(p) for p in permutations(range(1,9),4) if frozenset(p) in active}));wi={w:i for i,w in enumerate(words)};blocks=set()
    for w in words:
        for shift in range(4):
            p=w[shift:]+w[:shift]
            for t in labels-set(w):
                rr=rules((t,)+p)
                for omit in rr:
                    kept=rr-{omit}
                    if all(canon(r[:4]) in wi for r in kept):blocks.add(kept)
    blocks=tuple(sorted(blocks,key=lambda b:tuple(sorted(b))))
    rows=[sum(1<<wi[canon(r[:4])] for r in b) for b in blocks]
    return words,blocks,rows

class Checker:
    def __init__(self,words,blocks,rows):
        self.words=words;self.blocks=blocks;self.rows=rows;self.columns=[0]*len(words)
        for b,row in enumerate(rows):
            for j in bits(row):self.columns[j]|=1<<b
        self.conflicts=[]
        for row in rows:
            mask=0
            for j in bits(row):mask|=self.columns[j]
            self.conflicts.append(mask)
    def run(self,mandatory,seconds=5,node_limit=100000,hint=()):
        self.nodes=0;self.answer=None;self.answer_holes=None;self.deadline=time.monotonic()+seconds;self.node_limit=node_limit;self.hint=sum(1<<b for b in hint)
        left=(1<<len(self.words))-1;available=(1<<len(self.blocks))-1
        for b in mandatory:
            assert left&self.rows[b]==self.rows[b]
            left^=self.rows[b];available&=~self.conflicts[b]
        t=time.monotonic()
        try:found=self.search(left,available,2,[],[])
        except TimeoutError as e:return dict(status='UNKNOWN',reason=str(e),nodes=self.nodes,seconds=time.monotonic()-t)
        out=dict(status='FOUND' if found else 'EXHAUSTED_NO_COMPLETION',nodes=self.nodes,seconds=time.monotonic()-t)
        if found:
            selected=set(mandatory)|set(self.answer);covered=[j for b in selected for j in bits(self.rows[b])]
            assert len(selected)==52 and len(covered)==len(set(covered))==208 and set(covered)|set(self.answer_holes)==set(range(210))
            out.update(block_ids=sorted(selected),holes=[self.words[j] for j in self.answer_holes])
        return out
    def search(self,left,available,budget,chosen,holes):
        self.nodes+=1
        if self.nodes>self.node_limit:raise TimeoutError('NODE_LIMIT')
        if self.nodes%1000==0 and time.monotonic()>self.deadline:raise TimeoutError('WALL_LIMIT')
        if not left:
            if budget:return False
            self.answer=chosen[:];self.answer_holes=holes[:];return True
        bestn=100000;bestc=-1;options=0;zeros=0
        for j in bits(left):
            bs=self.columns[j]&available;n=bs.bit_count();zeros+=n==0
            if zeros>budget:return False
            if n<bestn:bestn=n;bestc=j;options=bs
        for mask in (options&self.hint,options&~self.hint):
            for b in bits(mask):
                if self.search(left^self.rows[b],available&~self.conflicts[b],budget,chosen+[b],holes):return True
        if budget and self.search(left^(1<<bestc),available&~self.columns[bestc],budget-1,chosen,holes+[bestc]):return True
        return False

def main():
    raw=(H/'fourflip_triangle_pure_seeds.json').read_bytes();source=json.loads(raw);words,blocks,rows=regenerate(FLIPS);assert len(words)==210 and len(blocks)==1920
    lookup={b:i for i,b in enumerate(blocks)};engine=Checker(words,blocks,rows)
    cw,cb,cr=regenerate(());knownrules={(a,*h,t) for a,h,t in json.loads((H/'inputs/baseline15051.rules.json').read_text())['rules']};known={b for b,rr in enumerate(cb) if rr<=knownrules};assert len(known)==52
    fixed=set(sorted(known)[:39]);control=Checker(cw,cb,cr).run(fixed,5,100000,known);assert control['status']=='FOUND' and len(set(control['block_ids'])-fixed)==13
    out=dict(method=__doc__,source_seed_sha256=hashlib.sha256(raw).hexdigest(),blocks=len(blocks),slots=len(words),seconds_per_seed=5,node_limit_per_seed=100000,R6_constraint_used=False,positive_control=dict(status='FOUND',retained_blocks=39,recovered_blocks=13,nodes=control['nodes']),cases=[]);start=time.monotonic()
    for index,seed in enumerate(source['seeds']):
        actual={frozenset(map(tuple,b)) for b in seed['actual_rules']};mandatory={lookup[b] for b in actual};assert len(mandatory)==18
        result=engine.run(mandatory);result['index']=index;out['cases'].append(result)
        print(index,result['status'],result['nodes'],round(result['seconds'],3),flush=True)
    out.update(counts=dict(Counter(c['status'] for c in out['cases'])),nodes=sum(c['nodes'] for c in out['cases']),seconds=time.monotonic()-start)
    (H/'fourflip_triangle_bitset_recheck.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('FINAL',out['counts'],out['nodes'],out['seconds'],flush=True)

if __name__=='__main__':main()
