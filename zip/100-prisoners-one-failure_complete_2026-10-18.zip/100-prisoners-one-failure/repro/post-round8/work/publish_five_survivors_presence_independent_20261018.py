"""Publish the requested aggregate; preserve all primary and raw CP results."""
from pathlib import Path
import hashlib, json

H = Path(__file__).resolve().parent
raw = H/'five_survivors_c3_presence_iff_independent_20261018.json'
data = json.loads(raw.read_text())
assert data['status'] == 'ALL_FIVE_INFEASIBLE_CONFIRMED'
assert [r['status'] for r in data['controls']] == ['OPTIMAL','INFEASIBLE']
assert [r['orbit_index'] for r in data['survivors']] == [1255,1291,1305,1319,1376]
assert all(r['status'] == 'INFEASIBLE' for r in data['survivors'])
data['records'] = [dict(r,index=r['orbit_index']) for r in data['survivors']]
data['complete'] = True
data['controls_passed'] = True
data['all_five_independent_infeasible'] = True
data['raw_independent_result'] = str(raw)
data['raw_independent_result_sha256'] = hashlib.sha256(raw.read_bytes()).hexdigest()
data['independent_builder'] = str(H/'five_survivors_c3_presence_iff_independent_20261018.py')
assert data['source_sha256'] == hashlib.sha256(Path(data['independent_builder']).read_bytes()).hexdigest()
data['scope_boundary'] = ('These are five fixed-support-orientation targetR7>=4 exclusions within '
                          'the52-block-plus<=2single complementary-orientation representation. '
                          'This file does not itself establish all other orientation exclusions, '
                          'and does not exclude the full-star family or arbitrary strategies.')
output = H/'canonical_orientation_five_survivors_presence_independent.json'
output.write_text(json.dumps(data,indent=2),encoding='utf-8')
print(json.dumps({'status':data['status'],'output':str(output),
                  'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                  'source_sha256':data['source_sha256'],
                  'records':[{'index':r['index'],'status':r['status'],
                              'seconds':r['solve_seconds']} for r in data['records']]},indent=2))
