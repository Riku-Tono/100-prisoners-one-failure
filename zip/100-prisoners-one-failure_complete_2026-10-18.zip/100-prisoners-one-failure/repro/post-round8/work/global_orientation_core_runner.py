"""Bounded all-orientation completion attempts for actual canonical witness cores.

No degree, flip-count or fixed-family cut is imposed. UNKNOWN is unresolved.
Each input core must supply the canonical six correct rules with noncolliding
losswords and compatible support orientations. Existing controls must pass.
Checkpoints preserve every attempted result and all unattempted core records.
"""
from pathlib import Path
import argparse,hashlib,json,time
from global_orientation_witness_completion import build,solve_once,universe,CANONICAL_SIX,ALL,H,canon

def load_representatives(path,extra_count=0,limit=4):
    path=Path(path);raw=path.read_bytes();doc=json.loads(raw.decode('utf-8-sig'))
    records=doc if isinstance(doc,list) else doc.get('representatives',doc.get('cores',doc.get('records',[])))
    if not isinstance(records,list) or not records:raise ValueError('Expected nonempty representatives or cores list.')
    _,allblocks,allsingles,_=universe();valid_blocks=set(allblocks);valid_singles=set(allsingles)
    selected=[]
    for pos,record in enumerate(records):
        blocks=record.get('actual_blocks',record.get('actual_rule_blocks'))
        extras=record.get('extras',record.get('single_rules',[]))
        if blocks is None:raise ValueError(f'Core at index{pos} has no actual_blocks.')
        extras=frozenset(map(tuple,extras));blocks=frozenset(frozenset(map(tuple,b)) for b in blocks)
        if len(extras)!=extra_count:continue
        if not blocks<=valid_blocks or not extras<=valid_singles:raise ValueError(f'Invalid actual rules at index{pos}.')
        used=[r for b in blocks for r in b]+list(extras)
        words=[canon(r[:4]) for r in used]
        if len(words)!=len(set(words)):raise ValueError(f'Lossword collision in input core{pos}.')
        supports={frozenset(w) for w in words}
        if any(ALL-s in supports for s in supports):raise ValueError(f'Complementary support collision in input core{pos}.')
        if not set(CANONICAL_SIX)<=set(used):raise ValueError(f'Core{pos} does not supply canonical six rules.')
        selected.append(dict(input_position=pos,representative_index=record.get('representative_index',record.get('index',pos)),
                             actual_blocks=[sorted(b) for b in sorted(blocks,key=lambda b:tuple(sorted(b)))],
                             extras=sorted(extras),core_rules=len(used),core_slots=len(words),
                             input_orbit_size=record.get('orbit_size'),status='NOT_RUN'))
        if limit is not None and len(selected)>=limit:break
    if not selected:raise ValueError('No matching extra-count representatives.')
    return selected,dict(source=str(path.resolve()),source_sha256=hashlib.sha256(raw).hexdigest(),
                         input_representative_count=len(records),selected_extra_count=extra_count,
                         selected_count=len(selected),selection_limit=limit)

def summary(state):
    records=state['records']
    unselected=state['provenance']['input_representative_count']-len(records)
    return dict(selected=len(records),attempted=sum(r['status']!='NOT_RUN' for r in records),
                found=sum(r['status'] in ('OPTIMAL','FEASIBLE') for r in records),
                strictly_infeasible=sum(r['status']=='INFEASIBLE' for r in records),
                unknown_unresolved=sum(r['status']=='UNKNOWN' for r in records),
                not_run=sum(r['status']=='NOT_RUN' for r in records),
                unselected_not_run=unselected,
                all_selected_strictly_closed=all(r['status']=='INFEASIBLE' for r in records),
                all_input_strictly_closed=unselected==0 and all(r['status']=='INFEASIBLE' for r in records))

def run(path,prefix,seconds=90,extra_count=0,limit=4,seed=1,resume=False,validate_only=False):
    controls_path=H/'global_orientation_controls.json';controls=json.loads(controls_path.read_text())
    if controls.get('status')!='PASS':raise ValueError('Global model controls must pass first.')
    prefix=Path(prefix);state_path=prefix.with_suffix('.checkpoint.json')
    selected,provenance=load_representatives(path,extra_count,limit)
    if state_path.exists():
        if not resume:raise ValueError('Checkpoint exists; use a new prefix or --resume.')
        state=json.loads(state_path.read_text())
        if state['provenance']!=provenance:raise ValueError('Resume input/selection does not match original checkpoint.')
        if len(state['records'])!=len(selected):raise ValueError('Resume core count changed.')
        if state['seconds_per_core']!=seconds or state['random_seed']!=seed:
            raise ValueError('Resume solver budget/seed differs; use a new prefix for a new attempt.')
    else:
        state=dict(scope=__doc__,provenance=provenance,workers=1,seconds_per_core=seconds,random_seed=seed,
                   model_controls_sha256=hashlib.sha256(controls_path.read_bytes()).hexdigest(),
                   forbidden_cuts_not_used=['degree','flip-count','fixed-orientation-family'],records=selected)
    started=time.monotonic()
    def save():
        state['summary']=summary(state);state['latest_invocation_seconds']=time.monotonic()-started
        state_path.write_text(json.dumps(state,indent=2),encoding='utf-8')
    save()
    for position,record in enumerate(state['records']):
        if record['status']!='NOT_RUN':continue
        model=build(target=4,canonical=True);fixed=model.fix_core(record['actual_blocks'],record['extras'])
        error=model.model.validate()
        if error:raise ValueError(error)
        record.update(fixed=fixed,validation_error=error)
        if validate_only:
            record['static_validated']=True;save();continue
        case_prefix=Path(str(prefix)+f'_core{position:03d}')
        if case_prefix.with_suffix('.result.json').exists():raise ValueError('Per-core result already exists without a matching completed checkpoint.')
        result=solve_once(model,seconds,case_prefix,seed)
        record.update(status=result['status'],result_file=str(case_prefix.with_suffix('.result.json')),
                      result_sha256=hashlib.sha256(case_prefix.with_suffix('.result.json').read_bytes()).hexdigest(),
                      solve_seconds=result['solve_seconds'])
        if 'audit' in result:record.update(certificate=result['certificate'],direct_audit=result['direct_audit'],audit=result['audit'])
        save()
        if result['status'] in ('OPTIMAL','FEASIBLE'):
            print('FOUND_AND_DIRECTLY_AUDITED',json.dumps(record),flush=True);break
    save();print(json.dumps(state['summary']),flush=True)
    return state

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source');p.add_argument('--prefix',required=True)
    p.add_argument('--seconds',type=float,default=90);p.add_argument('--extras',type=int,default=0)
    p.add_argument('--limit',type=int,default=4);p.add_argument('--seed',type=int,default=1)
    p.add_argument('--resume',action='store_true');p.add_argument('--validate-only',action='store_true');a=p.parse_args()
    run(a.source,a.prefix,a.seconds,a.extras,a.limit,a.seed,a.resume,a.validate_only)

if __name__=='__main__':main()
