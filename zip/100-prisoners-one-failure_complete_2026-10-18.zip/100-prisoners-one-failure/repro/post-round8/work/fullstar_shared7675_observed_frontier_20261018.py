"""Bounded scan of the2396 sampled shared7675 union cores, not the full pair set.

Reuse prior100 exact core outcomes including unresolved UNKNOWN records.
Attempt every remaining observed core with0.5 seconds/one million nodes,
R6=0 and2-e flexible holes. A600-second invocation cap retains NOT_RUN.
Only exact exhaustion excludes a particular observed mandatory-rule core.
"""
from pathlib import Path
from itertools import permutations
from collections import Counter
import argparse,hashlib,json,time
from fullstar_shared7675_observed_completion_20261018 import correct,actual_hash
from fullstar_finite_core_finish import HighEngine,RULES,ROWS,WORDS,CATALOGUE_SHA,canon,export_and_audit

H=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--wall-seconds',type=float,default=600)
 p.add_argument('--prefix',default='fullstar_shared7675_observed_frontier_20261018');p.add_argument('--resume',action='store_true')
 a=p.parse_args();start=time.monotonic();deadline=start+a.wall_seconds;prefix=H/a.prefix;output=prefix.with_suffix('.result.json')
 source=H/'fullstar_shared7675_witness_pair_preparation_20261018.observed_pair_cores.json'
 sample=json.loads(source.read_text());assert sample['complete'] is False and len(sample['cores'])==2396
 own=sorted({g-{r} for g in {correct(c) for c in permutations(range(1,8),5)} for r in g},key=lambda b:tuple(sorted(b)))
 assert own==RULES
 ordered=sorted(enumerate(sample['cores']),key=lambda ir:(len(ir[1]['all_core_blocks']),len(ir[1]['critical_extra_rules']),
                                                        tuple(ir[1]['all_core_blocks']),tuple(map(tuple,ir[1]['critical_extra_rules']))))
 six=[correct(c) for c in permutations(range(1,8),6) if c[0]==min(c)]
 seven=[(c,correct(c)) for c in permutations(range(1,8),7) if c[0]==min(c)]
 if output.exists():
  assert a.resume,'Use --resume for this existing frontier.'
  state=json.loads(output.read_text());assert state['source_sample_sha256']==sha(source)
 else:
  prior=[];rows=[]
  for name in ('fullstar_shared7675_observed_batch1_20261018.result.json','fullstar_shared7675_observed_batch2_20261018.result.json'):
   path=H/name;data=json.loads(path.read_text());assert data['source_sample_sha256']==sha(source)
   prior.append({'path':str(path),'sha256':sha(path)})
   for r in data['records']:
    position=r['priority_position'];observed_index,raw=ordered[position]
    assert observed_index==r['observed_union_index'] and raw['all_core_blocks']==r['mandatory_blocks']
    assert actual_hash(set(r['mandatory_blocks']),set(map(tuple,r['critical_extra_rules'])))==r['actual_core_sha256']
    rows.append({k:v for k,v in r.items() if k!='mandatory_actual_blocks'})
    rows[-1].update(reused_attempt=True,reused_source=str(path))
  rows.sort(key=lambda r:r['priority_position']);assert [r['priority_position'] for r in rows]==list(range(100))
  state={'scope':__doc__,'source_sample':str(source),'source_sample_sha256':sha(source),
         'source_sample_complete':False,'observed_union_count':2396,'block_catalogue_sha256':CATALOGUE_SHA,
         'full_actual_catalogue_match':True,'source_code_sha256':sha(Path(__file__)),
         'prior_attempts':prior,'seconds_per_core':0.5,'node_limit':1000000,'R6zero_required':True,
         'additional_rules_budget':2,'hint_is_not_a_constraint':True,'records':rows,
         'source_scope':'Observed unions from100000 sampled pairs only. Full450208467 cross-cycle pairs not enumerated.',
         'status':'RUNNING'}
 baseline=json.loads((H/'inputs/baseline15051.rules.json').read_text());br={(x,*hist,t) for x,hist,t in baseline['rules']}
 hint={i for i,b in enumerate(RULES) if b<=br};assert len(hint)==52
 engine=HighEngine();fixed=set(sorted(hint)[:39]);holes=set(WORDS)-set().union(*(set(ROWS[b]) for b in hint))
 extras={w+(8,) for w in holes};st,n,more,free=engine.run(fixed,extras,5,1000000,hint,True)
 assert st=='FOUND' and len(more)==13 and not free
 caudit=export_and_audit(prefix.with_suffix('.positive.rules.json'),fixed,extras,more,free,15051);assert caudit['wins']==15051
 state['latest_positive39_to52']={'status':st,'nodes':n,'direct_40320_audit':caudit}
 state['invocation_wall_limit_seconds']=a.wall_seconds;state['status']='RUNNING'
 def save():
  rows=state['records'];done={r['priority_position'] for r in rows}
  state['counts']=dict(Counter(r['status'] for r in rows));state['processed_count']=len(done)
  state['counts_by_extra']={str(e):dict(Counter(r['status'] for r in rows if r['fixed_extra_count']==e)) for e in range(3)}
  state['unprocessed_priority_positions']=sorted(set(range(2396))-done)
  state['unknown_priority_positions']=[r['priority_position'] for r in rows if r['status'].startswith('UNKNOWN')]
  state['all_observed_cores_attempted']=len(done)==2396;state['latest_invocation_seconds']=time.monotonic()-start
  output.write_text(json.dumps(state,indent=2),encoding='utf-8')
 save();done={r['priority_position'] for r in state['records']};processed_new=0
 for position,(observed_index,raw) in enumerate(ordered):
  if position in done:continue
  remaining=deadline-time.monotonic()
  if remaining<=0:state['status']='INVOCATION_WALL_LIMIT';break
  core=set(raw['all_core_blocks']);ex=set(map(tuple,raw['critical_extra_rules']))
  actual=set().union(*(RULES[b] for b in core))|ex
  assert len(actual)==4*len(core)+len(ex) and len(ex)<=2
  assert len({canon(r[:4]) for r in actual})==len(actual)
  assert max(len(rs&actual) for rs in six)<=4
  rescued=[c for c,rs in seven if len(rs&actual)>=6];assert len(rescued)>=4
  before=time.monotonic();st,n,more,free=engine.run(core,ex,min(0.5,remaining),1000000,hint,True)
  record={'priority_position':position,'observed_union_index':observed_index,'mandatory_blocks':sorted(core),
          'critical_extra_rules':sorted(ex),'actual_core_sha256':actual_hash(core,ex),
          'fixed_block_count':len(core),'fixed_extra_count':len(ex),'free_holes':2-len(ex),
          'fixed_rescued_sevens':rescued,'status':st,'nodes':n,'seconds':time.monotonic()-before,
          'reused_attempt':False}
  if st=='FOUND':
   cert=H/f'{a.prefix}_priority{position:04d}_observed{observed_index:04d}.rules.json'
   record['certificate']=str(cert);record['direct_40320_audit']=export_and_audit(cert,core,ex,more,free,15052)
   state['status']='FOUND_INDEPENDENTLY_VERIFIED'
  state['records'].append(record);processed_new+=1
  if processed_new%10==0 or st=='FOUND':
   save();print('PROGRESS',len(state['records']),'OF2396','new',processed_new,'counts',state['counts'],'elapsed',round(time.monotonic()-start,2),flush=True)
  if st=='FOUND':print('FOUND_TARGET4',json.dumps(record),flush=True);break
 else:state['status']='ALL_OBSERVED_CORES_ATTEMPTED_UNKNOWN_RETAINED'
 state['latest_invocation_new_count']=processed_new;save()
 print('FINAL',state['status'],'processed',state['processed_count'],'counts',state['counts'],
       'unprocessed',len(state['unprocessed_priority_positions']),'seconds',state['latest_invocation_seconds'],flush=True)

if __name__=='__main__':main()
