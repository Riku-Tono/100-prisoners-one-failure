"""Bitset implementation of pure 46-block + 2-hole packing completion."""
from completion_dlx_recheck import RULES,ROWS,WORDS,normalized_control
from collections import Counter
from pathlib import Path
import json,time,sys
H=Path(__file__).parent
WI={w:i for i,w in enumerate(WORDS)}
RB=[sum(1<<WI[w] for w in row) for row in ROWS]
COL=[0]*len(WORDS)
for b,row in enumerate(ROWS):
    for w in row:COL[WI[w]]|=1<<b
CONFLICT=[0]*len(ROWS)
for b,row in enumerate(ROWS):
    for w in row:CONFLICT[b]|=COL[WI[w]]

class Search:
    def run(self,mandatory,seconds=1,hint=()):
        self.deadline=time.monotonic()+seconds;self.nodes=0;self.hint=sum(1<<b for b in hint);self.answer=None
        words=(1<<len(WORDS))-1;rows=(1<<len(ROWS))-1
        for b in mandatory:
            assert words&RB[b]==RB[b]
            words^=RB[b];rows&=~CONFLICT[b]
        try:
            found=self.search(words,rows,2,[],[])
        except TimeoutError:return 'UNKNOWN',self.nodes,None,None
        if not found:return 'EXHAUSTED_NO_COMPLETION',self.nodes,None,None
        selected,holes=self.answer
        return 'FOUND',self.nodes,selected,[WORDS[c] for c in holes]

    def search(self,words,rows,budget,selected,holes):
        self.nodes+=1
        if self.nodes%1000==0 and time.monotonic()>self.deadline:raise TimeoutError
        if not words:
            if budget:return False
            self.answer=(selected[:],holes[:]);return True
        scan=words;bestn=100000;bestc=-1;bestopts=0;zeros=0
        while scan:
            bit=scan&-scan;scan^=bit;c=bit.bit_length()-1
            opts=COL[c]&rows;n=opts.bit_count()
            if not n:
                zeros+=1
                if zeros>budget:return False
            if n<bestn:bestn=n;bestc=c;bestopts=opts
        options=bestopts
        order=[]
        hint=options&self.hint
        while hint:
            bit=hint&-hint;hint^=bit;order.append(bit.bit_length()-1);options^=bit
        while options:
            bit=options&-options;options^=bit;order.append(bit.bit_length()-1)
        for b in order:
            if self.search(words^RB[b],rows&~CONFLICT[b],budget,selected+[b],holes):return True
        if budget and self.search(words^(1<<bestc),rows&~COL[bestc],budget-1,selected,holes+[bestc]):return True
        return False

def main():
    data=json.loads((H/'witness_pair_seeds.json').read_text());seeds=data['seeds']
    seconds=float(sys.argv[1]) if len(sys.argv)>1 else 1
    total=float(sys.argv[2]) if len(sys.argv)>2 else 180
    start=time.monotonic();out=dict(scope='pure packing of witness pair mandatory union, exactly46 old blocks and2 unrestricted holes; bitset DFS',cases=[])
    if '--resume' in sys.argv:out=json.loads((H/'agent_pair_bitset_probe.json').read_text())
    elapsed=out.get('seconds',0);begin=len(out['cases'])
    hint,singles=normalized_control();search=Search()
    # Control: exactly46 known disjoint rows must recover their actual two holes.
    st,nodes,extra,holes=search.run(hint,1)
    assert st=='FOUND' and not extra and set(holes)==singles
    out['positive_control']=dict(status=st,nodes=nodes)
    for index in range(begin,len(seeds)):
        seed=seeds[index]
        if time.monotonic()-start>=total:break
        st,nodes,extra,holes=search.run(set(seed['blocks']),seconds,hint)
        rec=dict(index=index,status=st,nodes=nodes)
        if st=='FOUND':
            blocks=sorted(set(seed['blocks'])|set(extra));used=[w for b in blocks for w in ROWS[b]]
            assert len(blocks)==46 and len(used)==len(set(used))==184 and set(used)|set(holes)==set(WORDS)
            rec.update(blocks=blocks,holes=holes)
        out['cases'].append(rec);out['counts']=dict(Counter(c['status'] for c in out['cases']));out['seconds']=elapsed+time.monotonic()-start;out['not_run']=len(seeds)-len(out['cases'])
        (H/'agent_pair_bitset_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        if index%10==0 or st!='UNKNOWN':print(index,st,nodes,out['counts'],round(out['seconds'],3),flush=True)
    print('FINAL',out['counts'],out['seconds'],out['not_run'],flush=True)

if __name__=='__main__':main()
