"""Necessary integral support-capacity relaxation for S8 orientation orbits.

Each four-rule block uses four distinct four-supports inside one five-set.
Replace actual blocks by their support patterns and bound every active
support's total use by six. A real52-block packing yields a feasible integer
solution of this model. INFEASIBLE is a valid necessary-capacity exclusion;
FEASIBLE/OPTIMAL here do not certify any rule table or winning score.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import json,time,hashlib
from general_orientation_model import cp_model
H=Path(__file__).resolve().parent;ALL=frozenset(range(1,9));A=tuple(map(frozenset,combinations(range(1,8),4)))
def build(flips):
    flips=set(map(frozenset,flips));active=set(A)-flips|{ALL-s for s in flips};supports=sorted(active,key=lambda s:tuple(sorted(s)))
    types=set()
    for t in combinations(range(1,9),5):
        ss=[frozenset(s) for s in combinations(t,4) if frozenset(s) in active]
        for pattern in combinations(ss,4):types.add(frozenset(pattern))
    types=sorted(types,key=lambda x:sorted(tuple(sorted(s)) for s in x))
    m=cp_model.CpModel();xs=[m.new_int_var(0,6,f'x{i}') for i in range(len(types))]
    m.add(sum(xs)==52)
    for support in supports:m.add(sum(xs[i] for i,t in enumerate(types) if support in t)<=6)
    return m,types,xs
def main():
    start=time.monotonic();source=H/'canonical_orientation_S8_classification.json';data=json.loads(source.read_text());records=[]
    # Positive control: actual known52 blocks map into support patterns.
    from general_orientation_model import read_rules,orientation_data,canon
    base=orientation_data(());rules=read_rules(H/'inputs/baseline15051.rules.json')
    blocks=[b for b in base.blocks if b<=rules];assert len(blocks)==52
    control,ts,xs=build(());counts=Counter(frozenset(frozenset(r[:4]) for r in b) for b in blocks)
    for i,t in enumerate(ts):control.add(xs[i]==counts[t])
    cs=cp_model.CpSolver();cs.parameters.num_search_workers=1;st=cs.solve(control);assert st==cp_model.OPTIMAL
    out=dict(method=__doc__,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),positive_control='PASS_52_actual_block_support_counts',records=records)
    path=H/'canonical_orientation_support_relaxation.json'
    for r in data['orbits']:
        m,types,xs=build(r['flips']);assert not m.validate()
        s=cp_model.CpSolver();s.parameters.num_search_workers=1;s.parameters.max_time_in_seconds=.5
        st=s.solve(m);status=s.status_name(st)
        records.append(dict(index=r['index'],canonical_S8_key_hex=r['canonical_S8_key_hex'],status=status,types=len(types),seconds=s.wall_time,
            support_pattern_counts=[dict(supports=[sorted(v) for v in t],count=s.value(xs[i])) for i,t in enumerate(types) if s.value(xs[i])] if st in (cp_model.FEASIBLE,cp_model.OPTIMAL) else None))
        if len(records)%50==0 or len(records)==len(data['orbits']):
            out.update(counts=dict(Counter(x['status'] for x in records)),complete=len(records)==len(data['orbits']),seconds=time.monotonic()-start)
            path.write_text(json.dumps(out,indent=2),encoding='utf-8');print(len(records),out['counts'],flush=True)
if __name__=='__main__':main()
