"""Independent fresh-block enumeration of witness and orbit coverage."""
from pathlib import Path
from collections import defaultdict,Counter
from itertools import permutations,combinations
import sys,json,time,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H))
from agent_pair_local_independent import blocks,rows,rules,cycles,words,canon
start=time.monotonic();inc=defaultdict(list)
for b,rs in enumerate(blocks):
 for r in rs:inc[r].append(b)
witness=[];parents=[];rescued=[]
for c in cycles(7):
 rr=sorted(rules(c));opts=[inc[r]for r in rr];counts=Counter(b for opts1 in opts for b in opts1);assert max(counts.values(),default=0)<=1
 found=set()
 for omit in range(7):
  choices=sorted((opts[j]for j in range(7)if j!=omit),key=len)
  if any(not o for o in choices):continue
  def search(k,used,chosen):
   if k==6:found.add(tuple(sorted(chosen)));return
   for b in choices[k]:
    if rows[b]&used:continue
    search(k+1,used|rows[b],chosen+[b])
  search(0,0,[])
 if found:
  parent=len(rescued);rescued.append(c)
  for w in sorted(found):witness.append(w);parents.append(parent)
slots=[sum(rows[b]for b in w)for w in witness];masks=[sum(1<<b for b in w)for w in witness]
adj=[set()for w in witness];pairs=[]
for i,j in combinations(range(len(witness)),2):
 if parents[i]==parents[j]:continue
 shared=masks[i]&masks[j];sharedslots=0
 while shared:
  bit=shared&-shared;shared^=bit;sharedslots|=rows[bit.bit_length()-1]
 if slots[i]&slots[j]!=sharedslots:continue
 adj[i].add(j);adj[j].add(i);pairs.append((i,j))
lookup={b:i for i,b in enumerate(blocks)};group=[]
for a in permutations((1,2,3)):
 for b in permutations((4,5,6)):
  mp=dict(zip((1,2,3,4,5,6,7),a+b+(7,)))
  group.append([lookup[frozenset(tuple(mp[x]for x in r)for r in rs)]for rs in blocks])
def orbitkey(w):return min(tuple(sorted(g[b]for b in w))for g in group)
pairkeys=set(orbitkey(set(witness[i])|set(witness[j]))for i,j in pairs)
raw=(H/'witness_pair_seeds.json').read_bytes();seed=json.loads(raw);expected={orbitkey(set(s['blocks']))for s in seed['seeds']};assert pairkeys==expected
trianglekeys=set();rawtriangles=0
for i,j in pairs:
 for k in adj[i]&adj[j]:
  if k<=j:continue
  rawtriangles+=1;trianglekeys.add(orbitkey(set(witness[i])|set(witness[j])|set(witness[k])))
rawt=(H/'agent_seed_triangles.json').read_bytes();tri=json.loads(rawt);expectedtri={tuple(s['block_ids'])for s in tri['seeds']};assert trianglekeys==expectedtri
out={'method':__doc__,'blocks':len(blocks),'slots':len(words),'cycles':len(rescued),'witnesses':len(witness),'compatible_pairs':len(pairs),'pair_orbits':len(pairkeys),'raw_triangles':rawtriangles,'triangle_orbits':len(trianglekeys),'pair_seed_set_matches_exactly':True,'triangle_seed_set_matches_exactly':True,'pair_seeds_sha256':hashlib.sha256(raw).hexdigest(),'triangle_seeds_sha256':hashlib.sha256(rawt).hexdigest(),'seconds':time.monotonic()-start}
(H/'agent_witness_orbit_independent.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))

