"""Read-only native matrix/CASE/control review; never invokes the executable."""
from pathlib import Path
from itertools import combinations
from collections import Counter,defaultdict
import hashlib,json,sys,time

H=Path(__file__).resolve().parent;N=H/'fullstar_native'
sys.path.insert(0,str(H/'claude_desktop_continuation3'))
from c3_model import cyc_rules,directed_cycles,word


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def parse_case(line):
    p=line.split();assert p[0]=='CASE'
    values=list(map(int,p[1:]));j=0
    ident,nf=values[:2];j=2;fixed=values[j:j+nf];j+=nf
    nh=values[j];j+=1;holes=values[j:j+nh];j+=nh
    budget,sixlimit,nodelimit,ninit=values[j:j+4];j+=4
    init=values[j:j+ninit];j+=ninit;assert j==len(values)
    return dict(id=ident,fixed=fixed,holes=holes,budget=budget,sixlimit=sixlimit,nodelimit=nodelimit,init=init)


def main():
    started=time.monotonic()
    blocks=set()
    for s in combinations(range(1,8),5):
        for cycle in directed_cycles(s):
            rr=cyc_rules(cycle)
            for omitted in range(5):blocks.add(frozenset(rr[:omitted]+rr[omitted+1:]))
    blocks=sorted(blocks,key=lambda b:tuple(sorted(b)))
    words=sorted({word(r) for block in blocks for r in block});wi={w:i for i,w in enumerate(words)}
    six=[frozenset(cyc_rules(c)) for s in combinations(range(1,8),6) for c in directed_cycles(s)]
    ri=defaultdict(list)
    for i,rr in enumerate(six):
        for r in rr:ri[r].append(i)
    expected=[]
    for block in blocks:
        row=sorted(wi[word(r)] for r in block)
        delta=Counter(i for r in block for i in ri[r])
        assert len(row)==len(set(row))==4 and len(delta)==8 and set(delta.values())=={1}
        expected.append(tuple(row+[8]+sorted(delta)))
    assert (len(words),len(blocks),len(six))==(210,2520,840)
    matrix=N/'fullstar_matrix.txt';lines=matrix.read_text(encoding='ascii').splitlines()
    assert tuple(map(int,lines[0].split()))==(210,2520,840)
    actual=[tuple(map(int,line.split())) for line in lines[1:]]
    assert actual==expected
    catalogue_sha=hashlib.sha256(json.dumps([sorted(b) for b in blocks],separators=(',',':')).encode()).hexdigest()
    assert catalogue_sha=='a57710fd3760ae84bd080095f3e00b452a31ca7e943c58afeb7539ee5ecda644'
    source=H/'claude_desktop_continuation3/c3_dlx.c';copy=N/'fullstar_dlx.c'
    assert sha(source)==sha(copy)=='77c463e36ba8e835da6d93de3928e1c913cf226865aa58cab7ec891fee102fab'
    controls_path=N/'controls.json';controls=json.loads(controls_path.read_text())
    assert controls['catalogue_sha256']==catalogue_sha
    assert controls['source_sha256']==sha(copy) and controls['exe_sha256']==sha(N/'fullstar_dlx.exe')
    cases=[parse_case(line) for line in (N/'controls.cases.txt').read_text().splitlines()]
    outputs=[line.split() for line in (N/'controls.stdout.txt').read_text().splitlines()]
    assert len(cases)==len(outputs) and len({c['id'] for c in cases})==len(cases)
    events=controls.get('state_transition_sequence',[dict(kind='KNOWN_POSITIVE') for _ in cases])
    assert len(events)==len(cases)
    critical_path=H/'fullstar_priority63_first.critical.json'
    critical=json.loads(critical_path.read_text())
    lookup={b:i for i,b in enumerate(blocks)}
    critical_fixed={lookup[frozenset(map(tuple,b))] for b in critical['fixed_actual_blocks']}
    parsed=[];nonzero_extra_multiset_checked=0
    for case,response,event in zip(cases,outputs,events):
        assert int(response[0])==case['id']
        assert len(case['fixed'])==len(set(case['fixed']))<=52
        assert all(0<=b<2520 for b in case['fixed'])
        assert len(case['holes'])==len(set(case['holes']))<=2
        assert all(0<=w<210 for w in case['holes'])
        assert case['budget']==2-len(case['holes']) and case['sixlimit'] in (4,99)
        assert 0<case['nodelimit']<2**63 and all(0<=i<840 for i in case['init'])
        occupied=[w for b in case['fixed'] for w in actual[b][:4]]+case['holes']
        assert len(occupied)==len(set(occupied))
        if event['kind']=='KNOWN_POSITIVE':
            expected_extras={words[w]+(8,) for w in case['holes']}
        else:
            record=critical['records'][event['critical_index']]
            actual_core=critical_fixed|{lookup[frozenset(map(tuple,b))] for b in record['additional_actual_blocks']}
            assert actual_core==set(case['fixed'])==set(record['core_blocks'])
            expected_extras=set(map(tuple,record['critical_extra_rules']))
            assert {wi[word(r)] for r in expected_extras}==set(case['holes'])
        expected_init=[i for r in sorted(expected_extras) for i in ri[r]]
        assert case['init']==expected_init
        if len(expected_init)>len(set(expected_init)):nonzero_extra_multiset_checked+=1
        status=response[1];nodes=int(response[2])
        entry=dict(id=case['id'],status=status,nodes=nodes,fixed_rows=len(case['fixed']),fixed_holes=len(case['holes']))
        if status=='FOUND':
            split=response.index('H');more=list(map(int,response[3:split]));free=list(map(int,response[split+1:]))
            selected=case['fixed']+more
            assert len(selected)==len(set(selected))==52 and all(0<=b<2520 for b in selected)
            block_words=[w for b in selected for w in actual[b][:4]]
            holes=case['holes']+free
            assert len(block_words)==len(set(block_words))==208
            assert len(free)==case['budget'] and len(holes)==len(set(holes))==2
            assert set(block_words).isdisjoint(holes) and set(block_words)|set(holes)==set(range(210))
            rules=set().union(*(blocks[b] for b in selected))
            assert max(len(s&rules) for s in six)<=case['sixlimit']
            entry['additional_rows']=len(more)
        elif status=='NODELIMIT':assert nodes==case['nodelimit']+1
        else:assert status in ('EXHAUSTED','FIXED_CONFLICT')
        parsed.append(entry)
    assert sum(r['status']=='FOUND' for r in parsed)>=2
    for r in controls['records']:
        d=r['direct_audit'];assert d['placements']==40320 and d['wins']==15051 and d['lost_cf']==0
        assert d['rescued_cycles']=={'5':52,'6':0,'7':3,'8':0}
        assert sha(d['file'])==d['sha256']
    wrapper=N/'native_wrapper.py'
    assert controls.get('wrapper_sha256',sha(wrapper))==sha(wrapper)
    report=dict(status='PASS_STATIC_ACTUAL_MATRIX_AND_EXISTING_CASE_FEED',scope=__doc__,
                native_executable_called_by_reviewer=False,construction_Solve_called=False,
                exact_matrix_regenerated=True,dimensions=[210,2520,840],row_words_distinct=True,
                row_six_contributions_exactly8_distinct=True,matrix_sha256=sha(matrix),
                block_catalogue_sha256=catalogue_sha,C_source_sha256=sha(source),native_copy_matches=True,
                exe_sha256=sha(N/'fullstar_dlx.exe'),wrapper_sha256=sha(wrapper),
                controls_sha256=sha(controls_path),parsed_existing_controls=parsed,
                critical_source_sha256=sha(critical_path),extra_multiset_shared_cycle_controls=nonzero_extra_multiset_checked,
                existing40320_audits_consistent=True,
                source_code_findings=['C does not check terminal budget explicitly, but210=4(F+r)+e+h,0<=e+h<=2 forces e+h=2 and F+r=52.',
                                     'FOUND retains counts and solution for output but restores all DLX links; nextCASE resets counters.',
                                     'NODELIMIT and ordinary exhaustion undo row/hole branches before returning.',
                                     'Wrapper constructs extras init as a list comprehension preserving shared-cycle multiplicity.',
                                     'Unexpected FIXED_CONFLICT raises and is not silently recorded as arbitrary exhaustion.'],
                wrapper_hardening_applied=['Each extra validates as distinct-label five-tuple in1..8 with old[7] history.',
                                          'sixlimit is restricted to integer4 and node_limit to positive signed64 range.',
                                          'Existing controls now cover FOUND->NODELIMIT->FOUND->EXHAUSTED->FOUND reuse.',
                                          'The exhaustion control contains two extras sharing a six-cycle; its repeated ninit ID is independently confirmed.'],
                boundary='This is a fullstar210/2520/840 feed and source audit, not a runtime proof for arbitrary dimensions, malformed inputs or generic budgets.',
                seconds=time.monotonic()-started)
    (H/'fullstar_native_feed_static_review_20261018.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print({k:v for k,v in report.items() if k not in ('source_code_findings','input_contract_recommendations')},flush=True)


if __name__=='__main__':main()
