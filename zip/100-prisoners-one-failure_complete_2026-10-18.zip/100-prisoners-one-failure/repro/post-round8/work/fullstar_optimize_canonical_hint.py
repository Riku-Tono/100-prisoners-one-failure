"""Full-star completion optimization with canonical six and a verified hint.

Uses known15051 as a hint only, maximizes R7, and adds only redundant two-hole
exact-cover equations. A FEASIBLE R7=3 is not an optimality claim.
"""
from pathlib import Path
from collections import defaultdict
import json
from general_orientation_model import build,read_rules,H,cp_model,canon,cycle_data
from global_orientation_witness_completion import CANONICAL_SIX
def main():
    m=build((),0);rules=read_rules(H/'global_orientation_control_baseline208.normalized.json')
    selected,extras=m.certificate_assignment(rules)
    for i,v in enumerate(m.blocks):m.model.add_hint(v,int(i in selected))
    for r,v in m.singles.items():m.model.add_hint(v,int(r in extras))
    for r,v in m.present.items():m.model.add_hint(v,int(r in rules))
    for c,rr in cycle_data(7):
        z=m.rescue_flags[7][c]
        if not isinstance(z,int):m.model.add_hint(z,int(len(rr & rules)>=6))
    for r in CANONICAL_SIX:m.model.add(m.present[r]==1)
    columns=defaultdict(list);single=defaultdict(list)
    for i,b in enumerate(m.data.blocks):
        for r in b:columns[canon(r[:4])].append(m.blocks[i])
    for r,v in m.singles.items():single[canon(r[:4])].append(v)
    holes={w:m.model.new_bool_var('hole'+str(i)) for i,w in enumerate(m.data.words)}
    used={canon(r[:4]) for i in selected for r in m.data.blocks[i]}
    for w,h in holes.items():
        m.model.add(sum(columns[w])+h==1);m.model.add(sum(single[w])<=h);m.model.add_hint(h,int(w not in used))
    m.model.add(sum(holes.values())==2)
    objective=sum(m.rescue_flags[7].values());m.model.maximize(objective);assert not m.model.validate()
    s=cp_model.CpSolver();s.parameters.num_search_workers=4;s.parameters.max_time_in_seconds=300;s.parameters.random_seed=41
    s.parameters.log_search_progress=True;s.parameters.log_to_stdout=False
    prefix=H/'fullstar_canonical_optimize300'
    class Progress(cp_model.CpSolverSolutionCallback):
        def __init__(self):super().__init__();self.records=[]
        def on_solution_callback(self):
            self.records.append(dict(R7=int(self.objective_value),seconds=self.wall_time))
            prefix.with_suffix('.progress.json').write_text(json.dumps(self.records,indent=2))
            print('fullstar R7',self.objective_value,self.wall_time,flush=True)
    progress=Progress()
    with prefix.with_suffix('.log.txt').open('w',encoding='utf-8') as f:
        s.log_callback=lambda x:f.write(x+'\n');st=s.solve(m.model,progress)
    out=dict(scope=__doc__,status=s.status_name(st),solve_seconds=s.wall_time,response_stats=s.response_stats(),workers=4,limit_seconds=300,incumbents=progress.records)
    if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):
        out.update(m.export_and_audit(s,prefix.with_suffix('.rules.json')))
        out.update(R7=int(s.objective_value),best_objective_bound=s.best_objective_bound)
    prefix.with_suffix('.result.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(out['status'],out.get('R7'),out.get('best_objective_bound'),flush=True)
if __name__=='__main__':main()
