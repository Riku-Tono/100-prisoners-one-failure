"""Optimizer-free Fraction verification of independent capacity certificates.

Only Python standard library plus Claude's cycle/rule definitions are used.
All finite patterns are regenerated from actual rules; solver statuses and
stored boolean verification flags are not used as fractional proof evidence.
"""
from pathlib import Path
from itertools import combinations
from fractions import Fraction
from collections import Counter
import sys,json,hashlib,time
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'claude_desktop_continuation3'))
from c3_model import directed_cycles,cyc_rules

def main():
    started=time.monotonic();src=H/'canonical_support_independent_fraction_audit.json';raw=src.read_bytes();doc=json.loads(raw)
    assert doc['complete'] and doc['status']=='PASS_COMPLETE'
    classification_raw=(H/'canonical_orientation_S8_classification.json').read_bytes()
    assert hashlib.sha256(classification_raw).hexdigest()==doc['input_classification_sha256']
    classification=json.loads(classification_raw)
    supports=tuple(map(frozenset,combinations(range(1,9),4)));si={s:i for i,s in enumerate(supports)};all8=frozenset(range(1,9))
    assert [sorted(s) for s in supports]==doc['global_support_catalogue']
    actual_blocks=set();patterns=set()
    for five in combinations(range(1,9),5):
        for cycle in directed_cycles(five):
            rs=cyc_rules(cycle)
            for skip in range(5):
                b=frozenset(rs[j] for j in range(5) if j!=skip);actual_blocks.add(b)
                p=tuple(sorted(si[frozenset(r[:4])] for r in b));assert len(set(p))==4;patterns.add(p)
    assert len(actual_blocks)==6720 and len(patterns)==280
    catalogue=tuple(tuple(p) for p in doc['global_pattern_catalogue']);assert tuple(sorted(patterns))==catalogue
    assert len(doc['records'])==len(classification['orbits'])==1378
    assert {r['index'] for r in doc['records']}=={r['index'] for r in classification['orbits']}
    lookup={r['index']:r for r in classification['orbits']};counts=Counter();bounds=Counter();cbc_only=[];survivors=[]
    for record in doc['records']:
        spec=lookup[record['index']];active={frozenset(s) for s in combinations(range(1,8),4)}
        for flipped in spec['flips']:
            s=frozenset(flipped);active.remove(s);active.add(all8-s)
        active=frozenset(si[s] for s in active)
        assert sorted(active)==record['active_support_indices']
        wanted={p for p in patterns if all(i in active for i in p)}
        stored={catalogue[j] for j in record['pattern_catalogue_indices']}
        assert len(stored)==len(record['pattern_catalogue_indices'])==record['support_pattern_count']
        assert wanted==stored
        status=record['independent_status'];counts[status]+=1
        if status=='EXACT_FRACTION_DUAL_EXCLUSION':
            certificate=record['certificate'];weights={row['support_index']:Fraction(*row['value']) for row in certificate['nonzero_weights']}
            assert len(weights)==len(certificate['nonzero_weights'])
            assert set(weights)<=active and all(q>=0 for q in weights.values())
            cover=[sum((weights.get(i,Fraction()) for i in p),Fraction()) for p in wanted]
            assert all(q>=1 for q in cover)
            bound=6*sum(weights.values(),Fraction());assert bound==Fraction(*certificate['upper_bound']) and bound<52
            if cover:assert min(cover)==Fraction(*certificate['minimum_pattern_cover'])
            bounds[str(bound)]+=1
        elif status=='INTEGER_RELAXATION_SURVIVES':
            checked=record['independent_integer_check'];assignment=checked['positive_pattern_counts']
            values={tuple(row['pattern']):row['count'] for row in assignment}
            assert len(values)==len(assignment) and set(values)<=wanted
            assert sum(values.values())==52 and all(isinstance(n,int) and 0<=n<=6 for n in values.values())
            assert all(sum(n for p,n in values.items() if i in p)<=6 for i in active)
            survivors.append(record['index'])
        elif status=='CBC_INTEGER_INFEASIBLE':
            cbc_only.append(record['index'])
        else:raise AssertionError(('unresolved or unexpected status',record['index'],status))
    assert survivors==[1255,1291,1305,1319,1376]
    out=dict(status='PASS_OPTIMIZER_FREE_CERTIFICATES',method=__doc__,input_sha256=hashlib.sha256(raw).hexdigest(),
             full_actual_blocks_regenerated=6720,full_actual_support_patterns=280,all_orientation_pattern_sets_equal=True,
             orientation_count=1378,counts=dict(counts),fractional_bounds_histogram=dict(sorted(bounds.items(),key=lambda p:Fraction(p[0]))),
             integer_feasibility_witnesses_exactly_checked=survivors,CBC_infeasibility_only_indices=cbc_only,
             unresolved=0,optimizer_imports_or_calls=0,seconds=time.monotonic()-started,
             scope='Certifies the stored fractional exclusions and integer positive witnesses for the supplied1378 orientations. Input enumeration/S8 coverage and low-minimum-degree classifications are separate dependencies; CBC-only infeasibility is computational evidence, not a Fraction certificate.')
    (H/'canonical_support_fraction_certificate_verify.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2),flush=True)

if __name__=='__main__':main()
