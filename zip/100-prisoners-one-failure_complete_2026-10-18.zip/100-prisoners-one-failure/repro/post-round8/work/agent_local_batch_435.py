import sys
import agent_pair_local_batch as runner
runner.PREFIX='agent_local_435'
sys.argv=['agent_local_batch_435','435','200','120']
runner.main()
