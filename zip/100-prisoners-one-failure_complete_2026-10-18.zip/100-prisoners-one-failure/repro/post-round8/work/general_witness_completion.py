"""Generic witness-first preparation / future local-core completion runner.

No old/new split or bound on block-only rescues or extra-rule gains is used.
All8 labels and all active single-rule choices remain available. R6=0 is
direct; R7 flags are iff; R8=0 follows from opposite complementary histories.
`prepare` never solves. `controls` solves only completely fixed known tables.
The explicit `run` entry point is for the coordinator's later audit-approved GO.
Any exhausted result concerns only completions containing the fixed mandatory
blocks. UNKNOWN never produces a no-good or an exclusion.
"""
from __future__ import annotations
from pathlib import Path
from collections import defaultdict,Counter
from itertools import combinations
from dataclasses import dataclass
from functools import lru_cache
import argparse,hashlib,json,time,traceback
from general_orientation_model import orientation_data,normalize_flips,cycle_data,canon,correct,cp_model,OrientationModel,read_rules,H

FOUR_FLIPS=((1,2,3,4),(1,2,3,5),(1,2,3,6),(1,2,3,7))

def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2),encoding='utf-8')

@lru_cache(maxsize=16)
def block_digest(flips):
    data=orientation_data(flips)
    return hashlib.sha256(json.dumps([sorted(b) for b in data.blocks],separators=(',',':')).encode()).hexdigest()

def certificate_parts(data,rules):
    """Decompose a completely known52-block table; never pad or infer rules."""
    rules=frozenset(map(tuple,rules));allowed=set(data.singles)
    if not rules<=allowed:raise ValueError('Known table contains inactive or invalid rules.')
    groups=defaultdict(set);options=defaultdict(list)
    for r in rules:groups[canon((r[4],)+r[:4])].add(r)
    for b,rr in enumerate(data.blocks):
        r=next(iter(rr));options[canon((r[4],)+r[:4])].append(b)
    chosen=set()
    for five,rr in groups.items():
        if len(rr)>=4:
            good=[b for b in options[five] if data.blocks[b]<=rr]
            if not good:raise ValueError('No admissible four-rule block for a rescued5-cycle.')
            chosen.add(min(good))
    supplied=set().union(*(data.blocks[b] for b in chosen)) if chosen else set()
    extras=rules-supplied
    if len(chosen)!=52 or len(supplied)!=208 or len(extras)>2:raise ValueError('Known table is not52 blocks plus<=2 singles.')
    slots=[canon(r[:4]) for r in rules]
    if len(slots)!=len(set(slots)):raise ValueError('Known table has colliding words.')
    return chosen,extras

@dataclass
class WitnessModel:
    data:object
    mandatory:frozenset
    local:bool
    target:int
    model:object
    blocks:dict
    singles:dict
    present:dict
    flags:dict
    stats:dict

    def require_extras(self,extras):
        for r in extras:
            if r not in self.singles:raise ValueError('Required extra collides with a fixed block or is inadmissible.')
            self.model.add(self.singles[r]==1)

    def fix_certificate(self,rules):
        chosen,extras=certificate_parts(self.data,rules)
        if not self.mandatory<=chosen:raise ValueError('Known block decomposition omits a mandatory block.')
        for b,v in self.blocks.items():self.model.add(v==int(b in chosen))
        if not extras<=self.singles.keys():raise ValueError('Known extra collides with the mandatory blocks.')
        for r,v in self.singles.items():self.model.add(v==int(r in extras))
        return dict(blocks=len(chosen),singles=len(extras),rules=208+len(extras))

    def selected(self,solver):
        return set(self.mandatory)|{b for b,v in self.blocks.items() if solver.value(v)},{r for r,v in self.singles.items() if solver.value(v)}

    def export_and_audit(self,solver,path):
        """Reuse the generic full-rule export and independent40320 simulation."""
        allblocks=[1 if b in self.mandatory else self.blocks.get(b,0) for b in range(len(self.data.blocks))]
        view=OrientationModel(self.data,self.target,self.model,allblocks,self.singles,self.present,self.flags,self.stats)
        return view.export_and_audit(solver,path)

def build(flips,mandatory=(),target=4,local=False):
    start=time.monotonic();data=orientation_data(flips);mandatory=frozenset(mandatory)
    if not isinstance(target,int) or target<0:raise ValueError('target must be a nonnegative integer.')
    if len(mandatory)>52 or any(not isinstance(b,int) or b not in range(len(data.blocks)) for b in mandatory):raise ValueError('Invalid mandatory block IDs.')
    rows=[frozenset(canon(r[:4]) for r in rr) for rr in data.blocks]
    used=[w for b in mandatory for w in rows[b]]
    if len(used)!=len(set(used)):raise ValueError('Mandatory blocks collide.')
    occupied=set(used);remaining=set(data.words)-occupied
    fixed=set().union(*(data.blocks[b] for b in mandatory)) if mandatory else set()
    permitted=[b for b,row in enumerate(rows) if not row&occupied]
    m=cp_model.CpModel();bs={b:m.new_bool_var(f'b{b}') for b in permitted}
    ss={r:m.new_bool_var(f's{i}') for i,r in enumerate(data.singles) if canon(r[:4]) in remaining}
    columns=defaultdict(list);suppliers=defaultdict(list)
    for b,v in bs.items():
        for w in rows[b]:columns[w].append(v)
        for r in data.blocks[b]:suppliers[r].append(v)
    for r,v in ss.items():columns[canon(r[:4])].append(v);suppliers[r].append(v)
    for w in remaining:m.add_at_most_one(columns[w])
    if local:m.add(sum(bs.values())<=52-len(mandatory))
    else:m.add(sum(bs.values())==52-len(mandatory))
    m.add(sum(ss.values())<=2)
    present={}
    for i,r in enumerate(data.singles):
        if r in fixed:present[r]=1
        elif canon(r[:4]) in occupied:present[r]=0
        else:
            v=m.new_bool_var(f'p{i}');present[r]=v;m.add(v==sum(suppliers[r]))
    # Every directed6-cycle on8 labels, including trivially safe cycles.
    for c,rr in cycle_data(6):m.add(sum(present.get(r,0) for r in rr)<=4)
    flags={7:{},8:{c:0 for c,rr in cycle_data(8)}};variable_flags=0;fixed_true=0
    for c,rr in cycle_data(7):
        values=[present.get(r,0) for r in rr]
        constant=sum(v for v in values if isinstance(v,int));potential=constant+sum(not isinstance(v,int) for v in values)
        if constant>=6:flags[7][c]=1;fixed_true+=1
        elif potential<6:flags[7][c]=0
        else:
            z=m.new_bool_var(f'z{variable_flags}');variable_flags+=1;flags[7][c]=z
            count=sum(values);m.add(count>=6).only_enforce_if(z);m.add(count<=5).only_enforce_if(z.Not())
    # For any complementary support orientation, H_i and H_(i+4) are
    # complements on an8-cycle. Exactly4 histories can be active; rescue needs7.
    m.add(sum(flags[7].values())>=target)
    stats=dict(flips=data.flips,block_definition_sha256=block_digest(data.flips),all_blocks=len(data.blocks),slots=210,mandatory_blocks=len(mandatory),occupied_slots=len(occupied),free_slots=len(remaining),block_variables=len(bs),single_variables=len(ss),expected_single_variables=16*len(remaining),six_constraints=len(cycle_data(6)),seven_cycles=len(flags[7]),seven_variable_flags=variable_flags,seven_fixed_true=fixed_true,eight_constant_zero_flags=len(flags[8]),local_relaxation=local,target=target,validation_error=m.validate(),build_seconds=time.monotonic()-start)
    assert len(ss)==stats['expected_single_variables'] and stats['validation_error']==''
    return WitnessModel(data,mandatory,local,target,m,bs,ss,present,flags,stats)

def map_actual_blocks(flips,actual_blocks):
    """Map portable rule tuples, never trusting serialized block IDs."""
    data=orientation_data(flips);lookup={rr:b for b,rr in enumerate(data.blocks)};mapped=[]
    for actual in actual_blocks:
        rr=frozenset(tuple(r) for r in actual)
        if len(rr)!=4 or rr not in lookup:raise ValueError('Seed block rule tuples do not match an admissible block.')
        mapped.append(lookup[rr])
    if len(set(mapped))!=len(mapped):raise ValueError('Repeated mandatory block.')
    used=[canon(r[:4]) for b in mapped for r in data.blocks[b]]
    if len(used)!=len(set(used)):raise ValueError('Mapped seed blocks collide.')
    return frozenset(mapped)

def load_mapped_seeds(flips,path):
    path=Path(path);raw=path.read_bytes();document=json.loads(raw);data=orientation_data(flips);result=[]
    for index,seed in enumerate(document['seeds']):
        mapped=map_actual_blocks(flips,seed['actual_rules'])
        supplied=set().union(*(data.blocks[b] for b in mapped))
        assert all(len(correct(tuple(c))&supplied)>=6 for c in seed.get('cycles',[]))
        result.append(dict(index=index,blocks=sorted(mapped),reported_ids_match=sorted(seed.get('blocks',[]))==sorted(mapped),cycles=seed.get('cycles',[]),source_sha256=hashlib.sha256(raw).hexdigest()))
    return result

def critical_core(model,solver):
    selected,extras=model.selected(solver);base=set().union(*(model.data.blocks[b] for b in selected));full=base|extras
    suppliers={r:b for b in selected for r in model.data.blocks[b]};possibilities=[]
    rescued=[(c,rr) for c,rr in cycle_data(7) if len(rr&full)>=6]
    if len(rescued)<model.target:raise AssertionError('Local assignment does not actually meet the target.')
    for c,rr in rescued:
        for six in combinations(sorted(rr&full),6):
            needed=frozenset(six);external=needed-base
            owners=frozenset(suppliers[r] for r in needed-external)
            possibilities.append((c,needed,owners,frozenset(external)))
    core=set(model.mandatory);critical=set();chosen=[];used_cycles=set()
    for _ in range(model.target):
        options=[p for p in possibilities if p[0] not in used_cycles]
        pick=min(options,key=lambda p:(len(p[3]-critical),len(p[2]-core),p[0],tuple(sorted(p[1]))))
        c,needed,owners,external=pick;core.update(owners);critical.update(external);used_cycles.add(c)
        chosen.append(dict(cycle=c,six_correct_rules=sorted(needed)))
    rules=set().union(*(model.data.blocks[b] for b in core))|critical
    assert critical<=extras and len(critical)<=2
    assert all(len(rr&rules)<=4 for c,rr in cycle_data(6))
    assert sum(len(rr&rules)>=6 for c,rr in cycle_data(7))>=model.target
    return dict(blocks=frozenset(core),extras=frozenset(critical),cycles=chosen)

def add_core_nogood(local,core):
    assert local.mandatory<=core['blocks'] and all(b in local.blocks for b in core['blocks']-local.mandatory)
    assert all(r in local.singles for r in core['extras'])
    literals=[local.blocks[b].Not() for b in sorted(core['blocks']-local.mandatory)]+[local.singles[r].Not() for r in sorted(core['extras'])]
    local.model.add_bool_or(literals) # Empty means the fixed seed itself has no completion.
    return len(literals)

def run_seed(flips,mandatory,target=4,wall_seconds=120,local_seconds=3,completion_seconds=5,max_iterations=1000,output_prefix='general_witness_completion_run'):
    start=time.monotonic();deadline=start+wall_seconds;local=build(flips,mandatory,target,True)
    out=dict(scope=__doc__,flips=local.data.flips,mandatory_blocks=sorted(mandatory),local_stats=local.stats,records=[],status='WITNESS_LIMIT')
    for iteration in range(max_iterations):
        remaining=deadline-time.monotonic()
        if remaining<=0:out['status']='WALL_LIMIT';break
        solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.random_seed=iteration+1;solver.parameters.max_time_in_seconds=min(local_seconds,remaining)
        st=solver.solve(local.model);name=solver.status_name(st)
        if st not in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            out['status']='EXHAUSTED_TARGET_WITH_FIXED_MANDATORY' if st==cp_model.INFEASIBLE else 'LOCAL_'+name;break
        core=critical_core(local,solver);completion=build(flips,core['blocks'],target,False);completion.require_extras(core['extras'])
        remaining=deadline-time.monotonic()
        if remaining<=0:out['status']='WALL_LIMIT';break
        finish=cp_model.CpSolver();finish.parameters.num_search_workers=1;finish.parameters.random_seed=iteration+1;finish.parameters.max_time_in_seconds=min(completion_seconds,remaining)
        end=finish.solve(completion.model);endname=finish.status_name(end)
        rec=dict(iteration=iteration,local_status=name,local_seconds=solver.wall_time,core_blocks=sorted(core['blocks']),critical_extra_rules=sorted(core['extras']),rescued_cycle_witnesses=core['cycles'],completion_status=endname,completion_seconds=finish.wall_time,no_good_added=False)
        if end in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            try:
                rec.update(completion.export_and_audit(finish,H/f'{output_prefix}_found_{iteration}.rules.json'));out['status']='FOUND_INDEPENDENTLY_VERIFIED'
            except Exception:
                rec['audit_error']=traceback.format_exc();out['status']='FAILED_INDEPENDENT_AUDIT'
            out['records'].append(rec);break
        if end==cp_model.INFEASIBLE:
            rec['no_good_literals']=add_core_nogood(local,core);rec['no_good_added']=True
            if not rec['no_good_literals']:
                out['status']='EXHAUSTED_TARGET_WITH_FIXED_MANDATORY';out['records'].append(rec);break
        else:
            out['status']='COMPLETION_'+endname;out['records'].append(rec);break
        out['records'].append(rec);out['seconds']=time.monotonic()-start;save(H/f'{output_prefix}_result.json',out)
    out['seconds']=time.monotonic()-start;out['completion_counts']=dict(Counter(r['completion_status'] for r in out['records']));save(H/f'{output_prefix}_result.json',out)
    return out

def prepare(seed_path=None,seed_index=0,flips=FOUR_FLIPS,prefix='general_witness_completion'):
    seed_path=Path(seed_path) if seed_path else H/'fourflip_witness_preparation_pairs.json'
    mapped=load_mapped_seeds(flips,seed_path);seed=mapped[seed_index]
    local=build(flips,seed['blocks'],4,True);completion=build(flips,seed['blocks'],4,False)
    out=dict(status='STATIC_BUILD_VALIDATE_ONLY_NO_SOLVE',scope=__doc__,mapped_seed_count=len(mapped),all_reported_ids_match=all(s['reported_ids_match'] for s in mapped),mapped_seeds=mapped,selected_seed_index=seed_index,local_stats=local.stats,completion_stats=completion.stats)
    save(H/f'{prefix}_prepare.json',out);return out

def controls():
    specs=[('fullstar208',(),3,H/'inputs/baseline15051.rules.json','OPTIMAL'),('standard3_r6zero',FOUR_FLIPS[:3],1,H/'agent_full_r6zero_control.rules.json','OPTIMAL'),('standard3_r6one_negative',FOUR_FLIPS[:3],1,H/'inputs/new15051.rules.json','INFEASIBLE')]
    out=dict(scope='Completely fixed existing certificates only; no new construction search.',records=[])
    for label,flips,target,path,expected in specs:
        data=orientation_data(flips);selected,extras=certificate_parts(data,read_rules(path));mandatory=sorted(selected)[:12]
        model=build(flips,mandatory,target,False);fixed=model.fix_certificate(read_rules(path));solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.max_time_in_seconds=15
        st=solver.solve(model.model);status=solver.status_name(st);assert status==expected
        rec=dict(label=label,input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),fixed=fixed,stats=model.stats,status=status,seconds=solver.wall_time)
        if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):rec.update(model.export_and_audit(solver,H/f'general_witness_completion_control_{label}.rules.json'))
        out['records'].append(rec);print(label,status,fixed,flush=True)
    save(H/'general_witness_completion_controls.json',out);return out

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    for command in ('prepare','run'):
        s=sub.add_parser(command);s.add_argument('--flips',default=json.dumps(FOUR_FLIPS));s.add_argument('--seed-file',default=str(H/'fourflip_witness_preparation_pairs.json'));s.add_argument('--seed-index',type=int,default=0);s.add_argument('--output-prefix',default='general_witness_completion')
        if command=='run':
            s.add_argument('--wall-seconds',type=float,default=120);s.add_argument('--local-seconds',type=float,default=3);s.add_argument('--completion-seconds',type=float,default=5);s.add_argument('--max-iterations',type=int,default=1000)
    sub.add_parser('controls');a=p.parse_args()
    if a.command=='controls':controls();return
    flips=normalize_flips(json.loads(a.flips))
    if a.command=='prepare':
        out=prepare(a.seed_file,a.seed_index,flips,a.output_prefix);print(out['status'],out['mapped_seed_count'],out['local_stats'],flush=True)
    else:
        mapped=load_mapped_seeds(flips,a.seed_file);seed=mapped[a.seed_index]
        out=run_seed(flips,seed['blocks'],4,a.wall_seconds,a.local_seconds,a.completion_seconds,a.max_iterations,a.output_prefix);print(out['status'],out['completion_counts'],flush=True)

if __name__=='__main__':main()
