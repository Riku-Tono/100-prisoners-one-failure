"""Construction search with a known 15051 table as a soft hint only.

No extra constraints or restrictions on support orientations are added.
The target remains R5=52, R6=0 and R7>=4. An infeasible hint is not a
certificate; UNKNOWN is retained as unresolved.
"""
import json
from pathlib import Path
from global_orientation_witness_completion import build,universe,solve_once
from general_orientation_model import H,read_rules,cycle_data

def main():
    control=json.loads((H/'global_orientation_controls.json').read_text())
    assert control['status']=='PASS'
    source=H/'global_orientation_control_baseline208.normalized.json'
    data=json.loads(source.read_text())
    rules=read_rules(source)
    model=build(target=4,canonical=True)
    selected,extras=model.certificate_assignment(rules)
    _,blocks,singles,pairs=universe()
    active={frozenset(s) for s in data['active_supports']}
    for i,var in enumerate(model.blocks):model.model.add_hint(var,int(i in selected))
    for r,var in model.singles.items():model.model.add_hint(var,int(r in extras))
    for r,var in model.present.items():model.model.add_hint(var,int(r in rules))
    for i,(a,b) in enumerate(pairs):model.model.add_hint(model.orientation[i],int(a in active))
    for c,rr in cycle_data(7):model.model.add_hint(model.flags[c],int(len(rr & rules)>=6))
    model.stats['hint_source']=str(source)
    model.stats['hint_is_constraint']=False
    solve_once(model,150,H/'global_orientation_hint150',seed=17)

if __name__=='__main__':main()
