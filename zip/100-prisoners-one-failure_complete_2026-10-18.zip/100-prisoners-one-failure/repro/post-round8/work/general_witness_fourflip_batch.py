"""Bounded four-flip local/core completion batch after coordinator audit GO.

Each seed stops on UNKNOWN and remains open; other independent seeds may
still be tried within the global wall budget. No unresolved core is excluded.
"""
from general_witness_completion import *
import sys

def main():
    start_index=int(sys.argv[1]) if len(sys.argv)>1 else 0
    count=int(sys.argv[2]) if len(sys.argv)>2 else 192
    wall=float(sys.argv[3]) if len(sys.argv)>3 else 120
    per_seed=float(sys.argv[4]) if len(sys.argv)>4 else 8
    prefix=sys.argv[5] if len(sys.argv)>5 else 'general_witness_fourflip_batch0'
    mapped=load_mapped_seeds(FOUR_FLIPS,H/'fourflip_witness_preparation_pairs.json')
    start=time.monotonic();deadline=start+wall
    out=dict(scope=__doc__,flips=FOUR_FLIPS,start_index=start_index,requested_count=count,workers=1,seed_file_sha256=mapped[0]['source_sha256'],records=[])
    for index in range(start_index,min(start_index+count,len(mapped))):
        remaining=deadline-time.monotonic()
        if remaining<=.1:break
        result=run_seed(FOUR_FLIPS,mapped[index]['blocks'],4,min(per_seed,remaining),2,2,100,f'{prefix}_seed{index}')
        out['records'].append(dict(index=index,status=result['status'],completion_counts=result['completion_counts'],core_records=len(result['records']),seconds=result['seconds'],result_file=f'{prefix}_seed{index}_result.json'))
        out['counts']=dict(Counter(r['status'] for r in out['records']));out['seconds']=time.monotonic()-start
        out['not_run']=count-len(out['records']);out['closed_indices']=[r['index'] for r in out['records'] if r['status']=='EXHAUSTED_TARGET_WITH_FIXED_MANDATORY'];out['open_attempted_indices']=[r['index'] for r in out['records'] if r['status']!='EXHAUSTED_TARGET_WITH_FIXED_MANDATORY']
        save(H/f'{prefix}_summary.json',out)
        print(index,result['status'],result['completion_counts'],'total',round(out['seconds'],2),flush=True)
        if result['status'] in ('FOUND_INDEPENDENTLY_VERIFIED','FAILED_INDEPENDENT_AUDIT'):break
    print('FINAL',out.get('counts',{}),out.get('seconds'),out.get('not_run'),flush=True)

if __name__=='__main__':main()
