"""Ten-second52-cover precheck for mandatory shared-block seed7675.

No R7 target is imposed. Exhaustion would exclude this fixed seed even
before rescue constraints. UNKNOWN remains unresolved. Any found table is
saved at208 and210 rules and directly simulated over all40320 placements.
"""
from pathlib import Path
from itertools import combinations,permutations,product
import hashlib,json,time
from fullstar_finite_core_finish import HighEngine,RULES,CATALOGUE_SHA,WORDS,canon
from independent_audit import audit

H=Path(__file__).resolve().parent
PREFIX=H/'fullstar_shared7675_target0_precheck_20261018'

def correct(c):
 return frozenset((c[i:] + c[:i])[:4]+((c[i:] + c[:i])[-1],) for i in range(len(c)))

def write_table(path,rules,blocks,extras):
 path.write_text(json.dumps({'n':8,'rules':[[r[0],list(r[1:4]),r[4]] for r in sorted(rules)],
                             'selected_block_ids':sorted(blocks),'extras':sorted(extras)},indent=2),encoding='utf-8')
 return audit(path)

def main():
 start=time.monotonic();source=H/'fullstar_prepare_pairs.json';d=json.loads(source.read_text())
 found=[(i,s) for i,s in enumerate(d['seeds']) if len(s['blocks'])==11]
 assert len(found)==1 and found[0][0]==7675
 core=set(found[0][1]['blocks'])
 own=sorted({g-{r} for g in {correct(p) for p in permutations(range(1,8),5)} for r in g},key=lambda b:tuple(sorted(b)))
 assert own==RULES and len(core)==11
 baseline=json.loads((H/'inputs/baseline15051.rules.json').read_text())
 br={(a,*hist,t) for a,hist,t in baseline['rules']}
 hint={i for i,b in enumerate(RULES) if b<=br}
 engine=HighEngine();status,nodes,additional,holes=engine.run(core,[],10,2000000,hint,True)
 out={'scope':__doc__,'seed':7675,'mandatory_blocks':sorted(core),'extras':[],
      'block_catalogue_sha256':CATALOGUE_SHA,'status':status,'nodes':nodes,
      'seconds':time.monotonic()-start,'wall_limit_seconds':10,'node_limit':2000000,
      'R6zero_required':True,'R7_target':None,'hint_only_not_constraint':sorted(hint)}
 if status=='FOUND':
  selected=core|set(additional);rs=set().union(*(RULES[i] for i in selected))
  assert len(selected)==52 and len(rs)==208 and len(holes)==2
  out['selected_blocks']=sorted(selected);out['holes']=holes
  out['audit208']=write_table(PREFIX.with_suffix('.208.rules.json'),rs,selected,[])
  pad={tuple(w)+(8,) for w in holes};out['audit210']=write_table(PREFIX.with_suffix('.210.rules.json'),rs|pad,selected,pad)
  assert out['audit208']['rescued_cycles']['6']==out['audit210']['rescued_cycles']['6']==0
  assert out['audit208']['rescued_cycles']==out['audit210']['rescued_cycles']
  # All singleton fillings of the two actual free cyclic-word slots.
  opts=[]
  for w in map(tuple,holes):opts.append([()] + [w[i:]+w[:i]+(t,) for i in range(4) for t in range(1,9) if t not in w])
  cyc={k:[(c,correct(c)) for s in combinations(range(1,9),k) for c in [(s[0],)+p for p in permutations(s[1:])]] for k in (6,7,8)}
  nearby={k:[(c,rr,len(rr&rs)) for c,rr in vals if len(rr&rs)>=k-3] for k,vals in cyc.items()}
  histogram={};best=-1;bestextra=None
  for choice in product(*opts):
   ex={r for r in choice if r};counts=tuple(sum(n+len(rr&ex)>=k-1 for c,rr,n in nearby[k]) for k in (6,7,8))
   histogram[str(counts)]=histogram.get(str(counts),0)+1
   if counts[0]==0 and counts[1]+counts[2]>best:best=counts[1]+counts[2];bestextra=ex
  out['all289_hole_fill_histogram_R6_R7_R8']=histogram;out['best_R6zero_R7plusR8']=best
  out['best_hole_extras']=sorted(bestextra)
  out['best_hole_fill_audit']=write_table(PREFIX.with_suffix('.best.rules.json'),rs|bestextra,selected,bestextra)
  assert out['best_hole_fill_audit']['rescued_cycles']['6']==0
  out['best_wins']=out['best_hole_fill_audit']['wins']
 out['seconds']=time.monotonic()-start
 PREFIX.with_suffix('.result.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
 print(json.dumps(out,indent=2),flush=True)

if __name__=='__main__':main()
