"""Independent reconstruction of local four-seven witnesses, not completions."""
from itertools import combinations,permutations
from pathlib import Path
from collections import Counter
import json
H=Path(__file__).parent
def rotate(x):
    x=tuple(x);return min(x[j:]+x[:j] for j in range(len(x)))
def cr(c):
    q=c+c+c
    return frozenset((q[j],q[j+1],q[j+2],q[j+3],q[j+len(c)-1]) for j in range(len(c)))
forbidden={frozenset(x) for x in ((1,2,3,4),(1,2,3,5),(1,2,3,6),(4,5,6,7))}
regenerated=set()
for support in combinations(range(1,8),5):
    for tail in permutations(support[1:]):
        rules=cr((support[0],)+tail)
        for omitted in rules:
            kept=rules-{omitted}
            if all(frozenset(r[:4]) not in forbidden for r in kept):regenerated.add(kept)
rows=sorted(regenerated,key=lambda rs:tuple(sorted(rs)))
assert len(rows)==1584
source=json.loads((H/'agent_seed_pair_reduced_0_local.json').read_text())
out=[]
for rec in source['records']:
    witness=rec['local_witness'];chosen=[rows[i] for i in witness['blocks']]
    extras=set(map(tuple,witness['extras']));rs=set().union(*chosen)|extras
    occupied=[rotate(r[:4]) for r in rs]
    assert len(rs)==4*len(chosen)+len(extras) and len(occupied)==len(set(occupied))
    rescued={6:[],7:[]}
    for k in (6,7):
        for support in combinations(range(1,8),k):
            for tail in permutations(support[1:]):
                c=(support[0],)+tail
                if len(cr(c)&rs)>=k-1:rescued[k].append(c)
    assert len(rescued[6])==0 and len(rescued[7])==4
    out.append(dict(seed=rec['index'],status='VALID_LOCAL_WITNESS_ONLY',blocks=len(chosen),rules=len(rs),old_blocks_still_needed=46-len(chosen),R6=0,R7=4,rescued_sevens=rescued[7],rules_explicit=sorted(rs)))
(H/'partial_four_witness_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print([(x['seed'],x['blocks'],x['rules'],x['old_blocks_still_needed']) for x in out])
