"""Independent exact residual-word LP obstructions for one fixed18-core branch.

Uses Claude c3's regenerated actual fullstar2520 blocks, not the primary
critical enumerator or cover engine. Remove every row touching fixed-block
or fixed-extra words. A52-block completion then needs t=52-fixed_count
residual disjoint rows. GLOP proposes y>=0 with each legal row sum(y)>=1.
Only Fraction-verified sum(y)<t excludes a case. R6 is ignored, safely.
An LP pass or solver UNKNOWN is unresolved, never a completion certificate.
No candidate construction search is performed.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
from fractions import Fraction
import argparse, hashlib, json, sys, time

H = Path(__file__).resolve().parent
sys.path.insert(0, str(H/'claude_desktop_continuation3'))
sys.path.insert(0, r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
from c3_model import Orientation, word
from ortools.linear_solver import pywraplp


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def qjson(q):
    return [q.numerator, q.denominator]


class ResidualLP:
    def __init__(self):
        active = [frozenset(s) for s in combinations(range(1,8),4)]
        gen = Orientation(active)
        self.blocks = tuple(frozenset(b) for b in gen.blocks)
        self.words = tuple(gen.words)
        self.wi = {w:i for i,w in enumerate(self.words)}
        self.lookup = {b:i for i,b in enumerate(self.blocks)}
        self.rows = tuple(tuple(sorted(self.wi[word(r)] for r in b)) for b in self.blocks)
        self.row_masks = tuple(sum(1<<i for i in row) for row in self.rows)
        assert len(self.blocks) == 2520 and len(self.words) == 210
        self.catalogue_sha = hashlib.sha256(json.dumps([sorted(b) for b in self.blocks],separators=(',',':')).encode()).hexdigest()

    def map_blocks(self, actual):
        result = [self.lookup[frozenset(tuple(r) for r in b)] for b in actual]
        assert len(result) == len(set(result))
        return frozenset(result)

    def residual(self, core, extras):
        used = [i for b in core for i in self.rows[b]]
        used += [self.wi[word(r)] for r in extras]
        assert len(used) == len(set(used)) == 4*len(core)+len(extras)
        occupied = sum(1<<i for i in used)
        available = tuple(b for b,bits in enumerate(self.row_masks) if not bits & occupied)
        free = tuple(i for i in range(210) if not occupied >> i & 1)
        return free, available

    def check_dual(self, free, available, weights, target):
        weights = {i:Fraction(q) for i,q in weights.items() if q}
        assert weights.keys() <= set(free) and all(q>=0 for q in weights.values())
        covers = [sum((weights.get(i,Fraction()) for i in self.rows[b]),Fraction()) for b in available]
        minimum = min(covers) if covers else None
        if minimum is not None and minimum < 1:
            return None
        bound = sum(weights.values(),Fraction())
        if bound >= target:
            return None
        return dict(bound=bound,weights=weights,minimum=minimum)

    def solve(self, core, extras, limit_ms=2000):
        start=time.monotonic()
        target=52-len(core)
        free, available = self.residual(core,extras)
        lp=pywraplp.Solver.CreateSolver('GLOP')
        lp.SetTimeLimit(limit_ms)
        y={i:lp.NumVar(0,lp.infinity(),f'y{i}') for i in free}
        for b in available:
            lp.Add(sum(y[i] for i in self.rows[b])>=1)
        lp.Minimize(sum(y.values()))
        status=lp.Solve()
        names={pywraplp.Solver.OPTIMAL:'OPTIMAL',pywraplp.Solver.FEASIBLE:'FEASIBLE',
               pywraplp.Solver.INFEASIBLE:'INFEASIBLE',pywraplp.Solver.NOT_SOLVED:'NOT_SOLVED',
               pywraplp.Solver.ABNORMAL:'ABNORMAL',pywraplp.Solver.UNBOUNDED:'UNBOUNDED'}
        rec=dict(required_remaining_blocks=target,fixed_blocks=len(core),critical_extras=len(extras),
                 free_words=len(free),available_actual_rows=len(available),
                 available_rows_sha256=hashlib.sha256(','.join(map(str,available)).encode()).hexdigest(),
                 floating_status=names.get(status,str(status)),floating_seconds=lp.wall_time()/1000,
                 independent_status='LP_NOT_EXCLUDED_UNRESOLVED')
        if status in (pywraplp.Solver.OPTIMAL,pywraplp.Solver.FEASIBLE):
            floating=lp.Objective().Value()
            rec['floating_dual_objective']=floating
            if floating < target-1e-7:
                proposed={i:max(0,y[i].solution_value()) for i in free}
                for denominator in (1000,1000000,1000000000):
                    weights={i:Fraction(v).limit_denominator(denominator) for i,v in proposed.items()}
                    covers=[sum((weights[i] for i in self.rows[b]),Fraction()) for b in available]
                    if covers and min(covers)<=0:
                        continue
                    if covers and min(covers)<1:
                        scale=min(covers)
                        weights={i:q/scale for i,q in weights.items()}
                    cert=self.check_dual(free,available,weights,target)
                    if cert:
                        rec['independent_status']='EXACT_FRACTION_DUAL_EXCLUSION'
                        rec['certificate']=dict(upper_bound=qjson(cert['bound']),
                                                minimum_row_weight=qjson(cert['minimum']) if cert['minimum'] is not None else None,
                                                nonnegative=True,all_legal_actual_rows_covered=True,
                                                exact_upper_bound_below_required=True,
                                                nonzero_word_weights=[dict(word_index=i,word=self.words[i],value=qjson(q))
                                                                      for i,q in sorted(cert['weights'].items())])
                        break
                else:
                    rec['independent_status']='FLOATING_GAP_NO_EXACT_CERTIFICATE_UNRESOLVED'
        else:
            rec['independent_status']='LP_'+names.get(status,str(status))+'_UNRESOLVED'
        rec['seconds']=time.monotonic()-start
        return rec


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',default='fullstar_priority63_first.critical.json')
    p.add_argument('--primary-result',default='fullstar_priority63_first.result.json')
    p.add_argument('--prefix',default='fullstar_core4_residual_lp_first100_20261018')
    p.add_argument('--limit',type=int,default=100)
    p.add_argument('--all',action='store_true')
    p.add_argument('--resume')
    a=p.parse_args()
    started=time.monotonic();source=H/a.source
    raw=source.read_bytes();data=json.loads(raw)
    assert data['status']=='EXHAUSTED_CRITICAL_ENUMERATION_NO_COMPLETION'
    assert data['unique_critical_cores']==len(data['records'])==3812
    engine=ResidualLP()
    assert data['block_catalogue_sha256']==engine.catalogue_sha
    fixed=engine.map_blocks(data['fixed_actual_blocks'])
    assert sorted(fixed)==data['fixed_core'] and len(fixed)==18
    manifest=H/'fullstar_priority63_preparation_20261018.json'
    prepared=json.loads(manifest.read_text())
    seed=prepared['seeds'][4]
    assert engine.map_blocks(seed['actual_blocks'])==fixed
    checked=[]
    for r in data['records']:
        core=engine.map_blocks(data['fixed_actual_blocks']+r['additional_actual_blocks'])
        assert sorted(core)==r['core_blocks'] and fixed<=core
        extras=frozenset(map(tuple,r['critical_extra_rules']))
        assert len(extras)==len(r['critical_extra_rules'])<=2
        engine.residual(core,extras)
        checked.append((core,extras))
    # Known positive residual:39 existing baseline blocks leave13 disjoint rows.
    baseline=H/'inputs/baseline15051.rules.json';base=json.loads(baseline.read_text())
    rules=frozenset((v,*hist,t) for v,hist,t in base['rules'])
    known={b for b,rs in enumerate(engine.blocks) if rs<=rules}
    assert len(known)==52
    retain=set(sorted(known)[:39]);remaining=known-retain
    free,available=engine.residual(retain,())
    assert len(remaining)==13 and remaining<=set(available)
    words=[i for b in remaining for i in engine.rows[b]]
    assert len(words)==len(set(words))==52
    positive=engine.solve(retain,())
    assert positive['independent_status']=='LP_NOT_EXCLUDED_UNRESOLVED'
    positive.update(known_actual_rows=len(remaining),known_primal_packing_exactly_verified=True,
                    baseline_source_sha256=sha(baseline))
    history=[];records=[];done=set()
    if a.resume:
        resume=H/a.resume;previous=json.loads(resume.read_text())
        assert previous['critical_source_sha256']==hashlib.sha256(raw).hexdigest()
        assert previous['block_catalogue_sha256']==engine.catalogue_sha
        records=list(previous['records']);done={r['index'] for r in records}
        history.append(dict(path=str(resume),sha256=sha(resume)))
    primary=H/a.primary_result;primaryraw=primary.read_bytes();pd=json.loads(primaryraw)
    assert pd['core_index']==4 and pd['fixed_core']==data['fixed_core']
    already_primary={r['index'] for r in pd['records']}
    minimal=data['minimal_record_indices']
    unresolved_minimal=[i for i in minimal if i not in already_primary]
    chosen=list(range(3812)) if a.all else unresolved_minimal[:a.limit]
    chosen=[i for i in chosen if i not in done]
    out=dict(status='RUNNING',scope=__doc__,critical_source=str(source),
             critical_source_sha256=hashlib.sha256(raw).hexdigest(),
             primary_result_snapshot_sha256=hashlib.sha256(primaryraw).hexdigest(),
             primary_snapshot_records=len(pd['records']),primary_snapshot_unprocessed_minimal=len(unresolved_minimal),
             source_critical_count=3812,source_minimal_count=len(minimal),
             source_seed_core_index=4,source_fixed_core=data['fixed_core'],
             all3812_actual_mandatory_extra_sets_verified=True,
             block_catalogue_sha256=engine.catalogue_sha,claude_c3_sha256=sha(H/'claude_desktop_continuation3/c3_model.py'),
             global_word_catalogue=engine.words,positive_control=positive,
             R6_constraint_used=False,construction_Solve_called=False,
             selected_indices=sorted(done|set(chosen)),records=records,source_history=history)
    output=H/f'{a.prefix}.json'
    def checkpoint():
        out['counts']=dict(Counter(r['independent_status'] for r in out['records']))
        out['seconds']=time.monotonic()-started
        out['tested']=len(out['records'])
        out['not_tested_source_critical_count']=3812-len(out['records'])
        output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    for i in chosen:
        core,extras=checked[i]
        r=engine.solve(core,extras)
        r.update(index=i,core_blocks=sorted(core),critical_extra_rules=sorted(extras))
        out['records'].append(r)
        if len(out['records'])%100==0:
            checkpoint();print(len(out['records']),out['counts'],'seconds',round(out['seconds'],3),flush=True)
    out['status']='ALL3812_LP_SCANNED' if len(out['records'])==3812 else 'SELECTED_LP_SCAN_COMPLETE'
    checkpoint();print('FINAL',out['status'],out['counts'],'seconds',round(out['seconds'],3),flush=True)


if __name__=='__main__':
    main()
