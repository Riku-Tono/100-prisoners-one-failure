"""Independent S8 orbit partition of independently regenerated orientations.

Unlike the submitted increasing-degree/minimum-set encoding, this uses
decreasing-degree cells and the maximum 8-bit-edge encoding, with direct
old-vertex-to-new-bit permutations. Every equal-degree ordering is retained.
No submitted generator is imported and no completion solver is called.
"""
from pathlib import Path
from itertools import combinations, permutations, product
from collections import defaultdict, Counter
import hashlib, json, time

H = Path(__file__).resolve().parent
START = time.monotonic()
EDGE_TUPLES = tuple(combinations(range(8),4))
EDGE_MASKS = tuple(sum(1 << x for x in e) for e in EDGE_TUPLES)
EDGE_CODES = {e: 1 << i for i,e in enumerate(EDGE_MASKS)}
STAR_EDGES = tuple(sum(1 << x for x in e) for e in combinations(range(7),4))
CANONICAL_PROOF = ('A hypergraph isomorphism preserves each vertex degree. '
                   'Mapping all degree cells in descending order to consecutive '
                   'new labels and trying every order inside each cell therefore '
                   'tries every possible isomorphism compatible with that sorted '
                   'degree sequence. Equal maximum encodings give an explicit '
                   'S8 isomorphism; an S8 isomorphism gives equal maxima.')

def active_edges(mask):
    return tuple(e ^ 255 if mask >> i & 1 else e for i,e in enumerate(STAR_EDGES))

def key(edges, degree):
    cells = defaultdict(list)
    for v,d in enumerate(degree): cells[d].append(v)
    best = -1
    tested = 0
    for chunks in product(*(permutations(cells[d]) for d in sorted(cells,reverse=True))):
        order = sum(chunks, ())
        image = [0]*8
        for new,old in enumerate(order): image[old] = 1 << new
        lo = [0]*16
        hi = [0]*16
        for bits in range(1,16):
            bit = bits & -bits
            j = bit.bit_length()-1
            lo[bits] = lo[bits ^ bit] | image[j]
            hi[bits] = hi[bits ^ bit] | image[j+4]
        value = sum(EDGE_CODES[lo[e & 15] | hi[e >> 4]] for e in edges)
        if value > best: best = value
        tested += 1
    return best, tested

def main():
    source = H/'independent_allcore_support_screen_20261018.json'
    own = json.loads(source.read_text())
    assert own['status'] == 'PASS'
    all_masks = sorted(int(h,16) for h in own['orientation_cores'])
    classes = defaultdict(list)
    low = Counter()
    minimum_hist = Counter()
    orderings = 0
    for mask in all_masks:
        edges = active_edges(mask)
        degree = tuple(sum(bool(e & (1 << v)) for e in edges) for v in range(8))
        minimum = min(degree)
        if minimum < 8:
            low[minimum] += 1
            continue
        minimum_hist[minimum] += 1
        canonical, n = key(edges, degree)
        orderings += n
        classes[canonical].append(mask)
    assert len(classes) == 1378
    assert sum(map(len, classes.values())) == 22610
    primary_path = H/'canonical_orientation_S8_classification.json'
    primary = json.loads(primary_path.read_text())
    primary_partition = {}
    all_primary_members = []
    for record in primary['orbits']:
        members = frozenset(int(h,16) for h in record['masks'])
        assert len(members) == record['labelled_masks_in_screen']
        assert int(record['representative_mask_hex'],16) in members
        assert members not in primary_partition
        primary_partition[members] = record
        all_primary_members.extend(members)
    assert len(all_primary_members) == len(set(all_primary_members)) == 22610
    assert {frozenset(v) for v in classes.values()} == set(primary_partition)
    assert dict(sorted(low.items())) == {int(k):v for k,v in primary['low_minimum_degree_counts'].items()}
    assert dict(sorted(minimum_hist.items())) == {int(k):v for k,v in primary['minimum_degree_histogram'].items()}
    records = []
    for canonical, members in sorted(classes.items()):
        original = primary_partition[frozenset(members)]
        core_cover = sorted({i for mask in members for i in own['orientation_cores'][f'{mask:09x}']})
        assert core_cover == original['core_indices']
        records.append({'independent_key_hex':f'{canonical:018x}',
                        'primary_orbit_index':original['index'],
                        'members':[f'{m:09x}' for m in members],
                        'core_indices':core_cover})
    digest = hashlib.sha256(json.dumps(sorted(sorted(v) for v in classes.values()),separators=(',',':')).encode()).hexdigest()
    out = {'status':'PASS','scope':__doc__,'Solve_called':False,
           'independent_input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
           'primary_classification_sha256':hashlib.sha256(primary_path.read_bytes()).hexdigest(),
           'distinct_capacity_orientations':len(all_masks),
           'minimum_degree_at_least8':sum(map(len,classes.values())),
           'S8_orbits':len(classes),'equal_degree_orderings_checked':orderings,
           'canonicalization_argument':CANONICAL_PROOF,
           'all1378_member_sets_exactly_match':True,
           'all_core_cover_sets_exactly_match':True,
           'partition_sha256':digest,
           'low_minimum_degree_counts':dict(sorted(low.items())),
           'minimum_degree_histogram':dict(sorted(minimum_hist.items())),
           'low_minimum_degree_connection': 'For any label v, relabeling v to8 gives exactly degree(v) flips from the star excluding8. Thus a minimum degree d corresponds to a d-flip family after S8 relabeling. This audit does not itself certify those separate fixed-flip exclusions.',
           'records':records,'seconds':time.monotonic()-START}
    output = H/'independent_orientation_S8_partition_20261018.json'
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in out.items() if k != 'records'},indent=2),flush=True)

if __name__ == '__main__':
    main()
