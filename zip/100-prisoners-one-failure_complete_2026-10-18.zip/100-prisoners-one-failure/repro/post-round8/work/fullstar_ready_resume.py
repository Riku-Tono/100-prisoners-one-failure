"""Resume the exact same full-star18-block core from verified no-goods.

Only completion_status=INFEASIBLE records may be replayed. Scope metadata,
the actual known core, and the2520-block catalogue are checked afresh.
Source files are immutable and their SHA256 values are retained. UNKNOWN
never adds a no-good; any unresolved local/completion solve ends the run.
"""
from pathlib import Path
from collections import Counter
from itertools import combinations,permutations
import argparse,hashlib,json,time,traceback
import fullstar_ready_search as ready
from fullstar_prepare_model import build,cp_model
from fullstar_prepare_basic import H,WORDS,RULES,ROWS,correct,canon

def sha(raw):return hashlib.sha256(raw).hexdigest()

def prepare_source(source):
    source=Path(source).resolve();raw=source.read_bytes();prior=json.loads(raw)
    fresh,seed,known,padding=ready.static_prepare()
    old=prior['static_readiness']
    assert old['status']=='STATIC_READY_NO_SOLVE_CALLED'
    assert old['scope']==fresh['scope'] and prior['scope']==ready.__doc__
    assert old['generic_regeneration_matches_all_2520_blocks'] is True
    assert old['baseline_rules_match_exactly_52_blocks'] is True
    assert old['baseline_rule_count']==208 and old['known_positive_padded_rule_count']==210
    assert old['mandatory_core_blocks']==fresh['mandatory_core_blocks']==sorted(seed)
    assert old['mandatory_core_count']==len(seed)==18
    assert old['known_positive_block_ids']==fresh['known_positive_block_ids'] and len(known)==52
    assert old['baseline_three_cycles']==fresh['baseline_three_cycles']
    assert old['model_stats']==fresh['model_stats']
    assert old['model_stats']['target_R7']==4 and old['model_stats']['local_relaxation'] is False
    assert old['model_stats']['fixed_rescued_sevens']==3
    assert old['known_positive_static_window_counts']=={'5':52,'6':0,'7':3,'8':0}
    pc=prior['positive_control'];assert pc['status'] in ('FEASIBLE','OPTIMAL')
    check=pc['direct_audit']
    assert check['placements']==40320 and check['wins']==15051 and check['lost_cf']==0
    assert check['rescued_cycles']=={'5':52,'6':0,'7':3,'8':0}
    local,lb,ls,lz,lstats=build(seed,target=4,local=True)
    assert prior['local_model_stats']==lstats
    if 'resume_settings' in prior:
        settings=prior['resume_settings']
        assert settings['flipped_supports']==[] and settings['required_blocks']==52
        assert settings['completion_single_rules']==2 and settings['R6']==0 and settings['R7_target']==4
        assert settings['fixed_core']==sorted(seed) and settings['slots']==210 and settings['admissible_blocks']==2520
    candidates=list(prior.get('replayed_no_goods',[]))+list(prior['records'])
    replay=[];seen=set();ignored=[]
    for rec in candidates:
        if rec['completion_status']!='INFEASIBLE':
            ignored.append({'iteration':rec.get('iteration'),'completion_status':rec['completion_status']});continue
        assert rec['no_good_added'] is True
        core=set(rec['core_blocks']);extras={tuple(r) for r in rec['critical_extra_rules']}
        assert seed<=core and len(core)<=24 and len(extras)<=2
        assert all(b in lb or b in seed for b in core) and all(r in ls for r in extras)
        used=[w for b in core for w in ROWS[b]]
        assert len(used)==len(set(used)) and not set(used)&{canon(r[:4]) for r in extras}
        assert len({canon(r[:4]) for r in extras})==len(extras)
        rules=set().union(*(RULES[b] for b in core))|extras
        assert all(len(correct((s[0],)+p)&rules)<=4 for s in combinations(range(1,8),6) for p in permutations(s[1:]))
        assert sum(len(correct((1,)+p)&rules)>=6 for p in permutations(range(2,8)))>=4
        key=(tuple(sorted(core)),tuple(sorted(extras)))
        if key in seen:continue
        seen.add(key)
        literals=[lb[b].Not() for b in core-seed]+[ls[r].Not() for r in extras]
        assert literals;local.add_bool_or(literals);replay.append(rec)
    catalogue=json.dumps([sorted(b) for b in RULES],separators=(',',':')).encode('utf-8')
    history=list(prior.get('source_history',[]))+[{'path':str(source),'sha256':sha(raw),'source_status':prior['status'],'source_records':len(prior['records']),'replayed_proofs_total':len(replay),'ignored_noninfeasible_records':ignored}]
    return prior,fresh,seed,known,padding,local,lb,ls,lz,lstats,replay,history,sha(raw),sha(catalogue)

def run(args):
    source=Path(args.resume_source).resolve();output=H/f'{args.output_prefix}_result.json'
    assert output.resolve()!=source
    prior,fresh,seed,known,padding,local,lb,ls,lz,lstats,replay,history,source_sha,catalogue_sha=prepare_source(source)
    assert local.validate()==''
    start=time.monotonic();deadline=start+args.wall_seconds
    settings={'flipped_supports':[],'slots':210,'admissible_blocks':2520,'required_blocks':52,'completion_single_rules':2,'local_single_rules_max':2,'R6':0,'R7_target':4,'fixed_core':sorted(seed),'workers':1,'unknowns_excluded':False,'block_catalogue_sha256':catalogue_sha}
    out={'scope':ready.__doc__,'resume_method':__doc__,'resume_settings':settings,'static_readiness':fresh,'source_history':history,'replayed_no_goods':replay,'replayed_no_good_count':len(replay),'local_model_stats':lstats,'records':[],'status':'STARTING'}
    ready.save(output,out)
    control=ready.positive_control(seed,known,padding,args.output_prefix,deadline);out['positive_control']=control
    if control['status'] not in ('FEASIBLE','OPTIMAL'):
        out['status']='POSITIVE_CONTROL_'+control['status'];ready.save(output,out);return out
    status='WITNESS_LIMIT';next_id=max([r.get('iteration',-1) for r in replay]+[-1])+1
    for step in range(args.max_witnesses):
        remaining=deadline-time.monotonic()
        if remaining<=0:status='WALL_LIMIT';break
        iteration=next_id+step
        s=cp_model.CpSolver();s.parameters.num_search_workers=1;s.parameters.random_seed=iteration+1
        s.parameters.max_time_in_seconds=min(args.local_seconds,remaining)
        lst=s.solve(local);lname=s.status_name(lst)
        if lst not in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            status='EXHAUSTED_NO_TARGET4_WITH_FIXED_CORE' if lst==cp_model.INFEASIBLE else 'LOCAL_'+lname
            out['last_local_status']=lname;out['last_local_response_stats']=s.response_stats();break
        selected=set(seed)|{b for b,v in lb.items() if s.value(v)}
        extras={r for r,v in ls.items() if s.value(v)}
        core,critical_extras,cycle=ready.critical_core(seed,selected,extras)
        completion,cb,cs,cz,cstats=build(core,target=4,local=False)
        for r in critical_extras:assert r in cs;completion.add(cs[r]==1)
        assert completion.validate()==''
        remaining=deadline-time.monotonic()
        if remaining<=0:status='WALL_LIMIT';break
        finish=cp_model.CpSolver();finish.parameters.num_search_workers=1;finish.parameters.random_seed=iteration+1
        finish.parameters.max_time_in_seconds=min(args.completion_seconds,remaining)
        cst=finish.solve(completion);cname=finish.status_name(cst)
        rec={'iteration':iteration,'local_status':lname,'local_seconds':s.wall_time,'core_blocks':sorted(core),'critical_extra_rules':sorted(critical_extras),'fourth_cycle':cycle,'completion_status':cname,'completion_seconds':finish.wall_time,'completion_branches':finish.num_branches,'completion_conflicts':finish.num_conflicts,'completion_model_stats':cstats,'no_good_added':False}
        if cst in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            allblocks=core|{b for b,v in cb.items() if finish.value(v)};allextras={r for r,v in cs.items() if finish.value(v)}
            path=H/f'{args.output_prefix}_found_{iteration}.rules.json'
            ready.export_table(path,allblocks,allextras,{'kind':'full-star target4 resumed completion','iteration':iteration,'fixed_core':sorted(seed),'source_sha256':source_sha})
            rec['certificate']=str(path)
            try:rec['direct_audit']=ready.independent_check(path,15052);status='FOUND_INDEPENDENTLY_VERIFIED'
            except Exception:rec['audit_error']=traceback.format_exc();status='FAILED_INDEPENDENT_AUDIT'
            out['records'].append(rec);break
        if cst==cp_model.INFEASIBLE:
            literals=[lb[b].Not() for b in core-seed]+[ls[r].Not() for r in critical_extras]
            assert literals;local.add_bool_or(literals);rec['no_good_added']=True
        else:
            status='COMPLETION_'+cname;out['records'].append(rec);break
        out['records'].append(rec);out['status']='RUNNING';out['seconds']=time.monotonic()-start
        out['new_completion_counts']=dict(Counter(r['completion_status'] for r in out['records']))
        out['total_proven_no_goods']=len(replay)+sum(r['no_good_added'] for r in out['records'])
        ready.save(output,out)
        if step%10==0:print('new',step+1,'iteration',iteration,cname,'replayed',len(replay),'elapsed',round(out['seconds'],2),flush=True)
    out['status']=status;out['seconds']=time.monotonic()-start
    out['new_completion_counts']=dict(Counter(r['completion_status'] for r in out['records']))
    out['total_proven_no_goods']=len(replay)+sum(r['no_good_added'] for r in out['records'])
    out['source_unchanged']=sha(source.read_bytes())==source_sha;assert out['source_unchanged']
    ready.save(output,out);return out

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--resume-source',required=True)
    p.add_argument('--output-prefix',required=True)
    p.add_argument('--wall-seconds',type=float,default=600)
    p.add_argument('--local-seconds',type=float,default=10)
    p.add_argument('--completion-seconds',type=float,default=15)
    p.add_argument('--max-witnesses',type=int,default=10000)
    p.add_argument('--prepare-only',action='store_true')
    a=p.parse_args()
    if a.prepare_only:
        result=prepare_source(a.resume_source)
        print('RESUME_PREPARED_NO_SOLVE','replayed',len(result[10]),'source_sha',result[12],'model_validation',result[5].validate(),flush=True)
    else:
        out=run(a);print(out['status'],out.get('new_completion_counts'),out.get('total_proven_no_goods'),out.get('seconds'),flush=True)
if __name__=='__main__':main()
