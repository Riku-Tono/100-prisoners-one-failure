"""Locate Claude-strict cores that have no Codex local-CP record: which Codex seed indices / closure methods."""
import json, glob, sys, os
from collections import Counter
sys.path.insert(0, '..')
from c3_model import G36, apply_perm
import completion_dlx_recheck as C
from c3_compare_cores import core_hash_rules, mine, codex_exh, fr
G = G36()
def canon_seed(blocks):
    best = None
    for g in G:
        key = tuple(sorted(tuple(sorted(apply_perm(g, tuple(r)) for r in b)) for b in blocks))
        if best is None or key < best: best = key
    return best
mys = json.load(open('c3_seeds.json'))['pair_seeds']
my_index = {tuple(tuple(map(tuple, b)) for b in s): i for i, s in enumerate(mys)}
theirs = json.load(open('../witness_pair_seeds.json'))['seeds']
t2m = {}
for k, s in enumerate(theirs):
    t2m[k] = my_index[canon_seed([C.RULES[b] for b in s['blocks']])]
m2t = {v: k for k, v in t2m.items()}
assert len(m2t) == 913
missing_by_seed = Counter()
for k, v in mine.items():
    for h, types, strict, st, nodes in v['core_list']:
        if strict and h not in codex_exh: missing_by_seed[int(k)] += 1
rows = []
for mk, n in sorted(missing_by_seed.items()):
    tk = m2t[mk]
    rows.append({'claude_seed': mk, 'codex_seed': tk, 'missing_cores': n, 'codex_method': fr['closed'][str(tk)]['method'],
                 'claude_cores_in_seed': mine[str(mk)]['cores']})
meth = Counter(r['codex_method'] for r in rows)
reduced_seeds = sorted(int(k) for k, v in fr['closed'].items() if v['method'] == 'reduced CP-SAT')
cores_in_reduced = sum(mine[str(t2m[k])]['cores'] for k in reduced_seeds)
res = {'missing_total': sum(missing_by_seed.values()), 'seeds_with_missing': len(rows), 'by_codex_method': dict(meth),
       'codex_reduced_seed_indices': reduced_seeds, 'claude_cores_inside_codex_reduced_seeds': cores_in_reduced,
       'rows_not_reduced': [r for r in rows if r['codex_method'] != 'reduced CP-SAT']}
json.dump(res, open('c3_compare_cores2.json', 'w'), indent=1)
print(json.dumps(res, indent=1))
