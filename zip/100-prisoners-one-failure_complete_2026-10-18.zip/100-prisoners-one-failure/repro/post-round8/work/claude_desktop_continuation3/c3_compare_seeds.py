"""Claude continuation3: compare Codex seed files with Claude's independently generated seeds,
by actual rule content (block ids translated through Codex's RULES only as data).
Run inside work/claude_desktop_continuation3 on the device."""
import json, hashlib, sys
sys.path.insert(0, '..')
from c3_model import G36, apply_perm
G = G36()
def canon(blocks):
    best = None
    for g in G:
        key = tuple(sorted(tuple(sorted(apply_perm(g, tuple(r)) for r in b)) for b in blocks))
        if best is None or key < best: best = key
    return best
def h(lst): return hashlib.sha256(json.dumps([[list(map(list, b)) for b in s] for s in lst]).encode()).hexdigest()
import completion_dlx_recheck as C
pairs = json.load(open('../witness_pair_seeds.json'))['seeds']
pc = sorted(set(canon([C.RULES[b] for b in s['blocks']]) for s in pairs))
tri = json.load(open('../agent_seed_triangles.json'))['seeds']
tc = sorted(set(canon(s['rules']) for s in tri))
# also check triangle block_ids agree with their rules
tri_ids_ok = all(sorted(map(sorted, ([tuple(r) for r in C.RULES[b]] for b in s['block_ids']))) == sorted(map(sorted, ([tuple(r) for r in blk] for blk in s['rules']))) for s in tri)
res = {'codex_pair_seeds': len(pairs), 'codex_pair_distinct_orbits': len(pc), 'codex_pair_canon_sha256': h(pc),
       'claude_pair_canon_sha256': 'dd5d1709b3059f14f8a1a82e8012db42a3ac946a8caf8d05bb5380023e2035fd',
       'codex_tri_seeds': len(tri), 'codex_tri_distinct_orbits': len(tc), 'codex_tri_canon_sha256': h(tc),
       'claude_tri_canon_sha256': '96278282c43e7d005f287605ddcf5172c93f1e1f94fcabd0e3d5a238efcd20dc',
       'codex_tri_block_ids_match_rules': tri_ids_ok}
res['pair_match'] = res['codex_pair_canon_sha256'] == res['claude_pair_canon_sha256']
res['tri_match'] = res['codex_tri_canon_sha256'] == res['claude_tri_canon_sha256']
json.dump(res, open('c3_compare_seeds.json', 'w'), indent=1)
print(json.dumps(res, indent=1))
