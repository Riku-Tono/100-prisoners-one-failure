"""Claude continuation3: independent model generator (written from scratch).

Conventions (independent re-derivation):
  box i contains card p(i).  A directed cycle (x0,...,x_{L-1}) means p(x_k)=x_{k+1}.
  Prisoner x_k sees x_{k+1},x_{k+2},x_{k+3} in his first three boxes and needs box x_{k-1}.
  rule = (a,b,c,d,t): prisoner a, after seeing b,c,d, opens t.
  word(rule) = directed 4-cycle (a,b,c,d) up to rotation  -> the CF-loss word.
  Each rule with t not in {a,b,c,d} is correct for exactly the 5-cycle (t,a,b,c,d).
  CF wins are preserved (<=1 failure) iff (i) every word carries at most one
  deviating rule and (ii) for every complementary pair of 4-sets at most one side
  carries deviating rules.  An orientation chooses the side ("active support").
"""
from itertools import permutations, combinations

ALL = frozenset(range(1, 9))


def rotmin(c):
    c = tuple(c)
    return min(c[k:] + c[:k] for k in range(len(c)))


def cyc_rules(c):
    """correct rules of directed cycle c (any length >=5)."""
    n = len(c)
    return tuple((c[k], c[(k + 1) % n], c[(k + 2) % n], c[(k + 3) % n], c[(k - 1) % n]) for k in range(n))


def word(r):
    return rotmin(r[:4])


def fivecycle(r):
    return rotmin((r[4],) + r[:4])


def directed_cycles(elems):
    elems = sorted(elems)
    first = elems[0]
    for p in permutations(elems[1:]):
        yield (first,) + p


def canon_cycle(c):
    return rotmin(c)


def apply_perm(g, obj):
    """g: dict label->label. obj: tuple/frozenset nested of ints."""
    if isinstance(obj, int):
        return g[obj]
    if isinstance(obj, frozenset):
        return frozenset(apply_perm(g, x) for x in obj)
    return tuple(apply_perm(g, x) for x in obj)


class Orientation:
    def __init__(self, active_sets, universe=ALL):
        """active_sets: iterable of 4-sets (one per complementary pair, or a subset)."""
        self.active = frozenset(frozenset(s) for s in active_sets)
        for s in self.active:
            assert ALL - s not in self.active, 'both sides of a complementary pair active'
        self.words = sorted({rotmin(w) for s in self.active for w in permutations(sorted(s))})
        self.wordset = set(self.words)
        # all admissible blocks: 5-cycle minus one rule, all 4 words active
        blocks = []
        for Y in combinations(sorted(ALL), 5):
            for c in directed_cycles(Y):
                rs = cyc_rules(c)
                for skip in range(5):
                    kept = tuple(sorted(rs[:skip] + rs[skip + 1:]))
                    if all(word(r) in self.wordset for r in kept):
                        blocks.append(kept)
        self.blocks = sorted(set(blocks))
        self.block_words = [frozenset(word(r) for r in b) for b in self.blocks]
        assert all(len(w) == 4 for w in self.block_words)


def standard3flip():
    sets = [frozenset(s) for s in combinations(range(1, 8), 4)]
    rem = {frozenset(x) for x in ((1, 2, 3, 4), (1, 2, 3, 5), (1, 2, 3, 6))}
    sets = [s for s in sets if s not in rem] + [ALL - s for s in rem]
    return sets


def G36():
    out = []
    for p in permutations((1, 2, 3)):
        for q in permutations((4, 5, 6)):
            g = {1: p[0], 2: p[1], 3: p[2], 4: q[0], 5: q[1], 6: q[2], 7: 7, 8: 8}
            out.append(g)
    return out


def stabilizer(active_sets, labels=range(1, 9)):
    """all permutations of 1..8 preserving the active set family (brute force 40320)."""
    A = frozenset(frozenset(s) for s in active_sets)
    res = []
    for p in permutations(range(1, 9)):
        g = dict(zip(range(1, 9), p))
        if all(frozenset(g[x] for x in s) in A for s in A):
            res.append(g)
    return res
