"""Claude continuation3: independent structural checks for the standard three-flip orientation.
No import of earlier research code. Output: c3_basic_checks.json
"""
import json, time
from itertools import combinations, permutations
from collections import Counter, defaultdict
from c3_model import *

t0 = time.time()
out = {}
O = Orientation(standard3flip())
out['active_words'] = len(O.words)
out['admissible_blocks_total'] = len(O.blocks)
four567 = frozenset((4, 5, 6, 7))
F = {frozenset(x) for x in ((1, 2, 3, 4), (1, 2, 3, 5), (1, 2, 3, 6), (4, 5, 6, 7))}

def kind(b):
    ws = [frozenset(r[:4]) for r in b]
    n8 = sum(8 in s for s in ws)
    n4567 = sum(s == four567 for s in ws)
    return (n8, n4567)

kinds = Counter(kind(b) for b in O.blocks)
out['block_kinds_(n8words,n4567words)'] = {str(k): v for k, v in kinds.items()}
newblocks = [b for b in O.blocks if kind(b)[0] > 0]
out['every_8word_block_on_45678_with_3x8_1x4567'] = all(
    set(x for r in b for x in r) == {4, 5, 6, 7, 8} and kind(b) == (3, 1) for b in newblocks)
# old problem
oldwords = sorted(w for w in O.words if frozenset(w) not in F and 8 not in w)
oldblocks = [b for b in O.blocks if all(frozenset(r[:4]) not in F and 8 not in r[:4] for r in b)]
out['old_words'] = len(oldwords)
out['old_blocks'] = len(oldblocks)

# new-side covers: 6 blocks exactly covering 24 special words
special = sorted(w for w in O.words if 8 in w or frozenset(w) == four567)
assert len(special) == 24
nb_words = [frozenset(word(r) for r in b) for b in newblocks]
covers = []
def rec(chosen, covered):
    if len(covered) == 24:
        covers.append(tuple(chosen)); return
    w = min(set(special) - covered)
    for i, ws in enumerate(nb_words):
        if w in ws and not (ws & covered):
            rec(chosen + [i], covered | ws)
rec([], frozenset())
out['new_side_exact_covers'] = len(set(frozenset(c) for c in covers))

# stabilizer of the orientation in S8
stab = stabilizer(standard3flip())
g36 = G36()
out['stabilizer_order'] = len(stab)
out['stabilizer_equals_G36'] = sorted(tuple(sorted(g.items())) for g in stab) == sorted(tuple(sorted(g.items())) for g in g36)

# R8=0: for every directed 8-cycle, number of correct rules on active words
active = O.active
mx8 = 0
for c in directed_cycles(range(1, 9)):
    n = sum(frozenset(r[:4]) in active for r in cyc_rules(c))
    mx8 = max(mx8, n)
out['max_active_correct_rules_8cycle'] = mx8

# 8-containing 6/7-cycles: a correct rule can be present only if its word is active and
# (word contains 8 -> rule belongs to a 45678 new block, i.e. 5-set == 45678) [blocks],
# or it is an extra on an old spare word (word without 8, in old support).
def suppliable(r):
    s = frozenset(r[:4])
    if s not in active: return False
    if 8 in s or s == four567:
        return set(r) == {4, 5, 6, 7, 8}   # only new-side block rules live on special words
    return True
mx = {}
for L in (6, 7):
    m = 0
    for S in combinations(range(1, 9), L):
        if 8 not in S: continue
        for c in directed_cycles(S):
            m = max(m, sum(suppliable(r) for r in cyc_rules(c)))
    mx[L] = m
out['max_suppliable_correct_rules_8containing'] = {'6cycle(need5)': mx[6], '7cycle(need6)': mx[7]}
# without the 45678 restriction (active words only)
mxa = {}
for L in (6, 7):
    m = 0
    for S in combinations(range(1, 9), L):
        if 8 not in S: continue
        for c in directed_cycles(S):
            m = max(m, sum(frozenset(r[:4]) in active for r in cyc_rules(c)))
    mxa[L] = m
out['max_active_correct_rules_8containing_no_block_restriction'] = mxa
# 5-cycles containing 8 other than on 45678: max suppliable
m5 = 0
for S in combinations(range(1, 9), 5):
    if 8 not in S or set(S) == {4, 5, 6, 7, 8}: continue
    for c in directed_cycles(S):
        m5 = max(m5, sum(suppliable(r) for r in cyc_rules(c)))
out['max_suppliable_rules_8containing_5cycle_not_45678(need4)'] = m5

# shared correct rules between distinct 7-cycles (all 7-sets of [8]) and 6/7 mixes
cyc7 = [c for S in combinations(range(1, 9), 7) for c in directed_cycles(S)]
by_rule = defaultdict(list)
for i, c in enumerate(cyc7):
    for r in cyc_rules(c): by_rule[r].append(i)
pair_count = Counter()
for r, lst in by_rule.items():
    for i, j in combinations(lst, 2): pair_count[(i, j)] += 1
out['seven_cycles_total'] = len(cyc7)
out['max_shared_correct_rules_between_distinct_7cycles'] = max(pair_count.values())
out['rules_correct_for_k_7cycles_on_[7]'] = dict(Counter(
    sum(1 for i in lst if 8 not in cyc7[i]) for lst in by_rule.values()))
out['seconds'] = round(time.time() - t0, 2)
json.dump(out, open('c3_basic_checks.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
