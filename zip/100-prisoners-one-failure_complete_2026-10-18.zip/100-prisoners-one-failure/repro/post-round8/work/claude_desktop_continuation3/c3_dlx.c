/* Claude continuation3: independent exact-cover completion solver (Dancing Links, Knuth Alg. X).
 * Written from scratch; no code shared with earlier research scripts.
 *
 * stdin:
 *   NW NB NS
 *   NB lines: w0 w1 w2 w3 k s_1 ... s_k      (block = 4 word columns, k six-cycle ids)
 *   then any number of cases:
 *   CASE <id> <nfixed> b... <nholes> w... <budget> <sixlimit> <nodelimit> <ninit> s...
 *     fixed blocks are forced; hole words are removed (must stay uncovered, rows touching them removed);
 *     budget = number of further words that may be left uncovered (chosen by the search);
 *     sixlimit: every six-cycle count must stay <= sixlimit (use 99 to disable);
 *     ninit six-cycle ids are pre-incremented (extras' contributions).
 *     nodelimit 0 = unlimited.
 * stdout per case: <id> FOUND|EXHAUSTED|NODELIMIT|FIXED_CONFLICT nodes [blocks of solution]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXW 512
#define MAXB 8192
#define MAXS 4096
static int NW, NB, NS;
static int bw[MAXB][4];
static int bk[MAXB];
static int bs[MAXB][16];
/* DLX structures */
static int L[MAXW + 1 + MAXB * 4], R[MAXW + 1 + MAXB * 4], U[MAXW + 1 + MAXB * 4], D[MAXW + 1 + MAXB * 4], C[MAXW + 1 + MAXB * 4], ROW[MAXW + 1 + MAXB * 4];
static int S[MAXW + 1];
static int rowfirst[MAXB];
static int six[MAXS];
static int sixlimit;
static long long nodes, nodelimit;
static int budget;
static int sol[256], nsol;
static int holes_chosen[64], nholes_chosen;
static int col_active[MAXW + 1];

static void build(void) {
    int n = NW;
    for (int c = 0; c <= n; c++) { L[c] = c - 1; R[c] = c + 1; U[c] = D[c] = c; C[c] = c; S[c] = 0; ROW[c] = -1; }
    L[0] = n; R[n] = 0;
    int k = n + 1;
    for (int b = 0; b < NB; b++) {
        int first = k;
        rowfirst[b] = first;
        for (int j = 0; j < 4; j++) {
            int c = bw[b][j] + 1;
            C[k] = c; ROW[k] = b;
            U[k] = U[c]; D[k] = c; D[U[c]] = k; U[c] = k; S[c]++;
            L[k] = (j == 0) ? first + 3 : k - 1;
            R[k] = (j == 3) ? first : k + 1;
            k++;
        }
    }
    for (int c = 1; c <= n; c++) col_active[c] = 1;
}
static void cover(int c) {
    L[R[c]] = L[c]; R[L[c]] = R[c]; col_active[c] = 0;
    for (int i = D[c]; i != c; i = D[i])
        for (int j = R[i]; j != i; j = R[j]) { U[D[j]] = U[j]; D[U[j]] = D[j]; S[C[j]]--; }
}
static void uncover(int c) {
    for (int i = U[c]; i != c; i = U[i])
        for (int j = L[i]; j != i; j = L[j]) { S[C[j]]++; U[D[j]] = j; D[U[j]] = j; }
    L[R[c]] = c; R[L[c]] = c; col_active[c] = 1;
}
static int six_ok(int b) {
    for (int j = 0; j < bk[b]; j++) if (six[bs[b][j]] + 1 > sixlimit) return 0;
    return 1;
}
static void six_add(int b, int d) { for (int j = 0; j < bk[b]; j++) six[bs[b][j]] += d; }

/* returns 1 found, 0 exhausted, -1 node limit */
static int search(void) {
    nodes++;
    if (nodelimit && nodes > nodelimit) return -1;
    if (R[0] == 0) return 1;
    int c = -1, best = 1 << 30;
    for (int j = R[0]; j != 0; j = R[j]) {
        /* count rows that are six-feasible */
        int cnt = 0;
        for (int i = D[j]; i != j; i = D[i]) if (six_ok(ROW[i])) cnt++;
        if (cnt < best) { best = cnt; c = j; if (cnt == 0) break; }
    }
    if (best == 0 && budget == 0) return 0;
    cover(c);
    for (int i = D[c]; i != c; i = D[i]) {
        int b = ROW[i];
        if (!six_ok(b)) continue;
        six_add(b, 1); sol[nsol++] = b;
        for (int j = R[i]; j != i; j = R[j]) cover(C[j]);
        int res = search();
        for (int j = L[i]; j != i; j = L[j]) uncover(C[j]);
        if (res == 1) { uncover(c); return 1; }
        nsol--; six_add(b, -1);
        if (res == -1) { uncover(c); return -1; }
    }
    if (budget > 0) { /* leave column c uncovered */
        budget--; holes_chosen[nholes_chosen++] = c - 1;
        int res = search();
        if (res == 1) { uncover(c); return 1; }
        nholes_chosen--; budget++;
        if (res == -1) { uncover(c); return -1; }
    }
    uncover(c);
    return 0;
}

int main(void) {
    if (scanf("%d %d %d", &NW, &NB, &NS) != 3) return 1;
    for (int b = 0; b < NB; b++) {
        for (int j = 0; j < 4; j++) scanf("%d", &bw[b][j]);
        scanf("%d", &bk[b]);
        for (int j = 0; j < bk[b]; j++) scanf("%d", &bs[b][j]);
    }
    build();
    char tag[16];
    while (scanf("%15s", tag) == 1) {
        if (strcmp(tag, "CASE") != 0) break;
        long long id; int nf, nh, ninit; int fixed[256], hw[64];
        scanf("%lld %d", &id, &nf);
        for (int i = 0; i < nf; i++) scanf("%d", &fixed[i]);
        scanf("%d", &nh);
        for (int i = 0; i < nh; i++) scanf("%d", &hw[i]);
        scanf("%d %d %lld %d", &budget, &sixlimit, &nodelimit, &ninit);
        memset(six, 0, sizeof(int) * NS);
        for (int i = 0; i < ninit; i++) { int s; scanf("%d", &s); six[s]++; }
        nodes = 0; nsol = 0; nholes_chosen = 0;
        /* apply holes and fixed rows; record covered columns to undo */
        int stack[MAXW + 1], ns = 0, conflict = 0;
        for (int i = 0; i < nh && !conflict; i++) {
            int c = hw[i] + 1;
            if (!col_active[c]) { conflict = 1; break; }
            cover(c); stack[ns++] = c;
        }
        for (int i = 0; i < nf && !conflict; i++) {
            int b = fixed[i];
            for (int j = 0; j < 4; j++) if (!col_active[bw[b][j] + 1]) conflict = 1;
            if (conflict) break;
            for (int j = 0; j < 4; j++) { int c = bw[b][j] + 1; cover(c); stack[ns++] = c; }
            six_add(b, 1);
        }
        for (int s = 0; s < NS && !conflict; s++) if (six[s] > sixlimit) conflict = 1;
        int res = 0;
        if (!conflict) res = search();
        while (ns > 0) uncover(stack[--ns]);
        if (conflict) printf("%lld FIXED_CONFLICT 0\n", id);
        else if (res == 1) {
            printf("%lld FOUND %lld", id, nodes);
            for (int i = 0; i < nsol; i++) printf(" %d", sol[i]);
            printf(" H");
            for (int i = 0; i < nholes_chosen; i++) printf(" %d", holes_chosen[i]);
            printf("\n");
        } else if (res == 0) printf("%lld EXHAUSTED %lld\n", id, nodes);
        else printf("%lld NODELIMIT %lld\n", id, nodes);
        fflush(stdout);
    }
    return 0;
}
