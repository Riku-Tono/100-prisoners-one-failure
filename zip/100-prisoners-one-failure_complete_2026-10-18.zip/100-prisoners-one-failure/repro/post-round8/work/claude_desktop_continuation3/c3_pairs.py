"""Claude continuation3: independent exhaustive re-verification of all 913 witness-pair seed orbits
(standard three-flip, R5=52, R6=0, R7>=4), without CP-SAT.

For each seed S (12 fixed blocks, two block-rescued [7]-seven-cycles) enumerate EVERY local option
for a newly rescued seven-cycle X:
  A-option: one extra r (correct for X, on an old word not covered by S) + the other correct rules of X
            except one (5 rules) supplied by old blocks compatible with S and avoiding word(r);
  B-option: two extras r,s (both correct for X) + 4 further correct rules of X from compatible blocks.
Cores = S + blocks of two compatible options (X != Y) using at most two extra rules in total:
  A(r)+A(s) [distinct words], A(r)+A(r) [same extra; second hole free], B(r,s)+A(r|s), B(r,s)+B(r,s).
(By the verified lemmas only A(r)+A(s) can occur; the others are included for robustness.)
Every core is completed by exhaustive Dancing Links over all 1584 old blocks to exactly the
remaining old words, with the extra words as holes, and every [7]-six-cycle count <= 4 (R6=0).
"""
import json, sys, time
from collections import Counter, defaultdict
from c3_old import *
from c3_dlxrun import run_cases

def seed_ids(s): return [BIDX[tuple(sorted(tuple(r) for r in b))] for b in s]

def compatible_with(blockset, used_words, S):
    return True

def enum_options(S):
    Sset = set(S)
    U = set().union(*(BWS[b] for b in S)); Srules = set().union(*(BRULES[b] for b in S))
    rule_seed_block = {r: b for b in S for r in BRULES[b]}
    base = [i for i, rs in enumerate(R7) if sum(r in Srules for r in rs) >= 6]
    optsA = set(); optsB = set()
    def fill(rs, idx, holes):
        """all block sets supplying rs[i] for i in idx, compatible with S, avoiding hole word set."""
        cands = []
        for i in idx:
            q = rs[i]
            if q in rule_seed_block:
                cands.append([rule_seed_block[q]]); continue
            cl = [b for b in blocks_with_rule[q] if not (BWS[b] & U) and not (BWS[b] & holes)]
            if not cl: return []
            cands.append(cl)
        out = []
        def rec(k, chosen, used):
            if k == len(cands): out.append(frozenset(chosen)); return
            for b in cands[k]:
                if b in Sset or b in chosen: rec(k + 1, chosen, used); continue
                if BWS[b] & used: continue
                rec(k + 1, chosen | {b}, used | BWS[b])
        rec(0, frozenset(), frozenset())
        return out
    for xi, rs in enumerate(R7):
        if xi in base: continue
        ok_ex = [i for i in range(7) if word(rs[i]) in OLDWSET and WIDX[word(rs[i])] not in U]
        for ir in ok_ex:
            hr = frozenset([WIDX[word(rs[ir])]])
            for g in range(7):
                if g == ir: continue
                for bset in fill(rs, [i for i in range(7) if i not in (ir, g)], hr):
                    optsA.add((xi, rs[ir], bset))
        for ir in ok_ex:
            for js in ok_ex:
                if js <= ir: continue
                if word(rs[ir]) == word(rs[js]): continue
                hrs = frozenset([WIDX[word(rs[ir])], WIDX[word(rs[js])]])
                for g in range(7):
                    if g in (ir, js): continue
                    for bset in fill(rs, [i for i in range(7) if i not in (ir, js, g)], hrs):
                        optsB.add((xi, frozenset([rs[ir], rs[js]]), bset))
    return base, sorted(optsA, key=str), sorted(optsB, key=str)

def blocks_compatible(A, B):
    for a in A:
        for b in B:
            if a != b and (BWS[a] & BWS[b]): return False
    return True

def words_of(bs):
    return set().union(*(BWS[b] for b in bs)) if bs else set()

def make_cores(S, optsA, optsB, base):
    """returns dict key=(fixed, extras, budget) -> {'holes':..., 'types': set, 'strict': bool}"""
    cores = {}
    Srules = set().union(*(BRULES[b] for b in S))
    def add(fixed, extras, budget, typ, strict):
        holes = frozenset(WIDX[word(r)] for r in extras)
        key = (frozenset(fixed), frozenset(extras), budget)
        e = cores.setdefault(key, {'holes': holes, 'types': set(), 'strict': False})
        e['types'].add(typ); e['strict'] = e['strict'] or strict
    def is_strict(X, r, Y, s, fixed):
        CR = set().union(*(BRULES[b] for b in fixed))
        if sum(q in CR for q in R7[X]) != 5 or sum(q in CR for q in R7[Y]) != 5: return False
        if s in R7[X] or r in R7[Y]: return False
        for zi, rs in enumerate(R7):
            if zi in base: continue
            if sum(q in CR for q in rs) > 5: return False
        return True
    for i in range(len(optsA)):
        X, r, bx = optsA[i]; wx = words_of(bx)
        for j in range(i + 1, len(optsA)):
            Y, s, by = optsA[j]
            if X == Y: continue
            if not blocks_compatible(bx, by): continue
            wy = words_of(by)
            if r == s:
                if WIDX[word(r)] in wy or WIDX[word(r)] in wx: continue
                add(set(S) | bx | by, {r}, 1, 'AA_same_extra', False); continue
            if word(r) == word(s): continue
            if WIDX[word(r)] in wy or WIDX[word(s)] in wx: continue
            fixed = set(S) | bx | by
            add(fixed, {r, s}, 0, 'AA', is_strict(X, r, Y, s, fixed))
    for i in range(len(optsB)):
        X, ex, bx = optsB[i]; wx = words_of(bx)
        exw = {WIDX[word(r)] for r in ex}
        for (Y, s, by) in optsA:
            if X == Y or s not in ex: continue
            if not blocks_compatible(bx, by) or (words_of(by) & exw): continue
            add(set(S) | bx | by, set(ex), 0, 'BA', False)
        for j in range(i + 1, len(optsB)):
            Y, ey, by = optsB[j]
            if X == Y or ey != ex: continue
            if not blocks_compatible(bx, by) or (words_of(by) & exw): continue
            add(set(S) | bx | by, set(ex), 0, 'BB', False)
    return cores

GG = G36()
def core_hash(fixed, extras):
    best = None
    for g in GG:
        key = (tuple(sorted(tuple(sorted(apply_perm(g, r) for r in BLOCKS[b])) for b in fixed)),
               tuple(sorted(apply_perm(g, r) for r in extras)))
        if best is None or key < best: best = key
    import hashlib
    return hashlib.sha1(repr(best).encode()).hexdigest()[:16]

def six_init(extras):
    return [s for r in extras for s in six_with_rule[r]]

def process(lo, hi, outpath):
    seeds = json.load(open('c3_seeds.json'))['pair_seeds']
    records = {}
    t0 = time.time()
    for k in range(lo, min(hi, len(seeds))):
        S = seed_ids(seeds[k])
        base, optsA, optsB = enum_options(S)
        cores = make_cores(S, optsA, optsB, base)
        cases = []; pre = Counter(); keys = list(cores)
        for ci, key in enumerate(keys):
            fixed, extras, budget = key
            holes = cores[key]['holes']
            cases.append({'id': ci, 'fixed': sorted(fixed), 'holes': sorted(holes), 'budget': budget,
                          'sixlimit': 4, 'init': six_init(extras)})
        out = run_cases(cases) if cases else {}
        st = Counter(v[0] for v in out.values())
        found = []
        for ci, v in out.items():
            if v[0] == 'FOUND':
                fixed, extras, budget = keys[ci]
                found.append({'blocks': [list(map(list, BLOCKS[b])) for b in sorted(set(fixed) | set(v[2]))],
                              'extras': [list(r) for r in extras], 'free_holes': v[3]})
        corelist = []
        for ci, key in enumerate(keys):
            fixed, extras, budget = key
            corelist.append([core_hash(fixed, extras), sorted(cores[key]['types']), cores[key]['strict'], out[ci][0], out[ci][1]])
        records[k] = {'base_cycles': len(base), 'optsA': len(optsA), 'optsB': len(optsB), 'cores': len(cores),
                      'status': dict(st), 'nodes': sum(v[1] for v in out.values()), 'found': found, 'core_list': corelist}
        if k % 50 == 0:
            print(k, records[k]['optsA'], records[k]['optsB'], records[k]['cores'], dict(st), round(time.time() - t0, 1), flush=True)
    json.dump({'range': [lo, hi], 'records': records, 'seconds': round(time.time() - t0, 2)}, open(outpath, 'w'))

if __name__ == '__main__':
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    process(lo, hi, sys.argv[3])
