"""Claude continuation3: independent witness / edge / triangle / orbit generation
for the old part (46 blocks on 186 old words) of the standard three-flip orientation.
Writes c3_witness.json (summary) and c3_seeds.json (canonical seeds, rule-level).
"""
import json, time, hashlib
from itertools import combinations, product
from collections import Counter, defaultdict
from c3_model import *

t0 = time.time()
O = Orientation(standard3flip())
F = {frozenset(x) for x in ((1, 2, 3, 4), (1, 2, 3, 5), (1, 2, 3, 6), (4, 5, 6, 7))}
OLDW = set(w for w in O.words if frozenset(w) not in F and 8 not in w)
BLOCKS = [b for b in O.blocks if all(word(r) in OLDW for r in b)]
assert len(BLOCKS) == 1584 and len(OLDW) == 186
BW = [frozenset(word(r) for r in b) for b in BLOCKS]
BIDX = {b: i for i, b in enumerate(BLOCKS)}
blocks_with_rule = defaultdict(list)
for i, b in enumerate(BLOCKS):
    for r in b: blocks_with_rule[r].append(i)

CYC7 = list(directed_cycles(range(1, 8)))
assert len(CYC7) == 720

def disjoint_ok(ids):
    seen = set()
    for i in ids:
        if BW[i] & seen: return False
        seen |= BW[i]
    return True

witnesses = []   # (cycle_index, frozenset(block ids), failure window)
for ci, c in enumerate(CYC7):
    rs = cyc_rules(c)
    for f in range(7):
        need = [rs[k] for k in range(7) if k != f]
        cands = [blocks_with_rule[r] for r in need]
        if any(not x for x in cands): continue
        def rec(k, chosen, used):
            if k == len(need):
                witnesses.append((ci, frozenset(chosen), f)); return
            for b in cands[k]:
                if BW[b] & used: continue
                rec(k + 1, chosen + [b], used | BW[b])
        rec(0, [], frozenset())
wit_cycles = sorted(set(w[0] for w in witnesses))
# distinct (cycle, blockset)
assert len(set((w[0], w[1]) for w in witnesses)) == len(witnesses)

def compatible(A, B):
    for a in A:
        for b in B:
            if a != b and (BW[a] & BW[b]): return False
    return True

W = witnesses
nW = len(W)
adj = [set() for _ in range(nW)]
for i in range(nW):
    for j in range(i + 1, nW):
        if W[i][0] != W[j][0] and compatible(W[i][1], W[j][1]):
            adj[i].add(j); adj[j].add(i)
edges = [(i, j) for i in range(nW) for j in adj[i] if j > i]
tris = [(i, j, k) for (i, j) in edges for k in adj[i] & adj[j] if k > j and len({W[i][0], W[j][0], W[k][0]}) == 3]

G = G36()
def block_image(g, b):
    return tuple(sorted(apply_perm(g, r) for r in BLOCKS[b]))
def canon_union(ids):
    best = None
    for g in G:
        key = tuple(sorted(block_image(g, b) for b in ids))
        if best is None or key < best: best = key
    return best

pair_unions = Counter()
pair_union_keys = {}
for (i, j) in edges:
    u = W[i][1] | W[j][1]
    pair_unions[frozenset(u)] += 1
pair_orbits = defaultdict(list)
for u in pair_unions:
    pair_orbits[canon_union(u)].append(u)
tri_unions = Counter(frozenset(W[i][1] | W[j][1] | W[k][1]) for (i, j, k) in tris)
tri_orbits = defaultdict(list)
for u in tri_unions:
    tri_orbits[canon_union(u)].append(u)

summary = {
    'old_blocks': len(BLOCKS), 'old_words': len(OLDW),
    'cycles_with_witness': len(wit_cycles), 'witnesses': nW,
    'witnesses_by_failure_window_count_per_cycle': dict(Counter(Counter(w[0] for w in W).values())),
    'compatible_edges': len(edges), 'distinct_pair_unions': len(pair_unions),
    'pair_union_orbits': len(pair_orbits),
    'pair_orbit_size_hist': dict(Counter(len(v) for v in pair_orbits.values())),
    'pair_union_block_count_hist': dict(Counter(len(k) for k in pair_orbits)),
    'raw_triangles': len(tris), 'distinct_triangle_unions': len(tri_unions),
    'triangle_union_orbits': len(tri_orbits),
    'triangle_union_block_count_hist': dict(Counter(len(k) for k in tri_orbits)),
}
pair_seeds = sorted(pair_orbits)
tri_seeds = sorted(tri_orbits)
blob = json.dumps({'pair_seeds': [[list(map(list, b)) for b in s] for s in pair_seeds],
                   'triangle_seeds': [[list(map(list, b)) for b in s] for s in tri_seeds]})
summary['seed_file_sha256'] = hashlib.sha256(blob.encode()).hexdigest()
summary['seconds'] = round(time.time() - t0, 2)
open('c3_seeds.json', 'w').write(blob)
json.dump(summary, open('c3_witness.json', 'w'), indent=1)
print(json.dumps(summary, indent=1))
