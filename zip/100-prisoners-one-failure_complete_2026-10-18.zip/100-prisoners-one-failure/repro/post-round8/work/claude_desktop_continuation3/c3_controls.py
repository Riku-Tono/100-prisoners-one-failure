"""Positive controls for c3_dlx on the known new15051 table (standard three-flip)."""
import json, random, time
from collections import defaultdict, Counter
from c3_old import *
from c3_dlxrun import run_cases
import os
P = '../inputs/new15051.rules.json' if os.path.exists('../inputs/new15051.rules.json') else 'inputs_copy/inputs/new15051.rules.json'
d = json.load(open(P, encoding='utf-8-sig'))
rules = [tuple([a, b, c, dd, t]) for a, (b, c, dd), t in d['rules']]
groups = defaultdict(set)
for r in rules: groups[fivecycle(r)].add(r)
old_blocks = []; other = []
for k, g in groups.items():
    if 8 not in k and len(g) >= 4 and all(word(r) in OLDWSET for r in g):
        if len(g) == 4: old_blocks.append(BIDX[tuple(sorted(g))])
        else: other.append((k, sorted(g)))
    else: other.append((k, sorted(g)))
used = set().union(*(BWS[b] for b in old_blocks))
spare = sorted(set(range(len(OLDW))) - used)
blockrules = set().union(*(BRULES[b] for b in old_blocks))
six_blocks_only = Counter(s for r in blockrules for s in six_with_rule[r])
res = {'old_blocks_found': len(old_blocks), 'spare_old_words': [OLDW[w] for w in spare],
       'other_groups': [(list(k), [list(x) for x in g]) for k, g in other if len(g) != 4 or 8 not in k][:6],
       'max_six_count_blocks_only': max(six_blocks_only.values()),
       'base_rescued_7cycles_blocks_only': sum(1 for rs in R7 if sum(r in blockrules for r in rs) >= 6)}
random.seed(12345)
cases = [{'id': 0, 'fixed': old_blocks, 'holes': spare, 'budget': 0}]
for i in range(1, 21):
    cases.append({'id': i, 'fixed': random.sample(old_blocks, 33), 'holes': spare, 'budget': 0})
for i in range(21, 31):
    cases.append({'id': i, 'fixed': random.sample(old_blocks, 20), 'holes': [], 'budget': 2})
cases.append({'id': 31, 'fixed': [], 'holes': [], 'budget': 2, 'nodelimit': 2000000})
t = time.time(); out = run_cases(cases)
res['cases'] = {cid: (st, nodes) for cid, (st, nodes, sol, holes) in sorted(out.items())}
# check that found solutions are valid exact covers
for cid, (st, nodes, sol, holes) in out.items():
    if st == 'FOUND':
        allb = set(cases[cid]['fixed']) | set(sol)
        ws = Counter(w for b in allb for w in BWI[b])
        assert all(v == 1 for v in ws.values()) and len(allb) == 46, cid
        hs = set(range(len(OLDW))) - set(ws)
        assert hs == set(cases[cid]['holes']) | set(holes), cid
        brs = set().union(*(BRULES[b] for b in allb))
        assert max(Counter(s for r in brs for s in six_with_rule[r]).values()) <= 4
res['seconds'] = round(time.time() - t, 2)
json.dump(res, open('c3_controls.json', 'w'), indent=1)
print(json.dumps(res, indent=1, default=str))
