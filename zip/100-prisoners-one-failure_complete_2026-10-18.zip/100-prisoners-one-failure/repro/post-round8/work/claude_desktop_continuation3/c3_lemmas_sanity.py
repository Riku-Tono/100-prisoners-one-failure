"""Sanity checks for c3_lemmas.feasible (positive controls)."""
import json
from c3_lemmas import feasible, reps
from c3_old import *
wc = json.load(open('c3_witness.json'))
# 1) cycles with a 6-rule block witness: feasible(6 rules) must hold for exactly the witness cycles (144)
n = 0
for rs in R7:
    if any(feasible(set(rs[:g] + rs[g+1:]), frozenset()) for g in range(7)): n += 1
# 2) single-cycle new rescue (5 block rules + r) should be locally feasible for many r
m = 0; tot = 0
for r in reps:
    wr = WIDX[word(r)]
    for ci in seven_with_rule[r]:
        others = [q for q in R7[ci] if q != r]
        tot += 1
        if any(feasible(set(others[:g] + others[g+1:]), frozenset([wr])) for g in range(6)): m += 1
res = {'cycles_with_6rule_local_witness': n, 'expected': wc['cycles_with_witness'],
       'single_cycle_new_rescue_locally_feasible': m, 'of': tot}
print(res); json.dump(res, open('c3_lemmas_sanity.json', 'w'), indent=1)
