"""Write the old-problem exact-cover matrix for c3_dlx (186 words, 1584 blocks, 840 [7]-six-cycles)."""
from c3_old import *
def write_matrix(path='c3_matrix.txt'):
    with open(path, 'w') as f:
        f.write(f'{len(OLDW)} {len(BLOCKS)} {len(CYC6)}\n')
        for b, rules in enumerate(BLOCKS):
            ss = sorted(set(s for r in rules for s in six_with_rule[r]))
            assert len(ss) == sum(len(six_with_rule[r]) for r in rules)
            f.write(' '.join(map(str, BWI[b])) + f' {len(ss)} ' + ' '.join(map(str, ss)) + '\n')
if __name__ == '__main__':
    write_matrix(); print('ok', len(OLDW), len(BLOCKS), len(CYC6))
