"""Claude continuation3: independent direct-opening simulator (no imports from prior scripts).

Usage: python3 c3_direct_sim.py RULES.json [more.json ...]
Rule format: [a,[b,c,d],t] = prisoner a, having seen cards b,c,d in his first
three boxes (boxes a,b,c), opens box t as 4th box. Otherwise 4th box = d (cycle following).
Box i contains card perm[i]. Win iff >=7 of 8 prisoners find their own number in <=4 boxes.
Reports wins over all 40320 placements, CF losses (placements with all cycles <=4 that lose),
and rescued long-cycle counts R5..R8 normalised per directed cycle.
"""
import json, sys
from itertools import permutations
from collections import Counter

def load(path):
    d = json.load(open(path, encoding='utf-8-sig'))
    rules = {}
    for a, (b, c, dd), t in d['rules']:
        key = (a, b, c, dd)
        assert key not in rules, ('duplicate observation', key)
        rules[key] = t
    return rules

def cycles(perm):
    seen = set(); out = []
    for i in range(1, 9):
        if i in seen: continue
        cyc = []; j = i
        while j not in seen:
            seen.add(j); cyc.append(j); j = perm[j]
        out.append(len(cyc))
    return out

def evaluate(rules):
    wins = 0; cf_loss = 0; long_wins = Counter(); fails_hist = Counter()
    for p in permutations(range(1, 9)):
        perm = dict(zip(range(1, 9), p))
        ok = 0
        for a in range(1, 9):
            box = a; seen = []; found = False
            for k in range(3):
                card = perm[box]
                if card == a: found = True; break
                seen.append(card); box = card
            if not found:
                b, c, d = seen
                t = rules.get((a, b, c, d), d)
                found = (perm[t] == a)
            ok += found
        cl = cycles(perm); L = max(cl)
        win = ok >= 7
        wins += win
        if L <= 4 and not win: cf_loss += 1
        if L >= 5 and win: long_wins[L] += 1
    mult = {5: 6, 6: 2, 7: 1, 8: 1}
    R = {L: long_wins[L] // mult[L] for L in (5, 6, 7, 8)}
    assert all(long_wins[L] % mult[L] == 0 for L in (5, 6, 7, 8))
    return {'wins': wins, 'cf_losses': cf_loss, 'R5': R[5], 'R6': R[6], 'R7': R[7], 'R8': R[8],
            'formula_14736_6R5_2R6_R7_R8': 14736 + 6 * R[5] + 2 * R[6] + R[7] + R[8]}

if __name__ == '__main__':
    res = {}
    for path in sys.argv[1:]:
        rules = load(path)
        r = evaluate(rules); r['rules'] = len(rules)
        res[path] = r; print(path, r, flush=True)
    if len(sys.argv) > 1:
        json.dump(res, open('c3_direct_sim_last.json', 'w'), indent=1)
