"""Driver for c3_dlx: batch cases through one solver process."""
import subprocess, os
HERE = os.path.dirname(os.path.abspath(__file__))
def run_cases(cases, matrix=os.path.join(HERE, 'c3_matrix.txt'), exe=os.path.join(HERE, 'c3_dlx')):
    """cases: list of dict(id, fixed, holes, budget, sixlimit, nodelimit, init). returns dict id->(status,nodes,sol,holes)"""
    lines = [open(matrix).read()]
    for c in cases:
        lines.append('CASE %d %d %s %d %s %d %d %d %d %s\n' % (
            c['id'], len(c['fixed']), ' '.join(map(str, c['fixed'])), len(c['holes']), ' '.join(map(str, c['holes'])),
            c.get('budget', 0), c.get('sixlimit', 4), c.get('nodelimit', 0), len(c.get('init', [])), ' '.join(map(str, c.get('init', [])))))
    p = subprocess.run([exe], input=''.join(lines), capture_output=True, text=True, check=True)
    out = {}
    for line in p.stdout.splitlines():
        parts = line.split()
        cid, st, nodes = int(parts[0]), parts[1], int(parts[2])
        sol, holes = [], []
        if st == 'FOUND':
            k = parts.index('H'); sol = list(map(int, parts[3:k])); holes = list(map(int, parts[k + 1:]))
        out[cid] = (st, nodes, sol, holes)
    assert len(out) == len(cases), (len(out), len(cases), p.stderr[-500:])
    return out
