"""Map Codex's five nonstar survivors (and flip-family candidates if available) to Claude's capacity orbits."""
import json, itertools, sys
sys.path.insert(0, '..')
PERMS = [dict(zip(range(1, 9), p)) for p in itertools.permutations(range(1, 9))]
def canon(fam):
    return min(tuple(sorted(tuple(sorted(g[x] for x in S)) for S in fam)) for g in PERMS)
mine = json.load(open('c3_capacity_orbits_partial14.json')); Q3 = [tuple(q) for q in mine['Q3']]
def fam_of(sol): return [frozenset(q + (8,)) if sol[i] else frozenset(set(range(1, 8)) - set(q)) for i, q in enumerate(Q3)]
mk = {canon(fam_of(s)): i for i, s in enumerate(mine['solutions'])}
def from_flips(flips):
    fl = {frozenset(f) for f in flips}
    return [frozenset(set(range(1, 9)) - S) if S in fl else S for S in map(frozenset, itertools.combinations(range(1, 8), 4))]
sv = json.load(open('../canonical_orientation_five_survivors.json'))['records']
out = []
for r in sv:
    c = canon(from_flips(r['stats']['flips']))
    out.append({'codex_index': r['index'], 'status': r['status'], 'claude_orbit_index': mk.get(c)})
print(json.dumps(out))
json.dump(out, open('c3_compare_survivors.json', 'w'), indent=1)
