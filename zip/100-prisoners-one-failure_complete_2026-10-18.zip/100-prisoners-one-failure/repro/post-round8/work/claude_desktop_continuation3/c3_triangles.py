"""Claude continuation3: independent completion check of all 248 triangle seed orbits
(three block-only rescued [7]-seven-cycles). Each: fix the 18 seed blocks, allow ANY two
uncovered old words (budget 2), no R6 restriction. EXHAUSTED for all => a completed
46-block old part rescues at most two seven-cycles by block rules alone."""
import json, time
from collections import Counter
from c3_old import *
from c3_dlxrun import run_cases
seeds = json.load(open('c3_seeds.json'))['triangle_seeds']
cases = []
for i, s in enumerate(seeds):
    ids = [BIDX[tuple(sorted(tuple(r) for r in b))] for b in s]
    rs = set().union(*(BRULES[b] for b in ids))
    assert sum(1 for x in R7 if sum(r in rs for r in x) >= 6) >= 3
    cases.append({'id': i, 'fixed': ids, 'holes': [], 'budget': 2, 'sixlimit': 99})
t = time.time(); out = run_cases(cases)
st = Counter(v[0] for v in out.values())
res = {'scope': 'standard three-flip old part; 18 fixed triangle blocks + any 46-block completion with <=2 uncovered words; no R6 restriction',
       'seeds': len(seeds), 'status_counts': dict(st), 'total_nodes': sum(v[1] for v in out.values()),
       'max_nodes': max(v[1] for v in out.values()), 'seconds': round(time.time() - t, 2),
       'per_seed': {i: [v[0], v[1]] for i, v in sorted(out.items())}}
json.dump(res, open('c3_triangles.json', 'w'), indent=0)
print({k: v for k, v in res.items() if k != 'per_seed'})
