"""Claude continuation3: cross-check Codex's local-CP cores and frontier against Claude's independent
exhaustive core enumeration (c3_pairs_*.json). Codex files are read as data only; Codex block ids are
translated to actual rules via completion_dlx_recheck.RULES (pure data, regenerated from five-cycles)."""
import json, glob, hashlib, sys, os
from collections import Counter, defaultdict
sys.path.insert(0, '..')
from c3_model import G36, apply_perm
import completion_dlx_recheck as C
G = G36()
def core_hash_rules(blocks, extras):
    best = None
    for g in G:
        key = (tuple(sorted(tuple(sorted(apply_perm(g, tuple(r)) for r in b)) for b in blocks)),
               tuple(sorted(apply_perm(g, tuple(r)) for r in extras)))
        if best is None or key < best: best = key
    return hashlib.sha1(repr(best).encode()).hexdigest()[:16]
# Claude records
mine = {}
for f in sorted(glob.glob('c3_pairs_*_*.json')):
    mine.update(json.load(open(f))['records'])
assert sorted(map(int, mine)) == list(range(913)), 'missing seeds'
mst = Counter(); mtypes = Counter(); my_all = set(); my_AA = set(); my_strict = set(); found = 0
for k, v in mine.items():
    mst.update(v['status']); found += len(v['found'])
    for h, types, strict, st, nodes in v['core_list']:
        my_all.add(h); mtypes.update(types)
        if 'AA' in types: my_AA.add(h)
        if strict: my_strict.add(h)
# Codex cores from every completion file (all records ever produced)
patterns = ('agent_seed_local_completion_[0-9]*.json', 'agent_pair_local_batch_[0-9]*.json', 'agent_pair_local_batch835_[0-9]*.json',
            'agent_local_batch_*_[0-9]*.json', 'agent_local_[0-9]*_[0-9]*.json', 'root_pair_local_*_[0-9]*.json')
codex = {}; rec_status = Counter(); file_status = Counter(); per_seed_final = defaultdict(list)
for path in sorted({p for pat in patterns for p in glob.glob(os.path.join('..', pat))}):
    try: data = json.load(open(path))
    except Exception: continue
    if 'seed_index' not in data: continue
    file_status[data.get('status', 'NONE')] += 1
    per_seed_final[data['seed_index']].append((os.path.basename(path), data.get('status')))
    for r in data.get('records', []):
        rec_status[r['status']] += 1
        if 'core_blocks' in r:
            h = core_hash_rules([C.RULES[b] for b in r['core_blocks']], r['extras'])
            codex.setdefault(h, set()).add(r['status'])
codex_exh = {h for h, s in codex.items() if any(x.startswith('EXHAUSTED') for x in s)}
codex_found = {h for h, s in codex.items() if 'FOUND' in s}
# frontier closure audit
fr = json.load(open('../WITNESS_FRONTIER.json'))
bad = []
for k, v in fr['closed'].items():
    d = json.load(open(os.path.join('..', v['file'])))
    if v['method'] == 'reduced CP-SAT':
        ok = any(r['index'] == int(k) and r['status'] == 'INFEASIBLE' for r in d['records']) and not d.get('local_relaxation', False)
    else:
        ok = d['seed_index'] == int(k) and d['status'] == 'LOCAL_INFEASIBLE' and all(r['status'].startswith('EXHAUSTED') for r in d['records'])
    if not ok: bad.append(k)
res = {
  'claude_seeds': len(mine), 'claude_completion_status': dict(mst), 'claude_found': found,
  'claude_core_types': dict(mtypes), 'claude_distinct_cores': len(my_all), 'claude_AA_cores': len(my_AA),
  'claude_strict_AA_cores': len(my_strict),
  'codex_completion_files_by_status': dict(file_status), 'codex_records_by_status': dict(rec_status),
  'codex_distinct_cores_any_status': len(codex), 'codex_distinct_exhausted_cores': len(codex_exh), 'codex_found_cores': len(codex_found),
  'codex_exhausted_cores_not_in_claude_AA': len(codex_exh - my_AA),
  'codex_exhausted_cores_not_in_claude_any': len(codex_exh - my_all),
  'claude_strict_cores_missing_from_codex': len(my_strict - codex_exh),
  'claude_strict_missing_examples': sorted(my_strict - codex_exh)[:10],
  'frontier_closed': len(fr['closed']), 'frontier_bad_entries': bad,
}
json.dump(res, open('c3_compare_cores.json', 'w'), indent=1)
print(json.dumps(res, indent=1))
