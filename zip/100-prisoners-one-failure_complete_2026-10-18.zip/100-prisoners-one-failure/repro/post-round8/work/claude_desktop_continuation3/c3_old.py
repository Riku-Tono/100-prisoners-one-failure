"""Claude continuation3: shared old-problem data (standard three-flip, 46 old blocks + holes).
Independent of earlier research code."""
from itertools import combinations
from collections import defaultdict
from c3_model import *

O = Orientation(standard3flip())
F = {frozenset(x) for x in ((1, 2, 3, 4), (1, 2, 3, 5), (1, 2, 3, 6), (4, 5, 6, 7))}
OLDW = sorted(w for w in O.words if frozenset(w) not in F and 8 not in w)
OLDWSET = set(OLDW)
WIDX = {w: i for i, w in enumerate(OLDW)}
BLOCKS = [b for b in O.blocks if all(word(r) in OLDWSET for r in b)]
assert len(BLOCKS) == 1584 and len(OLDW) == 186
BIDX = {b: i for i, b in enumerate(BLOCKS)}
BWI = [tuple(sorted(WIDX[word(r)] for r in b)) for b in BLOCKS]
BWS = [frozenset(x) for x in BWI]
BRULES = [frozenset(b) for b in BLOCKS]
blocks_with_rule = defaultdict(list)
for i, b in enumerate(BLOCKS):
    for r in b: blocks_with_rule[r].append(i)
CYC7 = list(directed_cycles(range(1, 8)))
CYC6 = [c for S in combinations(range(1, 8), 6) for c in directed_cycles(S)]
R7 = [cyc_rules(c) for c in CYC7]
R6 = [cyc_rules(c) for c in CYC6]
six_with_rule = defaultdict(list)
for i, rs in enumerate(R6):
    for r in rs: six_with_rule[r].append(i)
seven_with_rule = defaultdict(list)
for i, rs in enumerate(R7):
    for r in rs: seven_with_rule[r].append(i)
# every rule usable as an extra on an old word: (a,b,c,d,t), word old, t in [7]\{a,b,c,d}
EXTRA_RULES = [w[k:] + w[:k] + (t,) for w in OLDW for k in range(4) for t in range(1, 8) if t not in w]
EXTRA_RULES = [tuple(r) for r in EXTRA_RULES]
