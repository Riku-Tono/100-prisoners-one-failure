"""Claude continuation3: independent local verification of the extra-rule lemmas
in the standard three-flip old part (blocks = old admissible blocks on 186 old words).

L2: for any rule r (old word, target in [7]) the two [7]-seven-cycles C1,C2 having r as a correct rule
    cannot BOTH have five further correct rules supplied by mutually compatible old blocks that avoid word(r).
L3: same, when one other extra rule s (old word != word(r), not covered by blocks) may supply one of the
    remaining correct rules of C1 or C2 (all 12 useful choices of s enumerated).
A local relaxation: only the blocks needed for the required rules are chosen; infeasible => lemma.
Also L4: two distinct [7]-seven-cycles share at most one correct rule (exhaustive over all pairs).
"""
import json, time
from itertools import combinations
from collections import defaultdict, Counter
from c3_old import *

t0 = time.time()
G = G36()
def canon_rule(r): return min(tuple(g[x] for x in r) for g in G)
reps = sorted(set(canon_rule(r) for r in EXTRA_RULES))

def feasible(required, forbidden_words):
    """can every rule in `required` be put in an old block, blocks pairwise identical-or-disjoint,
    and no block touches forbidden word indices?"""
    req = sorted(required, key=lambda q: len(blocks_with_rule[q]))
    cands = []
    for q in req:
        cl = [b for b in blocks_with_rule[q] if not (BWS[b] & forbidden_words)]
        if not cl: return False
        cands.append(cl)
    order = sorted(range(len(req)), key=lambda i: len(cands[i]))
    def rec(k, chosen, used):
        if k == len(order): return True
        i = order[k]
        if any(req[i] in BRULES[b] for b in chosen): return rec(k + 1, chosen, used)
        for b in cands[i]:
            if BWS[b] & used: continue
            if rec(k + 1, chosen | {b}, used | BWS[b]): return True
        return False
    return rec(0, frozenset(), frozenset())

stats = Counter(); witnesses_L2 = []; witnesses_L3 = []
for r in reps:
    cyc = seven_with_rule[r]
    assert len(cyc) == 2
    C1, C2 = R7[cyc[0]], R7[cyc[1]]
    wr = WIDX[word(r)]
    others1 = [q for q in C1 if q != r]; others2 = [q for q in C2 if q != r]
    # L2
    for g1 in range(6):
        for g2 in range(6):
            req = set(others1[:g1] + others1[g1 + 1:]) | set(others2[:g2] + others2[g2 + 1:])
            stats['L2_cases'] += 1
            if feasible(req, frozenset([wr])):
                witnesses_L2.append((r, g1, g2))
    # L3: s is one of the 12 other correct rules, must sit on an old word different from word(r)
    for s in set(others1 + others2):
        if word(s) not in OLDWSET or word(s) == word(r):
            stats['L3_s_not_on_old_word_or_same_word'] += 1; continue
        ws = WIDX[word(s)]
        for g1 in range(6):
            for g2 in range(6):
                req = set(others1[:g1] + others1[g1 + 1:]) | set(others2[:g2] + others2[g2 + 1:])
                req.discard(s)
                stats['L3_cases'] += 1
                if feasible(req, frozenset([wr, ws])):
                    witnesses_L3.append((r, s, g1, g2))
# L4
pairs = Counter()
for q, lst in seven_with_rule.items():
    for i, j in combinations(lst, 2): pairs[(i, j)] += 1
res = {'scope': 'standard three-flip old part (186 old words, 1584 old blocks); local relaxation',
       'rule_orbit_reps': len(reps), 'stats': dict(stats),
       'L2_feasible_local_witnesses': len(witnesses_L2), 'L3_feasible_local_witnesses': len(witnesses_L3),
       'L2_examples': witnesses_L2[:5], 'L3_examples': witnesses_L3[:5],
       'L4_max_shared_correct_rules_[7]_seven_pairs': max(pairs.values()),
       'L4_pairs_sharing_a_rule': len(pairs), 'seconds': round(time.time() - t0, 2)}
json.dump(res, open('c3_lemmas.json', 'w'), indent=1)
print(json.dumps(res, indent=1))
