"""Independent fresh-rule audit of six-flip support allocations and 8-cycle filters.
Imports no general model, capacity enumerator, or solver code.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict,Counter
import json,time,hashlib
H=Path(__file__).resolve().parent;raw=(H/'sixflip_cluster_capacity_summary.json').read_bytes();d=json.loads(raw);pref=json.loads((H/'sixflip_cluster_capacity_presence.json').read_text());L=frozenset(range(1,9));start=time.monotonic();records=[]
def normal(x):
 x=tuple(x);return min(x[i:]+x[:i]for i in range(len(x)))
def rr(c):
 k=len(c);return frozenset((c[j],c[(j+1)%k],c[(j+2)%k],c[(j+3)%k],c[(j-1)%k])for j in range(k))
def cycs(k):
 for sub in combinations(range(1,9),k):
  for p in permutations(sub[1:]):yield(sub[0],)+p
long={k:[(c,rr(c))for c in cycs(k)]for k in(6,7)}
assert all(len({frozenset(r)for r in rs})==k for k in long for c,rs in long[k])
for case in d['records']:
 fs=set(map(frozenset,case['flips']));S=set(map(frozenset,combinations(range(1,8),4)))-fs|{L-f for f in fs};W={normal(p)for s in S for p in permutations(s)};B=set()
 for c in cycs(5):
  rs=rr(c)
  for omit in rs:
   b=rs-{omit}
   if all(normal(r[:4])in W for r in b):B.add(b)
 pats=[(frozenset(map(frozenset,p['new_supports'])),frozenset(map(frozenset,p['old_supports'])))for p in case['patterns']];pindex={p:i for i,p in enumerate(pats)};bypat=defaultdict(list);oldblocks=[]
 for b in B:
  ns=frozenset(frozenset(r[:4])for r in b if 8 in r[:4]);os=frozenset(frozenset(r[:4])for r in b if 8 not in r[:4])
  if ns:bypat[pindex[(ns,os)]].append(b)
  else:oldblocks.append(b)
 assert set(bypat)==set(range(len(pats)))
 assert all(len(bypat[i])==case['patterns'][i]['actual_rule_blocks']for i in bypat)
 found=[];usage=Counter()
 def capacity_dfs(i,counts,newused):
  if newused>36:return
  if i==len(pats):
   if newused>=34:found.append(tuple(counts))
   return
  resource=pats[i][0]|pats[i][1];maxx=min(6-usage[s]for s in resource)
  for n in range(maxx+1):
   for s in resource:usage[s]+=n
   capacity_dfs(i+1,counts+[n],newused+n*len(pats[i][0]))
   for s in resource:usage[s]-=n
 capacity_dfs(0,[],0)
 assert set(found)=={tuple(a['pattern_block_counts'])for a in case['allocations']}
 branches=[]
 for ai,a in enumerate(case['allocations']):
  counts=a['pattern_block_counts'];newuse=Counter();olduse=Counter()
  for i,n in enumerate(counts):
   for s in pats[i][0]:newuse[s]+=n
   for s in pats[i][1]:olduse[s]+=n
  bnew=sum(counts);newwords=sum(newuse.values());oldwords=sum(olduse.values());oldholes=174-oldwords-4*(52-bnew);assert oldholes==a['old_word_holes_after52blocks']
  allowed=[b for b in oldblocks if all(olduse[frozenset(r[:4])]<6 for r in b)]
  for i,n in enumerate(counts):
   if n:allowed+=bypat[i]
  blockrules=set().union(*allowed)
  single_supp={s for s in S if(8 in s and newuse[s]<6)or(8 not in s and oldholes>0 and olduse[s]<6)}
  singles={w[j:]+w[:j]+(t,)for w in W if frozenset(w)in single_supp for j in range(4)for t in L-set(w)};present=blockrules|singles
  new_five_supports={frozenset(r)for i,n in enumerate(counts)if n for b in bypat[i]for r in b};new_holes=36-newwords
  maxima={};elig={}
  for k,cycles in long.items():
   vals=[sum(r in present for r in rs)for c,rs in cycles if 8 in c];maxima[k]=max(vals);elig[k]=sum(v>=k-1 for v in vals)
   if len(new_five_supports)==2 and new_holes==0:
    assert all(sum(8 in r[:4]and r in blockrules for r in rs)<=2 for c,rs in cycles if 8 in c)
    assert maxima[k]<=k-2
  assert maxima[7]<=5
  union7={};hist=Counter()
  for c,rs in long[7]:
   if sum(r in present for r in rs)<6:continue
   need=max(0,6-sum(r in blockrules for r in rs));hist[(8 in c,need)]+=1
   if need<=2:union7[c]=need
  expected=next(z for z in pref['records']if z['orbit_index']==case['orbit_index'])['branches'][ai]
  assert len(union7)==expected['within_two_extras_total'];assert sum(8 in c for c in union7)==expected['within_two_extras_containing8']
  branches.append({'capacity_branch':ai,'pattern_block_counts':counts,'possible_rule_blocks':len(allowed),'possible_single_rules':len(singles),'new_five_label_supports':sorted(map(sorted,new_five_supports)),'new_holes':new_holes,'max_possible_correct_rules_for_cycles_containing8':maxima,'eligible_cycles_containing8':elig,'remaining_seven_candidates_within_two_extras':len(union7),'two_cluster_no_new_extra_bound_verified':len(new_five_supports)==2 and new_holes==0})
 records.append({'orbit_index':case['orbit_index'],'independent_capacity_allocation_count':len(found),'allocation_sets_match':True,'branches':branches})
 print(case['orbit_index'],'allocations',len(found),'max8R7',[b['max_possible_correct_rules_for_cycles_containing8'][7]for b in branches],flush=True)
out={'method':__doc__,'capacity_source_sha256':hashlib.sha256(raw).hexdigest(),'records':records,'all_8_containing_sevens_have_at_least_two_permanent_failures_in_every_surviving_capacity_branch':True,'scope':'Auxiliary necessary-condition analysis only; not an actualpacking or globalstrategy optimum certificate.','solver_calls':0,'seconds':time.monotonic()-start};(H/'sixflip_cluster_capacity_independent.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('FINAL',out['seconds'],flush=True)
