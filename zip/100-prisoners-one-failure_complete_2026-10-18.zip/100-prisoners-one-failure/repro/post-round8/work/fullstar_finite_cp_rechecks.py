"""Recheck the174 CP-only reused cases with the pure/R6 high-bitset cover."""
from fullstar_finite_core_finish import *

def main():
    started=time.monotonic();deadline=started+90
    source=H/'fullstar_finite_core_finish_result.json';raw=source.read_bytes();d=json.loads(raw)
    assert d['status']=='EXHAUSTED_NO_TARGET4_WITH_FIXED_18_CORE' and d['all_core_coverage'] and not d['unknown_indices']
    data=json.loads((H/'fullstar_fixed_core_enumeration.json').read_text());cores=data['minimal_records']
    pending=[r['index'] for r in d['records'] if r['status']=='REUSED_CP_INFEASIBLE'];assert len(pending)==174
    engine=HighEngine();records=[]
    for i in pending:
        c=cores[i];remaining=deadline-time.monotonic()
        if remaining<=0:break
        st,nodes,more,holes=engine.run(c['core_blocks'],c['critical_extra_rules'],min(2,remaining),2000000,use_r6=False)
        rec={'index':i,'status':st,'nodes':nodes,'engine':'PURE_HIGH_BITSET'}
        if st=='FOUND':
            rr=set().union(*(RULES[b] for b in set(c['core_blocks'])|set(more)))|set(map(tuple,c['critical_extra_rules']))
            if any(sum(r in rr for r in six)>=5 for six in SIX):st='NEEDS_R6_SEARCH'
        if st=='NEEDS_R6_SEARCH' or st.startswith('UNKNOWN'):
            remaining=deadline-time.monotonic()
            if remaining<=0:rec['status']='UNKNOWN_WALL_LIMIT'
            else:
                st,n2,more,holes=engine.run(c['core_blocks'],c['critical_extra_rules'],min(10,remaining),2000000,use_r6=True)
                rec.update(status=st,r6_nodes=n2,engine='R6_HIGH_BITSET')
        if st=='FOUND':
            cert=H/f'fullstar_finite_recheck_found_{i}.rules.json'
            rec['certificate']=str(cert);rec['direct_audit']=export_and_audit(cert,c['core_blocks'],c['critical_extra_rules'],more,holes,15052)
        records.append(rec)
        if st=='FOUND':break
    out={'scope':__doc__,'source':str(source),'source_sha256':hashlib.sha256(raw).hexdigest(),'expected_cases':174,'records':records,'counts':dict(Counter(r['status'] for r in records)),'seconds':time.monotonic()-started,'not_run':sorted(set(pending)-{r['index'] for r in records})}
    out['all_cp_only_cases_independently_exhausted']=len(records)==174 and all(r['status']=='EXHAUSTED_NO_COMPLETION' for r in records)
    save(H/'fullstar_finite_cp_rechecks_result.json',out)
    if out['all_cp_only_cases_independently_exhausted']:
        byindex={r['index']:r for r in records};coverage=[]
        for old in sorted(d['records'],key=lambda r:r['index']):
            r=byindex[old['index']] if old['status']=='REUSED_CP_INFEASIBLE' else old
            assert r['status'] in ('REUSED_EXHAUSTED','EXHAUSTED_NO_COMPLETION')
            coverage.append({'index':r['index'],'status':'EXHAUSTED_NO_COMPLETION','evidence':('fullstar_finite_cp_rechecks_result.json' if old['status']=='REUSED_CP_INFEASIBLE' else ('fullstar_finite_core_finish_result.json' if old['status']=='EXHAUSTED_NO_COMPLETION' else old['source'])),'nodes':r.get('nodes',r.get('source_nodes'))})
        assert len(coverage)==3735 and {r['index'] for r in coverage}==set(range(3735))
        final={'status':'EXHAUSTED_NO_TARGET4_WITH_FIXED_18_CORE','claim_scope':'Full-star orientation; exactly52 four-rule blocks plus at most2 other rules; R6=0; the listed18-block core fixed. No R7>=4 completion exists. Other3-cycle witnesses and general full-star strategies remain unresolved.','fixed_core':data['fixed_core'],'critical_core_enumeration':'fullstar_fixed_core_enumeration.json','total_core_count':3735,'fourth_cycle_count':data['distinct_fourth_cycles'],'all3735_verified_by_non_CP_cover':True,'unprocessed':0,'unknown':0,'found':0,'positive_control':d['positive_control'],'counts':{'EXHAUSTED_NO_COMPLETION':3735},'coverage':coverage,'evidence_files':['fullstar_finite_core_bitset_result.json','fullstar_finite_core_completion_result.json','fullstar_finite_core_finish_result.json','fullstar_finite_cp_rechecks_result.json']}
        save(H/'fullstar_fixed18_complete_summary.json',final)
    print(out['counts'],out['seconds'],'all174',out['all_cp_only_cases_independently_exhausted'],flush=True)
if __name__=='__main__':main()
