"""Prepare eight six-flip generic models: Build + Validate only, never Solve.

Support-window eligibility and completion geometry are preparation data.
Syntactic model validation is not a feasibility result.
"""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import sys,json,time,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));import general_orientation_model as G
raw=(H/'support_orientation_six_flip_screen.json').read_bytes();data=json.loads(raw);start=time.monotonic();records=[]
for spec in data['orbits']:
 if not spec['passes_slot_52_test']:continue
 flips=spec['removed_supports'];m=G.build(flips,target=4);error=m.model.validate();assert error=='',error
 blockrules=set().union(*m.data.blocks);eligible={};all8=G.LABELS
 for k in (6,7,8):
  hist=Counter();available_hist=Counter();extra_hist=Counter()
  for c,rr in G.cycle_data(k):
   n=sum(r in m.present for r in rr)
   if n<k-1:continue
   hist[8 in c]+=1;available_hist[(8 in c,n)]+=1
   bn=sum(r in blockrules for r in rr);extra_hist[(8 in c,max(0,k-1-bn))]+=1
  eligible[k]={'total':sum(hist.values()),'containing8':hist[True],'without8':hist[False],'correct_available_histogram':[{'contains8':has8,'available_correct_rules':n,'cycles':cnt}for(has8,n),cnt in sorted(available_hist.items())],'minimum_extras_histogram':[{'contains8':has8,'necessary_extras_at_least':n,'cycles':cnt}for(has8,n),cnt in sorted(extra_hist.items())]}
 supportpatterns=defaultdict(int)
 for b in m.data.blocks:
  ns=frozenset(frozenset(r[:4])for r in b if 8 in r[:4]);olds=frozenset(frozenset(r[:4])for r in b if 8 not in r[:4])
  if ns:supportpatterns[(ns,olds)]+=1
 npats=sorted(supportpatterns,key=lambda p:(sorted(map(sorted,p[0])),sorted(map(sorted,p[1]))));new_supp={s for p in npats for s in p[0]};unique_forced=[];necessary_obstruction=None
 if all(len(p[0])==3 for p in npats):
  # 174old+3bnew>=208 and 3bnew<=36 force bnew=12 and allnewwordscovered.
  for i,p in enumerate(npats):
   unique=[s for s in p[0]if sum(s in q[0]for q in npats)==1]
   if unique:unique_forced.append({'pattern_index':i,'at_least_blocks':6,'unique_new_supports':sorted(map(sorted,unique))})
  if sum(q['at_least_blocks']for q in unique_forced)>12:necessary_obstruction='Withonly3-new-wordblocks,52totalblocksforce12newblocksandall36newwordscovered. Thethreecluster-unique supportseachforce6blocks ofadifferentpattern,requiring18newblocks.'
 rec={'orbit_index':spec['index'],'flips':m.data.flips,'new_complement_triples':spec['new_complement_triples'],'S7_orbit_size':spec['S7_orbit_size'],'stats':m.stats,'protobuf_variables':len(m.model.proto.variables),'protobuf_constraints':len(m.model.proto.constraints),'model_stats_text':m.model.model_stats(),'validation_error':error,'validation_passed':True,'Solve_called':False,'long_cycle_eligibility':eligible,'new_block_support_patterns':[{'pattern_index':i,'new_supports':sorted(map(sorted,p[0])),'old_supports':sorted(map(sorted,p[1])),'actual_rule_blocks':supportpatterns[p]}for i,p in enumerate(npats)],'unique_support_forced_counts_if_52_blocks':unique_forced,'analytical_52_block_obstruction':necessary_obstruction,'new_triple_union_size':spec['new_triple_union_size'],'clusters':spec['clusters']}
 records.append(rec)
 print('BUILT',spec['index'],'blocks',len(m.blocks),'vars',rec['protobuf_variables'],'cons',rec['protobuf_constraints'],'R7',eligible[7]['total'],'R7with8',eligible[7]['containing8'],'R6with8',eligible[6]['containing8'],'valid',not error,flush=True)
# A reviewable heuristic order. Prefer a coupled completion geometry first,
# then distinct 8-label rescue opportunities; no claim about success odds.
byid={r['orbit_index']:r for r in records}
viable=[r for r in records if not r['analytical_52_block_obstruction']]
ranked=sorted(viable,key=lambda r:(r['orbit_index']!=2,-r['long_cycle_eligibility'][7]['containing8'],-r['new_triple_union_size'],r['stats']['blocks']))
ranked += [r for r in records if r['analytical_52_block_obstruction']]
for rank,r in enumerate(ranked,1):r['preparation_priority']=rank
out={'method':__doc__,'source_screen_sha256':hashlib.sha256(raw).hexdigest(),'general_model_sha256':hashlib.sha256((H/'general_orientation_model.py').read_bytes()).hexdigest(),'target':4,'models_built':len(records),'models_validated':sum(r['validation_passed']for r in records),'solver_calls':0,'records':records,'priority_orbit_indices':[r['orbit_index']for r in ranked],'priority_note':'Heuristicforfutureboundedsearch: coupled4clusterorbit2first;remainingnon-obstructedmodelsorderedbymoreeligible7cyclescontaining8,thensupportunionandblockcount. A largereligibilitycountisnotapromiseofbetterwinningprobability. SyntacticValidatepassesdonotprovefeasibility.','seconds':time.monotonic()-start}
for r in records:
 hist=r['long_cycle_eligibility'][7]['minimum_extras_histogram']
 r['presence_candidate_counts']={'within_two_extras_all7':sum(z['cycles']for z in hist if z['necessary_extras_at_least']<=2),'within_two_extras_with8':sum(z['cycles']for z in hist if z['contains8']and z['necessary_extras_at_least']<=2),'block_only_all7':sum(z['cycles']for z in hist if z['necessary_extras_at_least']==0),'block_only_with8':sum(z['cycles']for z in hist if z['contains8']and z['necessary_extras_at_least']==0),'excluded_need_three_or_more_extras':sum(z['cycles']for z in hist if z['necessary_extras_at_least']>=3),'status':'Necessary rule-presence filter only; ignores joint block-slot compatibility, R6, and exactly52 completion. No Solve call.'}
filtered_rank=sorted(viable,key=lambda r:(-r['presence_candidate_counts']['within_two_extras_all7'],-r['presence_candidate_counts']['within_two_extras_with8'],-r['presence_candidate_counts']['block_only_all7']))
filtered_rank += [r for r in records if r['analytical_52_block_obstruction']]
for rank,r in enumerate(filtered_rank,1):r['priority_after_presence_extra_filter']=rank
out['priority_after_presence_extra_filter_indices']=[r['orbit_index']for r in filtered_rank]
out['block_only_presence_order_indices']=[r['orbit_index']for r in sorted(viable,key=lambda r:-r['presence_candidate_counts']['block_only_all7'])]
out['extra_filter_priority_note']='After <=2extra necessary filter, prefer more remaining cycles, then more containing8, then more block-only candidates. This changes secondpriority from3to9. Counts do not establish locally compatible witnesses.'
inputs=[{'orbit_index':r['orbit_index'],'priority':r['priority_after_presence_extra_filter'],'flips':r['flips'],'target':4,'Solve_called':False}for r in filtered_rank]
(H/'sixflip_model_preparation_inputs.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
case4=byid[4]
aux={'status':'AUXILIARY_ANALYTICAL_OBSTRUCTION_NOT_USED_IN_FINAL_GLOBAL_CONCLUSION','orbit_index':4,'flips':case4['flips'],'old_slots':174,'new_slots':36,'block_slots_required_for52':208,'new_words_per_new_block':3,'forced_new_block_count':12,'reason_for_forced12':'208-174=34 newwords required; 3b>=34 and3b<=36 forceb=12 andall36 newwords covered.','pattern_unique_supports':case4['unique_support_forced_counts_if_52_blocks'],'forced_pattern_block_lower_sum':18,'contradiction':'Three separate patterns eachhaveanewsupportoccurringinnoneoftheothers; coveringits6words forcesatleast6blocks ofthatpattern. Atleast18newblocks contradicts12.','patterns':case4['new_block_support_patterns'],'solver_calls':0}
(H/'sixflip_model_preparation_case4_obstruction.json').write_text(json.dumps(aux,indent=2),encoding='utf-8')
(H/'sixflip_model_preparation_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('PRIORITY',out['priority_orbit_indices'],'seconds',out['seconds'],flush=True)
