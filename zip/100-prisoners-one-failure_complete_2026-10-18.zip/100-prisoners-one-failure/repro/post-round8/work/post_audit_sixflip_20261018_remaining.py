"""Post-audit remaining six-flip orientations, generic full model.
Only assigned orientations are checked. UNKNOWN remainsunresolved.
"""
from pathlib import Path
import sys,json,time,datetime,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));import general_orientation_model as G
PREFIX='post_audit_sixflip_20261018_remaining';source=(H/'support_orientation_six_flip_screen.json').read_bytes();screen=json.loads(source);byid={r['index']:r for r in screen['orbits']};order=[0,5,9,1,6,4];start=time.monotonic();batch={'scope':__doc__,'model_scope':G.__doc__,'source_screen_sha256':hashlib.sha256(source).hexdigest(),'general_model_sha256':hashlib.sha256((H/'general_orientation_model.py').read_bytes()).hexdigest(),'assigned_orbits':order,'workers':1,'seconds_per_solve':120,'records':[],'status':'RUNNING'}
def save():
 batch['seconds']=time.monotonic()-start;(H/(PREFIX+'_summary.json')).write_text(json.dumps(batch,indent=2),encoding='utf-8')
# Retrospective equivalentmodel exports for the two already completed solves.
for oldindex in(2,3):
 oldprefix=f'post_audit_sixflip_20261018_orbit{oldindex}_target4';p=H/(oldprefix+'.result.json');old=json.loads(p.read_text());rebuilt=G.build(old['flips'],target=4);assert rebuilt.model.validate()=='';modelpath=H/(oldprefix+'.model.txt');assert rebuilt.model.export_to_file(str(modelpath));old.update(reproduction_model=str(modelpath),reproduction_model_sha256=hashlib.sha256(modelpath.read_bytes()).hexdigest(),model_export_rebuilt_after_solve=True);p.write_text(json.dumps(old,indent=2),encoding='utf-8');(H/(oldprefix+'.response.txt')).write_text(old['response_stats'],encoding='utf-8')
for index in order:
 label=f'{PREFIX}_orbit{index}_target4';model=G.build(byid[index]['removed_supports'],target=4);assert model.model.validate()=='';modelpath=H/(label+'.model.txt');assert model.model.export_to_file(str(modelpath));record={'orbit_index':index,'target':4,'scope':G.__doc__,'flips':model.data.flips,'stats':model.stats,'validation_passed':True,'status':'RUNNING','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workers':1,'random_seed':20261018+10*index+4,'model_proto_text':str(modelpath),'model_proto_sha256':hashlib.sha256(modelpath.read_bytes()).hexdigest(),'auxiliary_capacity_cuts_applied':False}
 path=H/(label+'.result.json');path.write_text(json.dumps(record,indent=2),encoding='utf-8');batch['current']={'orbit_index':index,'target':4,'result':str(path)};save();print('START',index,flush=True)
 solver=G.cp_model.CpSolver();solver.parameters.max_time_in_seconds=120;solver.parameters.num_search_workers=1;solver.parameters.random_seed=record['random_seed'];(H/(label+'.parameters.txt')).write_text(str(solver.parameters),encoding='utf-8');status=solver.solve(model.model)
 record.update(status=solver.status_name(status),solve_seconds=solver.wall_time,response_stats=solver.response_stats(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());responsepath=H/(label+'.response.txt');responsepath.write_text(str(solver.response_proto),encoding='utf-8');record['solver_response_proto_text']=str(responsepath)
 if status in(G.cp_model.FEASIBLE,G.cp_model.OPTIMAL):record.update(model.export_and_audit(solver,H/(label+'.rules.json'),H/(label+'.audit.json')))
 path.write_text(json.dumps(record,indent=2),encoding='utf-8');batch['records'].append(record);batch.pop('current',None);save();print('END',index,record['status'],record['solve_seconds'],record.get('audit',{}).get('wins'),flush=True)
 if status in(G.cp_model.FEASIBLE,G.cp_model.OPTIMAL):batch['status']='TARGET4_FOUND';batch['found_orbit']=index;save();break
else:batch['status']='ASSIGNED_BOUNDED_SEARCHES_FINISHED';save()
print('FINAL',batch['status'],batch['seconds'],flush=True)
