"""Independent four-flip witness enumeration and fixed-hole completion.

Uses Desktop Claude's separately authored5-cycle generator; no import of the
fourflip enumeration or completion scripts. Source outputs are read as data
only and compared by actual rule tuples. No R6 condition in this checker.
"""
from pathlib import Path
from collections import defaultdict,Counter
from itertools import combinations,permutations
import sys,json,time,hashlib
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'claude_desktop_continuation3'))
from c3_model import Orientation,ALL,word,cyc_rules,directed_cycles

F={frozenset((1,2,3,x)) for x in (4,5,6,7)}
active=[frozenset(s) for s in combinations(range(1,8),4) if frozenset(s) not in F]+[ALL-s for s in F]
O=Orientation(active);blocks=[frozenset(b) for b in O.blocks]
bi={b:i for i,b in enumerate(blocks)};wi={w:i for i,w in enumerate(O.words)}
rows=[sum(1<<wi[word(r)] for r in b) for b in blocks]
old=[i for i,b in enumerate(blocks) if all(8 not in r for r in b)]
assert len(blocks)==1920 and len(old)==1800 and len(wi)==210
suppliers=defaultdict(list)
for b in old:
    for r in blocks[b]:suppliers[r].append(b)
cycles=list(directed_cycles(range(1,8)))

def witnesses(n):
    out=set()
    for c in cycles:
        rr=frozenset(cyc_rules(c))
        if n==6:
            tasks=[(None,rr-{omit}) for omit in rr]
        else:
            tasks=[(e,rr-{e,omit}) for e in rr if word(e) in wi for omit in rr-{e}]
        for extra,need in tasks:
            required=sorted(need,key=lambda r:len(suppliers[r]))
            forbidden=0 if extra is None else 1<<wi[word(extra)]
            if any(not suppliers[r] for r in required):continue
            assert sum(len(suppliers[r]) for r in required)==len(set(b for r in required for b in suppliers[r]))
            def visit(k,used,chosen):
                if k==len(required):
                    out.add((c,extra,tuple(sorted(chosen))));return
                for b in suppliers[required[k]]:
                    if rows[b]&used:continue
                    visit(k+1,used|rows[b],chosen+(b,))
            visit(0,forbidden,())
    return sorted(out)

def wordmask(bs):
    z=0
    for b in bs:z|=rows[b]
    return z
def compatible(a,ma,b,mb):
    overlap=wordmask(set(a)&set(b))
    return ma&mb==overlap

class Cover:
    def __init__(self,wordlist,ruleblocks):
        self.wi={w:i for i,w in enumerate(wordlist)}
        self.rows=[sum(1<<self.wi[word(r)] for r in b) for b in ruleblocks]
        self.cols=[0]*len(wordlist)
        for b,rr in enumerate(ruleblocks):
            for r in rr:self.cols[self.wi[word(r)]]|=1<<b
        self.conf=[]
        for rr in ruleblocks:
            v=0
            for r in rr:v|=self.cols[self.wi[word(r)]]
            self.conf.append(v)
        self.allrows=(1<<len(ruleblocks))-1;self.allwords=(1<<len(wordlist))-1
    def run(self,mandatory,holewords,hint=()):
        left=self.allwords;avail=self.allrows;self.nodes=0;self.answer=None
        self.hint=sum(1<<b for b in hint)
        for w in holewords:
            col=self.wi[w];left &= ~(1<<col);avail &= ~self.cols[col]
        for b in sorted(mandatory,reverse=True):
            assert left&self.rows[b]==self.rows[b]
            left ^= self.rows[b];avail &= ~self.conf[b]
        return self.search(left,avail,[])
    def search(self,left,avail,path):
        self.nodes+=1
        if not left:self.answer=path[:];return True
        todo=left;small=100000;opts=0
        while todo:
            bit=1<<(todo.bit_length()-1);todo^=bit
            cand=self.cols[bit.bit_length()-1]&avail
            n=cand.bit_count()
            if not n:return False
            if n<small:small=n;opts=cand
        for opts1 in (opts&self.hint,opts&~self.hint):
            while opts1:
                bit=1<<(opts1.bit_length()-1);opts1^=bit;b=bit.bit_length()-1
                if self.search(left^self.rows[b],avail&~self.conf[b],path+[b]):return True
        return False

def main():
    started=time.monotonic();six=witnesses(6);five=witnesses(5)
    assert len(six)==576 and len(five)==7488
    raw=(H/'fourflip_compound_pure_enumeration.json').read_bytes();submitted=json.loads(raw)
    mapid={i:bi[frozenset(tuple(r) for r in b)] for i,b in enumerate(submitted['block_definitions'])}
    actual5={(tuple(r['cycle']),tuple(r['extra']),tuple(sorted(mapid[b] for b in r['blocks']))) for r in submitted['local_witnesses']}
    assert set(five)==actual5
    pairraw=set()
    for i,(c,e,bs) in enumerate(six):
        ma=wordmask(bs)
        for d,f,bt in six[i+1:]:
            if c!=d and compatible(bs,ma,bt,wordmask(bt)):
                pairraw.add(tuple(sorted(set(bs)|set(bt))))
    assert len(pairraw)==25344
    seeddata=json.loads((H/'fourflip_witness_preparation_pairs.json').read_text())['seeds']
    seeds=[tuple(sorted(bi[frozenset(tuple(r) for r in bb)] for bb in s['actual_rules'])) for s in seeddata]
    groups=[]
    for p in permutations((1,2,3)):
        for q in permutations((4,5,6,7)):
            g={**dict(zip((1,2,3),p)),**dict(zip((4,5,6,7),q)),8:8}
            groups.append([bi[frozenset(tuple(g[x] for x in r) for r in b)] for b in blocks])
    covered=set()
    for bs in seeds:
        orbit={tuple(sorted(g[b] for b in bs)) for g in groups}
        assert not covered&orbit and orbit<=pairraw
        covered|=orbit
    assert covered==pairraw
    found=set();nlocal=0;perbase=[]
    for seed in seeds:
        sm=wordmask(seed);sr=set().union(*(blocks[b] for b in seed))
        already={c for c in cycles if len(set(cyc_rules(c))&sr)>=6}
        assert len(already)==2
        opts=[]
        for c,e,bs in five:
            if c in already or sm&(1<<wi[word(e)]):continue
            bm=wordmask(bs)
            if compatible(seed,sm,bs,bm):opts.append((c,e,bs,bm))
        nlocal+=len(opts);before=len(found)
        for j,(c,e,bs,bm) in enumerate(opts):
            for d,f,bt,bn in opts[j+1:]:
                if c==d or word(e)==word(f):continue
                if bm&(1<<wi[word(f)]) or bn&(1<<wi[word(e)]):continue
                if not compatible(bs,bm,bt,bn):continue
                found.add((tuple(sorted(set(seed)|set(bs)|set(bt))),tuple(sorted((e,f)))))
        perbase.append((len(opts),len(found)-before))
    actual={(tuple(sorted(mapid[b] for b in r['core_blocks'])),tuple(sorted(tuple(e) for e in r['extras']))) for r in submitted['seeds']}
    assert nlocal==11899 and len(found)==21097 and found==actual
    print('EXACT_SETS_MATCH',len(six),len(five),len(pairraw),len(seeds),nlocal,len(found),flush=True)
    # Positive control uses the same algorithm on a separately generated full-star universe.
    star=Orientation(combinations(range(1,8),4));sb=[frozenset(b) for b in star.blocks]
    base=json.loads((H/'inputs/baseline15051.rules.json').read_text())
    rr={(a,*h,t) for a,h,t in base['rules']};known={i for i,b in enumerate(sb) if b<=rr}
    assert len(known)==52
    holes=set(star.words)-{word(r) for i in known for r in sb[i]}
    positive=Cover(star.words,sb);fixed=set(sorted(known)[-39:])
    assert positive.run(fixed,holes,known) and len(positive.answer)==13
    complete=fixed|set(positive.answer)
    assert set().union(*(sb[b] for b in complete))==rr
    out=dict(method=__doc__,source_enumeration_sha256=hashlib.sha256(raw).hexdigest(),six_witnesses=len(six),five_plus_one_witnesses=len(five),raw_pairs=len(pairraw),G144_seed_cover_exact=True,compatible_local_witnesses=nlocal,compound_core_set_exact_match=True,total=len(found),R6_used=False,positive_control=dict(fixed=39,recovered=13,nodes=positive.nodes),cases=[])
    engine=Cover(O.words,blocks)
    for index,(bs,extras) in enumerate(sorted(found)):
        assert not engine.run(bs,{word(e) for e in extras}),('UNEXPECTED_COMPLETION',index,bs,extras,engine.answer)
        out['cases'].append(dict(index=index,status='EXHAUSTED',nodes=engine.nodes))
    out.update(exhausted=len(found),found=0,unknown=0,nodes=sum(r['nodes'] for r in out['cases']),max_nodes=max(r['nodes'] for r in out['cases']),seconds=time.monotonic()-started)
    (H/'fourflip_independent_regenerate_cover.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print({k:v for k,v in out.items() if k not in ('method','cases')},flush=True)

if __name__=='__main__':main()
