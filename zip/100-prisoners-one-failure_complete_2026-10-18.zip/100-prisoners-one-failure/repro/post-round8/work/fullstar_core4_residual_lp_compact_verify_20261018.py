"""Recheck residual LP certificates without a solver; compact by upward rounding.

Regenerate every actual residual row using Claude c3. Verify the original
Fraction weights and all actual-row constraints. Round each nonzero weight
UP to a common1e6 grid and independently recheck nonnegativity, every row
sum>=1, and total<t. No floating calculation or construction Solve is used.
"""
from pathlib import Path
from itertools import combinations
from fractions import Fraction
from collections import Counter
import hashlib, json, sys, time

H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'claude_desktop_continuation3'))
from c3_model import Orientation,word


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def qjson(q):return [q.numerator,q.denominator]


def main():
    started=time.monotonic()
    source=H/'fullstar_core4_residual_lp_all3812_20261018.json'
    data=json.loads(source.read_text())
    critical=Path(data['critical_source']);cd=json.loads(critical.read_text())
    assert sha(critical)==data['critical_source_sha256']
    assert data['status']=='ALL3812_LP_SCANNED' and len(data['records'])==3812
    assert {r['index'] for r in data['records']}==set(range(3812))
    o=Orientation([s for s in combinations(range(1,8),4)])
    words=tuple(o.words);wi={w:i for i,w in enumerate(words)}
    blocks=tuple(frozenset(b) for b in o.blocks);lookup={b:i for i,b in enumerate(blocks)}
    rows=tuple(tuple(sorted(wi[word(r)] for r in b)) for b in blocks)
    catalogue_sha=hashlib.sha256(json.dumps([sorted(b) for b in blocks],separators=(',',':')).encode()).hexdigest()
    assert catalogue_sha==data['block_catalogue_sha256']==cd['block_catalogue_sha256']
    assert list(map(list,words))==data['global_word_catalogue']
    fixed=frozenset(lookup[frozenset(map(tuple,b))] for b in cd['fixed_actual_blocks'])
    assert sorted(fixed)==cd['fixed_core']
    proofs=[]
    for r in data['records']:
        if r['independent_status']!='EXACT_FRACTION_DUAL_EXCLUSION':continue
        actual=cd['records'][r['index']]
        core=fixed|frozenset(lookup[frozenset(map(tuple,b))] for b in actual['additional_actual_blocks'])
        extras=set(map(tuple,actual['critical_extra_rules']))
        assert sorted(core)==actual['core_blocks']==r['core_blocks']
        assert sorted(extras)==list(map(tuple,r['critical_extra_rules']))
        occupied=[i for b in core for i in rows[b]]+[wi[word(e)] for e in extras]
        assert len(occupied)==len(set(occupied))==4*len(core)+len(extras)
        occupied=set(occupied)
        available=tuple(b for b,row in enumerate(rows) if not occupied.intersection(row))
        assert len(available)==r['available_actual_rows']
        assert hashlib.sha256(','.join(map(str,available)).encode()).hexdigest()==r['available_rows_sha256']
        weights={v['word_index']:Fraction(*v['value']) for v in r['certificate']['nonzero_word_weights']}
        assert len(weights)==len(r['certificate']['nonzero_word_weights'])
        assert not set(weights)&occupied and all(q>=0 for q in weights.values())
        assert all(list(words[v['word_index']])==v['word'] for v in r['certificate']['nonzero_word_weights'])
        original_bound=sum(weights.values(),Fraction())
        assert original_bound==Fraction(*r['certificate']['upper_bound'])<52-len(core)
        original_min=min(sum((weights.get(i,Fraction()) for i in rows[b]),Fraction()) for b in available) if available else None
        assert original_min is None or original_min>=1
        denominator=1000000
        compact={i:Fraction(-((-q.numerator*denominator)//q.denominator),denominator) for i,q in weights.items()}
        assert all(compact[i]>=q for i,q in weights.items())
        compact_bound=sum(compact.values(),Fraction())
        assert compact_bound<52-len(core)
        minimum=min(sum((compact.get(i,Fraction()) for i in rows[b]),Fraction()) for b in available) if available else None
        assert minimum is None or minimum>=1
        certificate=dict(upper_bound=qjson(compact_bound),minimum_row_weight=qjson(minimum) if minimum is not None else None,
                         exact_nonnegative=True,all_legal_actual_rows_covered=True,exact_upper_bound_below_required=True,
                         rounding_grid_denominator=denominator,
                         word_weights=[dict(word_index=i,word=words[i],value=qjson(q)) for i,q in sorted(compact.items())])
        proofs.append(dict(index=r['index'],independent_status='EXACT_FRACTION_DUAL_EXCLUSION',core_blocks=sorted(core),
                           critical_extra_rules=sorted(extras),required_remaining_blocks=52-len(core),
                           legal_rows=len(available),available_rows_sha256=r['available_rows_sha256'],certificate=certificate))
    assert len(proofs)==data['counts']['EXACT_FRACTION_DUAL_EXCLUSION']==540
    out=dict(status='PASS540_EXACT_FRACTION_DUALS_RECHECKED_NO_SOLVER',scope=__doc__,source_sha256=sha(source),
             critical_source_sha256=sha(critical),source_critical_count=3812,source_fixed18=cd['fixed_core'],
             source_seed_core_index=4,block_catalogue_sha256=catalogue_sha,claude_c3_sha256=sha(H/'claude_desktop_continuation3/c3_model.py'),
             verified_exact_dual_exclusions=len(proofs),unexcluded_count=3812-len(proofs),
             unexcluded_indices=sorted(set(range(3812))-{r['index'] for r in proofs}),
             R6_constraint_used=False,construction_Solve_called=False,any_solver_called=False,
             source_scan_seconds=data['seconds'],records=proofs,seconds=time.monotonic()-started)
    target=H/'fullstar_core4_residual_lp_compact_verified_20261018.json'
    target.write_text(json.dumps(out,separators=(',',':')),encoding='utf-8')
    print({k:v for k,v in out.items() if k not in ('scope','records','unexcluded_indices')},flush=True)
    print('bytes',target.stat().st_size,flush=True)


if __name__=='__main__':main()
