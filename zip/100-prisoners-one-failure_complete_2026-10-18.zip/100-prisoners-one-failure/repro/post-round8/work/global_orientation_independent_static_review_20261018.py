"""Independent finite universe/constraint audit; never calls Solve.

The conclusion concerns the 52 disjoint four-rule blocks plus <=2 singleton
representation and complementary support orientations, not arbitrary strategies.
"""
from pathlib import Path
from itertools import permutations
from collections import defaultdict, Counter
import hashlib, json, time
import global_orientation_witness_completion as G

H = Path(__file__).resolve().parent
START = time.monotonic()
LABELS = frozenset(range(1, 9))
MIN, MAX = -(2**63), 2**63 - 1

def normalize(word):
    return min(word[i:] + word[:i] for i in range(len(word)))

def rules_of_cycle(c):
    # Rotate the cycle, then read the first four boxes and final predecessor.
    return frozenset((c[i:] + c[:i])[:4] + ((c[i:] + c[:i])[-1],)
                     for i in range(len(c)))

def independent_cycles(k):
    return [(p, rules_of_cycle(p)) for p in permutations(range(1, 9), k)
            if p[0] == min(p)]

def terms_of(constraint):
    acc = Counter()
    for v, c in zip(constraint.linear.vars, constraint.linear.coeffs):
        acc[int(v)] += int(c)
    return {v: c for v, c in acc.items() if c}

def check_linear(c, expected, lo, hi, enforce=()):
    assert c.has_linear()
    assert terms_of(c) == {v: n for v, n in expected.items() if n}
    assert list(c.linear.domain) == [lo, hi]
    assert list(c.enforcement_literal) == list(enforce)

def certificate_values(m, rules, active):
    words, blocks, singles, pairs = G.universe()
    groups = defaultdict(set)
    for r in rules:
        groups[normalize(r)].add(r)
    supplied = set()
    selected = set()
    for group in groups.values():
        if len(group) >= 4:
            bid = next(i for i, b in enumerate(blocks) if b <= group)
            selected.add(bid)
            supplied.update(blocks[bid])
    extras = rules - supplied
    assert len(selected) == 52 and len(extras) <= 2
    val = [None] * len(m.model.proto.variables)
    for i, v in enumerate(m.blocks): val[v.index] = int(i in selected)
    for r, v in m.singles.items(): val[v.index] = int(r in extras)
    for r, v in m.present.items(): val[v.index] = int(r in rules)
    for i, (a, b) in enumerate(pairs): val[m.orientation[i].index] = int(a in active)
    for c, v in m.flags.items(): val[v.index] = int(len(rules_of_cycle(c) & rules) >= 6)
    assert all(v in (0, 1) for v in val)
    return val, selected, extras

def evaluate_constraints(m, val):
    def lit(j): return val[j] if j >= 0 else 1 - val[-j - 1]
    bad = []
    for i, c in enumerate(m.model.proto.constraints):
        if not all(lit(j) for j in c.enforcement_literal): continue
        if c.has_at_most_one(): okay = sum(lit(j) for j in c.at_most_one.literals) <= 1
        elif c.has_linear():
            result = sum(val[j] * coef for j, coef in terms_of(c).items())
            d = list(c.linear.domain)
            okay = any(d[j] <= result <= d[j+1] for j in range(0, len(d), 2))
        else: raise AssertionError('Unexpected constraint type')
        if not okay: bad.append(i)
    return bad

def main():
    # Independently enumerate raw valid ordered rules and cyclic-word slots.
    own_words = {normalize(p) for p in permutations(range(1, 9), 4)}
    own_rules = set(permutations(range(1, 9), 5))
    five_groups = {rules_of_cycle(p) for p in own_rules}
    own_blocks = {group - {r} for group in five_groups for r in group}
    own_pairs = {frozenset((frozenset(w), LABELS - frozenset(w))) for w in own_words}
    words, blocks, singles, pairs = G.universe()
    assert own_words == set(words) and own_rules == set(singles)
    assert own_blocks == set(blocks)
    assert own_pairs == {frozenset(pair) for pair in pairs}
    assert len(own_words) == 420 and len(own_rules) == len(own_blocks) == 6720
    assert len(own_pairs) == 35 and len(five_groups) == 1344
    # There are exactly 35 independent bits, hence all 2**35 orientations.
    assert len({s for pair in pairs for s in pair}) == 70

    own_six = independent_cycles(6)
    own_seven = independent_cycles(7)
    assert dict(own_six) == dict(G.cycle_data(6))
    assert dict(own_seven) == dict(G.cycle_data(7))
    normalized_cases = 0
    for c, rr in own_seven:
        for missing in range(7):
            shift = (missing + 1) % 7
            d = c[shift:] + c[:shift]
            mapping = {x: i+1 for i, x in enumerate(d)}
            mapping[next(iter(LABELS - set(d)))] = 8
            ignored = (c[missing:] + c[:missing])
            ignored = ignored[:4] + (ignored[-1],)
            moved = {tuple(mapping[x] for x in r) for r in rr - {ignored}}
            assert moved == set(G.CANONICAL_SIX)
            normalized_cases += 1
    assert normalized_cases == 40320

    # Check every generated constraint against an independently assembled RHS.
    m = G.build(target=4, canonical=True)
    assert m.model.validate() == ''
    columns = defaultdict(list)
    rule_sources = defaultdict(list)
    for i, block in enumerate(blocks):
        for r in block:
            columns[normalize(r[:4])].append(m.blocks[i].index)
            rule_sources[r].append(m.blocks[i].index)
    for r, v in m.singles.items():
        columns[normalize(r[:4])].append(v.index)
        rule_sources[r].append(v.index)
    cs = iter(m.model.proto.constraints)
    for w in words:
        c = next(cs)
        assert c.has_at_most_one() and not c.enforcement_literal
        assert sorted(c.at_most_one.literals) == sorted(columns[w])
    check_linear(next(cs), {v.index: 1 for v in m.blocks}, 52, 52)
    check_linear(next(cs), {v.index: 1 for v in m.singles.values()}, MIN, 2)
    for i, (a, b) in enumerate(pairs):
        lhs = Counter(j for w in words if frozenset(w) == a for j in columns[w])
        lhs[m.orientation[i].index] -= 6
        check_linear(next(cs), lhs, MIN, 0)
        lhs = Counter(j for w in words if frozenset(w) == b for j in columns[w])
        lhs[m.orientation[i].index] += 6
        check_linear(next(cs), lhs, MIN, 6)
    for r, p in m.present.items():
        lhs = {v: -1 for v in rule_sources[r]}
        lhs[p.index] = 1
        assert len(rule_sources[r]) == 5
        check_linear(next(cs), lhs, 0, 0)
    for c, rr in G.cycle_data(6):
        check_linear(next(cs), {m.present[r].index: 1 for r in rules_of_cycle(c)}, MIN, 4)
    for c, rr in G.cycle_data(7):
        z = m.flags[c]
        lhs = {m.present[r].index: 1 for r in rules_of_cycle(c)}
        check_linear(next(cs), lhs, 6, MAX, (z.index,))
        check_linear(next(cs), lhs, MIN, 5, (-z.index - 1,))
    check_linear(next(cs), {v.index: 1 for v in m.flags.values()}, 4, MAX)
    for r in G.CANONICAL_SIX:
        check_linear(next(cs), {m.present[r].index: 1}, 1, 1)
    assert next(cs, None) is None

    controls = []
    specs = [
        ('baseline', H/'global_orientation_control_baseline208.normalized.json', 3),
        ('standard3_positive', H/'global_orientation_control_standard3_r6zero.normalized.json', 1),
        ('standard3_R6one_negative', H/'global_orientation_control_standard3_r6one_negative.normalized.json', 1)]
    for label, path, target in specs:
        data = json.loads(path.read_text())
        rules = {(a, *history, t) for a, history, t in data['rules']}
        active = {frozenset(s) for s in data['active_supports']}
        control = G.build(target, True)
        val, selected, extras = certificate_values(control, rules, active)
        bad = evaluate_constraints(control, val)
        if label == 'standard3_R6one_negative':
            assert len(bad) == 1
            violated = control.model.proto.constraints[bad[0]]
            assert violated.has_linear() and list(violated.linear.domain) == [MIN, 4]
        else: assert not bad
        # The exact supplied block / singleton contract is tested, not just presence.
        fixed = sorted(selected)[:6]
        before = len(control.model.proto.constraints)
        fixed_result = control.fix_core([blocks[i] for i in fixed], extras)
        added = list(control.model.proto.constraints)[before:]
        assert len(added) == len(fixed) + len(extras)
        assert all(len(c.linear.vars) == 1 and list(c.linear.domain) == [1, 1] for c in added)
        assert evaluate_constraints(control, val) == bad
        controls.append({'label': label, 'rules': len(rules), 'selected_blocks': len(selected),
                         'extras': len(extras), 'violated_constraints': bad,
                         'fix_core': fixed_result})
    out = {'status': 'PASS', 'scope': __doc__, 'Solve_called': False,
           'source_sha256': hashlib.sha256((H/'global_orientation_witness_completion.py').read_bytes()).hexdigest(),
           'universe': {'words': len(words), 'valid_rules': len(singles), 'five_cycles': len(five_groups),
                        'blocks': len(blocks), 'support_pairs': len(pairs),
                        'orientation_count': 2**35},
           'normalization_cases_checked': normalized_cases,
           'model_variables': len(m.model.proto.variables),
           'all_constraints_independently_checked': len(m.model.proto.constraints),
           'controls': controls,
           'fix_core_contract': 'extras require selected singleton supplier variables, not presence alone; complete supplier-core enumeration is required.',
           'R8_exclusion': 'For every 8-cycle, opposite four-prefix supports are complements. At most one of each of four pairs is active, so correct count <=4 <7.',
           'conclusion': 'Complete within the stated complementary-orientation 52-block plus <=2 singleton representation; canonical normalization is lossless whenever R7>=1.',
           'seconds': time.monotonic() - START}
    output = H/'global_orientation_independent_static_review_20261018.json'
    output.write_text(json.dumps(out, indent=2), encoding='utf-8')
    print(json.dumps(out, indent=2))

if __name__ == '__main__':
    main()
