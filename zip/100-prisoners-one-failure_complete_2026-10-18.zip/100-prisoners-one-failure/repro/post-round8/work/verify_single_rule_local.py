"""Independent Cartesian-product check of the one-rule local lemma.
No imports from the structural generator or DFS enumeration.
"""
from itertools import combinations,permutations,product
from pathlib import Path
import json
def rot(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def rr(c):
    return tuple((c[i],c[(i+1)%len(c)],c[(i+2)%len(c)],c[(i+3)%len(c)],c[(i-1)%len(c)]) for i in range(len(c)))
L=range(1,8);blocks=[];options={}
for support in combinations(L,5):
    for p in permutations(support[1:]):
        c=(support[0],)+p
        for omitted in c:
            rules=frozenset(r for r in rr(c) if r[0]!=omitted)
            ss=frozenset(rot(r[:4]) for r in rules)
            i=len(blocks);blocks.append((c,omitted,rules,ss))
            for r in rules:options.setdefault(r,[]).append(i)
r=(1,2,3,4,5);cs=[(1,2,3,4,6,7,5),(1,2,3,4,7,6,5)];reserved=rot(r[:4])
ws=[];records=[]
for c in cs:
    found=set()
    for ignore in rr(c):
        if ignore==r:continue
        needed=[q for q in rr(c) if q not in (r,ignore)]
        choices=[[b for b in options[q] if reserved not in blocks[b][3]] for q in needed]
        for selection in product(*choices):
            ids=frozenset(selection);used=[]
            for b in ids:used.extend(blocks[b][3])
            if len(used)==len(set(used)):found.add(ids)
    assert len(found)==21
    ws.append(found)
    records.append([dict(blocks=[dict(cycle=blocks[b][0],omitted_prisoner=blocks[b][1]) for b in sorted(w)],slots=sorted(set().union(*(blocks[b][3] for b in w)))) for w in sorted(found,key=lambda x:tuple(sorted(x)))])
hist={}
for a in ws[0]:
    for b in ws[1]:
        assert not a&b
        aa=set().union(*(blocks[i][3] for i in a));bb=set().union(*(blocks[i][3] for i in b))
        k=len(aa&bb);hist[k]=hist.get(k,0)+1
assert min(hist)==6 and sum(hist.values())==441
result=dict(status='PASS',canonical_rule=r,cycles=cs,all_blocks=len(blocks),witness_counts=[len(w) for w in ws],pair_checks=441,collision_histogram=hist,minimum_conflicting_slots=min(hist),found_compatible_pair=False,witnesses=records)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print({k:v for k,v in result.items() if k!='witnesses'})

# Separate check for the 12 possible useful second rules.  A rule not
# correct for either cycle can only reserve another slot, never help.
def cartesian(c,external):
    found=set();reserved={rot(q[:4]) for q in external}
    for ignore in rr(c):
        if ignore in external:continue
        needed=[q for q in rr(c) if q not in external and q!=ignore]
        choices=[[b for b in options[q] if not blocks[b][3]&reserved] for q in needed]
        for selection in product(*choices):
            ids=frozenset(selection);used=[s for b in ids for s in blocks[b][3]]
            if len(used)==len(set(used)):found.add(ids)
    return found
second_records=[]
for second in sorted((set(rr(cs[0]))|set(rr(cs[1])))-{r}):
    w0=cartesian(cs[0],{r,second});w1=cartesian(cs[1],{r,second});compatible=0
    for a in w0:
        for b in w1:
            chosen=a|b;used=[s for bid in chosen for s in blocks[bid][3]]
            if len(used)!=len(set(used)):continue
            supplied=frozenset().union(*(blocks[bid][2] for bid in chosen))
            before=[len((supplied|{second})&set(rr(c))) for c in cs]
            if max(before)>=6:continue
            compatible+=1
    second_records.append(dict(second_rule=second,witness_counts=[len(w0),len(w1)],compatible=compatible))
assert len(second_records)==12 and all(x['compatible']==0 for x in second_records)
two=dict(status='PASS',method='independent Cartesian products; all 12 useful second rules',canonical_first_rule=r,cases=second_records,found_compatible_pair=False)
Path(__file__).with_name('verify_two_rule_synergy.json').write_text(json.dumps(two,indent=2),encoding='utf-8')
print('two-rule canonical check: 12 cases, no compatible pair')
