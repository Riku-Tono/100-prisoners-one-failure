"""Independent regenerated full-star rows + R6-zero flexible-hole DLX.

Complete every critical core in the finite3735-core list with52 four-rule
blocks. The e critical extra rules are fixed; exactly2-e other columns may
be holes and can be padded by target8 without affecting any old7-label
long-cycle success. New target4 certificates require40320-layout audit.
Node/time limits produce UNKNOWN and never authorize a core exclusion.
No CP-SAT or imports from the prior completion engines are used.
"""
from pathlib import Path
from itertools import permutations,combinations
from collections import defaultdict,Counter
import argparse,json,time,hashlib
from independent_audit import audit
H=Path(__file__).resolve().parent
def canon(w):
    w=tuple(w);j=w.index(min(w));return w[j:]+w[:j]
def correct(c):
    n=len(c);return tuple((c[i],c[(i+1)%n],c[(i+2)%n],c[(i+3)%n],c[(i+n-1)%n]) for i in range(n))
WORDS=sorted({canon(w) for w in permutations(range(1,8),4)})
rawblocks=set()
for c in permutations(range(1,8),5):
    if c[0]!=min(c):continue
    rr=correct(c)
    for omitted in range(5):rawblocks.add(frozenset(rr[:omitted]+rr[omitted+1:]))
RULES=sorted(rawblocks,key=lambda b:tuple(sorted(b)))
ROWS=[tuple(sorted(canon(r[:4]) for r in b)) for b in RULES]
assert len(WORDS)==210 and len(RULES)==2520 and all(len(set(w))==4 for w in ROWS)
SIX=[correct((s[0],)+p) for s in combinations(range(1,8),6) for p in permutations(s[1:])]
R6INC=defaultdict(list)
for i,rr in enumerate(SIX):
    for r in rr:R6INC[r].append(i)
DELTA=[]
for b in RULES:
    d=Counter(i for r in b for i in R6INC[r])
    assert len(d)==8 and max(d.values())==1
    DELTA.append(tuple(d))
CATALOGUE_SHA=hashlib.sha256(json.dumps([sorted(b) for b in RULES],separators=(',',':')).encode()).hexdigest()

class Limit(Exception):pass
class DLX:
    def __init__(self):
        n=len(WORDS);self.left=list(range(-1,n));self.left[0]=n
        self.right=list(range(1,n+2));self.right[n]=0
        self.up=list(range(n+1));self.down=list(range(n+1));self.col=list(range(n+1))
        self.size=[0]*(n+1);self.row=[-1]*(n+1);self.row_nodes=[];self.active=set(range(1,n+1))
        self.headers={w:i+1 for i,w in enumerate(WORDS)}
        for bid,words in enumerate(ROWS):
            ns=[]
            for w in words:
                c=self.headers[w];k=len(self.col);ns.append(k)
                self.col.append(c);self.row.append(bid);self.up.append(self.up[c]);self.down.append(c)
                self.down[self.up[c]]=k;self.up[c]=k;self.size[c]+=1
                self.left.append(k);self.right.append(k)
            for a,b in zip(ns,ns[1:]+ns[:1]):self.right[a]=b;self.left[b]=a
            self.row_nodes.append(ns)
    def cover(self,c):
        assert c in self.active;self.active.remove(c)
        self.right[self.left[c]]=self.right[c];self.left[self.right[c]]=self.left[c]
        i=self.down[c]
        while i!=c:
            j=self.right[i]
            while j!=i:
                self.down[self.up[j]]=self.down[j];self.up[self.down[j]]=self.up[j]
                self.size[self.col[j]]-=1;j=self.right[j]
            i=self.down[i]
    def uncover(self,c):
        i=self.up[c]
        while i!=c:
            j=self.left[i]
            while j!=i:
                self.size[self.col[j]]+=1;self.down[self.up[j]]=j;self.up[self.down[j]]=j;j=self.left[j]
            i=self.up[i]
        self.right[self.left[c]]=c;self.left[self.right[c]]=c;self.active.add(c)
    def search(self,selected,holes,budget):
        self.nodes+=1
        if self.nodes>self.node_limit:raise Limit('NODE_LIMIT')
        if self.nodes%256==0 and time.monotonic()>self.deadline:raise Limit('TIME_LIMIT')
        if not self.right[0]:
            if budget:return False
            self.answer=selected[:];self.holes=holes[:];return True
        c=self.right[0];j=c;zeros=0
        while j:
            if self.size[j]<self.size[c]:c=j
            zeros+=self.size[j]==0
            if zeros>budget:return False
            j=self.right[j]
        if not self.size[c] and not budget:return False
        self.cover(c);i=self.down[c];found=False
        while i!=c:
            b=self.row[i];delta=DELTA[b]
            if all(self.counts[k]<4 for k in delta):
                for k in delta:self.counts[k]+=1
                j=self.right[i]
                while j!=i:self.cover(self.col[j]);j=self.right[j]
                found=self.search(selected+[b],holes,budget)
                j=self.left[i]
                while j!=i:self.uncover(self.col[j]);j=self.left[j]
                for k in delta:self.counts[k]-=1
                if found:break
            i=self.down[i]
        if not found and budget:found=self.search(selected,holes+[c],budget-1)
        self.uncover(c);return found
    def run(self,mandatory,extras,seconds,node_limit):
        mandatory=set(mandatory);extras=set(map(tuple,extras));assert len(extras)<=2
        used=[w for b in mandatory for w in ROWS[b]];fixedholes={canon(r[:4]) for r in extras}
        assert len(used)==len(set(used)) and len(fixedholes)==len(extras) and not set(used)&fixedholes
        self.counts=[0]*840
        for b in mandatory:
            for k in DELTA[b]:self.counts[k]+=1
        for r in extras:
            for k in R6INC[r]:self.counts[k]+=1
        assert max(self.counts)<=4
        removed=[]
        for w in sorted(fixedholes):c=self.headers[w];self.cover(c);removed.append(c)
        for b in sorted(mandatory):
            cc=[self.col[k] for k in self.row_nodes[b]];assert all(c in self.active for c in cc)
            for c in cc:self.cover(c);removed.append(c)
        self.nodes=0;self.answer=None;self.holes=None;self.node_limit=node_limit;self.deadline=time.monotonic()+seconds
        try:found=self.search([],[],2-len(extras))
        except Limit as err:return 'UNKNOWN_'+str(err),self.nodes,None,None
        for c in reversed(removed):self.uncover(c)
        assert len(self.active)==210
        holes=[WORDS[c-1] for c in self.holes] if found else None
        return 'FOUND' if found else 'EXHAUSTED_NO_COMPLETION',self.nodes,self.answer,holes

def save(path,value):Path(path).write_text(json.dumps(value,indent=2),encoding='utf-8')
def export_and_audit(path,mandatory,extras,additional,holes,minimum):
    blocks=set(mandatory)|set(additional);single=set(map(tuple,extras))|{tuple(w)+(8,) for w in holes}
    rules=set().union(*(RULES[b] for b in blocks))|single
    assert len(blocks)==52 and len(single)==2 and len(rules)==210
    allslots=[canon(r[:4]) for r in rules];assert len(allslots)==len(set(allslots))==210
    save(path,{'n':8,'rules':[[r[0],list(r[1:4]),r[4]] for r in sorted(rules)],'selected_block_ids':sorted(blocks),'extra_rules':sorted(single)})
    checked=audit(path)
    assert checked['placements']==40320 and checked['lost_cf']==0 and checked['rescued_cycles']['5']==52 and checked['rescued_cycles']['6']==0
    assert checked['wins']>=minimum
    if minimum>=15052:assert checked['rescued_cycles']['7']>=4
    save(path.with_suffix('.audit.json'),checked);return checked

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--wall-seconds',type=float,default=300)
    p.add_argument('--per-core-seconds',type=float,default=2);p.add_argument('--node-limit',type=int,default=200000)
    p.add_argument('--prefix',default='fullstar_finite_core_completion');a=p.parse_args()
    source=H/'fullstar_fixed_core_enumeration.json';raw=source.read_bytes();data=json.loads(raw)
    assert data['block_catalogue_sha256']==CATALOGUE_SHA and data['fixed_core']==sorted(data['fixed_core'])
    assert data['flipped_supports']==[] and data['R6']==0 and data['R7_target']==4 and data['required_completed_blocks']==52
    cores=data['minimal_records'];assert len(cores)==3735
    start=time.monotonic();deadline=start+a.wall_seconds;matrix=DLX()
    baseline=json.loads((H/'inputs/baseline15051.rules.json').read_text());brules={(x,*h,t) for x,h,t in baseline['rules']}
    chosen={i for i,b in enumerate(RULES) if b<=brules};assert len(chosen)==52
    fixed=set(data['fixed_core']);fixed.update(sorted(chosen-fixed)[:39-len(fixed)]);assert len(fixed)==39 and fixed<=chosen
    holes=set(WORDS)-set().union(*(set(ROWS[b]) for b in chosen));extras={w+(8,) for w in holes}
    st,nodes,more,h=matrix.run(fixed,extras,min(5,deadline-time.monotonic()),a.node_limit)
    assert st=='FOUND' and len(more)==13
    positive=export_and_audit(H/f'{a.prefix}_positive.rules.json',fixed,extras,more,h,15051)
    out={'scope':__doc__,'source':str(source),'source_sha256':hashlib.sha256(raw).hexdigest(),'block_catalogue_sha256':CATALOGUE_SHA,'fixed_core':data['fixed_core'],'total_cores':len(cores),'positive_control':{'status':st,'retained':39,'recovered':13,'nodes':nodes,'direct_audit':positive},'records':[],'status':'RUNNING'}
    resultpath=H/f'{a.prefix}_result.json'
    if positive['wins']>=15052:
        out['status']='FOUND_IN_POSITIVE_CONTROL';save(resultpath,out);print(out['status'],positive['wins']);return
    for index,core in enumerate(cores):
        remaining=deadline-time.monotonic()
        if remaining<=0:out['status']='WALL_LIMIT';break
        st,nodes,more,holes=matrix.run(core['core_blocks'],core['critical_extra_rules'],min(a.per_core_seconds,remaining),a.node_limit)
        rec={'index':index,'status':st,'nodes':nodes,'core_blocks':len(core['core_blocks']),'critical_extras':len(core['critical_extra_rules'])}
        if st=='FOUND':
            path=H/f'{a.prefix}_found_{index}.rules.json'
            rec['certificate']=str(path);rec['direct_audit']=export_and_audit(path,core['core_blocks'],core['critical_extra_rules'],more,holes,15052)
            out['status']='FOUND_INDEPENDENTLY_VERIFIED'
        elif st.startswith('UNKNOWN'):matrix=DLX()
        else:assert st=='EXHAUSTED_NO_COMPLETION'
        out['records'].append(rec)
        out['counts']=dict(Counter(r['status'] for r in out['records']));out['seconds']=time.monotonic()-start
        out['unprocessed_indices']=list(range(index+1,len(cores)));out['unknown_indices']=[r['index'] for r in out['records'] if r['status'].startswith('UNKNOWN')]
        if index%25==0 or st=='FOUND':save(resultpath,out)
        if index%250==0 or st=='FOUND':print(index,st,nodes,'elapsed',round(out['seconds'],3),out['counts'],flush=True)
        if st=='FOUND':break
    else:out['status']='ALL_CORES_PROCESSED'
    out['seconds']=time.monotonic()-start;out['counts']=dict(Counter(r['status'] for r in out['records']))
    out['unprocessed_indices']=list(range(len(out['records']),len(cores)));out['unknown_indices']=[r['index'] for r in out['records'] if r['status'].startswith('UNKNOWN')]
    out['all_core_coverage']=len(out['records'])==len(cores)
    out['exhausted_fixed_core_branch']=out['all_core_coverage'] and not out['unknown_indices'] and out['counts'].get('EXHAUSTED_NO_COMPLETION')==len(cores)
    if out['exhausted_fixed_core_branch']:out['status']='EXHAUSTED_NO_TARGET4_WITH_FIXED_18_CORE'
    save(resultpath,out);print('FINAL',out['status'],out['counts'],out['seconds'],'unprocessed',len(out['unprocessed_indices']),'unknown',len(out['unknown_indices']),flush=True)
if __name__=='__main__':main()
