"""Block-only seven-cycle witness clique check; regenerated block input.
This proves an upper bound for a local relaxation, not a completed score.
"""
from completion_dlx_recheck import RULES,ROWS,correct,rotate_min,WORDS
from itertools import permutations,combinations
from collections import defaultdict,Counter
from pathlib import Path
import json
inc=defaultdict(set);rows=list(map(frozenset,ROWS))
for i,rr in enumerate(RULES):
    for r in rr:inc[r].add(i)
parents=[];witnesses=[];cycles=[]
for tail in permutations(range(2,8)):
    c=(1,)+tail;rr=frozenset(correct(c));found=set()
    for ignore in rr:
        def visit(todo,occupied,chosen):
            if not todo:found.add(frozenset(chosen));return
            options=[]
            for r in todo:
                bs=[b for b in inc[r] if not occupied&rows[b]]
                if not bs:return
                options.append((len(bs),r,bs))
            for b in min(options)[2]:visit(todo-RULES[b],occupied|rows[b],chosen|{b})
        visit(rr-{ignore},frozenset(),frozenset())
    if found:
        for w in found:witnesses.append(w);parents.append(len(cycles))
        cycles.append(c)
occupied=[frozenset().union(*(rows[i] for i in w)) for w in witnesses]
adj=[set() for w in witnesses];edges=0
for i,j in combinations(range(len(witnesses)),2):
    if parents[i]==parents[j]:continue
    shared=frozenset().union(*(rows[b] for b in witnesses[i]&witnesses[j]))
    if occupied[i]&occupied[j]!=shared:continue
    adj[i].add(j);adj[j].add(i);edges+=1
triangles=k4=0
for i in range(len(adj)):
    for j in (j for j in adj[i] if j>i):
        for k in (k for k in adj[i]&adj[j] if k>j):
            triangles+=1;k4+=sum(q>k for q in adj[i]&adj[j]&adj[k])
result=dict(cycles=len(cycles),witnesses=len(witnesses),witness_sizes=dict(Counter(map(len,witnesses))),edges=edges,triangles=triangles,K4=k4,status='EXHAUSTED',scope='standard three-flip, four-rule blocks only; local packing relaxation')
assert (len(cycles),len(witnesses),edges,triangles,k4)==(144,648,32076,8736,0)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(result)
