"""Split the45 two-singleton cores into three descending15-core batches."""
from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent
source=H/'canonical_six_witness_preparation.json';raw=source.read_bytes();d=json.loads(raw)
cores=[r for r in d['records'] if r['extra_count']==2]
assert len(cores)==45 and [r['representative_index'] for r in cores]==list(range(25,70))
cores=list(reversed(cores))
for batch in range(3):
    selected=cores[15*batch:15*(batch+1)]
    out={'scope':'Only canonical six-correct local cores are fixed; all remaining support orientations are free. No extra constraints beyond the core and inherited global52+<=2,R6zero,target4 model.','source':str(source),'source_sha256':hashlib.sha256(raw).hexdigest(),'batch':batch+1,'extra_count':2,'representative_indices':[r['representative_index'] for r in selected],'records':selected}
    path=H/f'canonical_six_extra2_batch_{batch+1:02d}.json';path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(path.name,out['representative_indices'])
