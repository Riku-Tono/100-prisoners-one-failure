"""Seed-specialized CP-SAT completion for R5=52,R6=0,R7>=4.

Scope: standard-three-flip, 46 old four-rule blocks + 2 extra rules.
Mandatory 2x7-cycle witnesses are constants, so incompatible columns/rows and
impossible rescue cycles are removed before constructing the CP model.
Strengthening uses independently checked lemmas: completed old block cores
rescue <=2 sevens, each extra rule newly rescues at most one seven even when
one other extra is already present, and distinct sevens share <=1 correct
rule. To attain four, the two new rescues each use exactly one extra rule and
5 block rules. If one new rescue used both extras, any second new rescue
would either make one extra newly rescue two cycles, or would also use both
extras, contradicting the shared-rule intersection bound.
"""
import sys,json,time
from pathlib import Path
from collections import defaultdict,Counter
from itertools import combinations,permutations
sys.path.insert(0,r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
from ortools.sat.python import cp_model
from completion_dlx_recheck import RULES,ROWS,WORDS,correct,rotate_min
H=Path(__file__).resolve().parent
CW={k:[correct((s[0],)+p) for s in combinations(range(1,8),k) for p in permutations(s[1:])] for k in (6,7)}
CS=[(1,)+p for p in permutations(range(2,8))]
blockrows=list(map(frozenset,ROWS));wordset=set(WORDS)

def build(seed,local=False):
    mandatory=set(seed['blocks']);fixedrules=set().union(*(RULES[b] for b in mandatory))
    occupied=set().union(*(blockrows[b] for b in mandatory))
    assert len(occupied)==4*len(mandatory)
    remaining=wordset-occupied
    permitted=[b for b in range(len(RULES)) if not occupied&blockrows[b]]
    inc=defaultdict(list)
    for b in permitted:
        for r in RULES[b]:inc[r].append(b)
    basecycles=[rr for rr in CW[7] if sum(r in fixedrules for r in rr)>=6]
    assert len(basecycles)==2
    # A filled column with a different rule is a permanent failure.  At most
    # one such column may occur in any potentially rescued seven-cycle.
    candidates=[]
    for c,rr in zip(CS,CW[7]):
        if rr in basecycles:continue
        if sum(r not in fixedrules and rotate_min(r[:4]) not in remaining for r in rr)>1:continue
        candidates.append((c,rr))
    useful={r for c,rr in candidates for r in rr if rotate_min(r[:4]) in remaining}
    m=cp_model.CpModel();bs={b:m.new_bool_var(f'b{b}') for b in permitted}
    ss={r:m.new_bool_var('s'+str(r)) for r in sorted(useful)}
    columns=defaultdict(list)
    for b,v in bs.items():
        for w in blockrows[b]:columns[w].append(v)
    for r,v in ss.items():columns[rotate_min(r[:4])].append(v)
    for w in remaining:
        if local:m.add_at_most_one(columns[w])
        else:m.add_exactly_one(columns[w])
    if local:m.add(sum(bs.values())<=46-len(mandatory))
    else:m.add(sum(bs.values())==46-len(mandatory))
    m.add(sum(ss.values())==2)
    def bn(rr):return sum(r in fixedrules for r in rr)+sum(bs[b] for r in rr for b in inc[r])
    def sn(rr):return sum(ss[r] for r in rr if r in ss)
    for rr in CW[6]:
        if sum(r in fixedrules or bool(inc[r]) or r in ss for r in rr)>=5:
            m.add(bn(rr)+sn(rr)<=4)
    zs={}; active=[]
    for c,rr in candidates:
        if sum(r in fixedrules or bool(inc[r]) or r in ss for r in rr)<6:continue
        z=m.new_bool_var('z'+str(c));zs[c]=z;active.append((c,rr,z))
        m.add(bn(rr)<=5)
        m.add(bn(rr)==5).only_enforce_if(z)
        m.add(sn(rr)==1).only_enforce_if(z)
    m.add(sum(zs.values())==2)
    for r,v in ss.items():
        zlist=[z for c,rr,z in active if r in rr]
        m.add(sum(zlist)==1).only_enforce_if(v)
    return m,bs,ss,{'mandatory':len(mandatory),'compatible_blocks':len(bs),'single_choices':len(ss),'candidate_new_cycles':len(zs),'remaining_slots':len(remaining)}

def export(s,bs,ss,seed,index):
    raw=json.loads((H/'inputs/new15051.rules.json').read_text())
    rr={(a,*h,t) for a,h,t in raw['rules']};groups=defaultdict(set)
    for r in rr:groups[rotate_min((r[-1],)+r[:4])].add(r)
    new=set().union(*(g for g in groups.values() if len(g)==4 and any(8 in r for r in g)))
    selected=set(seed['blocks'])|{b for b,v in bs.items() if s.value(v)}
    full=new|set().union(*(RULES[b] for b in selected))|{r for r,v in ss.items() if s.value(v)}
    assert len(full)==210
    path=H/f'agent_seed_pair_reduced_found_{index}.rules.json'
    path.write_text(json.dumps({'n':8,'rules':[[r[0],list(r[1:4]),r[4]] for r in sorted(full)],'seed_index':index},indent=2),encoding='utf-8')
    return str(path)

def main():
    seeds=json.loads((H/'witness_pair_seeds.json').read_text())['seeds']
    start=int(sys.argv[1]) if len(sys.argv)>1 else 0
    count=int(sys.argv[2]) if len(sys.argv)>2 else 20
    seconds=float(sys.argv[3]) if len(sys.argv)>3 else 3
    local='--local' in sys.argv;records=[];t0=time.monotonic()
    for index in range(start,min(start+count,len(seeds))):
        tbuild=time.monotonic();m,bs,ss,stats=build(seeds[index],local);buildseconds=time.monotonic()-tbuild
        s=cp_model.CpSolver();s.parameters.num_search_workers=1;s.parameters.max_time_in_seconds=seconds
        s.parameters.random_seed=index+1
        st=s.solve(m);rec={'index':index,'status':s.status_name(st),'solve_seconds':s.wall_time,'build_seconds':buildseconds,'branches':s.num_branches,**stats}
        if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            if local:rec['local_witness']={'blocks':sorted(set(seeds[index]['blocks'])|{b for b,v in bs.items() if s.value(v)}),'extras':[r for r,v in ss.items() if s.value(v)]}
            else:rec['certificate']=export(s,bs,ss,seeds[index],index)
        records.append(rec)
        out={'scope':__doc__,'local_relaxation':local,'seed_start':start,'total_seed_orbits':len(seeds),'records':records,'counts':dict(Counter(r['status'] for r in records)),'seconds':time.monotonic()-t0}
        suffix='_local' if local else ''
        (H/f'agent_seed_pair_reduced_{start}{suffix}.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        print(rec,flush=True)
        if 'certificate' in rec:break
    print('FINAL',out['counts'],out['seconds'],flush=True)
if __name__=='__main__':main()
