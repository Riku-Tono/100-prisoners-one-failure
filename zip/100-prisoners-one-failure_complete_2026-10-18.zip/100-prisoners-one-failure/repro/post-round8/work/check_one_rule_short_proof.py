"""Audit ChatGPT's short proof from regenerated unrestricted blocks."""
from itertools import combinations,permutations
from pathlib import Path
import json
def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def rules(c):
    n=len(c);return tuple((c[i],c[(i+1)%n],c[(i+2)%n],c[(i+3)%n],c[(i-1)%n]) for i in range(n))
allblocks=[]
for s in combinations(range(1,8),5):
    for p in permutations(s[1:]):
        c=(s[0],)+p
        for target in c:
            rs=frozenset(r for r in rules(c) if r[4]!=target)
            allblocks.append((c,target,rs,frozenset(canon(r[:4]) for r in rs)))
r=(1,2,3,4,7);A=(1,2,3,4,5,6,7);B=(1,2,3,4,6,5,7)
ar={q[0]:q for q in rules(A)};br={q[0]:q for q in rules(B)}
assert ar[7][:4]==br[7][:4] and ar[7][4]!=br[7][4]
occupied={canon(r[:4])};selected=[];supplied={r};steps=[]
expected=[((1,2,3,4,5),5),((2,3,4,5,6),6),((3,4,5,6,7),7),((1,4,5,6,7),1),((1,2,5,6,7),2)]
for prisoner in range(2,7):
    candidates=[b for b in allblocks if ar[prisoner] in b[2]]
    compatible=[b for b in candidates if not b[3]&occupied]
    assert len(candidates)==4 and len(compatible)==1
    chosen=compatible[0];assert chosen[:2]==expected[prisoner-2]
    selected.append(chosen);steps.append(dict(prisoner=prisoner,cycle=chosen[0],omitted_target=chosen[1],candidate_count=4,compatible_count=1))
    occupied.update(chosen[3]);supplied.update(chosen[2])
assert len(supplied&set(rules(A)))==6
fail=[]
for prisoner in (2,5):
    slot=canon(br[prisoner][:4]);occupants=[q for q in supplied if canon(q[:4])==slot]
    assert len(occupants)==1 and occupants[0]!=br[prisoner]
    fail.append(dict(prisoner=prisoner,correct_rule=br[prisoner],slot=slot,conflicting_fixed_rule=occupants[0]))
out=dict(status='PASS',external_rule=r,cycles=[A,B],same_history_conflict_prisoner=7,forced_steps=steps,unrepairable_B_failures=fail)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(out)
