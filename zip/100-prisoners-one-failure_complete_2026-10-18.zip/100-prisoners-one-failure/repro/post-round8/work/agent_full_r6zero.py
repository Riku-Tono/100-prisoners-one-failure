"""Independent standard3flip full block model, exact R6 zero."""
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict,Counter
import sys,time,json
sys.path.insert(0,r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
from ortools.sat.python import cp_model
H=Path(__file__).resolve().parent
L=range(1,9)
def canon(x):
 x=tuple(x);k=x.index(min(x));return x[k:]+x[:k]
def cycles(k):
 for s in combinations(L,k):
  for t in permutations(s[1:]):yield(s[0],)+t
def rules(c):
 k=len(c);return tuple((c[i],c[(i+1)%k],c[(i+2)%k],c[(i+3)%k],c[(i-1)%k])for i in range(k))
S={frozenset(t)for t in combinations(range(1,8),4)}
for t in [(1,2,3,4),(1,2,3,5),(1,2,3,6)]:S.remove(frozenset(t));S.add(frozenset(L)-frozenset(t))
words={c for c in cycles(4)if frozenset(c)in S}
blocks=[]
for c in cycles(5):
 rs=rules(c)
 for omit in range(5):
  b=rs[:omit]+rs[omit+1:]
  if all(canon(r[:4])in words for r in b):blocks.append(b)
print("model words,blocks",len(words),len(blocks),flush=True);assert len(words)==210
sevens=[(c,tuple(r for r in rules(c)if canon(r[:4])in words))for c in cycles(7)]
sevens=[(c,rs)for c,rs in sevens if len(rs)>=6]
single_options=set().union(*(set(rs)for c,rs in sevens))
control = len(sys.argv)>3 and sys.argv[3]=='control'
witness = len(sys.argv)>3 and sys.argv[3]=='witness'
if control:
 raw=json.loads((H/'r6zero_base.rules.json').read_text());prebase={(a,*h,t)for a,h,t in raw['rules']};holes=sorted(words-{canon(r[:4])for r in prebase});extras={w+(8,)for w in holes};single_options|=extras
start=time.monotonic();m=cp_model.CpModel();B=[m.NewBoolVar('b%d'%i)for i in range(len(blocks))]
by_rule=defaultdict(list);by_slot=defaultdict(list)
for v,b in zip(B,blocks):
 for r in b:by_rule[r].append(v);by_slot[canon(r[:4])].append(v)
Y={r:m.NewBoolVar('y')for r in sorted(single_options)}
for r,y in Y.items():by_rule[r].append(y);by_slot[canon(r[:4])].append(y)
for w in words:m.Add(sum(by_slot[w])<=1)
m.Add(sum(B)==52);m.Add(sum(Y.values())<=2)
P={r:m.NewBoolVar('p')for r in by_rule}
for r,v in P.items():m.Add(v==sum(by_rule[r]))
nsix=0
for c in cycles(6):
 terms=[P[r]for r in rules(c)if r in P]
 if len(terms)>=5:m.Add(sum(terms)<=4);nsix+=1
Z={}
for c,rs in sevens:
 terms=[P[r]for r in rs if r in P]
 if len(terms)<6:continue
 z=m.NewBoolVar('z');m.Add(sum(terms)>=6).OnlyEnforceIf(z);m.Add(sum(terms)<=5).OnlyEnforceIf(z.Not());Z[c]=z
m.Add(sum(Z.values())>=(1 if control else 4))
# Hints from a valid R6=0 packing.
base=json.loads((H/'r6zero_base.rules.json').read_text());base_rs={(a,*h,t)for a,h,t in base['rules']}
for v,b in zip(B,blocks):m.AddHint(v,int(set(b)<=base_rs))
for r,y in Y.items():m.AddHint(y,0)
if witness:
 m.Add(Z[(1,4,2,7,6,3,5)]==1)
 for v,b in zip(B,blocks):
  if any(8 in r[:4]for r in b):m.Add(v==int(set(b)<=base_rs))
if control:
 for v,b in zip(B,blocks):m.Add(v==int(set(b)<=base_rs))
 for r,y in Y.items():m.Add(y==int(r in extras))
secs=float(sys.argv[1])if len(sys.argv)>1 else 180
solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=secs;solver.parameters.num_workers=4
solver.parameters.random_seed=int(sys.argv[2])if len(sys.argv)>2 else 4
solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=True
status=solver.Solve(m)
rec={'scope':'all standard3flip 52-block packings with up to two seven-useful singleton rules','blocks':len(B),'slots':len(words),'singleton_options':len(Y),'six_constraints':nsix,'seven_vars':len(Z),'status':solver.StatusName(status),'seconds':time.monotonic()-start,'response_stats':solver.ResponseStats()}
if status in (cp_model.FEASIBLE,cp_model.OPTIMAL):
 rs=set(r for v,b in zip(B,blocks)if solver.Value(v)for r in b)|{r for r,y in Y.items()if solver.Value(y)}
 rec['selected_blocks']=[i for i,v in enumerate(B)if solver.Value(v)];rec['seven_cycles']=[c for c,z in Z.items()if solver.Value(z)]
 cert={'n':8,'rules':[[r[0],list(r[1:4]),r[4]]for r in sorted(rs)]};(H/('agent_full_r6zero_control.rules.json' if control else ('agent_fixedwitness_r6zero.rules.json' if witness else 'agent_full_r6zero.rules.json'))).write_text(json.dumps(cert,indent=2))
(H/('agent_full_r6zero_control_result.json' if control else ('agent_fixedwitness_r6zero_result.json' if witness else 'agent_full_r6zero_result.json'))).write_text(json.dumps(rec,indent=2));print(json.dumps(rec,indent=2))

