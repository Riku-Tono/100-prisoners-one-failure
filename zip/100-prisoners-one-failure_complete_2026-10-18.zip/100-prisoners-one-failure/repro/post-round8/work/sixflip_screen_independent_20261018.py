"""Independent all-six-flip screen audit by unions of at mostthree clusters.

Alternativegeneratoruses175patterns:140three-edgeK4clusters and35fullK4
clusters. No originalscreen code isimported for thisgeneration. Its accepted
set is compared to an exactread-only rerun of the originalcombination loop,
and to independent S7 expansions of all11 publishedrepresentatives.
No solver or strategy construction search is used.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import Counter
import json,time,hashlib
H=Path(__file__).resolve().parent;start=time.monotonic();primary_path=H/'support_orientation_six_flip_screen.py';primary_source=primary_path.read_bytes();primary_text=primary_source.decode('utf-8-sig');primary_json=(H/'support_orientation_six_flip_screen.json').read_bytes();published=json.loads(primary_json)
T=list(map(frozenset,combinations(range(1,8),3)));ti={t:i for i,t in enumerate(T)};U4=list(map(frozenset,combinations(range(1,8),4)));patterns=[]
for U in U4:
 edges=[ti[t]for t in T if t<U];assert len(edges)==4
 for three in combinations(edges,3):patterns.append(sum(1<<i for i in three))
 patterns.append(sum(1<<i for i in edges))
assert len(patterns)==175 and len(set(patterns))==175
pair_masks=set()
for a,b in combinations(patterns,2):
 u=a|b
 if u.bit_count()==6:pair_masks.add(u)
triple_masks=set()
for a,b,c in combinations(patterns,3):
 u=a|b|c
 if u.bit_count()==6:triple_masks.add(u)
accepted=pair_masks|triple_masks;assert len(accepted)==8995
cluster_masks=[sum(1<<ti[t]for t in T if t<U)for U in U4]
for mask in accepted:
 covered=0
 for cm in cluster_masks:
  meet=mask&cm
  if meet.bit_count()>=3:covered|=meet
 assert covered==mask
alternative_seconds=time.monotonic()-start
# Execute only the originalsource's pureenumerationprefix, before any orbit
# stage or write. The sourcepath and exactsourcehash are recorded below.
cut='\npassed_masks='
assert primary_text.count(cut)==1
prefix=primary_text.split(cut,1)[0]
assert '.write_'not in prefix and 'open('not in prefix
reference_namespace={'__file__':str(primary_path.resolve()),'__name__':'reference_screen_prefix_audit'}
ref_start=time.monotonic();exec(compile(prefix,str(primary_path)+'::<enumeration-prefix>','exec'),reference_namespace)
assert reference_namespace['enumeration_complete'] and reference_namespace['tested']==1623160
reference={mask for combo,mask in reference_namespace['passed']};assert accepted==reference
reference_seconds=time.monotonic()-ref_start
# Re-expand each representative directly by all5040labelpermutations.
seen=set();orbit_records=[]
for rep in published['orbits']:
 ts=list(map(frozenset,rep['new_complement_triples']));orbit=set()
 for p in permutations(range(1,8)):
  orbit.add(sum(1<<ti[frozenset(p[x-1]for x in t)]for t in ts))
 assert len(orbit)==rep['S7_orbit_size'];assert orbit<=accepted and not seen&orbit;seen|=orbit
 orbit_records.append({'index':rep['index'],'size':len(orbit)})
assert seen==accepted and len(orbit_records)==11
# Fresh actualrule-block regeneration for the3 capacity-excluded orbits.
def norm(w):
 w=tuple(w);return min(w[j:]+w[:j]for j in range(len(w)))
def cycle_rules(c):
 return frozenset((c[j],c[(j+1)%5],c[(j+2)%5],c[(j+3)%5],c[(j+4)%5])for j in range(5))
capacity=[];L=frozenset(range(1,9));base=set(map(frozenset,combinations(range(1,8),4)))
for rep in published['orbits']:
 if rep['passes_slot_52_test']:continue
 fs=set(map(frozenset,rep['removed_supports']));S=base-fs|{L-f for f in fs};W={norm(p)for s in S for p in permutations(s)};B=set()
 for sub in combinations(range(1,9),5):
  for tail in permutations(sub[1:]):
   rs=cycle_rules((sub[0],)+tail)
   for omitted in rs:
    block=rs-{omitted}
    if all(norm(r[:4])in W for r in block):B.add(block)
 usable={norm(r[:4])for b in B for r in b};upper=len(usable)//4
 assert len(B)==rep['four_rule_blocks'];assert len(usable)==rep['actual_usable_cyclic_word_slots'];assert upper==rep['R5_slot_capacity_upperbound']<52
 capacity.append({'index':rep['index'],'actual_rule_blocks':len(B),'usable_cyclic_word_slots':len(usable),'usable_old_word_slots':sum(8 not in w for w in usable),'usable_new_word_slots':sum(8 in w for w in usable),'unused_word_slots':len(W-usable),'R5_slot_capacity_upperbound':upper})
assert {r['index']for r in capacity}=={7,8,10}
def sethash(masks):return hashlib.sha256((''.join(f'{m:09x}\n'for m in sorted(masks))).encode('ascii')).hexdigest()
hashes={'alternative_pattern_unions':sethash(accepted),'exact_primary_combination_prefix':sethash(reference),'published_orbit_expansion':sethash(seen)};assert len(set(hashes.values()))==1
out={'method':__doc__,'primary_screen_py_sha256':hashlib.sha256(primary_source).hexdigest(),'primary_screen_json_sha256':hashlib.sha256(primary_json).hexdigest(),'labelled_masks_tested_by_exact_primary_prefix':reference_namespace['tested'],'patterns':{'size3':140,'size4':35,'total':175},'unique_pair_union_masks':len(pair_masks),'unique_triple_union_masks':len(triple_masks),'union_accepted_masks':len(accepted),'accepted_set_hash_encoding':'Triplesindexedbylexcombinations([1..7],3);sort35bitmaskintegersascending;each9lowercasehexcharactersplusLF;ASCII.','accepted_set_sha256':hashes,'all_three_sets_match':True,'S7_orbits_disjoint':True,'S7_orbits':orbit_records,'capacity_excluded_orbits_fresh_rule_checks':capacity,'completeness_argument':'ForacceptedH,itsclusterscoverH andeachhas3or4edges. Distinctfour-setclustersshareatmostoneedge. Ifaclusterhas4edges,anotherclustertoacoveredoutsideedgegivesa6-edgeunion. Otherwiseallclustershave3edges; ifnopairunionhas6edges,anytwodistinctclustersshare1edgeandtheirunionhas5edges. Aclustercoveringthemissing6thedgecompletestheunionin3clusters. ThuspairortripleunionsgenerateeveryacceptedH. Converselyevery6-edgeunionoftheseclusterpatternsisclustercovered.','screen_necessity':'Anewtripleabsentfromall3-of4clustershasno4-ruleblockusinganyofits6cyclicwords. 52blocksuse208of210wordsandleaveatmost2; thereforeoneentirelyunusable6wordsupportexcludes52blocks, withoutassumingextrasarezero.','scope':'Independentfiniteauditofsixflipnecessaryscreenandcapacityexclusionsonly. NoadditionalINFEASIBLEsolvercrosscheckandnogeneralstrategyoptimalityclaim.','solver_calls':0,'alternative_generation_seconds':alternative_seconds,'reference_enumeration_seconds':reference_seconds,'seconds':time.monotonic()-start}
(H/'sixflip_screen_independent_20261018.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
