"""Bounded independent batch using unmodified seed-local completion engine."""
from pathlib import Path
from collections import Counter
import sys,json,time,contextlib,traceback
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H))
import agent_seed_local_completion as engine
from independent_audit import audit
start=time.monotonic();budget=120;records=[];target=range(635,835);found=False
with (H/'agent_local_batch_635.log').open('w',encoding='utf-8')as log:
 for index in target:
  remaining=budget-(time.monotonic()-start)
  if remaining<2.5:break
  try:
   sys.argv=['agent_seed_local_completion.py',str(index),'10000',str(min(5,max(.2,remaining-2.2)))]
   with contextlib.redirect_stdout(log):engine.main()
   d=json.loads((H/f'agent_seed_local_completion_{index}.json').read_text())
   r={'index':index,'status':d['status'],'seconds':d['seconds'],'completion_counts':d['completion_counts'],'cores':len(d['records'])}
   if d['status']=='FOUND':
    cert=next(q['certificate']for q in d['records']if'certificate'in q)
    check=audit(Path(cert));r['independent_audit']=check
    (H/f'agent_seed_local_completion_found_{index}.audit.json').write_text(json.dumps(check,indent=2),encoding='utf-8');found=True
  except Exception as e:
   r={'index':index,'status':'ERROR','exception':repr(e),'traceback':traceback.format_exc()}
  records.append(r)
  out={'method':'unmodified agent_seed_local_completion.py; <=5 seconds per seed; 120 seconds batch budget','seed_start':635,'seed_end_inclusive':834,'records':records,'counts':dict(Counter(q['status']for q in records)),'completion_counts':dict(sum((Counter(q.get('completion_counts',{}))for q in records),Counter())),'not_run':[i for i in target if i not in {q['index']for q in records}],'seconds':time.monotonic()-start,'found':found}
  (H/'agent_local_batch_635_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
  print(index,r['status'],r.get('cores'),round(out['seconds'],2),flush=True)
  if found:break
print('FINAL',out['counts'],'notrun',len(out['not_run']),out['seconds'],flush=True)

