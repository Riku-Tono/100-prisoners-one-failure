"""Independent Cartesian regeneration of the priority63 actual-rule cores.

Uses Claude's cycle/rule generator, not the submitted witness preparation.
All4^6 suppliers for every omitted seventh rule are tested by slot masks;
4^7 supplies the full-seven templates. No construction completion is solved.
"""
from pathlib import Path
from itertools import combinations,product
from collections import defaultdict
import json,sys,hashlib,time
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'claude_desktop_continuation3'))
from c3_model import Orientation,cyc_rules,word,directed_cycles
def main():
    started=time.monotonic();source=H/'fullstar_priority63_preparation_20261018.json';d=json.loads(source.read_text())
    o=Orientation(list(map(frozenset,combinations(range(1,8),4))))
    blocks=tuple(sorted(map(frozenset,o.blocks),key=lambda b:tuple(sorted(b))));assert len(blocks)==2520
    wi={w:i for i,w in enumerate(o.words)};masks=[sum(1<<wi[word(r)] for r in b) for b in blocks]
    suppliers=defaultdict(list)
    for i,b in enumerate(blocks):
        for r in b:suppliers[r].append(i)
    cycles=list(map(tuple,d['same_known_three_cycles']));assert len(cycles)==3
    witnesses=[];fulls=[];assignments=0
    for c in cycles:
        rr=sorted(cyc_rules(c));assert all(len(suppliers[r])==4 for r in rr)
        ws=set();full=set()
        for omitted in range(7):
            wanted=rr[:omitted]+rr[omitted+1:]
            for rows in product(*(suppliers[r] for r in wanted)):
                assignments+=1;used=0;valid=True
                for b in rows:
                    if used&masks[b]:valid=False;break
                    used|=masks[b]
                if valid:ws.add(frozenset(rows))
        for rows in product(*(suppliers[r] for r in rr)):
            used=0;valid=True
            for b in rows:
                if used&masks[b]:valid=False;break
                used|=masks[b]
            if valid:full.add(frozenset(rows))
        assert len(ws)==28 and len(full)==1
        witnesses.append(ws);fulls.append(next(iter(full)))
    fixed_source=H/'fullstar_fixed18_complete_summary.json';fd=json.loads(fixed_source.read_text());fixed=frozenset(fd['fixed_core']);assert len(fixed)==18
    old=[]
    for c,ws in zip(cycles,witnesses):
        choices=[w for w in ws if w<=fixed];assert len(choices)==1;old.append(choices[0])
    assert frozenset().union(*old)==fixed
    expected=set()
    for j in range(3):
        replacements=[w for w in witnesses[j] if not w<=fulls[j]];assert len(replacements)==21
        for w in replacements:expected.add(fixed-old[j]|w)
    submitted=set();counts=[]
    six=[frozenset(cyc_rules(c)) for ss in combinations(range(1,8),6) for c in directed_cycles(ss)]
    sevens=[frozenset(cyc_rules(c)) for c in directed_cycles(range(1,8))]
    for r in d['seeds']:
        actual=frozenset(frozenset(map(tuple,b)) for b in r['actual_blocks'])
        key=frozenset(r['blocks']);assert actual==frozenset(blocks[i] for i in key) and len(key)==18
        used=0
        for b in key:assert not used&masks[b];used|=masks[b]
        rr=frozenset().union(*actual)
        assert used.bit_count()==72 and len(rr)==72 and not r['extras']
        assert [len(rr&frozenset(cyc_rules(c))) for c in cycles]==[6,6,6]
        assert max(len(rr&s) for s in six)<=4 and sum(len(rr&s)>=6 for s in sevens)==3
        assert key!=fixed;submitted.add(key);counts.append(r['core_index'])
    assert len(submitted)==63 and submitted==expected and sorted(counts)==list(range(63))
    out=dict(status='PASS_INDEPENDENT_CARTESIAN_REGENERATION',method=__doc__,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        fixed_core_sha256=hashlib.sha256(fixed_source.read_bytes()).hexdigest(),generator_sha256=hashlib.sha256((H/'claude_desktop_continuation3/c3_model.py').read_bytes()).hexdigest(),
        supplier_assignments=assignments,witnesses_per_cycle=[len(w) for w in witnesses],full_templates_per_cycle=[1,1,1],
        priority_core_count=63,actual_rule_sets_exact=True,all_partial_R6_zero=True,all_partial_R7_three=True,completed_solver_called=False,seconds=time.monotonic()-started)
    (H/'fullstar_priority63_independent_check.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
