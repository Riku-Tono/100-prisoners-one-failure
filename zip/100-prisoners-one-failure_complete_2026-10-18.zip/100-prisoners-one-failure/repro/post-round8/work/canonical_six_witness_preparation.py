"""Enumerate local cores supplying six fixed correct windows of one7-cycle.

Cycle=(1,2,3,4,5,6,7); only positions0..5 are required. Position6 is not
required. Each required rule is supplied by an actual four-rule5-cycle block
or by the correct singleton, with at most2 singletons and no lossword-slot
collision. Blocks supplying these rules necessarily use labels1..7; their
source universe is the2520 full-star blocks. This does NOT fix the remaining
support orientation: all other supports remain free in the global model.
No completion solver is called.
"""
from fullstar_prepare_basic import H,RULES,ROWS,correct,canon
from global_orientation_witness_completion import CANONICAL_SIX
from itertools import permutations,combinations
from collections import defaultdict,Counter
from pathlib import Path
import json,time,hashlib
CANONICAL=(1,2,3,4,5,6,7)
REQUIRED=tuple((CANONICAL[i],CANONICAL[(i+1)%7],CANONICAL[(i+2)%7],CANONICAL[(i+3)%7],CANONICAL[(i-1)%7]) for i in range(6))
assert REQUIRED==CANONICAL_SIX

def main():
    start=time.monotonic();inc=defaultdict(list)
    for b,rs in enumerate(RULES):
        assert len(rs&correct(CANONICAL))<=1
        for r in rs:inc[r].append(b)
    assert all(len(inc[r])==4 for r in REQUIRED)
    nodes=leaves=0;found=set()
    def dfs(todo,used,chosen,extras):
        nonlocal nodes,leaves
        nodes+=1
        if not todo:leaves+=1;found.add((tuple(sorted(chosen)),tuple(sorted(extras))));return
        opts=[]
        for r in todo:
            bs=[b for b in inc[r] if not ROWS[b]&used]
            s=len(extras)<2 and canon(r[:4]) not in used
            n=len(bs)+int(s)
            if not n:return
            opts.append((n,r,bs,s))
        _,r,bs,s=min(opts)
        for b in bs:dfs(todo-RULES[b],used|ROWS[b],chosen|{b},extras)
        if s:dfs(todo-{r},used|{canon(r[:4])},chosen,extras|{r})
    dfs(frozenset(REQUIRED),frozenset(),frozenset(),frozenset())
    six=[correct((s[0],)+p) for s in combinations(range(1,8),6) for p in permutations(s[1:])]
    seven=[correct((1,)+p) for p in permutations(range(2,8))]
    folder=H/'canonical_six_witness_cores';folder.mkdir(exist_ok=True)
    records=[]
    for index,(blocks,extras) in enumerate(sorted(found,key=lambda k:(len(k[1]),k[0],k[1]))):
        actual=[sorted(RULES[b]) for b in blocks];rr=set().union(*(RULES[b] for b in blocks))|set(extras)
        words=[canon(r[:4]) for r in rr]
        assert set(REQUIRED)<=rr and len(rr)==4*len(blocks)+len(extras)
        assert len(words)==len(set(words)) and len(blocks)+len(extras)==6
        assert len(correct(CANONICAL)&rr)==6
        R6=sum(len(q&rr)>=5 for q in six);R7=sum(len(q&rr)>=6 for q in seven)
        path=folder/f'core_{index:03d}.json'
        record={'representative_index':index,'actual_blocks':actual,'extras':extras,'required_rules':REQUIRED,'unrequired_seventh_rule':(7,1,2,3,6),'block_ids_in_fullstar_catalogue':blocks,'block_count':len(blocks),'extra_count':len(extras),'occupied_lossword_count':len(words),'occupied_losswords':sorted(words),'forced_active_supports':sorted({tuple(sorted(r[:4])) for r in rr}),'R6_in_partial_core':R6,'R7_in_partial_core':R7,'orientation_scope':'Only the supplied rules/slots are fixed; remaining support orientation is free.','core_file':str(path)}
        path.write_text(json.dumps(record,indent=2),encoding='utf-8');records.append(record)
    catalogue=json.dumps([sorted(b) for b in RULES],separators=(',',':')).encode()
    out={'status':'EXHAUSTED_LOCAL_CORE_ENUMERATION_NO_COMPLETION','scope':__doc__,'canonical_cycle':CANONICAL,'required_positions':list(range(6)),'unrequired_position':6,'required_rules':REQUIRED,'global_model_six_rules_exact_match':True,'block_catalogue_size':len(RULES),'block_catalogue_sha256':hashlib.sha256(catalogue).hexdigest(),'canonical_required_rule_supplier_counts':{str(r):len(inc[r]) for r in REQUIRED},'dfs_nodes':nodes,'dfs_leaves':leaves,'unique_cores':len(records),'extra_count_histogram':dict(Counter(r['extra_count'] for r in records)),'block_count_histogram':dict(Counter(r['block_count'] for r in records)),'R6_partial_histogram':dict(Counter(r['R6_in_partial_core'] for r in records)),'R7_partial_histogram':dict(Counter(r['R7_in_partial_core'] for r in records)),'zero_extra_indices':[r['representative_index'] for r in records if not r['extras']],'R6zero_indices':[r['representative_index'] for r in records if r['R6_in_partial_core']==0],'seconds':time.monotonic()-start,'records':records}
    (H/'canonical_six_witness_preparation.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print({k:v for k,v in out.items() if k not in ('scope','records','canonical_required_rule_supplier_counts','R6zero_indices')},flush=True)
if __name__=='__main__':main()
