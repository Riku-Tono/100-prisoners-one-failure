"""All four-flip orientations under S7, screened by necessary block-slot capacity.
No strategy construction or 15052 search is performed.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import Counter
from math import comb
import json,time
H=Path(__file__).resolve().parent;start=time.monotonic();L7=frozenset(range(1,8));L8=frozenset(range(1,9));base=list(map(frozenset,combinations(range(1,8),4)))
inv_maps=[]
for p in permutations(range(4)):
 inv=[0]*16
 for mask in range(16):inv[sum(1<<i for i in range(4)if mask&(1<<p[i]))]=mask
 inv_maps.append(inv)
def signature(fs):
 counts=[0]*16
 for x in L7:counts[sum(1<<i for i,f in enumerate(fs)if x in f)]+=1
 return min(tuple(counts[i]for i in inv)for inv in inv_maps)
classes={}
for fs in combinations(base,4):
 sig=signature(fs)
 if sig not in classes:classes[sig]={'removed_supports':tuple(tuple(sorted(f))for f in fs),'labelled_quadruples':0}
 classes[sig]['labelled_quadruples']+=1
standard=tuple(map(frozenset,((1,2,3,4),(1,2,3,5),(1,2,3,6),(1,2,3,7))));standard_sig=signature(standard);records=[]
for index,(sig,info)in enumerate(sorted(classes.items(),key=lambda p:p[1]['removed_supports'])):
 fs=tuple(map(frozenset,info['removed_supports']));S=set(base)-set(fs)|{L8-f for f in fs};new={s for s in S if 8 in s};used=set();profile=Counter();types=Counter()
 for U in map(frozenset,combinations(range(1,9),5)):
  inside={s for s in S if s<U};q=len(inside);profile[(8 in U,q)]+=1
  if q==4:
   used|=inside;n=sum(8 in s for s in inside);types[(n,4-n)]+=24
  elif q==5:
   used|=inside
   for omitted in inside:
    n=sum(8 in s for s in inside-{omitted});types[(n,4-n)]+=24
 triples={s-{8}for s in new};clusters=[]
 for U in map(frozenset,combinations(range(1,8),4)):
  contained={t for t in triples if t<=U}
  if len(contained)>=3:clusters.append({'four_set':sorted(U),'contained_triples':sorted(map(sorted,contained)),'old_four_support_allowed':U in S})
 all_covered=all(any(t<=frozenset(c['four_set'])for c in clusters)for t in triples)
 upper=6*len(used)//4;viable=upper>=52
 assert viable==(sig==standard_sig)==all_covered
 assert 5040%info['labelled_quadruples']==0
 records.append({'index':index,**info,'added_supports':sorted(map(sorted,new)),'venn_signature_mask0_to_15':sig,'S7_stabilizer_order':5040//info['labelled_quadruples'],'clusters':clusters,'all_new_triples_cluster_covered':all_covered,'new_usable_supports':len(new&used),'usable_supports':len(used),'usable_cyclic_word_slots':6*len(used),'R5_slot_capacity_upperbound':upper,'block_types':[{'new_slots':n,'old_slots':o,'blocks':k}for(n,o),k in sorted(types.items())],'blocks':sum(types.values()),'passes_necessary_52_block_test':viable})
assert sum(r['labelled_quadruples']for r in records)==comb(35,4)
out={'method':__doc__,'labelled_quadruples':comb(35,4),'S7_orbit_count':len(records),'orbits':records,'eligible_orbit_indices':[r['index']for r in records if r['passes_necessary_52_block_test']],'eligible_labelled_quadruples':sum(r['labelled_quadruples']for r in records if r['passes_necessary_52_block_test']),'necessary_argument':'52 pairwise-disjoint four-rule blocks use208 of210 cyclic-word slots, so one completely unusable support (six slots) already rules this out. A block meeting an8-history needs at leastthree allowed8-supports in one five-labelset {8}unionU. Thus each new triple must belong to acluster of at leastthree of thefournewtriples in a4setU. Anytwothree-edgeclusters shareatleasttwotriples; theiruniondeterminesU, so allfourtriples must lieinonesuchU. Fourdistinct3-subsets ofa4setarethecompleteK4^3, equivalenttoremoved1234,1235,1236,1237. This is necessary, not an attainment claim.','eligible_new_block_count_cases':[{'new_blocks':b,'blocks_omitting_old_four_support':k,'new_slots_used':3*b+k,'old_U_slots_used':b-k,'new_holes':24-3*b-k,'remaining_old_blocks':52-b}for b in range(9)for k in range(b+1)if 22<=3*b+k<=24 and b-k<=6],'scope':'Exactlyfour flips;necessarycapacityonly;doesnotexcludeorientationswithR5<52orsaytheuniquecandidateattains52. Singletonchoices are unrestricted; the argument uses at mosttwo slots outside52blocks, withoutassumingzero new-side singletons.','seconds':time.monotonic()-start}
(H/'support_orientation_four_flip_classification.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print({k:v for k,v in out.items()if k not in('orbits','method','necessary_argument')});print('capacity_hist',dict(Counter(r['R5_slot_capacity_upperbound']for r in records)))
