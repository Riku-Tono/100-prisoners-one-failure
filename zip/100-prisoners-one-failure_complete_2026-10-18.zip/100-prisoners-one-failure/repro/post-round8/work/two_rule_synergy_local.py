"""Test whether a second rule defeats the one-rule local exclusion.
All 35 supports on [7] are allowed; this is not a completed strategy.
"""
from itertools import combinations,permutations
from collections import defaultdict
from pathlib import Path
import json
def rot(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def rr(c):
    n=len(c);return frozenset((c[i],c[(i+1)%n],c[(i+2)%n],c[(i+3)%n],c[(i-1)%n]) for i in range(n))
blocks=[];slots=[];inc=defaultdict(list)
for s in combinations(range(1,8),5):
    for p in permutations(s[1:]):
        c=(s[0],)+p
        for omitted in rr(c):
            rset=rr(c)-{omitted};i=len(blocks);blocks.append(rset);slots.append(frozenset(rot(q[:4]) for q in rset))
            for q in rset:inc[q].append(i)
cs=[(1,2,3,4,6,7,5),(1,2,3,4,7,6,5)];r=(1,2,3,4,5)
def witnesses(c,external):
    result=set();rules=rr(c);occupied=frozenset(rot(q[:4]) for q in external)
    for ignored in rules-external:
        def dfs(needed,used,chosen):
            if not needed:result.add(frozenset(chosen));return
            opts=[]
            for q in needed:
                bs=[b for b in inc[q] if not slots[b]&used]
                if not bs:return
                opts.append((len(bs),q,bs))
            for b in min(opts)[2]:dfs(needed-blocks[b],used|slots[b],chosen|{b})
        dfs(rules-external-{ignored},occupied,frozenset())
    return result
out={'scope':'all 35 supports on [7], local block packing plus two rules; neither completion nor R6=0 imposed','first_rule':r,'cycles':cs,'tested_second_rules':0,'found':False,'cases':[]}
for s in sorted((rr(cs[0])|rr(cs[1]))-{r}):
    if rot(s[:4])==rot(r[:4]):continue
    out['tested_second_rules']+=1
    ws=[witnesses(c,{r,s}) for c in cs]
    rec={'second_rule':s,'witness_counts':list(map(len,ws)),'compatible':0}
    for a in ws[0]:
        useda=frozenset().union(*(slots[b] for b in a))
        for b in ws[1]:
            if any(slots[i]&useda for i in b-a):continue
            chosen=a|b;rules=frozenset().union(*(blocks[i] for i in chosen))
            before=[len((rules|{s})&rr(c)) for c in cs]
            after=[len((rules|{r,s})&rr(c)) for c in cs]
            if max(before)>=6:continue
            assert min(after)>=6
            rec['compatible']+=1;out.update(found=True,second_rule=s,before_adding_first=before,after_adding_first=after,selected_blocks=[sorted(blocks[i]) for i in sorted(chosen)])
            break
        if out['found']:break
    out['cases'].append(rec)
    if out['found']:break
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print({k:v for k,v in out.items() if k!='selected_blocks'})
