"""Check the pure packing counterexample's six-correct rescue and all hole extras.

This is a finite fixed-table calculation, not an orientation-wide bound.
"""
from itertools import combinations, permutations, product
from pathlib import Path
from collections import Counter
import json, time

H = Path(__file__).resolve().parent
START = time.monotonic()

def cycles(k):
    for support in combinations(range(1, 9), k):
        for tail in permutations(support[1:]):
            yield (support[0],) + tail

def correct(c):
    n = len(c)
    return frozenset((c[j], c[(j+1) % n], c[(j+2) % n],
                      c[(j+3) % n], c[(j-1) % n]) for j in range(n))

def rotate(w):
    w = tuple(w)
    return [w[j:] + w[:j] for j in range(4)]

def main():
    results = []
    allcycles = {k: [(c, correct(c)) for c in cycles(k)] for k in (5, 6, 7, 8)}
    for index in (1, 3):
        source = H / f'fullstar_six_witness_pure_completion_20261018_found_{index}.rules.json'
        data = json.loads(source.read_text())
        base = {(a, *hist, t) for a, hist, t in data['rules']}
        hole_options = [[()] + [w + (t,) for w in rotate(hole)
                               for t in range(1, 9) if t not in w]
                        for hole in data['holes']]
        assert [len(x) for x in hole_options] == [17, 17]
        relevant = {k: [(c, rr, len(base & rr)) for c, rr in values
                       if len(base & rr) >= k - 3]
                    for k, values in allcycles.items()}
        hist = Counter()
        best = -1
        examples = []
        for pair in product(*hole_options):
            extras = {r for r in pair if r}
            rescues = {k: [c for c, rr, n in values
                            if n + len(extras & rr) >= k - 1]
                       for k, values in relevant.items()}
            signature = tuple(len(rescues[k]) for k in (5, 6, 7, 8))
            hist[signature] += 1
            if signature[1] != 0:
                continue
            score = 6 * signature[0] + signature[2] + signature[3]
            if score > best:
                best, examples = score, []
            if score == best and len(examples) < 5:
                examples.append({'extras': sorted(extras), 'rescued_cycles': rescues})
        canonical = tuple(range(1, 8))
        canonical_rules = sorted(base & correct(canonical))
        assert len(canonical_rules) == (6 if index == 1 else 7)
        rec = {'index': index, 'certificate': str(source),
               'canonical_cycle_correct_rules': canonical_rules,
               'canonical_cycle_correct_count': len(canonical_rules),
               'base_rescued_sevens': [c for c, rr in allcycles[7]
                                       if len(base & rr) >= 6],
               'holes': data['holes'], 'variants': 17**2,
               'variant_rescue_histogram': [{'R5': s[0], 'R6': s[1],
                                             'R7': s[2], 'R8': s[3], 'count': n}
                                            for s, n in sorted(hist.items())],
               'best_R6zero_rescue_gain': best,
               'best_R6zero_wins': 14736 + best,
               'best_examples': examples}
        unrescued = [(c, rr, len(base & rr)) for c, rr in allcycles[7]
                     if len(base & rr) < 6]
        available_extras = set().union(*(set(x) - {()} for x in hole_options))
        rec['seven_base_correct_histogram'] = dict(sorted(Counter(len(base & rr)
                                                                 for c, rr in allcycles[7]).items()))
        rec['unrescued_seven_max_correct'] = max(n for c, rr, n in unrescued)
        rec['unrescued_sevens_improvable_by_holes'] = [
            {'cycle': c, 'base_correct': n,
             'possible_additional_correct_rules': sorted((rr - base) & available_extras),
             'max_correct_ignoring_hole_conflict': n + len((rr - base) & available_extras)}
            for c, rr, n in unrescued if (rr - base) & available_extras]
        improvable = rec['unrescued_sevens_improvable_by_holes']
        rec['improvable_seven_summary'] = {
            'count': len(improvable),
            'max_base_correct': max(q['base_correct'] for q in improvable),
            'max_correct_after_hole_fill': max(q['max_correct_ignoring_hole_conflict']
                                              for q in improvable),
            'base_correct_histogram': dict(sorted(Counter(q['base_correct'] for q in improvable).items())),
            'new_rescue_possible_count': sum(q['max_correct_ignoring_hole_conflict'] >= 6
                                              for q in improvable),
            'best_improvable_cycles': [q for q in improvable
                                      if q['max_correct_ignoring_hole_conflict'] ==
                                      max(z['max_correct_ignoring_hole_conflict'] for z in improvable)]}
        examples[0]['rules_file'] = str(H / f'fullstar_hole_fill_20261018_index{index}_best.rules.json')
        best_rules = base | {tuple(r) for r in examples[0]['extras']}
        best_path = Path(examples[0]['rules_file'])
        best_path.write_text(json.dumps({'n': 8, 'rules': [[r[0], list(r[1:4]), r[4]]
                                                         for r in sorted(best_rules)],
                                        'source_packing': str(source),
                                        'extras': examples[0]['extras']}, indent=2), encoding='utf-8')
        from independent_audit import audit
        rec['best_independent_40320_audit'] = audit(best_path)
        assert rec['best_independent_40320_audit']['wins'] == 14736 + best
        assert rec['best_independent_40320_audit']['lost_cf'] == 0
        results.append(rec)
    out = {'scope': __doc__, 'results': results,
           'seconds': time.monotonic() - START,
           'conclusion': 'The proposed unique-seven-correct-template necessity is false, even with R6=0.'}
    path = H / 'fullstar_nonextension_counterexample_details_20261018.json'
    path.write_text(json.dumps(out, indent=2), encoding='utf-8')
    print(json.dumps({'seconds': out['seconds'], 'results': [
        {k: r[k] for k in ('index', 'canonical_cycle_correct_count', 'base_rescued_sevens',
                          'variant_rescue_histogram', 'best_R6zero_wins',
                          'seven_base_correct_histogram', 'unrescued_seven_max_correct',
                          'improvable_seven_summary')}
        for r in results]}, indent=2))

if __name__ == '__main__':
    main()
