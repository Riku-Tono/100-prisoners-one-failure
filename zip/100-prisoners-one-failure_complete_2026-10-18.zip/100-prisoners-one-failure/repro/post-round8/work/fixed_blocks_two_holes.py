"""Complete 17^2 fill scan for the 208-block part of new15051.
This fixes all 52 blocks: a local search, not a bound for R6=0 generally.
"""
from itertools import combinations,permutations,product
from collections import defaultdict,Counter
from pathlib import Path
import json
HERE=Path(__file__).parent;L=tuple(range(1,9))
def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def rules(c):
    n=len(c);return frozenset((c[i],c[(i+1)%n],c[(i+2)%n],c[(i+3)%n],c[(i-1)%n]) for i in range(n))
def cycles(k):
    for s in combinations(L,k):
        for p in permutations(s[1:]):yield (s[0],)+p
raw=json.loads((HERE/'inputs/new15051.rules.json').read_text())
original={(a,*h,t) for a,h,t in raw['rules']};groups=defaultdict(set)
for a,b,c,d,t in original:groups[canon((t,a,b,c,d))].add((a,b,c,d,t))
base=set().union(*(rr for rr in groups.values() if len(rr)==4))
assert len(base)==208
active={frozenset(s) for s in combinations(range(1,8),4)}
for s in ((1,2,3,4),(1,2,3,5),(1,2,3,6)):
    active.remove(frozenset(s));active.add(frozenset(L)-frozenset(s))
words={c for c in cycles(4) if frozenset(c) in active}
holes=sorted(words-{canon(r[:4]) for r in base});assert len(holes)==2
choices=[]
for w in holes:
    choices.append([None]+[w[j:]+w[:j]+(target,) for j in range(4) for target in L if target not in w])
data=[]
for k in range(5,9):
    for c in cycles(k):
        rr=rules(c);data.append((k,len(base&rr),rr))
summary=Counter();records=[];best_zero=None;best_any=None
for chosen in product(*choices):
    extras={r for r in chosen if r is not None};rescued=Counter()
    for k,n,rr in data:
        if n+len(rr&extras)>=k-1:rescued[k]+=1
    wins=14736+6*rescued[5]+2*rescued[6]+rescued[7]+rescued[8]
    assert rescued[5]==52
    rec=dict(wins=wins,R={str(k):rescued[k] for k in range(5,9)},extras=[list(r) for r in sorted(extras)])
    summary[(rescued[6],rescued[7],rescued[8],wins)]+=1;records.append(rec)
    if best_any is None or wins>best_any['wins']:best_any=rec
    if rescued[6]==0 and (best_zero is None or wins>best_zero['wins']):best_zero=rec
out=dict(scope='all 52 five-cycle blocks fixed to block part of new15051',cases=len(records),holes=holes,best_any=best_any,best_R6_zero=best_zero,histogram=[dict(R6=k[0],R7=k[1],R8=k[2],wins=k[3],fillings=v) for k,v in sorted(summary.items())],records=records)
(HERE/'fixed_blocks_two_holes.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print({k:v for k,v in out.items() if k!='records'})
