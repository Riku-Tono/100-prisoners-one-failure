"""Independent lexical-DFS enumeration of critical fourth-seven witnesses.

Uses c3 actual rules and every omitted seventh window, with fixed lexical
rule order rather than the submitted MRV recursion. The fixed18 core must
already rescue exactly3 sevens. No cover completion is performed.
"""
from pathlib import Path
from itertools import combinations
from collections import defaultdict,Counter
import sys,json,time,hashlib,argparse
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H/'claude_desktop_continuation3'))
from c3_model import Orientation,cyc_rules,directed_cycles,word
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source',default=str(H/'fullstar_priority63_first.critical.json'));parser.add_argument('--output',default=str(H/'fullstar_core4_critical_independent.json'));args=parser.parse_args()
    started=time.monotonic();p=Path(args.source);d=json.loads(p.read_text());assert d['seed_facts']['base_R7']==3
    o=Orientation(list(map(frozenset,combinations(range(1,8),4))))
    blocks=tuple(sorted(map(frozenset,o.blocks),key=lambda b:tuple(sorted(b))));lookup={b:i for i,b in enumerate(blocks)}
    fixedids=frozenset(lookup[frozenset(map(tuple,b))] for b in d['fixed_actual_blocks'])
    assert fixedids==frozenset(d['fixed_core']) and len(fixedids)==18
    wi={w:i for i,w in enumerate(o.words)}
    masks=[sum(1<<wi[word(r)] for r in b) for b in blocks]
    fixedrules=frozenset().union(*(blocks[i] for i in fixedids));used0=0
    for b in fixedids:assert not used0&masks[b];used0|=masks[b]
    six=[frozenset(cyc_rules(c)) for ss in combinations(range(1,8),6) for c in directed_cycles(ss)]
    ri=defaultdict(list)
    for i,rs in enumerate(six):
        for r in rs:ri[r].append(i)
    changes=[]
    for b in blocks:
        change=Counter(i for r in b for i in ri[r]);assert max(change.values())==1
        changes.append(tuple(change))
    counts=[len(rs&fixedrules) for rs in six];assert max(counts)<=4
    suppliers=defaultdict(list)
    for i,b in enumerate(blocks):
        if not masks[i]&used0:
            for r in b:suppliers[r].append(i)
    found=set();nodes=0;leaves=0;cycles_with_witness=set()
    def walk(todo,used,chosen,extras,cycle):
        nonlocal nodes,leaves
        nodes+=1
        if not todo:
            leaves+=1;found.add((tuple(sorted(fixedids|chosen)),tuple(sorted(extras))));cycles_with_witness.add(cycle);return
        r=min(todo)
        for b in suppliers[r]:
            if used&masks[b] or any(counts[k]>=4 for k in changes[b]):continue
            for k in changes[b]:counts[k]+=1
            walk(todo-blocks[b],used|masks[b],chosen|{b},extras,cycle)
            for k in changes[b]:counts[k]-=1
        bit=1<<wi[word(r)]
        if len(extras)<2 and not used&bit and all(counts[k]<4 for k in ri[r]):
            for k in ri[r]:counts[k]+=1
            walk(todo-{r},used|bit,chosen,extras|{r},cycle)
            for k in ri[r]:counts[k]-=1
    for cycle in directed_cycles(range(1,8)):
        rr=frozenset(cyc_rules(cycle))
        if len(rr&fixedrules)>=6:continue
        for ignored in rr:
            todo=rr-{ignored}-fixedrules
            if any(used0&(1<<wi[word(r)]) for r in todo):continue
            walk(todo,used0,frozenset(),frozenset(),tuple(cycle))
    expected={(tuple(r['core_blocks']),tuple(map(tuple,r['critical_extra_rules']))) for r in d['records']}
    assert found==expected and len(found)==d['unique_critical_cores']
    encoding=''.join(json.dumps([bs,es],separators=(',',':'))+'\n' for bs,es in sorted(found)).encode('ascii')
    result=dict(status='PASS_EXACT_CRITICAL_CORE_SET',method=__doc__,primary_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
        c3_generator_sha256=hashlib.sha256((H/'claude_desktop_continuation3/c3_model.py').read_bytes()).hexdigest(),
        fixed_blocks=sorted(fixedids),nodes=nodes,leaves=leaves,distinct_critical_cores=len(found),
        distinct_fourth_cycles=len(cycles_with_witness),core_set_sha256=hashlib.sha256(encoding).hexdigest(),
        primary_nodes=d['dfs_nodes'],primary_leaves=d['dfs_leaves'],exact_actual_block_mapping=True,cover_solver_called=False,seconds=time.monotonic()-started)
    Path(args.output).write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
