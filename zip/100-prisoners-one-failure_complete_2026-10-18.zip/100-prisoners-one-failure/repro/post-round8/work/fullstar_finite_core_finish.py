"""Finish the finite3735-core frontier, retaining exact prior CP/bitset proofs.

Highest-index MRV ties follow the independently successful four-flip cover.
Pure-cover exhaustion is sufficient; a found pure cover is accepted only if
R6=0, otherwise the R6-saturated-row engine is used. UNKNOWN stays pending.
"""
from fullstar_finite_core_bitset import *

class HighEngine(Engine):
    def dfs(self,remaining,available,selected,holes,budget):
        self.nodes+=1
        if self.nodes>self.node_limit:raise Limited('NODE_LIMIT')
        if self.nodes%256==0 and time.monotonic()>self.deadline:raise Limited('TIME_LIMIT')
        if not remaining:
            if budget:return False
            self.answer=selected[:];self.answer_holes=holes[:];return True
        todo=remaining;small=100000;opts=0;wordbit=0
        while todo:
            bit=1<<(todo.bit_length()-1);todo^=bit;cand=COL[bit.bit_length()-1]&available;n=cand.bit_count()
            if n<small:small=n;opts=cand;wordbit=bit
            if n==0:break
        if not small:
            if not budget:return False
            return self.dfs(remaining^wordbit,available,selected,holes+[wordbit.bit_length()-1],budget-1)
        for bucket in (opts&self.hint,opts&~self.hint):
            while bucket:
                bit=1<<(bucket.bit_length()-1);bucket^=bit;b=bit.bit_length()-1;bad=CONFLICT[b]
                if self.use_r6:
                    for k in DELTA[b]:
                        self.counts[k]+=1
                        if self.counts[k]==4:bad|=SAT[k]
                found=self.dfs(remaining^RM[b],available&~bad,selected+[b],holes,budget)
                if self.use_r6:
                    for k in DELTA[b]:self.counts[k]-=1
                if found:return True
        if budget:return self.dfs(remaining^wordbit,available&~COL[wordbit.bit_length()-1],selected,holes+[wordbit.bit_length()-1],budget-1)
        return False
    def run(self,core,extras,seconds,node_limit,hint=frozenset(),use_r6=True):
        core=set(core);extras=set(map(tuple,extras));self.use_r6=use_r6
        rem=ALL_WORDS;avail=ALL_ROWS;self.counts=[0]*840;self.hint=sum(1<<b for b in hint)
        for b in core:
            assert rem&RM[b]==RM[b];rem^=RM[b];avail&=~CONFLICT[b]
            for k in DELTA[b]:self.counts[k]+=1
        for r in extras:
            w=WI[canon(r[:4])];bit=1<<w;assert rem&bit;rem^=bit;avail&=~COL[w]
            for k in R6INC[r]:self.counts[k]+=1
        assert max(self.counts)<=4
        if use_r6:
            for k,n in enumerate(self.counts):
                if n==4:avail&=~SAT[k]
        self.nodes=0;self.answer=None;self.answer_holes=None;self.node_limit=node_limit;self.deadline=time.monotonic()+seconds
        try:found=self.dfs(rem,avail,[],[],2-len(extras))
        except Limited as err:return 'UNKNOWN_'+str(err),self.nodes,None,None
        return ('FOUND',self.nodes,self.answer,[WORDS[w] for w in self.answer_holes]) if found else ('EXHAUSTED_NO_COMPLETION',self.nodes,None,None)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--wall-seconds',type=float,default=120);a=p.parse_args()
    src=H/'fullstar_fixed_core_enumeration.json';raw=src.read_bytes();data=json.loads(raw);cores=data['minimal_records']
    assert len(cores)==3735 and data['block_catalogue_sha256']==CATALOGUE_SHA
    keyindex={(tuple(r['core_blocks']),tuple(map(tuple,r['critical_extra_rules']))):i for i,r in enumerate(cores)}
    prior={};history=[]
    for name in ('fullstar_finite_core_bitset_result.json','fullstar_finite_core_completion_result.json'):
        path=H/name;b=path.read_bytes();d=json.loads(b)
        assert d['block_catalogue_sha256']==CATALOGUE_SHA and d['fixed_core']==data['fixed_core']
        history.append({'path':str(path),'sha256':hashlib.sha256(b).hexdigest(),'status':d['status']})
        for r in d['records']:
            if r['status']=='EXHAUSTED_NO_COMPLETION':prior[r['index']]={'index':r['index'],'status':'REUSED_EXHAUSTED','source':str(path),'source_nodes':r['nodes']}
    path=H/'post_audit_fullstar_20261018_resume1_result.json';b=path.read_bytes();d=json.loads(b)
    assert d['resume_settings']['fixed_core']==data['fixed_core'] and d['resume_settings']['flipped_supports']==[] and d['resume_settings']['R6']==0 and d['resume_settings']['R7_target']==4
    assert d['resume_settings']['required_blocks']==52 and d['resume_settings']['completion_single_rules']==2
    history.append({'path':str(path),'sha256':hashlib.sha256(b).hexdigest(),'status':d['status']})
    for r in d['replayed_no_goods']+d['records']:
        if r['completion_status']=='INFEASIBLE' and r['no_good_added']:
            i=keyindex[(tuple(r['core_blocks']),tuple(map(tuple,r['critical_extra_rules'])))];prior.setdefault(i,{'index':i,'status':'REUSED_CP_INFEASIBLE','source':str(path),'source_iteration':r['iteration']})
    start=time.monotonic();deadline=start+a.wall_seconds;engine=HighEngine()
    base=json.loads((H/'inputs/baseline15051.rules.json').read_text());brules={(x,*h,t) for x,h,t in base['rules']};known={i for i,b in enumerate(RULES) if b<=brules}
    fixed=set(data['fixed_core']);fixed.update(sorted(known-fixed)[:39-len(fixed)]);holes=set(WORDS)-set().union(*(set(ROWS[b]) for b in known));extras={w+(8,) for w in holes}
    st,nodes,more,free=engine.run(fixed,extras,5,2000000,known,True);assert st=='FOUND' and len(more)==13
    pos=export_and_audit(H/'fullstar_finite_core_finish_positive.rules.json',fixed,extras,more,free,15051)
    out={'scope':__doc__,'input_core_file':str(src),'input_core_sha256':hashlib.sha256(raw).hexdigest(),'block_catalogue_sha256':CATALOGUE_SHA,'total_cores':3735,'fixed_core':data['fixed_core'],'source_history':history,'reused_proof_count':len(prior),'positive_control':{'retained':39,'recovered':13,'nodes':nodes,'direct_audit':pos},'records':list(prior.values()),'status':'RUNNING'}
    target=H/'fullstar_finite_core_finish_result.json'
    pending=[i for i in range(3735) if i not in prior]
    for done,i in enumerate(pending):
        remaining=deadline-time.monotonic()
        if remaining<=0:out['status']='WALL_LIMIT';break
        c=cores[i];st,nodes,more,holes=engine.run(c['core_blocks'],c['critical_extra_rules'],min(2,remaining),2000000,use_r6=False)
        rec={'index':i,'status':st,'engine':'PURE_HIGH_BITSET','nodes':nodes}
        if st=='FOUND':
            rr=set().union(*(RULES[b] for b in set(c['core_blocks'])|set(more)))|set(map(tuple,c['critical_extra_rules']))
            if any(sum(r in rr for r in six)>=5 for six in SIX):st='NEEDS_R6_SEARCH'
        if st=='NEEDS_R6_SEARCH' or st.startswith('UNKNOWN'):
            remaining=deadline-time.monotonic()
            if remaining<=0:rec['status']='UNKNOWN_WALL_LIMIT'
            else:
                st,n2,more,holes=engine.run(c['core_blocks'],c['critical_extra_rules'],min(10,remaining),2000000,use_r6=True)
                rec.update(status=st,engine='R6_HIGH_BITSET',r6_nodes=n2)
        if st=='FOUND':
            cert=H/f'fullstar_finite_core_finish_found_{i}.rules.json';rec['certificate']=str(cert)
            rec['direct_audit']=export_and_audit(cert,c['core_blocks'],c['critical_extra_rules'],more,holes,15052);out['status']='FOUND_INDEPENDENTLY_VERIFIED'
        out['records'].append(rec);out['seconds']=time.monotonic()-start;out['counts']=dict(Counter(r['status'] for r in out['records']))
        if done%25==0 or st=='FOUND':save(target,out)
        if done%100==0 or st=='FOUND':print('pending',done+1,'index',i,rec['status'],'elapsed',round(out['seconds'],2),flush=True)
        if st=='FOUND':break
    else:out['status']='ALL_CORES_COVERED'
    covered={r['index'] for r in out['records']};assert len(covered)==len(out['records'])
    out['seconds']=time.monotonic()-start;out['counts']=dict(Counter(r['status'] for r in out['records']))
    out['unprocessed_indices']=sorted(set(range(3735))-covered);out['unknown_indices']=[r['index'] for r in out['records'] if r['status'].startswith('UNKNOWN')]
    out['all_core_coverage']=len(covered)==3735
    out['exhausted_fixed_core_branch']=out['all_core_coverage'] and not out['unknown_indices'] and not any(r['status']=='FOUND' for r in out['records'])
    if out['exhausted_fixed_core_branch']:out['status']='EXHAUSTED_NO_TARGET4_WITH_FIXED_18_CORE'
    save(target,out);print('FINAL',out['status'],out['counts'],out['seconds'],'unprocessed',len(out['unprocessed_indices']),'unknown',out['unknown_indices'],flush=True)
if __name__=='__main__':main()
