"""Bounded six-flip necessary cluster screen; no construction search.

Enumerates all C(35,6) new-triple masks, then reduces only passing masks
underS7. The first screen is necessary only: every triple must belong to
atleastthreeofthefour triples ofsomefour-setU. Every stage reports partial
status ifthe60second walllimit isreached.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import Counter
from math import comb
import json,time
Hdir=Path(__file__).resolve().parent;start=time.monotonic();deadline=start+60;L7=frozenset(range(1,8));L8=frozenset(range(1,9));triples=list(map(frozenset,combinations(range(1,8),3)));ti={t:i for i,t in enumerate(triples)};foursets=list(map(frozenset,combinations(range(1,8),4)));clusters=[sum(1<<ti[t]for t in triples if t<U)for U in foursets]
passed=[];tested=0;enumeration_complete=True
for combo in combinations(range(35),6):
 mask=sum(1<<i for i in combo);covered=0;tested+=1
 for cluster in clusters:
  meet=mask&cluster
  if meet.bit_count()>=3:covered|=meet
 if covered==mask:passed.append((combo,mask))
 if tested%10000==0 and time.monotonic()>deadline:enumeration_complete=False;break
passed_masks={m for c,m in passed};seen=set();records=[];orbit_complete=enumeration_complete
for combo,mask in passed:
 if mask in seen:continue
 if time.monotonic()>deadline:orbit_complete=False;break
 ts=[triples[i]for i in combo];orbit=set()
 for p in permutations(range(1,8)):
  orbit.add(sum(1<<ti[frozenset(p[x-1]for x in t)]for t in ts))
 if enumeration_complete:assert orbit<=passed_masks and not orbit&seen
 seen|=orbit
 fs={L7-t for t in ts};S=set(foursets)-fs|{t|{8}for t in ts};used=set();patterns=[];blocktypes=Counter()
 for X in map(frozenset,combinations(range(1,9),5)):
  inside={s for s in S if s<X};q=len(inside)
  if q==4:
   used|=inside;n=sum(8 in s for s in inside);blocktypes[(n,4-n)]+=24;patterns.append(inside)
  elif q==5:
   used|=inside
   for omit in inside:
    pattern=inside-{omit};n=sum(8 in s for s in pattern);blocktypes[(n,4-n)]+=24;patterns.append(pattern)
 cs=[{'four_set':sorted(U),'triples':sorted(map(sorted,(t for t in ts if t<U))),'old_four_support_allowed':U in S}for U in foursets if sum(t<U for t in ts)>=3]
 records.append({'index':len(records),'new_complement_triples':sorted(map(sorted,ts)),'removed_supports':sorted(map(sorted,fs)),'added_supports':sorted(map(sorted,(t|{8}for t in ts))),'S7_orbit_size':len(orbit),'S7_stabilizer_order':5040//len(orbit),'clusters':cs,'new_triple_union_size':len(set().union(*ts)),'actual_usable_supports':len(used),'actual_usable_cyclic_word_slots':6*len(used),'R5_slot_capacity_upperbound':6*len(used)//4,'passes_slot_52_test':len(used)==35,'four_rule_blocks':sum(blocktypes.values()),'block_types':[{'new_slots':n,'old_slots':o,'blocks':num}for(n,o),num in sorted(blocktypes.items())]})
if enumeration_complete and orbit_complete:assert seen==passed_masks
out={'method':__doc__,'total_labelled_six_flips':comb(35,6),'tested':tested,'enumeration_complete':enumeration_complete,'not_tested':comb(35,6)-tested,'first_screen_passing_masks':len(passed),'orbit_classification_complete':orbit_complete,'classified_S7_orbits':len(records),'classified_passing_masks':len(seen&passed_masks),'unclassified_passing_masks':len(passed_masks-seen),'orbits':records,'slot_eligible_orbit_indices':[r['index']for r in records if r['passes_slot_52_test']],'scope':'Necessary cluster andusable-wordcapacityonly. No actual52blockpacking or15052strategy search performed; a pass isnot anattainment claim.','seconds':time.monotonic()-start}
(Hdir/'support_orientation_six_flip_screen.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print({k:v for k,v in out.items()if k not in('orbits','method')});print([(r['index'],r['S7_orbit_size'],len(r['clusters']),r['R5_slot_capacity_upperbound'],r['four_rule_blocks'])for r in records])
