"""Independent column-branch exact-cover count of the four-flip local gadget."""
from pathlib import Path
from itertools import permutations,combinations
from functools import lru_cache
import json,time,hashlib
H=Path(__file__).resolve().parent;raw=(H/'support_orientation_four_flip_gadget_covers.json').read_bytes();cert=json.loads(raw);start=time.monotonic()
def normal(x):return min(x[k:]+x[:k]for k in range(len(x)))
W=sorted({normal(p)for labels in combinations((4,5,6,7,8),4)for p in permutations(labels)});wi={w:i for i,w in enumerate(W)};NEW=sum(1<<i for i,w in enumerate(W)if 8 in w)
B=set()
for p in permutations((4,5,6,7)):
 c=(8,)+p;rs=[(c[i],c[(i+1)%5],c[(i+2)%5],c[(i+3)%5],c[(i+4)%5])for i in range(5)]
 for omit in range(5):B.add(frozenset(rs[:omit]+rs[omit+1:]))
B=sorted(B,key=lambda b:tuple(sorted(b)));assert len(B)==120;row=[sum(1<<wi[normal(r[:4])]for r in b)for b in B];kinds=[int((r&NEW).bit_count()==4)for r in row];cols=[[i for i,r in enumerate(row)if r>>j&1]for j in range(30)]
@lru_cache(maxsize=500000)
def count(left,b,k,hn,ho):
 if min(b,k,hn,ho)<0 or k>b:return 0
 if not b:return int((left&NEW).bit_count()==hn and (left&~NEW).bit_count()==ho and k==0)
 best=None;c=None;scan=left
 while scan:
  bit=scan&-scan;scan^=bit;j=bit.bit_length()-1
  opts=[i for i in cols[j]if row[i]&left==row[i]and(not kinds[i]or k)and(kinds[i]or k<b)]
  if not opts and not(hn if bit&NEW else ho):return 0
  if best is None or len(opts)<len(best):best=opts;c=bit
 total=sum(count(left^row[i],b-1,k-kinds[i],hn,ho)for i in best)
 if c&NEW:
  if hn:total+=count(left^c,b,k,hn-1,ho)
 elif ho:total+=count(left^c,b,k,hn,ho-1)
 return total
records=[]
for rec in cert['cases']:
 b=rec['b'];k=rec['k'];hn=rec['new_holes'];ho=30-4*b-hn;actual=count((1<<30)-1,b,k,hn,ho);assert actual==rec['packings']
 ex=rec['example_block_ids'];used=0
 for i in ex:assert not row[i]&used;used|=row[i]
 assert len(ex)==b and sum(kinds[i]for i in ex)==k
 records.append({'b':b,'k':k,'independent_packings':actual,'example_verified':True})
out={'method':__doc__,'input_sha256':hashlib.sha256(raw).hexdigest(),'cases':records,'cache_info':str(count.cache_info()),'seconds':time.monotonic()-start,'construction_search_performed':False}
(H/'support_orientation_four_flip_gadget_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
