"""Independently regenerate tuple rows and set-cover-audit all 858 cores.

No imports from completion/witness/search scripts. Core block IDs are
translated by the published sorted actual-rule ordering, then each core's
R6=0 and four rescued sevens are freshly checked. Completion omits R6=0,
so an exhaustive failure is stronger than the proposed constrained check.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict,Counter
import json,time
H=Path(__file__).resolve().parent
def canon(w):
    j=w.index(min(w));return w[j:]+w[:j]
def correct(c):
    n=len(c);return tuple((c[i],c[(i+1)%n],c[(i+2)%n],c[(i+3)%n],c[(i+n-1)%n]) for i in range(n))
forbidden={frozenset(s) for s in ((1,2,3,4),(1,2,3,5),(1,2,3,6),(4,5,6,7))}
words={canon(p) for s in combinations(range(1,8),4) if frozenset(s) not in forbidden for p in permutations(s)}
allblocks=set()
for s in combinations(range(1,8),5):
    for p in permutations(s[1:]):
        rr=correct((s[0],)+p)
        for omit in range(5):
            b=frozenset(rr[:omit]+rr[omit+1:])
            if all(canon(r[:4]) in words for r in b):allblocks.add(b)
blocks=sorted(allblocks,key=lambda b:tuple(sorted(b)))
rows=[{canon(r[:4]) for r in b} for b in blocks]
assert len(words)==186 and len(blocks)==1584
inc=defaultdict(set)
for i,row in enumerate(rows):
    for w in row:inc[w].add(i)
cw={k:[correct((s[0],)+p) for s in combinations(range(1,8),k) for p in permutations(s[1:])] for k in (6,7)}
nodes=0
def solve(rem,selected):
    global nodes
    nodes+=1
    if not rem:return selected
    choices=[]
    for w in rem:
        bs=[b for b in inc[w] if rows[b]<=rem]
        if not bs:return None
        choices.append((len(bs),w,bs))
    for b in min(choices)[2]:
        ans=solve(rem-rows[b],selected+[b])
        if ans is not None:return ans
    return None
def run(core,extras):
    used=[w for b in core for w in rows[b]];holes=[canon(r[:4]) for r in extras]
    assert len(used)==len(set(used)) and len(holes)==2 and len(set(holes))==2 and not set(used)&set(holes)
    return solve(words-set(used)-set(holes),[])
raw=json.loads((H/'r6zero_base.rules.json').read_text());rr={(a,*h,t) for a,h,t in raw['rules']}
control={i for i,b in enumerate(blocks) if b<=rr};assert len(control)==46
holes=words-set().union(*(rows[b] for b in control));extras={w+(8,) for w in holes}
fixed=set(sorted(control)[:33]);nodes=0;ans=run(fixed,extras)
assert ans is not None and len(ans)==13
out={'method':__doc__,'positive_control':{'fixed':33,'recovered':13,'nodes':nodes},'seed_start':435,'seed_end_inclusive':634,'cases':[]}
chosen={}
for prefix in (435,483,597):
    d=json.loads((H/f'agent_local_{prefix}_summary.json').read_text())
    for seed in d['records']:
        if seed['status']=='LOCAL_INFEASIBLE':chosen[seed['seed_index']]=seed
assert len(chosen)==200
t0=time.monotonic()
for seed_index,seed in sorted(chosen.items()):
    for r in seed['records']:
        core=set(r['core_blocks']);extras=set(map(tuple,r['extras']))
        supplied=set().union(*(blocks[b] for b in core))|extras
        assert all(sum(q in supplied for q in rr)<=4 for rr in cw[6])
        assert sum(sum(q in supplied for q in rr)>=6 for rr in cw[7])>=4
        nodes=0;ans=run(core,extras)
        rec={'seed':seed_index,'iteration':r['iteration'],'status':'FOUND_PURE_COVER' if ans is not None else 'EXHAUSTED_NO_COMPLETION','nodes':nodes}
        if ans is not None:rec['additional_blocks']=ans
        out['cases'].append(rec)
out['counts']=dict(Counter(r['status'] for r in out['cases']));out['nodes']=sum(r['nodes'] for r in out['cases']);out['seconds']=time.monotonic()-t0
(H/'agent_witness_435_634_independent.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print({k:v for k,v in out.items() if k not in ('method','cases')})
