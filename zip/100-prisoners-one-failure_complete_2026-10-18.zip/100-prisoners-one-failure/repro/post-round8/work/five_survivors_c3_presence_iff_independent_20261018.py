"""Independent c3-generated exact-presence CP checks for five orientations.

No primary CP builder is imported. Claude's audited c3 generator supplies
actual blocks, words and correct cycle rules. This implementation creates
its own block/singleton/presence channels and bidirectional seven flags.
Each fixed orientation is unrestricted by witness cores or pattern counts.
"""
from pathlib import Path
from itertools import combinations
from collections import defaultdict
import hashlib, json, sys, time

H = Path(__file__).resolve().parent
C3 = H/'claude_desktop_continuation3'
sys.path.insert(0,str(C3))
from c3_model import Orientation,cyc_rules,directed_cycles,word,fivecycle,rotmin,ALL
sys.path.insert(0,r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
from ortools.sat.python import cp_model

START = time.monotonic()
STAR = frozenset(frozenset(s) for s in combinations(range(1,8),4))

def every_cycle(k):
    return [(c,cyc_rules(c)) for support in combinations(range(1,9),k)
            for c in directed_cycles(support)]

CYCLES = {k:every_cycle(k) for k in (6,7,8)}

def source_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def make_model(flips,target):
    flips = frozenset(map(frozenset,flips))
    active = (STAR-flips) | frozenset(ALL-s for s in flips)
    assert len(active) == 35 and all(ALL-s not in active for s in active)
    gen = Orientation(active)
    rules = sorted({w[j:]+w[:j]+(t,) for w in gen.words for j in range(4)
                    for t in range(1,9) if t not in w})
    assert len(gen.words) == 210 and len(rules) == 3360
    m = cp_model.CpModel()
    block = [m.new_bool_var(f'block_{i}') for i in range(len(gen.blocks))]
    single = {r:m.new_bool_var(f'single_{i}') for i,r in enumerate(rules)}
    presence = {r:m.new_bool_var(f'present_{i}') for i,r in enumerate(rules)}
    columns = defaultdict(list)
    suppliers = defaultdict(list)
    for i,actual in enumerate(gen.blocks):
        assert len(actual) == 4 and len({word(r) for r in actual}) == 4
        for r in actual:
            columns[word(r)].append(block[i])
            suppliers[r].append(block[i])
    for r,s in single.items():
        columns[word(r)].append(s)
        suppliers[r].append(s)
    for w in gen.words: m.add_at_most_one(columns[w])
    m.add(sum(block) == 52)
    m.add(sum(single.values()) <= 2)
    for r,p in presence.items(): m.add(p == sum(suppliers[r]))
    nontrivial_six = 0
    for c,rs in CYCLES[6]:
        eligible = [presence[r] for r in rs if r in presence]
        if len(eligible) >= 5: nontrivial_six += 1
        m.add(sum(eligible) <= 4)
    flags = {}
    eligible_seven = 0
    for c,rs in CYCLES[7]:
        eligible = [presence[r] for r in rs if r in presence]
        if len(eligible) >= 6: eligible_seven += 1
        z = m.new_bool_var(f'seven_{len(flags)}')
        flags[c] = z
        m.add(sum(eligible) >= 6).only_enforce_if(z)
        m.add(sum(eligible) <= 5).only_enforce_if(z.Not())
    m.add(sum(flags.values()) >= target)
    max_eight = max(sum(r in presence for r in rs) for c,rs in CYCLES[8])
    assert max_eight == 4
    assert m.validate() == ''
    stats = {'blocks':len(block),'words':len(gen.words),'valid_rules':len(rules),
             'six_constraints':len(CYCLES[6]),'nontrivial_six_constraints':nontrivial_six,
             'seven_iff_flags':len(flags),'eligible_seven_flags':eligible_seven,
             'maximum_eligible_eight_correct_rules':max_eight,'target':target}
    return m,gen,block,single,presence,flags,stats

def fixed_table(gen,block,single,m,path):
    d = json.loads(path.read_text(encoding='utf-8-sig'))
    actual = frozenset((a,*hist,t) for a,hist,t in d['rules'])
    groups = defaultdict(set)
    by_group = defaultdict(list)
    for r in actual: groups[fivecycle(r)].add(r)
    for i,b in enumerate(gen.blocks): by_group[fivecycle(b[0])].append(i)
    selected = set()
    for group,rs in groups.items():
        if len(rs) >= 4:
            eligible = [i for i in by_group[group] if set(gen.blocks[i]) <= rs]
            assert eligible
            selected.add(min(eligible))
    supplied = set().union(*(set(gen.blocks[i]) for i in selected))
    extras = actual-supplied
    assert len(selected) == 52 and len(supplied) == 208 and len(extras) <= 2
    assert len({word(r) for r in actual}) == len(actual)
    assert actual <= single.keys()
    for i,v in enumerate(block): m.add(v == int(i in selected))
    for r,v in single.items(): m.add(v == int(r in extras))
    return {'rules':len(actual),'fixed_selected_blocks':len(selected),'fixed_extras':len(extras),
            'source_sha256':source_hash(path)}

def solve_case(label,flips,target,fixed=None):
    m,gen,bs,ss,ps,flags,stats = make_model(flips,target)
    fixed_info = fixed_table(gen,bs,ss,m,fixed) if fixed is not None else None
    prefix = H/f'five_survivors_c3_presence_iff_{label}_20261018'
    m.export_to_file(str(prefix.with_suffix('.model.pbtxt')))
    s = cp_model.CpSolver()
    s.parameters.num_search_workers = 1
    s.parameters.max_time_in_seconds = 60
    s.parameters.random_seed = 1
    s.parameters.log_search_progress = True
    s.parameters.log_to_stdout = False
    prefix.with_suffix('.parameters.txt').write_text(str(s.parameters),encoding='utf-8')
    with prefix.with_suffix('.log.txt').open('w',encoding='utf-8') as log:
        s.log_callback = lambda line:log.write(line+'\n')
        st = s.solve(m)
    out = {'label':label,'status':s.status_name(st),'workers':1,'limit_seconds':60,
           'solve_seconds':s.wall_time,'response_stats':s.response_stats(),'stats':stats,
           'fixed_control':fixed_info,'validation_error':m.validate(),
           'model_proto':str(prefix.with_suffix('.model.pbtxt')),
           'model_proto_sha256':source_hash(prefix.with_suffix('.model.pbtxt'))}
    if st in (cp_model.OPTIMAL,cp_model.FEASIBLE):
        actual = {r for r,p in ps.items() if s.value(p)}
        selected = [i for i,b in enumerate(bs) if s.value(b)]
        extras = {r for r,v in ss.items() if s.value(v)}
        assert len(selected) == 52 and len(actual) == 208+len(extras) and len(extras) <= 2
        cert = prefix.with_suffix('.rules.json')
        cert.write_text(json.dumps({'n':8,'rules':[[r[0],list(r[1:4]),r[4]] for r in sorted(actual)],
                                    'selected_actual_blocks':[gen.blocks[i] for i in selected],
                                    'extras':sorted(extras)},indent=2),encoding='utf-8')
        from independent_audit import audit
        checked = audit(cert)
        out['certificate'] = str(cert)
        out['direct_40320_audit'] = checked
        assert checked['lost_cf'] == 0 and checked['rescued_cycles']['5'] == 52
        assert checked['rescued_cycles']['6'] == 0 and checked['rescued_cycles']['7'] >= target
        assert checked['rescued_cycles']['7'] == sum(s.value(z) for z in flags.values())
    prefix.with_suffix('.result.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(label,out['status'],out['solve_seconds'],flush=True)
    return out

def main():
    out = {'scope':__doc__,'primary_builder_imported':False,
           'source_sha256':source_hash(Path(__file__)),
           'c3_generator_sha256':source_hash(C3/'c3_model.py'),
           'controls':[],'survivors':[],'status':'RUNNING'}
    output = H/'five_survivors_c3_presence_iff_independent_20261018.json'
    pos = solve_case('control_baseline',(),3,H/'inputs/baseline15051.rules.json')
    assert pos['status'] == 'OPTIMAL'
    out['controls'].append(pos)
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    neg_path = H/'inputs/new15051.rules.json'
    from independent_audit import audit
    neg_audit = audit(neg_path)
    assert neg_audit['rescued_cycles']['6'] == 1
    neg = solve_case('control_R6one',((1,2,3,4),(1,2,3,5),(1,2,3,6)),1,neg_path)
    assert neg['status'] == 'INFEASIBLE'
    neg['rejected_control_direct_40320_audit'] = neg_audit
    out['controls'].append(neg)
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    classification = H/'canonical_orientation_S8_classification.json'
    primary_results = H/'canonical_orientation_five_survivors.json'
    out['classification_sha256'] = source_hash(classification)
    out['primary_result_sha256'] = source_hash(primary_results)
    orbits = {r['index']:r for r in json.loads(classification.read_text())['orbits']}
    expected = {r['index']:r for r in json.loads(primary_results.read_text())['records']}
    for i in (1255,1291,1305,1319,1376):
        row = orbits[i]
        result = solve_case(f'orbit{i}',row['flips'],4)
        result['orbit_index'] = i
        result['canonical_S8_key_hex'] = row['canonical_S8_key_hex']
        assert result['stats']['blocks'] == expected[i]['stats']['blocks']
        assert result['stats']['nontrivial_six_constraints'] == expected[i]['stats']['six_constraints']
        assert result['stats']['eligible_seven_flags'] == expected[i]['stats']['seven_variable_flags']
        result['agrees_with_primary_status'] = result['status'] == expected[i]['status']
        out['survivors'].append(result)
        out['seconds'] = time.monotonic()-START
        output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    out['status'] = 'ALL_FIVE_INFEASIBLE_CONFIRMED' if all(r['status']=='INFEASIBLE' for r in out['survivors']) else 'INDEPENDENT_CHECK_HAS_UNRESOLVED_OR_DIFFERING_RESULT'
    out['seconds'] = time.monotonic()-START
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('FINAL',out['status'],out['seconds'],flush=True)

if __name__ == '__main__':
    main()
