from pathlib import Path
from collections import Counter
import json,sys,time
sys.path.insert(0,'work')
from agent_seed_local_completion import NoSixDLX,RULES,ROWS,WORDS,rotate_min,CW
H=Path('work');d=json.loads((H/'r6zero_base.rules.json').read_text());base={(a,*h,t)for a,h,t in d['rules']}
old={i for i,b in enumerate(RULES)if b<=base};assert len(old)==46
oldrules=set().union(*(RULES[i]for i in old));holes=set(WORDS)-{rotate_min(r[:4])for r in oldrules};assert len(holes)==2
extras={tuple(w)+(8,)for w in holes};mandatory=set(sorted(old)[:33]);mat=NoSixDLX();start=time.monotonic();status,nodes,add=mat.run_nosix(mandatory,extras,3)
assert status=='FOUND';blocks=mandatory|set(add);assert len(blocks)==46
rules=set().union(*(RULES[i]for i in blocks));assert len(rules)==184
assert all(sum(r in rules|extras for r in rr)<=4 for rr in CW[6])
assert {rotate_min(r[:4])for r in rules}|holes==set(WORDS)
full=(base-oldrules)|rules|extras;p=H/'agent_nosixdlx_control.rules.json';p.write_text(json.dumps({'n':8,'rules':[[r[0],list(r[1:4]),r[4]]for r in sorted(full)]},indent=2),encoding='utf-8')
from independent_audit import audit
checked=audit(p);assert checked['lost_cf']==0 and checked['rescued_cycles']['6']==0 and checked['rescued_cycles']['5']==52
out={'status':status,'nodes':nodes,'fixed_oldblocks':33,'recovered_oldblocks':len(add),'oldblocks':len(blocks),'seconds':time.monotonic()-start,'independent_40320_audit':checked}
(H/'agent_nosixdlx_control.audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
