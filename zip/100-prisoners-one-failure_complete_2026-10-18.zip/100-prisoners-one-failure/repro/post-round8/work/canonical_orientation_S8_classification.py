"""S8 quotient of all capacity-passing orientations of the70 witness cores.

The necessary capacity screen is a superset. Sort vertex degrees, then
enumerate every permutation within equal-degree cells; this yields the
exact S8 canonical form of a four-uniform support hypergraph. Low minimum
degrees1..7 are linked to already closed fixed-flip families; minimum0 is
full-star and retained separately as unresolved. No completion is solved.
"""
from pathlib import Path
from itertools import combinations,permutations,product
from collections import Counter,defaultdict
import json,time,hashlib
H=Path(__file__).resolve().parent;ALL=frozenset(range(1,9));A=tuple(map(frozenset,combinations(range(1,8),4)))
SETS=tuple(combinations(range(1,9),4));si={frozenset(s):i for i,s in enumerate(SETS)}
def active(mask):return tuple(s if not mask>>i&1 else ALL-s for i,s in enumerate(A))
def key(ss,degrees):
    cells=defaultdict(list)
    for v,d in enumerate(degrees,1):cells[d].append(v)
    best=None
    for order in product(*(permutations(cells[d]) for d in sorted(cells))):
        mp={v:i+1 for i,v in enumerate(sum(order,()))}
        moved=sum(1<<si[frozenset(mp[v] for v in s)] for s in ss)
        if best is None or moved<best:best=moved
    return best
def main():
    start=time.monotonic();paths=[H/f'canonical_orientation_capacity_{a}_{b}.json' for a,b in [(0,4),(4,25),(25,70)]]
    orientations=defaultdict(list)
    for p in paths:
        d=json.loads(p.read_text());assert d['complete']
        for r in d['records']:
            for h in r['accepted_masks_hex']:orientations[int(h,16)].append(r['core_index'])
    orbits={};low=Counter();eligible=0;degreehist=Counter()
    for mask,cores in sorted(orientations.items()):
        ss=active(mask);degrees=tuple(sum(v in s for s in ss) for v in range(1,9));minimum=min(degrees)
        if minimum<8:
            low[minimum]+=1;continue
        eligible+=1;degreehist[minimum]+=1;can=key(ss,degrees)
        if can not in orbits:
            orbits[can]=dict(canonical_S8_key_hex=f'{can:018x}',representative_mask_hex=f'{mask:09x}',
                flips=[sorted(A[i]) for i in range(35) if mask>>i&1],degrees=degrees,
                representative_core_indices=cores,masks=[],core_indices=[])
        x=orbits[can];x['masks'].append(f'{mask:09x}');x['core_indices'].extend(cores)
    rows=[]
    for i,(can,r) in enumerate(sorted(orbits.items())):
        r['index']=i;r['core_indices']=sorted(set(r['core_indices']));r['labelled_masks_in_screen']=len(r['masks']);rows.append(r)
    out=dict(method=__doc__,capacity_input_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        distinct_capacity_passing_masks=len(orientations),low_minimum_degree_counts=dict(sorted(low.items())),
        minimum_degree_at_least8_masks=eligible,minimum_degree_histogram=dict(sorted(degreehist.items())),
        S8_orbits_with_minimum_degree_at_least8=len(rows),orbits=rows,seconds=time.monotonic()-start)
    (H/'canonical_orientation_S8_classification.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in out.items() if k not in ['orbits','method','capacity_input_sha256']},indent=2),flush=True)
if __name__=='__main__':main()
