import json
from pathlib import Path
from collections import Counter
H=Path(__file__).resolve().parent
chosen={};sources=[]
for prefix in (435,483,597):
    p=H/f'agent_local_{prefix}_summary.json'
    d=json.loads(p.read_text());sources.append(p.name)
    for r in d['records']:
        if r['status']=='LOCAL_INFEASIBLE':chosen[r['seed_index']]=r
out={'scope':'standard3flip; pairorbits435..634; local4-rescue witness generation plusR6zero exactcover','seed_start':435,'seed_end_inclusive':634,'counts':dict(Counter(r['status'] for r in chosen.values())),'closed':len(chosen),'pending':[i for i in range(435,635) if i not in chosen],'witness_cores':sum(len(r['records']) for r in chosen.values()),'dlx_nodes':sum(x['nodes'] for r in chosen.values() for x in r['records']),'source_summaries':sources}
(H/'agent_witness_435_634_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(out)
