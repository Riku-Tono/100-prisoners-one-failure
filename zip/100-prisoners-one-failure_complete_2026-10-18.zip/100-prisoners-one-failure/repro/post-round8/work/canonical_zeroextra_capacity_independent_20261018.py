"""Independent zero-extra orientation screen and distinct rule-variable CP audit.

The screen uses actual block support patterns regenerated from all eight
labels. It is only a necessary packing screen. The CP check fixes the sole
eight-flip orientation but does not fix the witness core.
"""
from pathlib import Path
from itertools import combinations, permutations
from collections import Counter, defaultdict
import hashlib, json, sys, time

H = Path(__file__).resolve().parent
START = time.monotonic()
ALL = frozenset(range(1,9))

def norm(w):
    return min(w[i:] + w[:i] for i in range(len(w)))

def correct(c):
    return frozenset((c[i:] + c[:i])[:4] + ((c[i:] + c[:i])[-1],)
                     for i in range(len(c)))

def cycles(k):
    return [(p, correct(p)) for p in permutations(range(1,9),k) if p[0] == min(p)]

def main():
    groups = {correct(p) for p in permutations(range(1,9),5)}
    allblocks = sorted({g-{r} for g in groups for r in g}, key=lambda b: tuple(sorted(b)))
    supports = tuple(map(frozenset, combinations(range(1,9),4)))
    si = {s:i for i,s in enumerate(supports)}
    star = tuple(s for s in supports if 8 not in s)
    patterns = {sum(1 << si[frozenset(r[:4])] for r in block) for block in allblocks}
    assert len(allblocks) == 6720 and len(patterns) == 280
    assert all(mask.bit_count() == 4 for mask in patterns)
    primary_path = H/'canonical_orientation_capacity_0_4.json'
    primary = json.loads(primary_path.read_text())
    records = []
    larger = []
    for i in range(4):
        data = json.loads((H/'canonical_six_witness_cores'/f'core_{i:03}.json').read_text())
        forced = {frozenset(r[:4]) for block in data['actual_blocks'] for r in block}
        assert len(forced) == 24 and not data['extras']
        free = [j for j,s in enumerate(star) if s not in forced]
        assert len(free) == 11
        accepted = []
        word_checks = []
        for bits in range(2**11):
            flips = {free[j] for j in range(11) if bits >> j & 1}
            active = {ALL-s if j in flips else s for j,s in enumerate(star)}
            mask = sum(1 << si[s] for s in active)
            covered = 0
            for pattern in patterns:
                if pattern & mask == pattern: covered |= pattern
            if covered != mask: continue
            flipmask = sum(1 << j for j in flips)
            accepted.append(flipmask)
            # Stronger direct actual-block/actual-word check on every accepted case.
            available = [b for b in allblocks if all(frozenset(r[:4]) in active for r in b)]
            usable = {norm(r[:4]) for b in available for r in b}
            assert len(usable) == 210
            word_checks.append({'flip_mask': f'{flipmask:09x}',
                                'actual_blocks': len(available), 'usable_words': len(usable)})
            if len(flips) >= 8: larger.append((i, flipmask, active, available))
        accepted.sort()
        own_hex = [f'{mask:09x}' for mask in accepted]
        p = primary['records'][i]
        assert p['core_index'] == i
        assert own_hex == p['accepted_masks_hex']
        digest = hashlib.sha256(''.join(x+'\n' for x in own_hex).encode()).hexdigest()
        assert digest == p['accepted_sha256']
        records.append({'core_index': i, 'tested': 2**11, 'accepted': len(accepted),
                        'accepted_masks_hex': own_hex, 'accepted_sha256': digest,
                        'by_flip_count': dict(sorted(Counter(x.bit_count() for x in accepted).items())),
                        'direct_usable_word_checks': word_checks})
    assert sum(r['accepted'] for r in records) == 54
    assert len(larger) == 1 and larger[0][0:2] == (0, int('00300e80c',16))
    out = {'screen_status': 'PASS', 'scope': __doc__,
           'source_generator_imported': False,
           'primary_screen_sha256': hashlib.sha256(primary_path.read_bytes()).hexdigest(),
           'actual_blocks_regenerated': len(allblocks), 'block_support_patterns': len(patterns),
           'orientations_tested_counting_core_entries': 4*2**11,
           'accepted_core_orientation_entries': 54,
           'accepted_distinct_orientations': len(set(x for r in records for x in r['accepted_masks_hex'])),
           'all_54_actual_word_union_sizes': [210], 'records': records,
           'capacity_necessity': 'A support absent from every available block leaves all six cyclic-word slots unusable, whereas 52 disjoint four-rule blocks require208 of210 active slots. Therefore every active support must occur in an available actual block.',
           'eightflip_cases': [{'core': i, 'mask': f'{mask:09x}',
                                 'degrees': [sum(v in s for s in active) for v in range(1,9)],
                                 'actual_blocks': len(available)} for i,mask,active,available in larger],
           'screen_seconds': time.monotonic()-START}
    output = H/'canonical_zeroextra_capacity_independent_20261018.json'
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('SCREEN PASS', [r['accepted'] for r in records], out['eightflip_cases'], flush=True)

    # A distinct exact representation: x_r are rule-presence variables. A chosen
    # block implies its four x_r. At most one chosen block per five-cycle group,
    # disjoint cyclic-word columns, and208<=sum(x)<=210 allow at most two extras.
    sys.path.insert(0, r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
    from ortools.sat.python import cp_model
    _, flipmask, active, available = larger[0]
    validrules = sorted(r for r in permutations(range(1,9),5) if frozenset(r[:4]) in active)
    assert len(validrules) == 3360 and len(available) == 1344
    m = cp_model.CpModel()
    x = {r:m.new_bool_var(f'x{i}') for i,r in enumerate(validrules)}
    b = [m.new_bool_var(f'b{i}') for i in range(len(available))]
    columns = defaultdict(list)
    blockgroups = defaultdict(list)
    for r,v in x.items(): columns[norm(r[:4])].append(v)
    for opts in columns.values(): m.add_at_most_one(opts)
    for j,block in enumerate(available):
        group = norm(next(iter(block)))
        blockgroups[group].append(b[j])
        for r in block: m.add_implication(b[j], x[r])
    for opts in blockgroups.values(): m.add_at_most_one(opts)
    m.add(sum(b) == 52)
    m.add(sum(x.values()) >= 208)
    m.add(sum(x.values()) <= 210)
    six_count = 0
    for c,rr in cycles(6):
        eligible = [x[r] for r in rr if r in x]
        if len(eligible) >= 5:
            m.add(sum(eligible) <= 4)
            six_count += 1
    flags = []
    for c,rr in cycles(7):
        eligible = [x[r] for r in rr if r in x]
        if len(eligible) < 6: continue
        z = m.new_bool_var(f'seven_{len(flags)}')
        m.add(sum(eligible) >= 6).only_enforce_if(z)
        flags.append(z)
    m.add(sum(flags) >= 4)
    assert len(columns) == 210 and six_count == 588 and len(flags) == 440
    assert m.validate() == ''
    prefix = H/'canonical_zeroextra8flip_independent_rule_model_20261018'
    m.export_to_file(str(prefix.with_suffix('.model.pbtxt')))
    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = 1
    solver.parameters.max_time_in_seconds = 120
    solver.parameters.random_seed = 1
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = False
    prefix.with_suffix('.parameters.txt').write_text(str(solver.parameters),encoding='utf-8')
    with prefix.with_suffix('.log.txt').open('w',encoding='utf-8') as log:
        solver.log_callback = lambda line: log.write(line+'\n')
        status = solver.solve(m)
    result = {'status': solver.status_name(status), 'scope': 'Fixed 00300e80c orientation, targetR7>=4,R6=0,52 noncolliding blocks+<=2 extra rules. No witness core is fixed. Independently regenerated rule-presence model with block implications and five-cycle-group uniqueness; no singleton variables.',
              'workers': 1, 'seconds_limit': 120, 'solve_seconds': solver.wall_time,
              'blocks': len(b), 'valid_rules': len(x), 'five_cycle_groups': len(blockgroups),
              'six_constraints': six_count, 'eligible_seven_flags': len(flags),
              'validation_error': m.validate(), 'response_stats': solver.response_stats(),
              'model_variables': len(m.proto.variables), 'model_constraints': len(m.proto.constraints)}
    if status in (cp_model.FEASIBLE,cp_model.OPTIMAL):
        rs = sorted(r for r,v in x.items() if solver.value(v))
        cert = prefix.with_suffix('.rules.json')
        cert.write_text(json.dumps({'n':8,'rules':[[r[0],list(r[1:4]),r[4]] for r in rs]},indent=2),encoding='utf-8')
        from independent_audit import audit
        result['direct_40320_audit'] = audit(cert)
        assert result['direct_40320_audit']['lost_cf'] == 0
        assert result['direct_40320_audit']['rescued_cycles']['5'] == 52
        assert result['direct_40320_audit']['rescued_cycles']['6'] == 0
        assert result['direct_40320_audit']['rescued_cycles']['7'] >= 4
    prefix.with_suffix('.result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    out['independent_eightflip_CP'] = result
    out['total_seconds'] = time.monotonic()-START
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('INDEPENDENT CP',result['status'],result['solve_seconds'],flush=True)

if __name__ == '__main__':
    main()
