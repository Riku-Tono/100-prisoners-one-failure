"""Independent actual-block screen of all70 canonical-core orientations.

Builds a 280-pattern catalogue directly from all6720 actual four-rule blocks,
then checks every active support for a compatible actual block pattern.
The separate C# loop uses ordinary binary assignments and early failure at
an unusable active support. No submitted generator is imported. No Solve.
"""
from pathlib import Path
from itertools import combinations, permutations
from collections import defaultdict, Counter
import hashlib, json, subprocess, shutil, time

H = Path(__file__).resolve().parent
START = time.monotonic()
ALL = frozenset(range(1,9))

def correct(c):
    return frozenset((c[i:] + c[:i])[:4] + ((c[i:] + c[:i])[-1],)
                     for i in range(len(c)))

def digest_masks(accepted):
    return hashlib.sha256(''.join(f'{x:09x}\n' for x in sorted(accepted)).encode()).hexdigest()

def main():
    groups = {correct(p) for p in permutations(range(1,9),5)}
    blocks = {g - {r} for g in groups for r in g}
    star = tuple(map(frozenset, combinations(range(1,8),4)))
    supports = star + tuple(ALL-s for s in star)
    si = {s:i for i,s in enumerate(supports)}
    patterns = sorted({frozenset(si[frozenset(r[:4])] for r in b) for b in blocks}, key=lambda x: tuple(sorted(x)))
    assert len(blocks) == 6720 and len(patterns) == 280
    assert all(len(p) == 4 and len({j % 35 for j in p}) == 4 for p in patterns)
    req = [sum(1 << (j % 35) for j in p) for p in patterns]
    value = [sum(1 << (j % 35) for j in p if j >= 35) for p in patterns]
    columns = [[i for i,p in enumerate(patterns) if s in p] for s in range(70)]
    assert {len(x) for x in columns} == {16}
    cores = []
    for i in range(70):
        d = json.loads((H/'canonical_six_witness_cores'/f'core_{i:03}.json').read_text())
        forced = {frozenset(r[:4]) for b in d['actual_blocks'] for r in b} | {frozenset(r[:4]) for r in d['extras']}
        assert forced <= set(star)
        free = [j for j,s in enumerate(star) if s not in forced]
        assert len(free) == 11 + 3*len(d['extras'])
        cores.append({'core_index':i, 'free':free})
    total = sum(1 << len(c['free']) for c in cores)
    assert total == 6250496
    inp = {'required':req, 'value':value, 'supportPatterns':columns,
           'cores':cores, 'total_tested':total}
    (H/'independent_allcore_support_screen_20261018.input.json').write_text(json.dumps(inp),encoding='utf-8')
    shell = shutil.which('pwsh') or shutil.which('powershell')
    assert shell
    subprocess.run([shell,'-NoProfile','-File',str(H/'independent_allcore_support_screen_20261018.ps1')],check=True)
    native = json.loads((H/'independent_allcore_support_screen_20261018.csharp.json').read_text(encoding='utf-8-sig'))
    sources = [H/f'canonical_orientation_capacity_{a}_{b}.json' for a,b in ((0,4),(4,25),(25,70))]
    primary = {}
    for path in sources:
        data = json.loads(path.read_text())
        assert data['complete']
        for r in data['records']: primary[r['core_index']] = r
    assert len(native['records']) == len(primary) == 70
    orientation_cores = defaultdict(list)
    records = []
    for record in native['records']:
        i = record['core_index']
        accepted = record['accepted_masks']
        p = primary[i]
        assert record['tested'] == p['tested']
        assert [f'{x:09x}' for x in accepted] == p['accepted_masks_hex']
        own_hash = digest_masks(accepted)
        assert own_hash == p['accepted_sha256']
        for mask in accepted: orientation_cores[mask].append(i)
        records.append({'core_index':i,'tested':record['tested'],'accepted':len(accepted),
                        'accepted_sha256':own_hash,
                        'by_flip_count':dict(sorted(Counter(x.bit_count() for x in accepted).items()))})
    distinct = sorted(orientation_cores)
    assert len(distinct) == 27423
    degree_hist = Counter()
    low = Counter()
    eligible = []
    for mask in distinct:
        active = [ALL-s if mask >> j & 1 else s for j,s in enumerate(star)]
        minimum = min(sum(v in s for s in active) for v in range(1,9))
        if minimum < 8: low[minimum] += 1
        else: eligible.append(mask); degree_hist[minimum] += 1
    assert len(eligible) == 22610
    out = {'status':'PASS','scope':__doc__,'Solve_called':False,
           'actual_blocks':len(blocks),'actual_block_support_patterns':len(patterns),
           'patterns_per_support':16,'total_core_orientation_assignments':total,
           'accepted_core_orientation_entries':sum(r['accepted'] for r in records),
           'distinct_accepted_orientations':len(distinct),
           'distinct_accepted_sha256':digest_masks(distinct),
           'minimum_degree_at_least8_count':len(eligible),
           'minimum_degree_at_least8_sha256':digest_masks(eligible),
           'low_minimum_degree_counts':dict(sorted(low.items())),
           'minimum_degree_histogram':dict(sorted(degree_hist.items())),
           'all70_per_core_sets_exact_match':True,'records':records,
           'orientation_cores':{f'{mask:09x}':orientation_cores[mask] for mask in distinct},
           'primary_input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
           'native_screen_seconds':native['seconds'],'seconds':time.monotonic()-START}
    (H/'independent_allcore_support_screen_20261018.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in out.items() if k not in ('records','orientation_cores')},indent=2),flush=True)

if __name__ == '__main__':
    main()
