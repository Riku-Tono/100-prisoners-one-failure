"""Validate observed local pair cores and count singleton-budget pair pruning.

No completion is searched and the sampled pair graph remains incomplete.
"""
from pathlib import Path
from itertools import permutations
from collections import Counter,defaultdict
import hashlib,json,time

H=Path(__file__).resolve().parent
PREFIX=H/'fullstar_shared7675_witness_pair_preparation_20261018'
START=time.monotonic()

def correct(c):return frozenset((c[i:]+c[:i])[:4]+((c[i:]+c[:i])[-1],) for i in range(len(c)))
def norm(w):return min(w[i:]+w[:i] for i in range(len(w)))
def cross(a,b):return sum(a.values())*sum(b.values())-sum(n*b.get(c,0) for c,n in a.items())
def within(a):return (sum(a.values())**2-sum(n*n for n in a.values()))//2

def main():
 raw=PREFIX.with_suffix('.witnesses.json');doc=json.loads(raw.read_text());ws=doc['witnesses']
 counts=[Counter() for _ in range(3)];single=defaultdict(Counter);pairs=defaultdict(Counter)
 for w in ws:
  c=w['cycle_index'];ex=tuple(tuple(r) for r in w['extras']);e=len(ex);counts[e][c]+=1
  if e==1:single[ex[0]][c]+=1
  if e==2:pairs[ex][c]+=1
 detail={'zero_zero':within(counts[0]),'zero_one':cross(counts[0],counts[1]),
         'zero_two':cross(counts[0],counts[2]),'one_one':within(counts[1]),
         'one_two':sum(cross(single.get(r,{}),hist) for ex,hist in pairs.items() for r in ex),
         'two_two_same_pair':sum(within(hist) for hist in pairs.values())}
 budget=sum(detail.values())
 groups={correct(p) for p in permutations(range(1,8),5)}
 blocks=sorted({g-{r} for g in groups for r in g},key=lambda b:tuple(sorted(b)))
 six=[correct(p) for p in permutations(range(1,8),6) if p[0]==min(p)]
 seven=[(p,correct(p)) for p in permutations(range(1,8),7) if p[0]==min(p)]
 inc6=defaultdict(list);inc7=defaultdict(list)
 for i,rr in enumerate(six):
  for r in rr:inc6[r].append(i)
 for i,(c,rr) in enumerate(seven):
  for r in rr:inc7[r].append(i)
 obs_path=PREFIX.with_suffix('.observed_pair_cores.json');obs=json.loads(obs_path.read_text())
 assert obs['complete'] is False
 hist=Counter();minblocks=100;minrecords=[]
 for i,record in enumerate(obs['cores']):
  bs=set(record['all_core_blocks']);ex=set(map(tuple,record['critical_extra_rules']))
  rr=set().union(*(blocks[b] for b in bs))|ex
  assert len(rr)==4*len(bs)+len(ex) and len(ex)<=2
  assert len({norm(r[:4]) for r in rr})==len(rr)
  n6=Counter(k for r in rr for k in inc6[r]);assert max(n6.values(),default=0)<=4
  n7=Counter(k for r in rr for k in inc7[r]);rescued=[seven[k][0] for k,n in n7.items() if n>=6]
  assert len(rescued)>=4
  hist[(len(bs),len(ex),len(rescued))]+=1
  if len(bs)<minblocks:minblocks=len(bs);minrecords=[]
  if len(bs)==minblocks:minrecords.append({'observed_index':i,'all_core_blocks':sorted(bs),
                                         'extras':sorted(ex),'rescued_sevens':rescued})
 out={'status':'PASS_PREPARATION_CHECKS_ONLY','completion_Solve_called':False,
      'pair_graph_complete':False,'witness_records':len(ws),
      'exact_cross_cycle_pairs_passing_extra_budget':budget,
      'extra_budget_pair_detail':detail,'observed_pair_union_cores_checked':len(obs['cores']),
      'all_observed_cores_have_R6zero_R7atleast4':True,
      'observed_core_histogram':[{'blocks':b,'extras':e,'rescued_sevens':r,'count':n}
                                for (b,e,r),n in sorted(hist.items())],
      'minimum_observed_blocks':minblocks,'minimum_block_observed_cores':minrecords,
      'witness_source_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),
      'observed_core_source_sha256':hashlib.sha256(obs_path.read_bytes()).hexdigest(),
      'interpretation':'Only local critical cores have been validated. None is asserted to complete to52 blocks. The full compatibility graph has not been enumerated.',
      'seconds':time.monotonic()-START}
 (H/'fullstar_shared7675_preparation_checks_20261018.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in out.items() if k not in ('observed_core_histogram','minimum_block_observed_cores')},indent=2),flush=True)

if __name__=='__main__':main()
