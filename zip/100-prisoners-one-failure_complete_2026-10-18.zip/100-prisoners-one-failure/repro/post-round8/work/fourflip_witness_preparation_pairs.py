"""Enumerate four-flip compatible witness-pair orbits; no solving.

Uses actual lossword collisions, allows shared blocks, and normalizes each
possible first witness to one of4 representatives under the144-label group.
This prepares pair seeds only; no bound on completed block-only R7 is used.
"""
from fourflip_witness_preparation_data import prepare,H
from general_orientation_model import correct
from collections import Counter
from itertools import combinations
import json,time

def main():
    start=time.monotonic()
    d,data,rows,group,maps,ws,parents,wtypes,normalizers=prepare()
    wi={w:i for i,w in enumerate(data.words)}
    rowmasks=[sum(1<<wi[w] for w in row) for row in rows]
    occupied=[sum(rowmasks[b] for b in w) for w in ws]
    invmaps=[]
    for m in maps:
        inv=[0]*len(m)
        for i,j in enumerate(m):inv[j]=i
        invmaps.append(inv)
    reps=d['representative_witnesses'];keys={};ordered=selfreverse=0;sharedhist=Counter()
    for aid,a in enumerate(reps):
        aa=frozenset(a['blocks']);aocc=sum(rowmasks[b] for b in aa)
        for j,b in enumerate(ws):
            if parents[j]==tuple(a['cycle']):continue
            common=aa&b
            if aocc&occupied[j]!=sum(rowmasks[q] for q in common):continue
            ordered+=1;sharedhist[len(common)]+=1
            bid,gi=normalizers[(parents[j],b)]
            inv=invmaps[gi];reverse=(bid,tuple(sorted(inv[q] for q in aa)))
            forward=(aid,tuple(sorted(b)));selfreverse+=int(reverse==forward)
            key=min(forward,reverse)
            if key not in keys:
                if key==forward:core=sorted(aa|b);cycles=[a['cycle'],parents[j]]
                else:
                    core=sorted(set(reps[bid]['blocks'])|set(reverse[1]))
                    g=group[gi];inverse={v:k for k,v in g.items()}
                    mapped=tuple(inverse[x] for x in a['cycle']);q=mapped.index(min(mapped));mapped=mapped[q:]+mapped[:q]
                    cycles=[reps[bid]['cycle'],mapped]
                used=[s for q in core for s in rows[q]]
                assert len(used)==len(set(used))==4*len(core)
                supplied=set().union(*(data.blocks[q] for q in core))
                assert all(len(correct(tuple(c))&supplied)>=6 for c in cycles)
                keys[key]={'blocks':core,'cycles':cycles,'actual_rules':[sorted(data.blocks[q]) for q in core]}
    assert ordered==2*len(keys)-selfreverse
    # Explicit raw graph count independently checks the orbit/stabilizer count.
    edges=0;adj=[set() for _ in ws]
    for i,j in combinations(range(len(ws)),2):
        if parents[i]==parents[j]:continue
        shared=ws[i]&ws[j]
        if occupied[i]&occupied[j]!=sum(rowmasks[b] for b in shared):continue
        edges+=1;adj[i].add(j);adj[j].add(i)
    assert edges==ordered*144//2
    triangles=k4=0
    for i in range(len(ws)):
        for j in (q for q in adj[i] if q>i):
            for k in (q for q in adj[i]&adj[j] if q>j):
                triangles+=1;k4+=sum(q>k for q in adj[i]&adj[j]&adj[k])
    out={'status':'PREPARED_ENUMERATION_ONLY_NO_SOLVE','scope':__doc__,'group_order':144,'witnesses':len(ws),'witness_orbits':len(reps),'raw_compatible_pair_edges':edges,'normalized_ordered_pairs':ordered,'self_reverse_pair_orbits':selfreverse,'unordered_pair_orbits':len(keys),'shared_block_histogram_of_normalized_ordered_pairs':dict(sharedhist),'pair_union_size_histogram':dict(Counter(len(s['blocks']) for s in keys.values())),'raw_triangles':triangles,'raw_K4':k4,'clique_count_scope':'Fresh local block-only witness compatibility graph for this four-flip orientation; not completion, no extra rules, not a target4 exclusion.','seconds':time.monotonic()-start,'seeds':[keys[k] for k in sorted(keys)]}
    (H/'fourflip_witness_preparation_pairs.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print({k:v for k,v in out.items() if k not in ('scope','seeds')},flush=True)
if __name__=='__main__':main()
