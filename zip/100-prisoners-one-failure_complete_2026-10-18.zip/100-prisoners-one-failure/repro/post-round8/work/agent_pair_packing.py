"""Bounded pure packing prefilter for all 913 witness pair seed orbits.

Any EXHAUSTED result excludes the seed even before R6/R7 requirements.
FOUND means only its first packing was scanned for all 17^2 hole fillings.
UNKNOWN never means infeasible. Timed-out DLX matrices are discarded.
"""
from agent_seed_triangle_completion import FlexibleDLX, RULES, ROWS, WORDS
from completion_dlx_recheck import rotate_min, correct
from itertools import combinations, permutations, product
from collections import defaultdict, Counter
from pathlib import Path
import json, time, sys, hashlib

H=Path(__file__).parent

def all_cycles(k):
    for s in combinations(range(1,9),k):
        for p in permutations(s[1:]): yield (s[0],)+p

def new_rules():
    raw=json.loads((H/'inputs/new15051.rules.json').read_text())
    group=defaultdict(set)
    for a,h,t in raw['rules']:
        r=(a,*h,t);group[rotate_min((t,)+r[:4])].add(r)
    new=set().union(*(g for g in group.values() if len(g)==4 and any(8 in r for r in g)))
    assert len(new)==24
    return new

DATA=[];INC=defaultdict(list)
for k in range(5,9):
    for c in all_cycles(k):
        rr=frozenset(correct(c));i=len(DATA);DATA.append((k,rr))
        for r in rr:INC[r].append(i)
NEW=new_rules()

def fill_scan(blocks,holes,index):
    base=NEW|set().union(*(RULES[b] for b in blocks));assert len(base)==208
    counts=[len(base&rr) for k,rr in DATA]
    resc=Counter(k for (k,rr),n in zip(DATA,counts) if n>=k-1)
    choices=[[None]+[tuple(w[j:]+w[:j])+(t,) for j in range(4) for t in range(1,9) if t not in w] for w in holes]
    assert all(len(c)==17 for c in choices)
    hist=Counter();best=None;target=None
    for extras in product(*choices):
        delta=Counter(i for r in extras if r is not None for i in INC[r]);R=resc.copy()
        for i,d in delta.items():
            k,_=DATA[i];n=counts[i];R[k]+=int(n+d>=k-1)-int(n>=k-1)
        assert R[5]==52
        wins=14736+6*R[5]+2*R[6]+R[7]+R[8]
        hist[(R[6],R[7],R[8],wins)]+=1
        if R[6]==0 and (best is None or wins>best['wins']):
            best=dict(wins=wins,R={str(k):R[k] for k in range(5,9)},extras=[r for r in extras if r is not None])
        if R[6]==0 and R[7]>=4 and (target is None or wins>target[0]):
            target=(wins,base|{r for r in extras if r is not None})
    result=dict(fillings=289,best_R6_zero=best,histogram=[dict(R6=k[0],R7=k[1],R8=k[2],wins=k[3],count=v) for k,v in sorted(hist.items())])
    if target is not None:
        wins,rules=target;path=H/f'agent_pair_packing_found_{index}.rules.json'
        path.write_text(json.dumps(dict(n=8,rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(rules)]),indent=2),encoding='utf-8')
        from independent_audit import audit
        checked=audit(path)
        assert checked['wins']==wins and checked['lost_cf']==0 and checked['rescued_cycles']['6']==0
        result.update(certificate=str(path),direct_audit=checked)
    return result

def main():
    raw=(H/'witness_pair_seeds.json').read_bytes();seeds=json.loads(raw)['seeds']
    seconds=float(sys.argv[1]) if len(sys.argv)>1 else 1
    total=float(sys.argv[2]) if len(sys.argv)>2 else 180
    out=dict(scope='913 G36 witness pair union orbits, pure completion to 46 old blocks and 2 unrestricted holes; first packing only on FOUND',input_sha256=hashlib.sha256(raw).hexdigest(),seconds_per_seed=seconds,total_seeds=len(seeds),cases=[])
    start=time.monotonic();matrix=FlexibleDLX()
    for index,seed in enumerate(seeds):
        if time.monotonic()-start>=total:break
        mandatory=set(seed['blocks']);used=[w for b in mandatory for w in ROWS[b]]
        assert len(used)==len(set(used))
        st,nodes,extra,holes=matrix.run_flexible(mandatory,seconds)
        rec=dict(index=index,status=st,nodes=nodes)
        if st=='UNKNOWN':matrix=FlexibleDLX()
        if st=='FOUND':
            blocks=sorted(mandatory|set(extra));used=[w for b in blocks for w in ROWS[b]]
            assert len(blocks)==46 and len(used)==184 and len(set(used))==184 and set(used)|set(holes)==set(WORDS)
            rec.update(blocks=blocks,holes=holes,fill_scan=fill_scan(blocks,holes,index))
        out['cases'].append(rec);out['counts']=dict(Counter(c['status'] for c in out['cases']));out['seconds']=time.monotonic()-start;out['not_run']=len(seeds)-len(out['cases'])
        (H/'agent_pair_packing.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        if index%10==0 or st!='UNKNOWN':print(index,st,nodes,out['counts'],round(out['seconds'],3),flush=True)
        if st=='FOUND' and 'certificate' in rec['fill_scan']:break
    print('FINAL',out['counts'],out['seconds'],out['not_run'],flush=True)

if __name__=='__main__':main()
