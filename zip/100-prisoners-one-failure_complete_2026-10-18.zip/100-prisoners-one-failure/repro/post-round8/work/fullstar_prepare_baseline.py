"""Extract known full-star 15051 certificate and its three-seven witness.

Preparation only: no alternate completion or new construction is searched.
"""
from fullstar_prepare_basic import *
raw=json.loads((H/'inputs/baseline15051.rules.json').read_text())
rr={(a,*h,t) for a,h,t in raw['rules']}
chosen={b for b,rs in enumerate(RULES) if rs<=rr}
assert len(rr)==208 and len(chosen)==52
used=[w for b in chosen for w in ROWS[b]]
assert len(used)==len(set(used))==208
holes=set(WORDS)-set(used);assert len(holes)==2
rescued={k:[] for k in (6,7)}
for k in (6,7):
    for s in combinations(range(1,8),k):
        for p in permutations(s[1:]):
            c=(s[0],)+p
            if len(correct(c)&rr)>=k-1:rescued[k].append(c)
assert len(rescued[6])==0 and len(rescued[7])==3
options=[];correct_counts=[]
for c in rescued[7]:
    needed=correct(c)&rr
    correct_counts.append(len(needed))
    opts=[]
    for kept in combinations(sorted(needed),6):
        w={b for b in chosen if RULES[b]&set(kept)}
        assert len(w)==6
        opts.append(w)
    options.append(opts)
triples=[]
for a in options[0]:
    for b in options[1]:
        for c in options[2]:triples.append((a|b|c,[a,b,c]))
core,ws=min(triples,key=lambda t:(len(t[0]),tuple(sorted(t[0]))));rules=set().union(*(RULES[b] for b in core))
assert all(len(correct(c)&rules)>=6 for c in rescued[7])
out={'status':'PREPARED_EXISTING_CERTIFICATE_ONLY','scope':__doc__,'rules':len(rr),'blocks':len(chosen),'R5':52,'R6':0,'R7':3,'wins':15051,'rescued_sevens':rescued[7],'correct_window_counts':correct_counts,'witness_options_per_cycle':list(map(len,options)),'witness_option_triples':len(triples),'triple_union_size_histogram':dict(Counter(len(c) for c,w in triples)),'two_holes':sorted(holes),'selected_blocks':sorted(chosen),'witness_blocks':[sorted(w) for w in ws],'mandatory_three_witness_union':sorted(core),'mandatory_block_count':len(core),'additional_blocks_for52':52-len(core),'actual_mandatory_rules':[sorted(RULES[b]) for b in sorted(core)],'known_selected_actual_rules':[sorted(RULES[b]) for b in sorted(chosen)]}
(H/'fullstar_prepare_baseline.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print({k:v for k,v in out.items() if k not in ('scope','selected_blocks','witness_blocks','mandatory_three_witness_union','actual_mandatory_rules','known_selected_actual_rules')},flush=True)
