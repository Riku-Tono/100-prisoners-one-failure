"""Prepare compatible full-star two-seven witness seeds under S7.

No completion or construction search. Normalize one directed seven-cycle
and its witness to one of four canonical anchors; the anchor stabilizer is
trivial. Normalize both possible anchor choices and retain the lesser key.
This counts unordered witnessed-cycle-pair orbits, not necessarily distinct
mandatory-union orbits when different witness decompositions share a union.
"""
from fullstar_prepare_basic import *

def main():
    t0=time.monotonic();canonical=tuple(range(1,8));base=sorted(witnesses(canonical),key=lambda w:tuple(sorted(w)))
    bindex={w:i for i,w in enumerate(base)}
    def mapblock(b,mp):return lookup[frozenset(tuple(mp[x] for x in r) for r in RULES[b])]
    rotations=[{x:(x-1+s)%7+1 for x in range(1,8)} for s in range(7)]
    orbitkeys={};norm={}
    for i,w in enumerate(base):
        options=[(tuple(sorted(mapblock(b,mp) for b in w)),s) for s,mp in enumerate(rotations)]
        key,shift=min(options);norm[i]=(key,shift)
    anchors=sorted({key for key,shift in norm.values()});atype={w:i for i,w in enumerate(anchors)}
    assert len(base)==28 and len(anchors)==4
    # There is exactly one stabilizer map for a canonical witness.
    assert all(sum(tuple(sorted(mapblock(b,mp) for b in w))==tuple(sorted(w)) for mp in rotations)==1 for w in base)
    relevant=set().union(*base);global_w=[];parents=[];baseids=[];cyclelist=[]
    for tail in permutations(range(2,8)):
        c=(1,)+tail;cid=len(cyclelist);cyclelist.append(c);mp=dict(zip(range(1,8),c))
        mapped={b:mapblock(b,mp) for b in relevant}
        for i,w in enumerate(base):global_w.append(frozenset(mapped[b] for b in w));parents.append(cid);baseids.append(i)
    assert len(global_w)==20160
    rowsmask=[]
    wi={w:i for i,w in enumerate(WORDS)}
    for row in ROWS:rowsmask.append(sum(1<<wi[w] for w in row))
    occ=[sum(rowsmask[b] for b in w) for w in global_w]
    # All witness rows are disjoint, so bitwise OR and integer sum coincide.
    assert all(x.bit_count()==24 for x in occ)
    canonical_id=cyclelist.index(canonical);pairkeys={};ordered=0;selfreverse=0;sharedhist=Counter();unionhist=Counter()
    for aid,a in enumerate(anchors):
        aa=frozenset(a);aocc=sum(rowsmask[b] for b in aa)
        for j,b in enumerate(global_w):
            if parents[j]==canonical_id:continue
            common=aa&b
            if aocc&occ[j]!=sum(rowsmask[q] for q in common):continue
            ordered+=1;sharedhist[len(common)]+=1;unionhist[len(aa|b)]+=1
            # The map first takes cycle c back to 1..7, then rotates its base
            # witness into the unique canonical anchor representative.
            c=cyclelist[parents[j]];basekey,shift=norm[baseids[j]];bid=atype[basekey]
            mp={c[k]:(k+shift)%7+1 for k in range(7)}
            reverse=(bid,tuple(sorted(mapblock(q,mp) for q in aa)))
            selfreverse+=int(reverse==(aid,tuple(sorted(b))))
            key=min((aid,tuple(sorted(b))),reverse)
            if key not in pairkeys:
                if key[0]==aid and key[1]==tuple(sorted(b)):
                    core=tuple(sorted(aa|b));cs=[canonical,c]
                else:
                    core=tuple(sorted(set(anchors[bid])|set(reverse[1])));cs=[canonical,canon(tuple(mp[x] for x in canonical))]
                pairkeys[key]={'blocks':core,'cycles':cs,'anchor_type':key[0]}
    assert ordered==2*len(pairkeys)-selfreverse
    for seed in pairkeys.values():
        used=[w for b in seed['blocks'] for w in ROWS[b]]
        supplied=set().union(*(RULES[b] for b in seed['blocks']))
        assert len(used)==len(set(used))==4*len(seed['blocks'])
        assert all(len(correct(c)&supplied)>=6 for c in seed['cycles'])
    out={'status':'PREPARED_NO_CONSTRUCTION_SEARCH','scope':__doc__,'slots':210,'blocks':2520,'cycles':720,'witnesses':len(global_w),'distinct_witness_block_sets':len(set(global_w)),'anchor_types':4,'normalized_ordered_compatible_pairs':ordered,'self_reverse_pair_orbits':selfreverse,'unordered_witnessed_pair_orbits':len(pairkeys),'unordered_pair_seed_union_size_histogram':dict(Counter(len(seed['blocks']) for seed in pairkeys.values())),'raw_compatible_pair_edges_via_orbit_stabilizer':ordered*5040//2,'ordered_pair_shared_block_histogram':dict(sharedhist),'ordered_pair_union_size_histogram':dict(unionhist),'seconds':time.monotonic()-t0,'seeds':[pairkeys[k] for k in sorted(pairkeys)]}
    (H/'fullstar_prepare_pairs.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print({k:v for k,v in out.items() if k not in ('scope','seeds')},flush=True)
if __name__=='__main__':main()
