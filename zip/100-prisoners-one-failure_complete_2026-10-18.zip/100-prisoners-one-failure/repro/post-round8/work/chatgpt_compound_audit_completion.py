"""Independently complete all2938 compound cores WITHOUT ANY R6 condition.

Regenerates all1584 old block rows from5-cycles. Uses integer-bitset Algorithm
X with fixed two singleton slots; no CP-SAT, DLX, six-cycle rules or counters.
No time limit: every recorded negative result is exhaustive.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import Counter
import json,time,hashlib
H=Path(__file__).resolve().parent

def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def correct(c):
    n=len(c)
    return frozenset((c[j],c[(j+1)%n],c[(j+2)%n],c[(j+3)%n],c[(j-1)%n]) for j in range(n))
def cycles(k):
    for s in combinations(range(1,8),k):
        for p in permutations(s[1:]):yield (s[0],)+p

forbidden={frozenset(s) for s in ((1,2,3,4),(1,2,3,5),(1,2,3,6),(4,5,6,7))}
words=tuple(c for c in cycles(4) if frozenset(c) not in forbidden);wi={w:i for i,w in enumerate(words)}
blockset=set()
for c in cycles(5):
    rr=correct(c)
    for omit in rr:
        kept=rr-{omit}
        if all(canon(r[:4]) in wi for r in kept):blockset.add(kept)
blocks=tuple(sorted(blockset,key=lambda rs:tuple(sorted(rs))))
assert len(words)==186 and len(blocks)==1584
rows=[sum(1<<wi[canon(r[:4])] for r in b) for b in blocks]
columns=[0]*186
for b,rr in enumerate(blocks):
    for r in rr:columns[wi[canon(r[:4])]]|=1<<b
conflict=[]
for rr in blocks:
    mask=0
    for r in rr:mask|=columns[wi[canon(r[:4])]]
    conflict.append(mask)

class PureCover:
    def run(self,mandatory,extras,hint=()):
        self.nodes=0;self.answer=None;self.hint=sum(1<<b for b in hint)
        self.mandatory=set(mandatory);self.holes={canon(r[:4]) for r in extras}
        assert len(self.holes)==2
        left=(1<<186)-1;available=(1<<1584)-1
        for h in self.holes:
            i=wi[h];left^=1<<i;available&=~columns[i]
        for b in sorted(mandatory):
            assert left&rows[b]==rows[b]
            left^=rows[b];available&=~conflict[b]
        return self.search(left,available,[])
    def search(self,left,available,chosen):
        self.nodes+=1
        if not left:
            self.answer=chosen[:];return True
        pending=left;small=100000;options=0
        while pending:
            bit=pending&-pending;pending^=bit;i=bit.bit_length()-1
            possible=columns[i]&available;n=possible.bit_count()
            if not n:return False
            if n<small:small=n;options=possible
        preferred=options&self.hint;rest=options&~self.hint
        for mask in (preferred,rest):
            while mask:
                bit=mask&-mask;mask^=bit;b=bit.bit_length()-1
                if self.search(left^rows[b],available&~conflict[b],chosen+[b]):return True
        return False

def main():
    start=time.monotonic();raw=(H/'chatgpt_compound_audit_compound_seeds.json').read_bytes();data=json.loads(raw);seeds=data['seeds'];assert len(seeds)==2938
    engine=PureCover()
    controlraw=(H/'r6zero_base.rules.json').read_bytes();control=json.loads(controlraw)
    controlrules={(a,*h,t) for a,h,t in control['rules']};known={b for b,rr in enumerate(blocks) if rr<=controlrules};assert len(known)==46
    used={canon(r[:4]) for b in known for r in blocks[b]};holes=set(words)-used;assert len(holes)==2
    extras={w+(8,) for w in holes};retained=set(sorted(known)[:33])
    found=engine.run(retained,extras,known);assert found and len(engine.answer)==13
    recovered=retained|set(engine.answer);covered=[canon(r[:4]) for b in recovered for r in blocks[b]]
    assert len(recovered)==46 and len(covered)==len(set(covered))==184 and set(covered)|holes==set(words)
    out=dict(method=__doc__,input_sha256=hashlib.sha256(raw).hexdigest(),R6_constraint_used=False,time_limit=None,positive_control=dict(status='FOUND',fixed_blocks=33,recovered_blocks=13,nodes=engine.nodes,control_source_sha256=hashlib.sha256(controlraw).hexdigest()),cases=[])
    for index,seed in enumerate(seeds):
        core=set(seed['core_blocks']);extras=set(map(tuple,seed['extras']))
        found=engine.run(core,extras)
        assert not found,('UNEXPECTED_COMPLETION',index,sorted(core),sorted(extras),engine.answer)
        out['cases'].append(dict(index=index,status='EXHAUSTED_NO_COMPLETION_WITHOUT_R6',nodes=engine.nodes,in_existing2791=seed['in_existing2791'],base_indices=[p['base_index'] for p in seed['provenance']]))
    out.update(total=len(out['cases']),exhausted=len(out['cases']),found=0,unknown=0,nodes=sum(c['nodes'] for c in out['cases']),max_nodes=max(c['nodes'] for c in out['cases']),node_histogram=dict(sorted(Counter(c['nodes'] for c in out['cases']).items())),seconds=time.monotonic()-start)
    (H/'chatgpt_compound_audit_completion.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in out.items() if k!='cases'},indent=2),flush=True)

if __name__=='__main__':main()
