from itertools import combinations,permutations
from collections import Counter
from pathlib import Path
import json
L=set(range(1,9))
def canon(x):
 x=tuple(x);i=x.index(min(x));return x[i:]+x[:i]
def cycs(k):
 for s in combinations(sorted(L),k):
  for t in permutations(s[1:]):yield (s[0],)+t
def rr(c):
 k=len(c);return tuple((c[i],c[(i+1)%k],c[(i+2)%k],c[(i+3)%k],c[(i-1)%k])for i in range(k))
S={frozenset(s)for s in combinations(range(1,8),4)}
for a in [(1,2,3,4),(1,2,3,5),(1,2,3,6)]:S.remove(frozenset(a));S.add(frozenset(L-set(a)))
W={c for c in cycs(4)if frozenset(c)in S};N={w for w in W if 8 in w};Q={w for w in W if frozenset(w)==frozenset((4,5,6,7))};O=W-N-Q
B=[]
for c in cycs(5):
 rs=rr(c)
 for omit in range(5):
  b=rs[:omit]+rs[omit+1:];words={canon(r[:4])for r in b}
  if words<=W:B.append((b,words))
counts=Counter((len(w&N),len(w&Q),len(w&O))for b,w in B)
assert counts=={(0,0,4):1584,(0,1,3):288,(3,1,0):24}
record={'status':'EXACT_FINITE_COUNTS','slots':{'total':len(W),'contains8':len(N),'4567':len(Q),'old':len(O)},'block_types':[{'slots_contains8':a,'slots_4567':b,'old_slots':c,'count':n}for(a,b,c),n in sorted(counts.items())],'proof':'52 blocks consume208 of210 pairwise-disjoint slots, leaving at most2. With b blocks that meet an8-slot, the18 such slots require18-3b<=2, hence b>=6. Each such block consumes one of6 slots4567, so b<=6. Thus b=6, all24 new-side slots occupied, no singleton there, and all288 cross blocks excluded. Remaining46 blocks cover184 of186 old slots, leaving two old singleton slots.'}
record['long_cycle_support_windows']={}
for n in (6,7,8):
 distribution=Counter()
 for c in cycs(n):
  allowed=sum(frozenset(c[(j+i)%n]for i in range(4))in S for j in range(n))
  distribution[(8 in c,allowed)]+=1
 record['long_cycle_support_windows'][str(n)]={'max_containing8':max(k for(has8,k),num in distribution.items()if has8),'eligible':sum(num for(has8,k),num in distribution.items()if k>=n-1),'eligible_containing8':sum(num for(has8,k),num in distribution.items()if has8 and k>=n-1),'distribution':[{'contains8':has8,'allowed_windows':k,'cycles':num}for(has8,k),num in sorted(distribution.items())]}
Path('work/agent_full_split_check.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record,indent=2))
