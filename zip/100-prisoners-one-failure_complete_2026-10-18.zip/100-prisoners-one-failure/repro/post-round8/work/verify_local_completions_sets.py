"""Independent tuple/set exact-cover audit of recorded local-witness cores.
Regenerates block rules from five-cycles; no submitted completion imports.
"""
from audit_partial_four_witness import rows,rotate,cr,H
from itertools import permutations,combinations
from collections import Counter,defaultdict
import json,time
slots=[frozenset(rotate(r[:4]) for r in rs) for rs in rows]
words=frozenset().union(*slots)
six=[cr((s[0],)+p) for s in combinations(range(1,8),6) for p in permutations(s[1:])]
inc=defaultdict(list)
for i,rs in enumerate(six):
    for r in rs:inc[r].append(i)
delta=[Counter(i for r in rs for i in inc[r]) for rs in rows]
columns={w:{b for b,s in enumerate(slots) if w in s} for w in words}
def solve(core,extras,hint=frozenset()):
    occupied={rotate(r[:4]) for r in extras}
    for b in core:
        assert not occupied&slots[b]
        occupied.update(slots[b])
    counts=Counter(i for r in extras for i in inc[r])
    for b in core:counts.update(delta[b])
    nodes=0
    if any(v>=5 for v in counts.values()):return False,0,None
    def visit(remaining,available,chosen):
        nonlocal nodes
        nodes+=1
        if not remaining:return chosen
        c=min(remaining,key=lambda w:len(columns[w]&available))
        candidates=sorted(columns[c]&available,key=lambda b:b not in hint)
        for b in candidates:
            if any(counts[k]+v>=5 for k,v in delta[b].items()):continue
            counts.update(delta[b])
            answer=visit(remaining-slots[b],{q for q in available if not slots[q]&slots[b]},chosen+[b])
            counts.subtract(delta[b])
            if answer is not None:return answer
        return None
    answer=visit(words-occupied,{b for b,s in enumerate(slots) if not s&occupied},[])
    return answer is not None,nodes,answer

original=json.loads((H/'inputs/new15051.rules.json').read_text())
rs={(a,*h,t) for a,h,t in original['rules']}
control={i for i,rules in enumerate(rows) if rules<=rs}
assert len(control)==46
holes=words-set().union(*(slots[b] for b in control))
extras={w+(8,) for w in holes}
fixed=set(sorted(control)[:33])
found,nodes,answer=solve(fixed,extras,control)
assert found and len(answer)==13
out=dict(method=__doc__,positive_control=dict(fixed_blocks=33,recovered_blocks=13,nodes=nodes,status='FOUND'),cases=[])
start=time.monotonic();seen=set()
patterns=('agent_seed_local_completion_[0-9]*.json','agent_pair_local_batch_[0-9]*.json','agent_pair_local_batch835_[0-9]*.json','agent_local_batch_*_[0-9]*.json','agent_local_[0-9]*_[0-9]*.json','root_pair_local_*_[0-9]*.json')
for path in sorted({p for pattern in patterns for p in H.glob(pattern)}):
    try:data=json.loads(path.read_text())
    except json.JSONDecodeError:continue
    if 'seed_index' not in data:continue
    for i,rec in enumerate(data['records']):
        if not rec['status'].startswith('EXHAUSTED'):continue
        key=(tuple(rec['core_blocks']),tuple(map(tuple,rec['extras'])))
        if key in seen:continue
        seen.add(key)
        found,nodes,answer=solve(set(rec['core_blocks']),set(map(tuple,rec['extras'])))
        assert not found,(path.name,i)
        out['cases'].append(dict(file=path.name,iteration=i,status='EXHAUSTED_NO_R6ZERO_COMPLETION',nodes=nodes))
out['total']=len(out['cases']);out['seconds']=time.monotonic()-start
(H/'local_completions_independent_sets.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(dict(total=out['total'],nodes=sum(r['nodes'] for r in out['cases']),seconds=out['seconds'],positive_control=out['positive_control']))
