"""A completed R6=0 strategy calibrates the exact CP-SAT model."""
from witness_pair_completion import *
from independent_audit import audit
raw=json.loads((H/'inputs/new15051.rules.json').read_text())
original={(a,*h,t) for a,h,t in raw['rules']};old={i for i,rs in enumerate(RULES) if rs<=original}
assert len(old)==46
covered={w for i in old for w in ROWS[i]};holes=sorted(set(WORDS)-covered)
singles={tuple(w)+(8,) for w in holes}
assert len(singles)==2 and all(8 not in w for w in holes)
results=[]
for target in (1,4):
    m,bs,ss=build(target=target)
    for i,v in enumerate(bs):m.add(v==int(i in old))
    for r,v in ss.items():m.add(v==int(r in singles))
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=10
    status=solver.solve(m)
    result=dict(target=target,status=solver.status_name(status))
    assert status==(cp_model.OPTIMAL if target==1 else cp_model.INFEASIBLE)
    results.append(result)
    if target==1:
        dest=Path(export_solution(solver,bs,ss,dict(control=True),filename='witness_control_15049.rules.json'))
        checked=audit(dest);assert checked['wins']==15049 and checked['lost_cf']==0
        assert checked['rescued_cycles']=={'5':52,'6':0,'7':1,'8':0}
        results.append(dict(direct_check=checked))
(H/'witness_model_control.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(results,indent=2))
