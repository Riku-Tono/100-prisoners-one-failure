"""Four-flip5+1 witnesses /192 base pairs / full210 pure completion.

No R6 constraint in witness enumeration or pure exact cover. A pure FOUND
is independently simulated; if it rescues a six, its R6-zero completion is
separately attempted and UNKNOWN is kept unresolved. No marginal lemma is
assumed from a changed family: its unrestricted[7] version applies here,
after the four-flip48-triangle completion exclusion established base<=2.
"""
from fourflip_triangle_pure_completion import H,FOUR,data,cycles,canon,correct,FlexibleCover
from itertools import combinations
from collections import defaultdict,Counter
import json,time,hashlib,sys

def bitids(mask):
    while mask:
        bit=mask&-mask;mask^=bit;yield bit.bit_length()-1

class FixedHoleCover(FlexibleCover):
    def __init__(self,words,rows):
        super().__init__(words,rows);self.wi={w:i for i,w in enumerate(words)};self.start_sizes=tuple(self.S)
    def run_fixed(self,mandatory,holewords,seconds=2,node_limit=100000,hint=()):
        holes=[self.wi[w] for w in holewords];assert len(holes)==len(set(holes))==2
        seen=set(holes);removed=[]
        for h in holes:self.cover(h+1);removed.append(h+1)
        for b in sorted(mandatory):
            assert not seen&set(self.rows[b]);seen.update(self.rows[b])
            for k in self.row_nodes[b]:c=self.C[k];self.cover(c);removed.append(c)
        self.nodes=0;self.answer=None;self.holes=None;self.hint=set(hint);self.node_limit=node_limit;self.deadline=time.monotonic()+seconds;t=time.monotonic()
        try:found=self.search([],holes,0)
        except TimeoutError as e:return dict(status='UNKNOWN',reason=str(e),nodes=self.nodes,seconds=time.monotonic()-t)
        for c in reversed(removed):self.uncover(c)
        assert tuple(self.S)==self.start_sizes
        result=dict(status='FOUND' if found else 'EXHAUSTED_NO_COMPLETION_WITHOUT_R6',nodes=self.nodes,seconds=time.monotonic()-t)
        if found:
            selected=set(mandatory)|set(self.answer);used=[w for b in selected for w in self.rows[b]]
            assert len(selected)==52 and len(used)==len(set(used))==208 and set(used)|set(holes)==set(range(210))
            result.update(block_ids=sorted(selected),holes=holewords)
        return result

def regenerate(words,blocks,rows):
    start=time.monotonic();wi={w:i for i,w in enumerate(words)};wordset=set(words);lookup={b:i for i,b in enumerate(blocks)}
    rm=[sum(1<<w for w in row) for row in rows];inc=defaultdict(list)
    for b,rr in enumerate(blocks):
        for r in rr:inc[r].append(b)
    allsingles={w[j:]+w[:j]+(t,) for w in words for j in range(4) for t in range(1,9) if t not in w};assert len(allsingles)==3360
    allsevens=[(c,correct(c)) for c in cycles(7)];eight_windows=[sum(canon(r[:4]) in wordset for r in rr) for c,rr in allsevens if 8 in c]
    assert max(eight_windows)==5
    sevens=[(c,rr) for c,rr in allsevens if 8 not in c]
    oldsingles={r for c,rr in sevens for r in rr if canon(r[:4]) in wi};assert len(oldsingles)==2232
    locals=[];seen=set()
    for c,rr in sevens:
        for extra in sorted(rr):
            if extra not in oldsingles:continue
            slot=1<<wi[canon(extra[:4])]
            for ignore in sorted(rr-{extra}):
                choices=sorted(([b for b in inc[r] if not rm[b]&slot] for r in rr-{extra,ignore}),key=len)
                if any(not opts for opts in choices):continue
                def visit(j,used,chosen):
                    if j==5:
                        chosen=tuple(sorted(chosen));key=(c,extra,chosen)
                        if key in seen:return
                        seen.add(key);locals.append(dict(cycle=c,extra=extra,blocks=chosen,blockmask=sum(1<<b for b in chosen),wordmask=used^slot,extraslot=slot));return
                    for b in choices[j]:
                        if not rm[b]&used:visit(j+1,used|rm[b],chosen+[b])
                visit(0,slot,[])
    locals.sort(key=lambda w:(w['cycle'],w['extra'],w['blocks']))
    print('GLOBAL5+1',len(locals),'seconds',round(time.monotonic()-start,3),flush=True)
    raw=(H/'fourflip_witness_preparation_pairs.json').read_bytes();bases=json.loads(raw)['seeds'];assert len(bases)==192
    compatible_total=pairs=0;compound={};perbase=[]
    for index,seed in enumerate(bases):
        bs={lookup[frozenset(map(tuple,rr))] for rr in seed['actual_rules']};assert len(bs)==12
        bm=sum(1<<b for b in bs);wm=sum(rm[b] for b in bs);assert wm.bit_count()==48
        supplied=set().union(*(blocks[b] for b in bs));basecycles={c for c,rr in sevens if len(rr&supplied)>=6};assert len(basecycles)==2
        compatible=[]
        for localid,w in enumerate(locals):
            if w['cycle'] in basecycles or wm&w['extraslot']:continue
            overlap=wm&w['wordmask']
            if overlap:
                shared=0
                for b in bitids(bm&w['blockmask']):shared|=rm[b]
                if overlap!=shared:continue
            compatible.append(localid)
        compatible_total+=len(compatible);count=0
        for a,b in combinations(compatible,2):
            x=locals[a];y=locals[b]
            if x['cycle']==y['cycle'] or x['extraslot']==y['extraslot']:continue
            if x['extraslot']&y['wordmask'] or y['extraslot']&x['wordmask']:continue
            overlap=x['wordmask']&y['wordmask']
            if overlap:
                shared=0
                for q in bitids(x['blockmask']&y['blockmask']):shared|=rm[q]
                if overlap!=shared:continue
            core=tuple(bitids(bm|x['blockmask']|y['blockmask']));extras=tuple(sorted((x['extra'],y['extra'])));key=(core,extras)
            compound.setdefault(key,[]).append(dict(base_index=index,local_witness_ids=[a,b],new_cycles=[x['cycle'],y['cycle']]))
            count+=1;pairs+=1
        perbase.append(dict(index=index,compatible_local_witnesses=len(compatible),compound_pair_occurrences=count))
    out=dict(scope=__doc__,flips=FOUR,base_seed_sha256=hashlib.sha256(raw).hexdigest(),blocks=len(blocks),slots=len(words),all_single_options=3360,seven_useful_old_single_options=2232,single_options_excluded_as_seven_irrelevant=1128,old_single_options_in_no_block=sum(not inc[r] for r in oldsingles),max_active_windows_in_seven_containing8=max(eight_windows),global_five_plus_one_witnesses=len(locals),base_pair_representatives=192,compatible_local_witnesses=compatible_total,compound_pair_occurrences=pairs,unique_compound_seeds=len(compound),perbase=perbase,block_definitions=[sorted(b) for b in blocks],local_witnesses=[{k:v for k,v in w.items() if k not in ('blockmask','wordmask','extraslot')} for w in locals],seeds=[dict(core_blocks=k[0],extras=k[1],provenance=compound[k]) for k in sorted(compound)],seconds=time.monotonic()-start)
    out['irrelevant_single_explanation']='Every7-cycle containing8 has at most5 active windows, hence is never rescued. For old[7]7-cycles, singles involving8 cannot be correct. Both extras must be useful under base<=2 and marginal<=1, so discarding these1128 candidates is equivalent for targetR7>=4. No candidate is derived only from block membership.'
    return out

def main():
    wall=float(sys.argv[1]) if len(sys.argv)>1 else 120
    percase=float(sys.argv[2]) if len(sys.argv)>2 else 2
    node_limit=int(sys.argv[3]) if len(sys.argv)>3 else 100000
    words,blocks,rows=data(FOUR);ep=H/'fourflip_compound_pure_enumeration.json'
    resume='--resume' in sys.argv
    if resume:
        enumeration=json.loads(ep.read_text());assert tuple(frozenset(map(tuple,b)) for b in enumeration['block_definitions'])==blocks
    else:
        enumeration=regenerate(words,blocks,rows);ep.write_text(json.dumps(enumeration,indent=2),encoding='utf-8')
    print('ENUM',{k:v for k,v in enumeration.items() if k not in ('scope','perbase','block_definitions','local_witnesses','seeds','irrelevant_single_explanation')},flush=True)
    cw,cb,cr=data(());raw=(H/'inputs/baseline15051.rules.json').read_bytes();knownrules={(a,*h,t) for a,h,t in json.loads(raw)['rules']};known={b for b,rr in enumerate(cb) if rr<=knownrules};assert len(known)==52
    used={cw[w] for b in known for w in cr[b]};holes=sorted(set(cw)-used);fixed=set(sorted(known)[:39]);control=FixedHoleCover(cw,cr).run_fixed(fixed,holes,5,100000,known);assert control['status']=='FOUND' and len(set(control['block_ids'])-fixed)==13
    out=dict(scope=__doc__,enumeration_sha256=hashlib.sha256(ep.read_bytes()).hexdigest(),R6_constraint_used_in_pure_cover=False,seconds_per_seed=percase,node_limit_per_seed=node_limit,positive_control=dict(status='FOUND',retained_blocks=39,recovered_blocks=13,nodes=control['nodes']),cases=[])
    if resume:
        out=json.loads((H/'fourflip_compound_pure_completion.json').read_text())
        assert out['enumeration_sha256']==hashlib.sha256(ep.read_bytes()).hexdigest()
        assert all(c['status']=='EXHAUSTED_NO_COMPLETION_WITHOUT_R6' for c in out['cases']), 'Unresolved earlier cases require explicit retry, not skip.'
        assert [c['index'] for c in out['cases']]==list(range(len(out['cases'])))
        out['resume_runs']=out.get('resume_runs',0)+1
    begin=len(out['cases']);elapsed=out.get('seconds',0)
    start=time.monotonic();deadline=start+wall;engine=FixedHoleCover(words,rows)
    for index,seed in enumerate(enumeration['seeds']):
        if index<begin:continue
        remaining=deadline-time.monotonic()
        if remaining<=0:break
        extras=set(map(tuple,seed['extras']));holewords=sorted(canon(r[:4]) for r in extras)
        result=engine.run_fixed(seed['core_blocks'],holewords,min(percase,remaining),node_limit);result['index']=index
        if result['status']=='UNKNOWN':engine=FixedHoleCover(words,rows)
        if result['status']=='FOUND':
            full=set().union(*(blocks[b] for b in result['block_ids']))|extras;cert=H/f'fourflip_compound_pure_found_{index}.rules.json'
            cert.write_text(json.dumps(dict(n=8,flipped_supports=FOUR,rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(full)],block_ids=result['block_ids'],extras=sorted(extras)),indent=2),encoding='utf-8')
            from independent_audit import audit
            checked=audit(cert);assert checked['rules']==210 and checked['lost_cf']==0 and checked['rescued_cycles']['5']==52 and checked['rescued_cycles']['7']>=4
            result.update(certificate=str(cert),direct_audit=checked)
            if checked['rescued_cycles']['6']==0:result['target_status']='FOUND_R6ZERO_INDEPENDENTLY_VERIFIED'
            else:
                from general_witness_completion import build,cp_model
                completion=build(FOUR,seed['core_blocks'],4,False);completion.require_extras(extras);solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.max_time_in_seconds=max(.001,min(10,deadline-time.monotonic()));st=solver.solve(completion.model)
                result['R6zero_completion_status']=solver.status_name(st)
                if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):result['R6zero_candidate']=completion.export_and_audit(solver,H/f'fourflip_compound_R6zero_found_{index}.rules.json')
        out['cases'].append(result);out['counts']=dict(Counter(c['status'] for c in out['cases']));out['nodes']=sum(c['nodes'] for c in out['cases']);out['seconds']=elapsed+time.monotonic()-start;out['not_run']=len(enumeration['seeds'])-len(out['cases'])
        if index%250==0 or result['status']!='EXHAUSTED_NO_COMPLETION_WITHOUT_R6' or not out['not_run']:
            (H/'fourflip_compound_pure_completion.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
            print(index,result['status'],result['nodes'],'counts',out['counts'],'total',round(out['seconds'],3),flush=True)
        if result['status']=='FOUND':break
    (H/'fourflip_compound_pure_completion.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('FINAL',out.get('counts',{}),out.get('nodes'),out.get('seconds'),out.get('not_run'),flush=True)

if __name__=='__main__':main()
