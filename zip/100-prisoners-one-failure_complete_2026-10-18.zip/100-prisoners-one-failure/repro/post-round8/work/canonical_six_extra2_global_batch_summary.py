"""Aggregate bounded global completion attempts of the45 two-extra cores."""
from pathlib import Path
from collections import Counter
import json,hashlib
H=Path(__file__).resolve().parent
sources=[];records=[]
for batch in range(1,4):
    path=H/f'post_audit_global_extra2_batch{batch:02d}_20261018.checkpoint.json'
    raw=path.read_bytes();state=json.loads(raw)
    assert state['workers']==1 and state['seconds_per_core']==20
    assert state['provenance']['selected_extra_count']==2
    assert set(state['forbidden_cuts_not_used'])=={'degree','flip-count','fixed-orientation-family'}
    sources.append({'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'model_controls_sha256':state['model_controls_sha256'],'summary':state['summary'],'wall_seconds':state['latest_invocation_seconds']})
    for r in state['records']:
        records.append({'representative_index':r['representative_index'],'status':r['status'],'batch':batch,'solve_seconds':r.get('solve_seconds'),'result_file':r.get('result_file'),'result_sha256':r.get('result_sha256'),'certificate':r.get('certificate'),'direct_audit':r.get('direct_audit')})
assert len(records)==45 and {r['representative_index'] for r in records}==set(range(25,70))
assert len({r['representative_index'] for r in records})==45
counts=dict(Counter(r['status'] for r in records))
out={'status':'BOUNDED_GLOBAL_ATTEMPTS_NO_IMPOSSIBILITY_CLAIM','scope':__doc__,'canonical_cycle':[1,2,3,4,5,6,7],'required_positions':list(range(6)),'unrequired_position':6,'core_extras':2,'all_remaining_orientations_free':True,'further_extra_rule_constraints_added':False,'workers':1,'seconds_per_core':20,'total_selected':45,'attempted':sum(r['status']!='NOT_RUN' for r in records),'counts':counts,'unknown_unresolved_ids':sorted(r['representative_index'] for r in records if r['status']=='UNKNOWN'),'not_run_ids':sorted(r['representative_index'] for r in records if r['status']=='NOT_RUN'),'strictly_infeasible_ids':sorted(r['representative_index'] for r in records if r['status']=='INFEASIBLE'),'found_ids':sorted(r['representative_index'] for r in records if r['status'] in ('FEASIBLE','OPTIMAL')),'total_solver_seconds':sum(r.get('solve_seconds') or 0 for r in records),'sources':sources,'records':sorted(records,key=lambda r:r['representative_index'])}
(H/'canonical_six_extra2_global_batch_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print({k:v for k,v in out.items() if k not in ('sources','records','scope')})
