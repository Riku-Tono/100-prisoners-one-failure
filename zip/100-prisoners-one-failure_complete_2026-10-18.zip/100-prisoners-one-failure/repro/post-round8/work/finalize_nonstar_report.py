"""Write the bounded non-star conclusion and an evidence manifest."""
from pathlib import Path
import json,hashlib,datetime
H=Path(__file__).resolve().parent
def load(n):return json.loads((H/n).read_text(encoding='utf-8-sig'))
def main():
    frontier=load('SUPPORT_FRONTIER_2026-10-18.json')
    assert frontier['nonstar_all_orientation_reduction']['status']=='NONSTAR_TARGET4_EXCLUDED_WITH_INDEPENDENT_CHECKS'
    finalcp=load('canonical_orientation_five_survivors_presence_independent.json')
    assert finalcp['complete'] and finalcp['controls_passed'] and finalcp['all_five_independent_infeasible']
    support=load('canonical_support_fraction_certificate_verify.json')
    assert support['status']=='PASS_OPTIMIZER_FREE_CERTIFICATES'
    assert support['counts']=={'EXACT_FRACTION_DUAL_EXCLUSION':1372,'INTEGER_RELAXATION_SURVIVES':5,'CBC_INTEGER_INFEASIBLE':1}
    logic=load('canonical_orientation_logical_chain_review.json')
    assert 'PASS' in str(logic.get('status',''))
    text='''全star以外の支持向き：R6=0・15,052勝の枝に対する有限計算の結論
2026-10-18

結論
52個の4規則5巡回ブロック＋追加2規則以内、最初3箱CF・最後の箱のみ変更、
CF勝ち保存、R6=0という範囲では、全star以外の支持向きにR7>=4の構成はない。
支持向きは全35個の相補4集合対から片側を選ぶものとする。
全starとは、ある1ラベルvを含まない全35個の4集合を使う向き（S8同値を含む）。
これは有限列挙と終了した限定ソルバー結果を独立照合した計算上の結論。
15,051勝の全戦略における最適性や、全star内の目標不存在は未証明。
新しい15,052勝構成は今回見つからなかった。

Claudeデスクトップによる先行監査
913代表完了の標準3支持反転の結果は、Claude自身の別コード・C補完器・
直接40,320配置検算によりAUDIT_PASS。候補表・巡回・witness集合も一致した。
監査書：claude_desktop_continuation3/audit_status.json
今回の全支持向きへの追加還元は、下記の別実装で追加検証したものであり、
Claudeが全1378向きの新しい最終監査を行ったと主張するものではない。

網羅性の接続
1. 目標構成には救済7巡回がある。欠落する正解規則の位置を6番へ回転し、
   ラベルを巡回順に1..7、残りを8へ置くと、位置0..5の6正解が必要となる。
   7/7正解の場合は任意の1位置を無視すれば同じ正規化ができる。
2. 6正解の供給元を、実4規則ブロック又はsingletonとして全列挙する。
   全5^6=15,625供給割当から、追加高々2本・損失語非衝突の核心は70件。
   内訳は追加0本4件、1本21件、2本45件。別の直積列挙でも実規則集合一致。
   5規則全て正解の5巡回も、4規則ブロック＋第5規則singletonとして含む。
   7巡回の第7規則を不正解に固定する制約は加えていない。
3. 各核心が強制しない支持選択は、それぞれ11/14/17ビット。
   全6,250,496割当を列挙する。52ブロックは208語を使い、active語は210個。
   active支持1つが全くブロックに使えないと6語失うため、52ブロックは不可能。
   従って全active支持が、少なくとも1つの4-of-5 active支持clusterに属す必要がある。
   この必要条件を通る53,392核心・向き組、相異なる27,423向きを得た。
   別言語・実ブロック由来のpatternで全割当を再列挙し、各70集合まで一致。
4. ラベルごとのactive支持所属数を次数とする。最小次数dのラベルを8に
   置けば、[7]starから正確にd個反転した向きになる。
   d=0は全starなので未決として残す。d=1..7は先行の各反転族の限定排除を使う。
   d>=8の22,610向きは、S8で正確に1,378軌道となる。
   次数昇順・最小encodingと、次数降順・最大encodingという別の正準化で、
   全1,378軌道の所属集合及び核心集合まで一致した。

1,378軌道の容量排除
実4規則ブロックを、それが使う4個の4支持のpatternへ緩和する。
patternごとの整数個数xを数え、各active支持の使用数<=6、sum x=52を課す。
実構成52ブロックがあれば、この必要緩和も必ず満たす。
主計算CP-SATは1,373軌道をINFEASIBLEとし、5軌道を残した。
別検算では、Claudeの独立実規則生成から全6,720ブロックと280patternを作り直した。
全1,378向きのpattern集合を実ブロックで照合し、次の内訳で一致した。
・1,372軌道：非負有理数重みyを保存し、全patternでsum y>=1、6sum y<52を
  Python Fractionで厳密検証した。別のoptimizer不要検査器でもPASS。
・残1軌道（1267番）：有理数双対では排除できない。別の整数engine CBCで
  INFEASIBLEが終了し、CP-SATと一致。有理数証明とは区別する。
・5軌道：整数容量緩和の陽性解を保存・厳密検算し、完全な規則モデルへ送った。

最後の5軌道
1255、1291、1305、1319、1376番（いずれも代表では10支持反転）。
核心やpattern個数を固定せず、各向きの全4規則ブロック・全3,360 singleton、
全6巡回のR6=0、全7巡回の救済flagを含めたモデルで、全5件INFEASIBLE。
さらに、一次builderをimportせずClaudeの実ブロック生成を用いた別実装でも、
presence=供給ブロック＋singleton、7巡回flagを双方向に記述して全5件一致。
既知15,051勝の完全固定陽性対照はOPTIMAL・直接40,320配置一致、
R6=1の既知表は陰性対照としてINFEASIBLEだった。
この2つの終了した全5件の照合を使い、時限UNKNOWNは排除根拠に使っていない。

低次数族への依存
3反転：全10軌道、唯一の52候補は標準向き。913代表の完了資料をClaudeが監査済み。
4反転：全38軌道、唯一の52候補について48三角形代表と21,097複合核心を全排除、
       別列挙・別cover補完でも一致。R6を使わずR7<=3。
5反転：必要screen後の2軌道ともR5<=49の容量障害。
6反転：11軌道、容量候補8件すべて2つの規則モデルでINFEASIBLE。
7反転：17軌道、容量候補14件中12件を2つのモデルでINFEASIBLE。
       元CPでUNKNOWNだった9・15番は、後続の容量・規則共有補題でR7<=3。
       元UNKNOWNログは保存し、結論を後続証拠と区別した。
1・2反転は8入りブロックに必要な3支持がなく、使用可能語数が208未満。

残る範囲
全starでは、特定18ブロック固定の3,735核心は全件補完不能と確認したが、
別witnessの枝は残る。全starの5分最適化はFEASIBLE R7=3であり、最適性証明ではない。
またR5<52、R6>0、早い箱からの変更、一般戦略全体への最適値は対象外。
「救済7巡回は必ず7/7正解」という還元には具体反例があるので使用していない。

主な再現・監査資料
canonical_six_witness_preparation.json
canonical_six_witness_independent_review_20261018.json
independent_allcore_support_screen_20261018.json
independent_orientation_S8_partition_20261018.json
canonical_support_independent_fraction_audit.json
canonical_support_fraction_certificate_verify.py / .json
canonical_orientation_five_survivors.json
canonical_orientation_five_survivors_presence_independent.json
canonical_orientation_logical_chain_review.json
SUPPORT_FRONTIER_2026-10-18.json
NONSTAR_SUPPORT_EXCLUSION_SHA256.json
元入力・途中UNKNOWN・全CPログを保持し、否定根拠に採用した証拠を別に参照する。
'''
    report=H/'NONSTAR_SUPPORT_EXCLUSION_2026-10-18.txt';report.write_text(text,encoding='utf-8-sig')
    sources=set(frontier['evidence_sha256'])
    sources.update(['NONSTAR_SUPPORT_EXCLUSION_2026-10-18.txt','SUPPORT_FRONTIER_2026-10-18.json',
        'CONTINUATION3_STATUS_2026-10-18.txt','canonical_six_witness_preparation.py',
        'canonical_orientation_capacity_screen.py','canonical_orientation_S8_classification.py',
        'canonical_orientation_support_relaxation.py','canonical_orientation_five_survivors.py',
        'canonical_support_independent_fraction_audit.py','canonical_support_fraction_certificate_verify.py',
        'five_survivors_c3_presence_iff_independent_20261018.py','global_orientation_independent_static_review_20261018.json',
        'fullstar_canonical_optimize300.result.json','canonical_orientation_five_direct_supplier_interruption.json',
        'canonical_orientation_logical_chain_review.py','canonical_orientation_logical_chain_review.json',
        'refresh_continuation3_status.py','finalize_nonstar_report.py'])
    for p in H.glob('five_survivors_c3_presence_iff_*'):
        if p.is_file():sources.add(p.name)
    for p in H.glob('*nonstar*logic*'):
        if p.is_file():sources.add(p.name)
    paths={n:hashlib.sha256((H/n).read_bytes()).hexdigest() for n in sorted(sources)}
    manifest=dict(status='FINAL_BOUNDED_NONSTAR_EXCLUSION',created_local=datetime.datetime.now().isoformat(timespec='seconds'),
        claim='52 four-rule blocks+<=2 extras, R6=0, non-full-star support orientation => R7<=3; full-star remains unresolved; no global strategy optimum.',
        total_files=len(paths),sha256=paths)
    (H/'NONSTAR_SUPPORT_EXCLUSION_SHA256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    assert report.read_bytes()[:3]==b'\xef\xbb\xbf' and '\ufffd' not in report.read_text(encoding='utf-8-sig')
    for n,v in paths.items():assert hashlib.sha256((H/n).read_bytes()).hexdigest()==v
    print(json.dumps(dict(report=report.name,manifest_files=len(paths),status=manifest['status']),ensure_ascii=False))
if __name__=='__main__':main()
