"""Can one external rule help two directed seven-cycles simultaneously?

Local old-side packing relaxation only; no requirement of 46 old blocks.
Only imports our separately generated block definitions, not an AI proposal.
"""
from completion_dlx_recheck import RULES, ROWS, WORDS, correct, rotate_min
from itertools import permutations, combinations
from collections import defaultdict, Counter
from pathlib import Path
import json,time

HERE=Path(__file__).parent
start=time.perf_counter()
inc=defaultdict(set)
for b,rs in enumerate(RULES):
    for r in rs:inc[r].add(b)
allsevens=[(1,)+tail for tail in permutations(range(2,8))]
rcycles=defaultdict(list)
for c in allsevens:
    rr=correct(c)
    if sum(rotate_min(r[:4]) in set(WORDS) for r in rr)<6:continue
    for r in rr:
        if rotate_min(r[:4]) in set(WORDS):rcycles[r].append(c)
rows=[frozenset(row) for row in ROWS]

def witnesses(c,r):
    found=set();rr=frozenset(correct(c));slot=rotate_min(r[:4])
    for ignored in rr-{r}:
        def visit(needs,occupied,chosen):
            if not needs:found.add(frozenset(chosen));return
            options=[]
            for rule in needs:
                bb=[b for b in inc[rule] if not occupied&rows[b]]
                if not bb:return
                options.append((len(bb),rule,bb))
            _,rule,choices=min(options)
            for b in choices:visit(needs-RULES[b],occupied|rows[b],chosen|{b})
        visit(rr-{ignored,r},frozenset({slot}),frozenset())
    return found

result={'scope':'old-side 31 supports, noncolliding block subset + one external rule; no full completion constraint','rules_with_two_support_eligible_sevens':sum(len(v)==2 for v in rcycles.values()),'tested_rules':0,'compatible_pairs':0,'status':'EXHAUSTED_NO_EXAMPLE'}
stats=Counter()
for r,cc in sorted(rcycles.items()):
    if len(cc)!=2:continue
    result['tested_rules']+=1;a,b=cc
    wa=witnesses(a,r);wb=witnesses(b,r)
    stats[(bool(wa),bool(wb))]+=1
    for x in wa:
        xslots=set().union(*(rows[i] for i in x))
        for y in wb:
            common=x&y
            ynew=y-common
            if any(xslots&rows[i] for i in ynew):continue
            selected=x|y
            allrules=set().union(*(RULES[i] for i in selected))
            before=[sum(rule in allrules for rule in correct(c)) for c in cc]
            after=[sum(rule in allrules|{r} for rule in correct(c)) for c in cc]
            if max(before)>5:continue
            assert min(after)>=6 and r not in allrules
            used=[s for i in selected for s in rows[i]]
            assert len(used)==len(set(used)) and rotate_min(r[:4]) not in used
            result.update(status='EXPLICIT_LOCAL_EXAMPLE',rule=r,cycles=cc,before=before,after=after,blocks=[dict(rules=sorted(RULES[i]),slots=ROWS[i]) for i in sorted(selected)])
            result['compatible_pairs']+=1
            break
        if result['compatible_pairs']:break
    if result['compatible_pairs']:break
result['witness_existence_histogram']={str(k):v for k,v in stats.items()}
result['seconds']=time.perf_counter()-start
(HERE/'single_rule_two_sevens.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print({k:v for k,v in result.items() if k!='blocks'},flush=True)
