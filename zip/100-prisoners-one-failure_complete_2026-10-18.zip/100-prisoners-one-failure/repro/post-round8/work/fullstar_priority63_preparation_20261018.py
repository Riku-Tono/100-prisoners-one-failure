"""Prepare63 untried witness cores; only known-certificate controls may solve.

Replace exactly one of the three six-correct witnesses of the closed18-core
by any of that cycle's21 witnesses not contained in its unique seven-correct
pure-block template. This does not require7/7 correct in a completed table.
The other two six-correct witnesses remain fixed. The manifest is only a
priority subset of21951 unclosed cores for these same three known cycles.
No new target4 construction Solve is called.
"""
from pathlib import Path
from itertools import permutations, combinations
from collections import Counter
import json, hashlib, time
from fullstar_prepare_basic import H, RULES, ROWS, WORDS, inc, witnesses, correct

PREFIX = 'fullstar_priority63_preparation_20261018'


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def seven_templates(cycle):
    result = set()

    def dfs(todo, used, chosen):
        if not todo:
            result.add(frozenset(chosen))
            return
        options = [(len(bs), r, bs) for r in todo
                   for bs in [[b for b in inc[r] if not ROWS[b] & used]]]
        _, r, bs = min(options)
        for b in bs:
            dfs(todo - RULES[b], used | ROWS[b], chosen | {b})

    dfs(correct(cycle), frozenset(), frozenset())
    return result


def stream_expansion(path):
    """Read compact keys and header without materializing186MB actual-rule data."""
    header, keys = [], []
    in_reps = collecting = False
    block = []
    with path.open(encoding='utf-8') as f:
        for line in f:
            s = line.strip()
            if not in_reps:
                if s == '"representatives": [':
                    in_reps = True
                    header.append('  "representatives": []\n}')
                else:
                    header.append(line)
                continue
            if s == '"blocks": [':
                assert not collecting
                collecting = True
                block = []
            elif collecting:
                if s in ('],', ']'):
                    assert len(block) == 18
                    keys.append(tuple(block))
                    collecting = False
                else:
                    block.append(int(s.rstrip(',')))
    assert not collecting and in_reps
    return json.loads(''.join(header)), keys


def main():
    start = time.monotonic()
    baseline_path = H/'fullstar_prepare_baseline.json'
    closed_path = H/'fullstar_fixed18_complete_summary.json'
    expansion_path = H/'fullstar_threecycle_witness_expansion_preparation.json'
    baseline = json.loads(baseline_path.read_text())
    closed = json.loads(closed_path.read_text())
    assert closed['status'] == 'EXHAUSTED_NO_TARGET4_WITH_FIXED_18_CORE'
    assert closed['all3735_verified_by_non_CP_cover'] and not closed['unknown'] and not closed['unprocessed']
    old = frozenset(closed['fixed_core'])
    cycles = tuple(map(tuple, baseline['rescued_sevens']))
    current = tuple(frozenset(s) for s in baseline['witness_blocks'])
    assert len(old) == 18 and set().union(*current) == old
    ws = [witnesses(c) for c in cycles]
    templates = [seven_templates(c) for c in cycles]
    assert list(map(len, ws)) == [28, 28, 28]
    assert list(map(len, templates)) == [1, 1, 1]
    nonext = [sorted((w for w in group if not any(w <= t for t in ts)), key=lambda w: tuple(sorted(w)))
              for group, ts in zip(ws, templates)]
    assert list(map(len, nonext)) == [21, 21, 21]
    assert all(current[i] in ws[i] and any(current[i] <= t for t in templates[i]) for i in range(3))
    manifest = []
    keys = set()
    six = [correct((s[0],)+p) for s in combinations(range(1,8),6) for p in permutations(s[1:])]
    sevens = [correct((1,)+p) for p in permutations(range(2,8))]
    for i in range(3):
        for j, replacement in enumerate(nonext[i]):
            triple = list(current)
            triple[i] = replacement
            union = frozenset().union(*triple)
            assert len(union) == 18 and union != old
            words = [w for b in union for w in ROWS[b]]
            assert len(words) == len(set(words)) == 72
            key = tuple(sorted(union))
            assert key not in keys
            keys.add(key)
            rr = set().union(*(RULES[b] for b in union))
            counts = [len(correct(c)&rr) for c in cycles]
            r6 = sum(len(q&rr)>=5 for q in six)
            r7 = sum(len(q&rr)>=6 for q in sevens)
            assert counts == [6,6,6] and r6 == 0 and r7 == 3
            actual = [sorted(RULES[b]) for b in key]
            manifest.append(dict(core_index=len(manifest), changed_cycle_index=i,
                                 replacement_nonextension_index=j, blocks=key,
                                 actual_blocks=actual, actual_rules=actual, extras=[],
                                 cycles=cycles, six_witness_blocks=[sorted(w) for w in triple],
                                 correct_rules_per_known_cycle=counts,
                                 R6_in_partial_core=r6, R7_in_partial_core=r7,
                                 already_closed=False, previously_attempted_exact18=False,
                                 status='NOT_RUN',
                                 local_nonextension_meaning='Replacement6-block witness is not a subset of the unique7-correct pure-block template; no52-block incompletability is inferred.'))
    assert len(manifest) == len(keys) == 63

    header, all_keys = stream_expansion(expansion_path)
    assert header['union_orbits'] == len(all_keys) == len(set(all_keys)) == 21952
    assert header['threecycle_set_stabilizer_order'] == 1
    assert header['closed_summary_sha256'] == digest(closed_path)
    assert tuple(sorted(old)) == tuple(header['closed_canonical_key'])
    keyindex = {key: i for i,key in enumerate(all_keys)}
    assert keys <= keyindex.keys() and tuple(sorted(old)) in keyindex
    for r in manifest:
        r['expansion_representative_index'] = keyindex[tuple(r['blocks'])]

    # Exact mandatory18-core history. A broader bounded one-witness/global
    # UNKNOWN run is not a completed test or exclusion of these63 branches.
    histories = []
    attempted = set()
    explicit = [
        'post_audit_fullstar_20261018_result.json',
        'post_audit_fullstar_20261018_resume1_result.json',
        'fullstar_finite_core_completion_result.json',
        'fullstar_finite_core_bitset_result.json',
        'fullstar_finite_core_finish_result.json']
    for name in explicit:
        path = H/name
        data = json.loads(path.read_text())
        fixed = data.get('fixed_core', data.get('resume_settings',{}).get('fixed_core'))
        if fixed is None:
            fixed = data.get('settings',{}).get('fixed_core')
        if fixed is None:
            fixed = data.get('static_readiness',{}).get('mandatory_core_blocks')
        assert fixed is not None, ('No explicit mandatory-core evidence', name)
        assert len(fixed) == 18 and frozenset(fixed) == old
        attempted.add(tuple(sorted(fixed)))
        histories.append(dict(path=name,sha256=digest(path),status=data['status'],fixed_core=sorted(fixed)))
    assert not keys & attempted

    # Portable API mapping and Model Build/Validate, not target4 solving.
    from general_witness_completion import map_actual_blocks, build, cp_model, read_rules
    from fullstar_finite_core_completion import RULES as INDEPENDENT_RULES
    assert RULES == INDEPENDENT_RULES
    generic_ids = []
    for r in manifest:
        mapped = map_actual_blocks((),r['actual_blocks'])
        assert sorted(mapped) == list(r['blocks'])
        generic_ids.append(sorted(mapped))
    build_controls = []
    for index in (0,21,42):
        seed = manifest[index]
        local = build((),seed['blocks'],4,True)
        completion = build((),seed['blocks'],4,False)
        assert not local.model.validate() and not completion.model.validate()
        assert local.stats['seven_fixed_true'] == completion.stats['seven_fixed_true'] == 3
        build_controls.append(dict(core_index=index,local=local.stats,completion=completion.stats))

    # Positive control only: all selected variables are fixed to the existing
    # baseline15051 table, so this is not a new construction search.
    positive = build((),old,3,False)
    fixed_info = positive.fix_certificate(read_rules(H/'inputs/baseline15051.rules.json'))
    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = 1
    solver.parameters.max_time_in_seconds = 10
    st = solver.solve(positive.model)
    assert st == cp_model.OPTIMAL
    positive_status = solver.status_name(st)
    checked = positive.export_and_audit(solver,H/f'{PREFIX}_known_positive.rules.json')
    assert checked['audit']['wins'] == 15051
    assert checked['audit']['rescued_cycles'] == {'5':52,'6':0,'7':3,'8':0}

    # The non-CP finite-cover engine is reusable for arbitrary actual core IDs,
    # but a target4 check must first add a fourth-cycle critical witness.
    from fullstar_finite_core_finish import HighEngine, CATALOGUE_SHA, export_and_audit
    brules = read_rules(H/'inputs/baseline15051.rules.json')
    chosen = {b for b,rr in enumerate(RULES) if rr <= brules}
    assert len(chosen) == 52
    fixed39 = set(old) | set(sorted(chosen-old)[:21])
    holes = set(WORDS)-set().union(*(ROWS[b] for b in chosen))
    extras = {w+(8,) for w in holes}
    engine = HighEngine()
    st,nodes,more,free = engine.run(fixed39,extras,5,2000000,chosen,True)
    assert st == 'FOUND' and len(more) == 13
    cover_checked = export_and_audit(H/f'{PREFIX}_cover_positive.rules.json',fixed39,extras,more,free,15051)
    assert cover_checked['wins'] == 15051 and cover_checked['rescued_cycles']['7'] == 3

    out = dict(status='PREPARED63_UNTRIED_CORES_KNOWN_POSITIVE_CONTROLS_PASS',
               scope=__doc__,flips=[],R5=52,R6=0,R7_target=4,
               rule_budget_max=210,completed_blocks=52,completed_extras_max=2,
               same_known_three_cycles=cycles,source_all_threecycle_orbits=21952,
               previously_closed_orbits=1,total_unclosed_same_threecycle_orbits=21951,
               selected_priority_cores=63,other_unselected_unclosed_orbits=21951-63,
               replacement_counts_by_changed_cycle=dict(Counter(r['changed_cycle_index'] for r in manifest)),
               distinct_core_keys=len(keys),already_closed_selected=0,previously_exact18_attempted_selected=0,
               new_construction_solve_called=False,
               selected_all_partial_correct_counts_are_6_not_7=True,
               prior_exact18_branch_histories=histories,
               source_sha256={p.name:digest(p) for p in (baseline_path,closed_path,expansion_path)},
               block_catalogue_sha256=CATALOGUE_SHA,
               known_positive_control=dict(status=positive_status,
                                           fixed=fixed_info,result=checked),
               cover_positive_control=dict(status='FOUND',retained=39,recovered=13,nodes=nodes,audit=cover_checked),
               static_build_validate_controls=build_controls,
               api={
                   'general_load':'load_mapped_seeds((), manifest_path) accepts seeds[].actual_rules plus cycles and verifies actual block sets.',
                   'general_construct_after_GO':'run_seed((), mandatory=seed[blocks], target=4, wall_seconds=..., output_prefix=unique) has full3360 singles and no7/7 condition.',
                   'finite_cover':'HighEngine().run(core_ids, critical_extras, seconds, node_limit, hint=..., use_r6=True) completes to52 blocks with2-e free holes. Enumerate fourth-cycle6-correct critical cores first; a52-block completion with only3 rescued cycles is not target4.',
                   'finite_enumerator_adaptation':'fullstar_fixed_core_enumeration.enumerate_cores currently hardcodes baseline seed; do not call it unchanged for these63. Parameterize the18 mandatory IDs in a new file.',
                   'unknown_policy':'UNKNOWN never excludes a seed or adds a no-good.'},
               counterexample_caveat='A prior independently audited52-block table contains a6-correct witness outside the unique7-correct block template. Local nonextension cannot prove52-block noncompletion.',
               seeds=manifest,seconds=time.monotonic()-start)
    path = H/f'{PREFIX}.json'
    path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print({k:v for k,v in out.items() if k not in ('scope','api','seeds','known_positive_control','cover_positive_control','static_build_validate_controls','prior_exact18_branch_histories')},flush=True)


if __name__ == '__main__':
    main()
