"""Bounded52-cover construction attempts for sampled shared7675 witness unions.

Only the2396 observed union cores from a random pair sample are considered.
Ordering prefers fewer mandatory blocks, then fewer critical singletons.
The sample graph and the full shared11 branch are not exhaustively covered.
UNKNOWN is unresolved. Each exhausted core concerns only that exact core.
"""
from pathlib import Path
from itertools import permutations
from collections import Counter
import argparse,hashlib,json,time
from fullstar_finite_core_finish import HighEngine,RULES,ROWS,WORDS,CATALOGUE_SHA,canon,export_and_audit

H=Path(__file__).resolve().parent

def correct(c):return frozenset((c[i:]+c[:i])[:4]+((c[i:]+c[:i])[-1],) for i in range(len(c)))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def actual_hash(ids,extras):
 return hashlib.sha256(json.dumps({'actual_blocks':sorted([sorted(RULES[b]) for b in ids]),
                                    'extras':sorted(extras)},separators=(',',':')).encode()).hexdigest()

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--start',type=int,default=0)
 p.add_argument('--count',type=int,default=50);p.add_argument('--seconds',type=float,default=0.5)
 p.add_argument('--prefix',default='fullstar_shared7675_observed_batch1_20261018')
 a=p.parse_args();started=time.monotonic();prefix=H/a.prefix
 source=H/'fullstar_shared7675_witness_pair_preparation_20261018.observed_pair_cores.json'
 sample=json.loads(source.read_text());assert sample['complete'] is False and len(sample['cores'])==2396
 catalogue=sorted({g-{r} for g in {correct(c) for c in permutations(range(1,8),5)} for r in g},key=lambda b:tuple(sorted(b)))
 assert catalogue==RULES and len(RULES)==2520
 six=[correct(c) for c in permutations(range(1,8),6) if c[0]==min(c)]
 seven=[(c,correct(c)) for c in permutations(range(1,8),7) if c[0]==min(c)]
 ordered=sorted(enumerate(sample['cores']),key=lambda ir:(len(ir[1]['all_core_blocks']),len(ir[1]['critical_extra_rules']),
                                                        tuple(ir[1]['all_core_blocks']),tuple(map(tuple,ir[1]['critical_extra_rules']))))
 selected=ordered[a.start:a.start+a.count];assert len(selected)==a.count
 baseline=json.loads((H/'inputs/baseline15051.rules.json').read_text());br={(x,*hist,t) for x,hist,t in baseline['rules']}
 hint={i for i,b in enumerate(RULES) if b<=br};assert len(hint)==52
 fixed=set(sorted(hint)[:39]);holes=set(WORDS)-set().union(*(set(ROWS[b]) for b in hint))
 extras={w+(8,) for w in holes};engine=HighEngine()
 cstatus,nodes,more,free=engine.run(fixed,extras,5,1000000,hint,True)
 assert cstatus=='FOUND' and len(more)==13 and not free
 caudit=export_and_audit(prefix.with_suffix('.positive.rules.json'),fixed,extras,more,free,15051)
 assert caudit['wins']==15051
 state={'scope':__doc__,'source_sample':str(source),'source_sample_sha256':sha(source),
        'source_sample_complete':False,'observed_union_count':len(sample['cores']),
        'block_catalogue_sha256':CATALOGUE_SHA,'full_actual_catalogue_match':True,
        'ordering':['mandatory_block_count','critical_extra_count','block_ids','actual_extra_rules'],
        'priority_start':a.start,'selected_count':a.count,'seconds_per_core':a.seconds,'node_limit':1000000,
        'R6zero_required':True,'R7_target_already_in_fixed_core':4,
        'positive39_to52':{'status':cstatus,'nodes':nodes,'direct_40320_audit':caudit},
        'hint_is_not_a_constraint':True,'records':[],'status':'RUNNING',
        'source_code_sha256':sha(Path(__file__))}
 output=prefix.with_suffix('.result.json');output.write_text(json.dumps(state,indent=2),encoding='utf-8')
 print('POSITIVE39_TO52',cstatus,nodes,caudit['wins'],flush=True)
 for position,(observed_index,r) in enumerate(selected,a.start):
  mandatory=set(r['all_core_blocks']);ex=set(map(tuple,r['critical_extra_rules']))
  actual=set().union(*(RULES[b] for b in mandatory))|ex
  assert len(actual)==4*len(mandatory)+len(ex) and len(ex)<=2
  assert len({canon(rule[:4]) for rule in actual})==len(actual)
  assert max(len(rs&actual) for rs in six)<=4
  rescued=[c for c,rs in seven if len(rs&actual)>=6];assert len(rescued)>=4
  rec={'priority_position':position,'observed_union_index':observed_index,
       'mandatory_blocks':sorted(mandatory),'mandatory_actual_blocks':[sorted(RULES[b]) for b in sorted(mandatory)],
       'critical_extra_rules':sorted(ex),'actual_core_sha256':actual_hash(mandatory,ex),
       'fixed_block_count':len(mandatory),'fixed_extra_count':len(ex),'free_holes':2-len(ex),
       'fixed_rescued_sevens':rescued,'status':'NOT_RUN'}
  before=time.monotonic();st,n,additional,free=engine.run(mandatory,ex,a.seconds,1000000,hint,True)
  rec.update(status=st,nodes=n,seconds=time.monotonic()-before)
  if st=='FOUND':
   cert=H/f'{a.prefix}_priority{position:04d}_observed{observed_index:04d}.rules.json'
   rec['certificate']=str(cert);rec['direct_40320_audit']=export_and_audit(cert,mandatory,ex,additional,free,15052)
   state['status']='FOUND_INDEPENDENTLY_VERIFIED'
  state['records'].append(rec);state['seconds']=time.monotonic()-started
  state['counts']=dict(Counter(x['status'] for x in state['records']))
  state['counts_by_extra']={str(e):dict(Counter(x['status'] for x in state['records'] if x['fixed_extra_count']==e)) for e in range(3)}
  output.write_text(json.dumps(state,indent=2),encoding='utf-8')
  if position%10==a.start%10 or st=='FOUND':print('PRIORITY',position,'OBS',observed_index,'B/E',len(mandatory),len(ex),st,n,flush=True)
  if st=='FOUND':break
 else:state['status']='SELECTED_SAMPLE_CORE_BATCH_FINISHED'
 state['unprocessed_selected_positions']=list(range(a.start+len(state['records']),a.start+a.count))
 state['unknown_positions']=[r['priority_position'] for r in state['records'] if r['status'].startswith('UNKNOWN')]
 state['seconds']=time.monotonic()-started
 output.write_text(json.dumps(state,indent=2),encoding='utf-8')
 print('FINAL',state['status'],state['counts'],'seconds',state['seconds'],flush=True)

if __name__=='__main__':main()
