"""Witness-first, exact R6=0 CP-SAT search in standard three-flip family.
No UNKNOWN is an exclusion. Pair orbit reduction uses only G36 symmetries.
"""
from pathlib import Path
from itertools import permutations, combinations
from collections import defaultdict,Counter
import sys,json,time,hashlib
sys.path.insert(0,r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
from ortools.sat.python import cp_model
from completion_dlx_recheck import RULES,ROWS,WORDS,correct,rotate_min
H=Path(__file__).parent

def cycles(k):
    for s in combinations(range(1,8),k):
        for p in permutations(s[1:]):yield (s[0],)+p

def get_seeds():
    import base208_recheck as b
    lookup={rs:i for i,rs in enumerate(RULES)}
    mappings=[]
    for p in permutations((1,2,3)):
        for q in permutations((4,5,6)):
            mp=dict(zip(range(1,8),p+q+(7,)))
            mappings.append([lookup[frozenset(tuple(mp[x] for x in r) for r in rs)] for rs in RULES])
    # We group by mandatory block union. Different witnessing pairs with the
    # same union impose exactly the same completion constraints.
    seen=set();seeds=[];raw=0
    for i in range(len(b.witnesses)):
        for j in b.adj[i]:
            if j<=i:continue
            raw+=1;u=b.witnesses[i]|b.witnesses[j]
            if u in seen:continue
            orbit={frozenset(m[k] for k in u) for m in mappings}
            seen.update(orbit)
            seeds.append(dict(blocks=sorted(u),cycles=[b.cycles[b.parents[i]],b.cycles[b.parents[j]]],orbit_size=len(orbit)))
    seeds.sort(key=lambda s:(len(s['blocks']),s['blocks']))
    data=dict(raw_edges=raw,union_orbits=len(seeds),seeds=seeds)
    (H/'witness_pair_seeds.json').write_text(json.dumps(data),encoding='utf-8')
    print('PAIR SEEDS',raw,len(seeds),flush=True)
    return seeds

def build(target=4, strengthened=False):
    m=cp_model.CpModel();bs=[m.new_bool_var(f'b{i}') for i in range(len(RULES))]
    columns=defaultdict(list);terms=defaultdict(list);ss={}
    for i,rs in enumerate(RULES):
        for r in rs:terms[r].append(bs[i]);columns[rotate_min(r[:4])].append(bs[i])
    for w in WORDS:
        for j in range(4):
            key=w[j:]+w[:j]
            for t in range(1,9):
                if t in w:continue
                r=key+(t,);v=m.new_bool_var('s'+str(r));ss[r]=v
                columns[w].append(v);terms[r].append(v)
    for w in WORDS:m.add_exactly_one(columns[w])
    m.add(sum(bs)==46);m.add(sum(ss.values())==2)
    # Exact non-rescue, independently of any auxiliary rescue flags.
    for c in cycles(6):m.add(sum(v for r in correct(c) for v in terms[r])<=4)
    zs=[];cycle_flags={};baseflags=[]
    for c in cycles(7):
        avail=[r for r in correct(c) if terms[r]]
        if len(avail)<6:continue
        z=m.new_bool_var('z'+str(c));n=sum(v for r in avail for v in terms[r])
        m.add(n>=6).only_enforce_if(z);m.add(n<=5).only_enforce_if(z.Not())
        zs.append(z);cycle_flags[c]=z
        if strengthened:
            bz=m.new_bool_var('base'+str(c));bn=sum(bs[i] for i,rs in enumerate(RULES) for r in correct(c) if r in rs)
            m.add(bn>=6).only_enforce_if(bz);m.add(bn<=5).only_enforce_if(bz.Not())
            baseflags.append(bz)
    m.add(sum(zs)>=target)
    if strengthened:
        # Search the necessary baseR7=2 branch after all triangle completions
        # have been excluded. Both extra rules must contribute to rescue.
        m.add(sum(baseflags)==2)
        for r,v in ss.items():
            possible=[z for c,z in cycle_flags.items() if r in correct(c)]
            m.add(sum(possible)>=v)
    return m,bs,ss

def export_solution(s,bs,ss,seed,filename='witness_pair_found.rules.json'):
    raw=json.loads((H/'inputs/new15051.rules.json').read_text())
    rs={(a,*h,t) for a,h,t in raw['rules']};group=defaultdict(set)
    for r in rs:group[rotate_min((r[-1],)+r[:4])].add(r)
    new=[]
    for g in group.values():
        if len(g)==4 and any(8 in r for r in g):new.extend(g)
    assert len(new)==24
    selected=[i for i,v in enumerate(bs) if s.value(v)]
    rules=set(new)|{r for i in selected for r in RULES[i]}|{r for r,v in ss.items() if s.value(v)}
    assert len(rules)==210
    output=H/filename
    output.write_text(json.dumps(dict(n=8,rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(rules)],seed=seed),indent=2),encoding='utf-8')
    return str(output)

def main():
    seeds=get_seeds();strong='--strong' in sys.argv;m,bs,ss=build(strengthened=strong)
    start=int(sys.argv[1]) if len(sys.argv)>1 else 0
    count=int(sys.argv[2]) if len(sys.argv)>2 else 60
    seconds=float(sys.argv[3]) if len(sys.argv)>3 else 2
    results=[];t0=time.monotonic()
    for index in range(start,min(start+count,len(seeds))):
        seed=seeds[index];mm=m.clone()
        for i in seed['blocks']:mm.add(bs[i]==1)
        s=cp_model.CpSolver();s.parameters.max_time_in_seconds=seconds
        s.parameters.num_search_workers=4;s.parameters.random_seed=index+1
        st=s.solve(mm);rec=dict(index=index,status=s.status_name(st),seconds=s.wall_time,branches=s.num_branches,seed_blocks=len(seed['blocks']))
        if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            rec['certificate']=export_solution(s,bs,ss,seed)
        results.append(rec)
        out=dict(scope='standard three-flip, R5=52,R6=0,R7>=4; fixed block-only witness pair union',total_seed_orbits=len(seeds),seed_start=start,records=results,status_counts=dict(Counter(r['status'] for r in results)),seconds=time.monotonic()-t0)
        suffix='_strong' if strong else ''
        (H/f'witness_pair_run_{start}{suffix}.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        if (index-start)%10==0 or st in (cp_model.FEASIBLE,cp_model.OPTIMAL):print(index,rec,flush=True)
        if 'certificate' in rec:break
    print(json.dumps({k:v for k,v in out.items() if k!='records'}),flush=True)
if __name__=='__main__':main()
