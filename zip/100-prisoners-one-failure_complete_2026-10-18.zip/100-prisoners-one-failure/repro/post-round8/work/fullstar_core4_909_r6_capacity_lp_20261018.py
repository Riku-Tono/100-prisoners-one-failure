"""One-case R6 capacity LP study, separate from pure-word LP evidence.

For critical909 only, regenerate c3 actual blocks and all840 six-cycles
on[7]. Every R6zero completion needs sum(row_delta*x)<=4-fixed_correct.
Initially saturated cycles forbid contributing rows. The soft-cap dual
has nonnegative word weights y and six-cycle weights z, with each row's
sum(y)+sum(delta*z)>=1 and total sum(y)+sum(cap*z)<needed rows. Only an
exact Fraction check can exclude. LP nonexclusion remains inconclusive.
"""
from fullstar_core4_residual_lp_20261018 import H,ResidualLP,pywraplp,qjson,sha
from c3_model import directed_cycles,cyc_rules
from itertools import combinations
from fractions import Fraction
from collections import Counter
import json,time


def propose(engine,free,available,target,deltas,capacities,soft):
    lp=pywraplp.Solver.CreateSolver('GLOP');lp.SetTimeLimit(3000)
    y={i:lp.NumVar(0,lp.infinity(),f'w{i}') for i in free}
    relevant=sorted({s for b in available for s in deltas[b]}) if soft else []
    z={i:lp.NumVar(0,lp.infinity(),f'six{i}') for i in relevant}
    for b in available:
        lp.Add(sum(y[i] for i in engine.rows[b])+sum(z[i] for i in deltas[b] if i in z)>=1)
    lp.Minimize(sum(y.values())+sum(capacities[i]*v for i,v in z.items()))
    status=lp.Solve()
    out=dict(lp_status={pywraplp.Solver.OPTIMAL:'OPTIMAL',pywraplp.Solver.FEASIBLE:'FEASIBLE'}.get(status,str(status)),
             available_actual_rows=len(available),required_remaining_blocks=target,
             status='LP_NOT_EXCLUDED_UNRESOLVED',R6_soft_inequalities=soft)
    if status not in (pywraplp.Solver.OPTIMAL,pywraplp.Solver.FEASIBLE):return out
    floating=lp.Objective().Value();out['floating_objective']=floating
    if floating>=target-1e-7:return out
    for den in (1000000,1000000000):
        # Common denominator and upward rounding, followed by exact checking.
        def rounded(var):
            v=Fraction(max(0,var.solution_value()))
            return Fraction(-((-v.numerator*den)//v.denominator)+1,den) if v else Fraction()
        yy={i:rounded(v) for i,v in y.items()};zz={i:rounded(v) for i,v in z.items()}
        weights=[sum((yy[i] for i in engine.rows[b]),Fraction())+
                 sum((zz.get(i,Fraction()) for i in deltas[b]),Fraction()) for b in available]
        bound=sum(yy.values(),Fraction())+sum((capacities[i]*q for i,q in zz.items()),Fraction())
        if (not weights or min(weights)>=1) and bound<target:
            assert all(q>=0 for q in yy.values()) and all(q>=0 for q in zz.values())
            out.update(status='EXACT_FRACTION_DUAL_EXCLUSION',certificate=dict(
                upper_bound=qjson(bound),min_actual_row_weight=qjson(min(weights)) if weights else None,
                nonnegative=True,all_legal_actual_rows_covered=True,exact_upper_bound_below_required=True,
                word_weights=[dict(index=i,word=engine.words[i],value=qjson(q)) for i,q in yy.items() if q],
                six_weights=[dict(index=i,capacity=capacities[i],value=qjson(q)) for i,q in zz.items() if q]))
            break
    return out


def main():
    start=time.monotonic();source=H/'fullstar_priority63_first.critical.json';data=json.loads(source.read_text())
    r=data['records'][909];assert r['index']==909
    engine=ResidualLP();assert engine.catalogue_sha==data['block_catalogue_sha256']
    core=engine.map_blocks(data['fixed_actual_blocks']+r['additional_actual_blocks'])
    extras=frozenset(map(tuple,r['critical_extra_rules']))
    assert len(core)==24 and not extras and sorted(core)==r['core_blocks']
    fixed=set().union(*(engine.blocks[b] for b in core))|extras
    cycles=[c for s in combinations(range(1,8),6) for c in directed_cycles(s)]
    rules=[set(cyc_rules(c)) for c in cycles];assert len(cycles)==840
    initial=[len(rr&fixed) for rr in rules];assert max(initial)<=4
    capacities=[4-n for n in initial]
    ri={}
    for i,rr in enumerate(rules):
        for rule in rr:ri.setdefault(rule,[]).append(i)
    delta=[]
    for block in engine.blocks:
        counts=Counter(i for rule in block for i in ri.get(rule,[]))
        assert len(counts)==8 and max(counts.values())==1
        delta.append(tuple(sorted(counts)))
    free,available=engine.residual(core,extras)
    saturated={i for i,c in enumerate(capacities) if c==0}
    removed=[b for b in available if saturated.intersection(delta[b])]
    filtered=tuple(b for b in available if not saturated.intersection(delta[b]))
    removed_proof=[dict(row=b,saturated_six=min(saturated.intersection(delta[b]))) for b in removed]
    assert all(initial[p['saturated_six']]==4 and p['saturated_six'] in delta[p['row']] for p in removed_proof)
    sat=propose(engine,free,filtered,28,delta,capacities,False)
    soft=propose(engine,free,available,28,delta,capacities,True)
    out=dict(status='SINGLE_CASE_NECESSARY_LP_STUDY_COMPLETE',scope=__doc__,critical_source_sha256=sha(source),
             critical_index=909,source_seed_core_index=4,block_catalogue_sha256=engine.catalogue_sha,
             fixed_blocks=sorted(core),extras=sorted(extras),fourth_cycles=r['fourth_cycles'],
             six_cycles=cycles,initial_correct_counts=initial,remaining_R6_capacities=capacities,
             pure_legal_rows=len(available),saturated_six_cycles=len(saturated),
             forbidden_rows_from_initial_R6_saturation=removed_proof,
             saturation_deletion_variant=sat,all_R6_softcap_variant=soft,
             construction_Solve_called=False,seconds=time.monotonic()-start)
    target=H/'fullstar_core4_909_r6_capacity_lp_20261018.json'
    target.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('saturation',sat['status'],sat.get('floating_objective'),'rows',len(filtered),flush=True)
    print('softcap',soft['status'],soft.get('floating_objective'),'seconds',out['seconds'],flush=True)


if __name__=='__main__':main()
