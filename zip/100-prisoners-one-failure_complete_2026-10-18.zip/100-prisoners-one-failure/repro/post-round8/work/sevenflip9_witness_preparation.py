"""All5760 seven-cycle block witnesses for seven-flip screen orbit9.

No CP/construction search and no pair graph. Cycles containing8 are included.
Uses actual generic block rules and full210 lossword collisions. Computes
the full S7 support stabilizer with8 fixed; proves8 is fixed by degree first.
No [7]-only extra-rule marginal bound is transferred to this orientation.
"""
from general_orientation_model import orientation_data,cycle_data,correct,canon,H
from itertools import permutations
from collections import Counter,defaultdict
import json,time,hashlib

def prepare():
    start=time.monotonic();source=H/'post_audit_sevenflip_20261018_screen.json';raw=source.read_bytes();screen=json.loads(raw)
    orbit=next(x for x in screen['orbits'] if x['index']==9);data=orientation_data(orbit['flips'])
    assert len(data.blocks)==1680 and len(data.words)==210
    active=set(data.active_supports);degree={i:sum(i in s for s in active) for i in range(1,9)}
    assert degree[8]==7 and all(degree[i]>degree[8] for i in range(1,8))
    flips=set(map(frozenset,orbit['flips']));group=[]
    for p in permutations(range(1,8)):
        mp=dict(zip(range(1,9),p+(8,)))
        if {frozenset(mp[x] for x in s) for s in flips}==flips:
            assert {frozenset(mp[x] for x in s) for s in active}==active;group.append(mp)
    assert len(group)==orbit['S7_stabilizer_order']==24
    wi={w:i for i,w in enumerate(data.words)}
    rows=[frozenset(canon(r[:4]) for r in b) for b in data.blocks]
    masks=[sum(1<<wi[w] for w in row) for row in rows];inc=defaultdict(list)
    for b,rr in enumerate(data.blocks):
        for r in rr:inc[r].append(b)
    allkeys=set();cyclecounts=[];dfs_nodes=0
    for c,rr in cycle_data(7):
        found=set();active_windows=sum(canon(r[:4]) in wi for r in rr);potential=sum(bool(inc[r]) for r in rr)
        if potential>=6:
            multiplicity=Counter(b for r in rr for b in inc[r]);assert max(multiplicity.values())<=1
            for ignored in sorted(rr):
                options=sorted((inc[r] for r in rr-{ignored}),key=len)
                if any(not a for a in options):continue
                def visit(j,occupied,chosen):
                    nonlocal dfs_nodes
                    dfs_nodes+=1
                    if j==6:found.add(tuple(sorted(chosen)));return
                    for b in options[j]:
                        if not occupied&masks[b]:visit(j+1,occupied|masks[b],chosen+[b])
                visit(0,0,[])
        for w in found:
            assert sum(len(rows[b]) for b in w)==24 and sum(masks[b] for b in w).bit_count()==24
            supplied=set().union(*(data.blocks[b] for b in w));assert len(rr&supplied)>=6
            allkeys.add((c,w))
        cyclecounts.append(dict(cycle=c,contains8=8 in c,active_windows=active_windows,potential_block_correct_rules=potential,witnesses=len(found)))
    assert len(cyclecounts)==5760
    print('ENUM',len(allkeys),'witnesses in',sum(x['witnesses']>0 for x in cyclecounts),'cycles, seconds',round(time.monotonic()-start,3),flush=True)
    lookup={b:i for i,b in enumerate(data.blocks)};maps=[]
    for mp in group:maps.append([lookup[frozenset(tuple(mp[x] for x in r) for r in rr)] for rr in data.blocks])
    remaining=set(allkeys);representatives=[];normalizers={}
    while remaining:
        initial=min(remaining)
        imagekeys=[(canon(tuple(mp[x] for x in initial[0])),tuple(sorted(bmap[b] for b in initial[1]))) for mp,bmap in zip(group,maps)]
        representative=min(imagekeys);rid=len(representatives);c,w=representative
        images=set()
        for gi,(mp,bmap) in enumerate(zip(group,maps)):
            key=(canon(tuple(mp[x] for x in c)),tuple(sorted(bmap[b] for b in w)))
            assert key in allkeys and key not in normalizers
            normalizers[key]=(rid,gi);images.add(key)
        assert len(images)==24 and images<=remaining
        remaining-=images
        representatives.append(dict(cycle=c,contains8=8 in c,blocks=w,orbit_size=len(images),actual_rules=[sorted(data.blocks[b]) for b in w]))
    keys=sorted(allkeys);witnesses=[frozenset(w) for c,w in keys];parents=[c for c,w in keys]
    with8=[x for x in cyclecounts if x['contains8'] and x['witnesses']]
    without8=[x for x in cyclecounts if not x['contains8'] and x['witnesses']]
    warning='[7]-only marginal<=1 and distinct-seven shared-correct-rule<=1 are not global lemmas for cycles on different7-subsets of[8]. They cannot justify a two-base-witness restriction here. A rule on5 labels can belong to6 seven-cycles across3 seven-subsets.'
    out=dict(status='COMPLETE_WITNESS_PREPARATION_NO_PAIR_GRAPH_NO_SOLVE',scope=__doc__,screen_source_sha256=hashlib.sha256(raw).hexdigest(),orbit_index=9,flips=data.flips,active_supports=sorted(sorted(s) for s in active),active_support_degrees=degree,unique_min_degree_label=8,full_orientation_stabilizer_order=len(group),stabilizer_group=[list(mp.values()) for mp in group],blocks=len(data.blocks),slots=len(data.words),all_seven_cycles=len(cyclecounts),support_eligible_seven_cycles=sum(x['active_windows']>=6 for x in cyclecounts),support_eligible_seven_cycles_containing8=sum(x['active_windows']>=6 and x['contains8'] for x in cyclecounts),block_witness_cycles=len(with8)+len(without8),block_witness_cycles_without8=len(without8),block_witness_cycles_containing8=len(with8),all_witnesses=len(keys),witnesses_without8=sum(x['witnesses'] for x in without8),witnesses_containing8=sum(x['witnesses'] for x in with8),witness_orbits=len(representatives),witness_orbits_containing8=sum(r['contains8'] for r in representatives),witness_orbits_without8=sum(not r['contains8'] for r in representatives),distinct_witness_block_sets=len(set(w for c,w in keys)),dfs_nodes=dfs_nodes,witnesses_per_rescuable_cycle_histogram=dict(Counter(x['witnesses'] for x in cyclecounts if x['witnesses'])),block8_count_per_witness_histogram=dict(Counter(sum(any(8 in r for r in data.blocks[b]) for b in w) for c,w in keys)),pair_graph_built=False,extra_rule_lemma_warning=warning,seconds=time.monotonic()-start,representative_witnesses=representatives,all_witness_data=[dict(cycle=c,contains8=8 in c,blocks=w,orbit=normalizers[(c,w)][0]) for c,w in keys],cycle_counts=cyclecounts)
    return out,data,rows,group,maps,witnesses,parents,normalizers

def main():
    out,*_=prepare();path=H/'sevenflip9_witness_preparation.json';path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in out.items() if k not in ('scope','representative_witnesses','all_witness_data','cycle_counts','stabilizer_group','active_supports')},indent=2),flush=True)

if __name__=='__main__':main()
