"""Redundant exact-cover form of the unchanged all-orientation model.

For every cyclic lossword w, block_occupation(w)+hole(w)=side(w), where
side is its35-pair orientation Boolean or its complement. AtMostOne and
the original orientation constraints already imply block_occupation is0/1
and never exceeds side. Thus hole is uniquely side-block_occupation.
There are210 active words and52*4=208 block-used words, hence exactly2 holes.
A singleton can only use an active word unoccupied by a block, so its word
supplier sum<=hole is redundant too. No construction is added or removed.

This wrapper does not modify the original builder or its raw logs. Search is
an explicit entry point, enabled only after the original and wrapper controls
pass; the root separately reviewed the equivalence and authorized its use.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict
from pathlib import Path
import argparse,hashlib,json,time
from global_orientation_witness_completion import GlobalModel,build as original_build,universe,solve_once,H,canon,read_rules

@dataclass
class HoleModel(GlobalModel):
    holes:dict

    def export_and_audit(self,solver,path,audit_path=None):
        result=super().export_and_audit(solver,path,audit_path)
        holes={w for w,v in self.holes.items() if solver.value(v)}
        extras={canon(r[:4]) for r,v in self.singles.items() if solver.value(v)}
        assert len(holes)==2 and extras<=holes
        result['model_hole_words']=sorted(holes)
        result['single_words_among_holes']=sorted(extras)
        return result

def build(target=4,canonical=True):
    base=original_build(target,canonical);words,allblocks,allsingles,pairs=universe()
    block_terms=defaultdict(list);single_terms=defaultdict(list)
    for i,b in enumerate(allblocks):
        for r in b:block_terms[canon(r[:4])].append(base.blocks[i])
    for r,v in base.singles.items():single_terms[canon(r[:4])].append(v)
    sides={}
    for i,(a,b) in enumerate(pairs):sides[a]=base.orientation[i];sides[b]=1-base.orientation[i]
    holes={w:base.model.new_bool_var(f'hole{i}') for i,w in enumerate(words)}
    for w,h in holes.items():
        base.model.add(sum(block_terms[w])+h==sides[frozenset(w)])
        base.model.add(sum(single_terms[w])<=h)
    base.model.add(sum(holes.values())==2)
    stats=dict(base.stats)
    stats.update(variant='redundant_word_holes',hole_variables=len(holes),
                 block_hole_side_equalities=len(holes),single_word_hole_inequalities=len(holes),
                 exact_total_holes=2,new_orientation_or_degree_cuts=False,
                 equivalence='hole(w)=side(w)-block_occupation(w); total210 active minus208 block-used; single usage<=hole follows original AtMostOne and orientation.')
    return HoleModel(base.model,base.target,base.canonical,base.blocks,base.singles,base.present,base.orientation,base.flags,stats,holes)

def validate_static():
    model=build();error=model.model.validate()
    out=dict(status='PASS' if not error else 'FAILED',scope=__doc__,stats=model.stats,
             variables=len(model.model.proto.variables),constraints=len(model.model.proto.constraints),
             validation_error=error,Solve_called=False)
    (H/'global_orientation_holes_static_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    if error:raise ValueError(error)
    print('HOLE_STATIC_VALIDATE_PASS',out['variables'],out['constraints'],flush=True)
    return out

def run_controls():
    from independent_audit import audit
    original_path=H/'global_orientation_controls.json';original=json.loads(original_path.read_text())
    if original.get('status')!='PASS':raise ValueError('Original model controls must pass first.')
    out=dict(scope='Only completely fixed known original controls, with identical targets, canonical constraint and orientations.',
             original_control_sha256=hashlib.sha256(original_path.read_bytes()).hexdigest(),records=[])
    for record in original['records']:
        label=record['label'];target=record['result']['stats']['target'];expected=record['result']['status']
        src=H/f'global_orientation_control_{label}.normalized.json';data=json.loads(src.read_text());rules=read_rules(src)
        before=audit(src)
        model=build(target,canonical=True);fixed=model.fix_certificate(rules,data['active_supports'])
        assert model.model.validate()==''
        result=solve_once(model,15,H/f'global_orientation_holes_control_{label}')
        assert result['status']==expected,(label,result['status'],expected)
        if 'audit' in result:
            for key in ('placements','wins','success_histogram','lost_cf','rescued_cycles','rescued_multiplicities'):
                assert before[key]==result['audit'][key],(label,key)
            assert len(result['model_hole_words'])==2
        else:assert before['rescued_cycles']['6']==1
        out['records'].append(dict(label=label,target=target,expected_original_status=expected,
                                  fixed=fixed,normalized_table_direct_audit=before,result=result))
        (H/'global_orientation_holes_controls.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    out['status']='PASS_ORIGINAL_FIXED_CONTROLS_MATCH'
    (H/'global_orientation_holes_controls.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=('validate','controls','prepare','search'))
    p.add_argument('--seconds',type=float,default=180);p.add_argument('--seed',type=int,default=1)
    p.add_argument('--prefix',help='Required for an explicit new search.');a=p.parse_args()
    if a.command in ('validate','prepare'):validate_static()
    if a.command in ('controls','prepare'):run_controls()
    if a.command=='search':
        if not a.prefix:raise ValueError('Explicit search output prefix is required.')
        controls=json.loads((H/'global_orientation_holes_controls.json').read_text())
        if controls.get('status')!='PASS_ORIGINAL_FIXED_CONTROLS_MATCH':raise ValueError('Wrapper controls must pass before search.')
        model=build(target=4,canonical=True)
        solve_once(model,a.seconds,Path(a.prefix),a.seed)

if __name__=='__main__':main()
