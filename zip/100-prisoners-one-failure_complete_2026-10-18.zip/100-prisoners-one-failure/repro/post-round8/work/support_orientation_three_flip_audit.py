"""Independent S7 orbit expansion and actual cyclic-rule block regeneration.
Reads only representatives/counts as data; imports no classification code.
"""
from itertools import combinations,permutations
from pathlib import Path
from collections import Counter
import json,time,hashlib
H=Path(__file__).resolve().parent;start=time.monotonic();raw=(H/'support_orientation_three_flip_classification.json').read_bytes();d=json.loads(raw)
base=list(map(frozenset,combinations(range(1,8),4)));index={s:i for i,s in enumerate(base)};perms=list(permutations(range(1,8)));alltrips=set(combinations(range(35),3));seen=set();records=[]
def norm(w):
 w=tuple(w);k=w.index(min(w));return w[k:]+w[:k]
for rec in d['orbits']:
 fs=list(map(frozenset,rec['removed_supports']));orb=set()
 for p in perms:
  orb.add(tuple(sorted(index[frozenset(p[x-1]for x in f)]for f in fs)))
 assert len(orb)==rec['labelled_triples'];assert not seen&orb;seen|=orb
 supports=set(base)-set(fs)|{frozenset(range(1,9))-f for f in fs};words={norm(p)for s in supports for p in permutations(s)};assert len(words)==210
 blocks=set()
 for labels in combinations(range(1,9),5):
  for tail in permutations(labels[1:]):
   c=(labels[0],)+tail;rr=tuple((c[i],c[(i+1)%5],c[(i+2)%5],c[(i+3)%5],c[(i+4)%5])for i in range(5))
   for omit in range(5):
    b=frozenset(rr[:omit]+rr[omit+1:])
    if all(norm(r[:4])in words for r in b):blocks.add(b)
 used={norm(r[:4])for b in blocks for r in b};newused={w for w in used if 8 in w};profile=Counter(sum(8 in r[:4]for r in b)for b in blocks)
 assert len(blocks)==rec['four_rule_blocks'];assert len(used)==rec['usable_cyclic_word_slots'];assert len(used)//4==rec['R5_slot_capacity_upperbound']
 assert bool(newused)==rec['is_standard_three_flip_orbit']
 records.append({'index':rec['index'],'S7_orbit_size':len(orb),'actual_blocks':len(blocks),'actual_usable_slots':len(used),'actual_new_usable_slots':len(newused),'blocks_by_new_word_count':dict(profile),'slot_upper_bound':len(used)//4})
assert seen==alltrips and len(seen)==6545
out={'method':__doc__,'input_sha256':hashlib.sha256(raw).hexdigest(),'all_6545_triples_covered_exactly_once':True,'S7_orbits':len(records),'orbits':records,'seconds':time.monotonic()-start,'construction_search_performed':False}
(H/'support_orientation_three_flip_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
