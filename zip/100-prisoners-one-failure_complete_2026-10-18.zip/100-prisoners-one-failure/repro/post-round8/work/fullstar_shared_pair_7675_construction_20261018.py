"""Bounded completion search for the sole eleven-block full-star witness pair.

Mandatory actual rules are independently mapped to the current full-star
catalogue. Search only this fixed pair, all other blocks/singletons free,
52 total blocks, <=2 singletons, R6=0, R7>=4. No local no-good is added.
This search does not rely on the nonstar exclusion or new Claude audit.
"""
from pathlib import Path
from itertools import permutations
from collections import Counter
import hashlib, json, time
from general_witness_completion import build,certificate_parts,read_rules,cp_model

H = Path(__file__).resolve().parent
START = time.monotonic()
PREFIX = H/'fullstar_shared_pair_7675_20261018'

def correct(c):
    return frozenset((c[i:] + c[:i])[:4] + ((c[i:] + c[:i])[-1],)
                     for i in range(len(c)))

def norm(w):
    return min(w[i:] + w[:i] for i in range(len(w)))

def own_cycles(k):
    return [(p,correct(p)) for p in permutations(range(1,9),k) if p[0] == min(p)]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def control(label,flips,path,target,expected):
    first = build(flips,(),target,False)
    selected,extras = certificate_parts(first.data,read_rules(path))
    m = build(flips,sorted(selected)[:11],target,False)
    fixed = m.fix_certificate(read_rules(path))
    s = cp_model.CpSolver();s.parameters.num_search_workers=1;s.parameters.max_time_in_seconds=15
    st = s.solve(m.model)
    result={'label':label,'status':s.status_name(st),'fixed':fixed,
            'source_sha256':sha(path),'seconds':s.wall_time,'stats':m.stats}
    assert result['status'] == expected
    if st in (cp_model.OPTIMAL,cp_model.FEASIBLE):
        result.update(m.export_and_audit(s,H/f'fullstar_shared_pair_7675_control_{label}_20261018.rules.json'))
    print('CONTROL',label,result['status'],result['seconds'],flush=True)
    return result

def main():
    source = H/'fullstar_prepare_pairs.json'
    pairs = json.loads(source.read_text())
    eleven = [(i,s) for i,s in enumerate(pairs['seeds']) if len(s['blocks'])==11]
    assert len(pairs['seeds'])==10289 and len(eleven)==1
    index,seed = eleven[0]
    assert index==7675
    groups = {correct(p) for p in permutations(range(1,8),5)}
    own_blocks = sorted({g-{r} for g in groups for r in g},key=lambda b:tuple(sorted(b)))
    assert len(own_blocks)==2520
    initial = build((),(),4,False)
    assert list(initial.data.blocks)==own_blocks
    fixed = set(seed['blocks'])
    actual = [own_blocks[i] for i in sorted(fixed)]
    lookup = {b:i for i,b in enumerate(initial.data.blocks)}
    remapped = {lookup[b] for b in actual}
    assert remapped==fixed
    occupied = [norm(r[:4]) for b in actual for r in b]
    assert len(occupied)==len(set(occupied))==44
    supplied = set().union(*actual)
    partial = {}
    rescued = {}
    for k in (5,6,7,8):
        counts = [(c,len(rs&supplied)) for c,rs in own_cycles(k)]
        rescued[k] = [c for c,n in counts if n>=k-1]
        partial[k] = {'rescues':len(rescued[k]),'max_correct':max(n for c,n in counts),
                      'correct_histogram':dict(sorted(Counter(n for c,n in counts).items()))}
    assert partial[6]['rescues']==0 and partial[7]['rescues']>=2
    assert all(tuple(c) in rescued[7] for c in seed['cycles'])
    out={'scope':__doc__,'source_sha256':sha(source),'source_seed_index':index,
         'source_seed':seed,'mandatory_actual_blocks':[sorted(b) for b in actual],
         'full2520_catalogue_actual_rules_match':True,'occupied_slots':44,
         'partial_counts':partial,'partial_rescued_sevens':rescued[7],
         'source_code_sha256':sha(Path(__file__)),'controls':[],'status':'PREPARED'}
    output=PREFIX.with_suffix('.result.json')
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    specs=[('baseline_positive',(),H/'inputs/baseline15051.rules.json',3,'OPTIMAL'),
           ('baseline_target4_negative',(),H/'inputs/baseline15051.rules.json',4,'INFEASIBLE'),
           ('R6one_negative',((1,2,3,4),(1,2,3,5),(1,2,3,6)),H/'inputs/new15051.rules.json',1,'INFEASIBLE')]
    for args in specs:
        out['controls'].append(control(*args))
        output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    model=build((),fixed,4,False)
    assert model.stats['mandatory_blocks']==11 and model.stats['occupied_slots']==44
    assert model.stats['seven_fixed_true']>=2 and not model.stats['local_relaxation']
    model.model.export_to_file(str(PREFIX.with_suffix('.model.pbtxt')))
    solver=cp_model.CpSolver();solver.parameters.num_search_workers=1
    solver.parameters.max_time_in_seconds=180;solver.parameters.random_seed=1
    solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
    PREFIX.with_suffix('.parameters.txt').write_text(str(solver.parameters),encoding='utf-8')
    out['stats']=model.stats;out['status']='RUNNING'
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('SEED',index,'PARTIAL', {k:v['rescues'] for k,v in partial.items()},'SEARCH_BEGIN',flush=True)
    with PREFIX.with_suffix('.log.txt').open('w',encoding='utf-8') as log:
        solver.log_callback=lambda line:log.write(line+'\n')
        st=solver.solve(model.model)
    out['status']=solver.status_name(st);out['workers']=1;out['limit_seconds']=180
    out['solve_seconds']=solver.wall_time;out['response_stats']=solver.response_stats()
    if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):
        out.update(model.export_and_audit(solver,PREFIX.with_suffix('.rules.json')))
    out['total_seconds']=time.monotonic()-START
    out['interpretation']='Completion result only for mandatory eleven-block witness seed7675. UNKNOWN is unresolved; no no-good or branch exclusion is added.'
    output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('FINAL',out['status'],out['solve_seconds'],flush=True)

if __name__=='__main__':
    main()
