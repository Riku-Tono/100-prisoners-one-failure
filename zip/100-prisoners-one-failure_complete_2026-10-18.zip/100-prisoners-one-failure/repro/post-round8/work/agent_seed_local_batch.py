import sys
import agent_seed_local_completion as a
for index in [2,3,10,11,16,20,24,26,28,30,31]:
    print('SEED',index,flush=True)
    sys.argv=['agent',str(index),'100','6']
    a.main()
