"""MSVC port driver for Claude c3 DLX; fullstar210/2520/840 only.

Actual rules/rows/six incidences are independently regenerated from Claude's
cycle functions. Positive node limits are mandatory. FOUND is accepted only
after52 distinct rows,210 exactly covered-or-hole words,2 total holes and
all840 six capacities have been checked; exported tables get40320 auditing.
"""
from pathlib import Path
from itertools import combinations
from collections import defaultdict,Counter
import argparse,hashlib,json,subprocess,sys,time

HERE=Path(__file__).resolve().parent;H=HERE.parent
sys.path.insert(0,str(H/'claude_desktop_continuation3'));sys.path.insert(0,str(H))
from c3_model import directed_cycles,cyc_rules,word
from independent_audit import audit

WORDS=tuple(sorted({word(r) for s in combinations(range(1,8),5) for c in directed_cycles(s) for r in cyc_rules(c)}));WI={w:i for i,w in enumerate(WORDS)}
BLOCKS=tuple(sorted({frozenset(rs[:skip]+rs[skip+1:]) for s in combinations(range(1,8),5) for c in directed_cycles(s) for rs in (cyc_rules(c),) for skip in range(5)},key=lambda b:tuple(sorted(b))))
LOOKUP={b:i for i,b in enumerate(BLOCKS)}
SIX=tuple(frozenset(cyc_rules(c)) for s in combinations(range(1,8),6) for c in directed_cycles(s));INC=defaultdict(list)
for k,rr in enumerate(SIX):
    for r in rr:INC[r].append(k)
ROWS=[];DELTAS=[]
for block in BLOCKS:
    cols=tuple(sorted(WI[word(r)] for r in block));delta=Counter(k for r in block for k in INC[r])
    assert len(cols)==len(set(cols))==4 and len(delta)==8 and set(delta.values())=={1}
    ROWS.append(cols);DELTAS.append(tuple(sorted(delta)))
CATALOGUE_SHA=hashlib.sha256(json.dumps([sorted(b) for b in BLOCKS],separators=(',',':')).encode()).hexdigest()
assert (len(WORDS),len(BLOCKS),len(SIX))==(210,2520,840)
assert CATALOGUE_SHA=='a57710fd3760ae84bd080095f3e00b452a31ca7e943c58afeb7539ee5ecda644'
MATRIX='210 2520 840\n'+''.join(' '.join(map(str,ROWS[i]+(len(DELTAS[i]),)+DELTAS[i]))+'\n' for i in range(2520))

def write(path,obj):Path(path).write_text(json.dumps(obj,separators=(',',':')),encoding='utf-8')

class NativeEngine:
    def __init__(self,exe=None,trace_prefix=None):
        self.exe=Path(exe) if exe else HERE/'fullstar_dlx.exe';self.counter=0
        self.p=subprocess.Popen([str(self.exe.resolve())],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,
                                bufsize=1,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.p.stdin.write(MATRIX);self.p.stdin.flush()
        self.input_trace=self.output_trace=None
        if trace_prefix:
            self.input_trace=Path(str(trace_prefix)+'.cases.txt').open('w',encoding='ascii')
            self.output_trace=Path(str(trace_prefix)+'.stdout.txt').open('w',encoding='ascii')
    def close(self):
        if self.p.stdin:self.p.stdin.close()
        self.p.wait(timeout=5)
        for f in (self.input_trace,self.output_trace):
            if f:f.close()
    def solve(self,mandatory,extras=(),node_limit=2000000,sixlimit=4):
        if type(node_limit) is not int or not 0<node_limit<2**63:raise ValueError('Node limit must be explicitly positive signed64 integer.')
        if type(sixlimit) is not int or sixlimit!=4:raise ValueError('This fullstar wrapper requires sixlimit4.')
        fixed=frozenset(mandatory);extras=frozenset(map(tuple,extras));assert len(extras)<=2 and all(0<=b<2520 for b in fixed)
        assert all(type(b) is int for b in fixed)
        for r in extras:
            assert len(r)==5 and len(set(r))==5 and all(type(x) is int and 1<=x<=8 for x in r)
            assert set(r[:4])<=set(range(1,8)) and r[4] not in r[:4]
        cols=[w for b in fixed for w in ROWS[b]];holes=[WI[word(r)] for r in extras]
        assert len(cols)==len(set(cols)) and len(holes)==len(set(holes))==len(extras) and not set(cols)&set(holes)
        init=[k for r in sorted(extras) for k in INC[r]] # multiset; duplicates MUST stay
        counts=Counter(init)
        for b in fixed:counts.update(DELTAS[b])
        assert all(n<=sixlimit for n in counts.values())
        ident=self.counter;self.counter+=1;budget=2-len(extras)
        case=' '.join(map(str,['CASE',ident,len(fixed),*sorted(fixed),len(holes),*holes,budget,sixlimit,node_limit,len(init),*init]))+'\n'
        if self.input_trace:self.input_trace.write(case);self.input_trace.flush()
        started=time.monotonic();self.p.stdin.write(case);self.p.stdin.flush();line=self.p.stdout.readline()
        if not line:raise RuntimeError(('Native solver failed',self.p.poll(),self.p.stderr.read()))
        if self.output_trace:self.output_trace.write(line);self.output_trace.flush()
        fields=line.split();assert int(fields[0])==ident
        st=fields[1];nodes=int(fields[2]);out=dict(status=st,nodes=nodes,seconds=time.monotonic()-started,node_limit=node_limit)
        if st=='FOUND':
            split=fields.index('H');more=list(map(int,fields[3:split]));free=list(map(int,fields[split+1:]));selected=fixed|set(more)
            assert len(more)==len(set(more)) and not fixed&set(more) and len(selected)==52
            allcols=[w for b in selected for w in ROWS[b]];allholes=holes+free
            assert len(allcols)==len(set(allcols))==208 and len(allholes)==len(set(allholes))==2
            assert len(free)==budget and not set(allcols)&set(allholes) and set(allcols)|set(allholes)==set(range(210))
            rr=set().union(*(BLOCKS[b] for b in selected))|set(extras)
            assert all(len(s&rr)<=sixlimit for s in SIX)
            out.update(selected_blocks=sorted(selected),additional_blocks=more,free_hole_words=[WORDS[w] for w in free],fixed_hole_words=[WORDS[w] for w in holes])
        elif st=='NODELIMIT':out['status']='UNKNOWN_NODE_LIMIT';assert nodes==node_limit+1
        elif st!='EXHAUSTED':raise AssertionError(('Unexpected native fixed conflict/status',st))
        return out

def export(path,result,extras=(),minimum=15051):
    path=Path(path);blocks=result['selected_blocks'];single=set(map(tuple,extras))|{tuple(w)+(8,) for w in result['free_hole_words']}
    rr=set().union(*(BLOCKS[b] for b in blocks))|single
    assert len(blocks)==52 and len(single)==2 and len(rr)==210 and len({word(r) for r in rr})==210
    write(path,dict(n=8,rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(rr)],selected_block_ids=blocks,extra_rules=sorted(single),block_catalogue_sha256=CATALOGUE_SHA))
    checked=audit(path)
    assert checked['placements']==40320 and checked['lost_cf']==0 and checked['rescued_cycles']['5']==52 and checked['rescued_cycles']['6']==0
    assert checked['wins']>=minimum
    if minimum>=15052:assert checked['rescued_cycles']['7']>=4
    write(path.with_suffix('.audit.json'),checked);return checked

def controls():
    source=H/'inputs/baseline15051.rules.json';doc=json.loads(source.read_text());rr={(a,*hist,t) for a,hist,t in doc['rules']}
    known=frozenset(i for i,b in enumerate(BLOCKS) if b<=rr);assert len(known)==52
    old=json.loads((H/'fullstar_fixed18_complete_summary.json').read_text());fixed=set(old['fixed_core']);assert fixed<=known
    fixed.update(sorted(known-fixed)[:39-len(fixed)]);assert len(fixed)==39
    unused=set(WORDS)-{WORDS[w] for b in known for w in ROWS[b]};assert len(unused)==2
    extras={w+(8,) for w in unused}
    critical=json.loads((H/'fullstar_priority63_first.critical.json').read_text())
    old_results=json.loads((H/'fullstar_priority63_first.result.json').read_text())
    easy=next(r['index'] for r in old_results['records'] if r['status']=='EXHAUSTED_NO_COMPLETION' and r['engine']=='PURE_HIGH_BITSET' and r['nodes']==1)
    engine=NativeEngine(trace_prefix=HERE/'controls');records=[];sequence=[]
    for repeat in range(3):
        result=engine.solve(fixed,extras,2000000);assert result['status']=='FOUND' and len(result['additional_blocks'])==13
        checked=export(HERE/f'positive39_repeat{repeat}.rules.json',result,extras,15051)
        records.append(dict(repeat=repeat,result=result,direct_audit=checked))
        sequence.append(dict(kind='KNOWN_POSITIVE',status=result['status'],nodes=result['nodes']))
        if repeat<2:
            index=909 if repeat==0 else easy;row=critical['records'][index]
            probe=engine.solve(row['core_blocks'],row['critical_extra_rules'],1 if repeat==0 else 2000000)
            expected='UNKNOWN_NODE_LIMIT' if repeat==0 else 'EXHAUSTED';assert probe['status']==expected
            sequence.append(dict(kind='NODELIMIT_PROBE' if repeat==0 else 'KNOWN_EXHAUSTION',critical_index=index,**probe))
    engine.close();out=dict(status='PASS_NATIVE_39_TO_52_AND_MIXED_STATE_REUSE',actual_words=210,actual_blocks=2520,actual_sixes=840,
                           catalogue_sha256=CATALOGUE_SHA,records=records,source_sha256=hashlib.sha256((HERE/'fullstar_dlx.c').read_bytes()).hexdigest(),
                           exe_sha256=hashlib.sha256((HERE/'fullstar_dlx.exe').read_bytes()).hexdigest(),
                           wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),state_transition_sequence=sequence)
    write(HERE/'controls.json',out);print('NATIVE_CONTROLS_PASS',[(r['result']['nodes'],r['result']['seconds'],r['direct_audit']['wins']) for r in records],flush=True)
    return out

def load_critical(path):
    path=Path(path);raw=path.read_bytes();doc=json.loads(raw);assert doc['block_catalogue_sha256']==CATALOGUE_SHA
    fixed=frozenset(LOOKUP[frozenset(map(tuple,b))] for b in doc['fixed_actual_blocks']);assert fixed==set(doc['fixed_core'])
    cases=[]
    for index in doc['minimal_record_indices']:
        row=doc['records'][index];assert row['index']==index
        core=fixed|{LOOKUP[frozenset(map(tuple,b))] for b in row['additional_actual_blocks']};assert core==set(row['core_blocks'])
        extras=frozenset(map(tuple,row['critical_extra_rules']))
        rr=set().union(*(BLOCKS[b] for b in core))|set(extras)
        assert sum(len(set(cyc_rules(c))&rr)>=6 for c in directed_cycles(range(1,8)))>=4
        cases.append((index,core,extras))
    return cases,dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),cases=len(cases))

def benchmark(paths,node_limit):
    if node_limit<=0:raise ValueError('Positive node limit required.')
    control=json.loads((HERE/'controls.json').read_text());assert control['status']=='PASS_NATIVE_39_TO_52_AND_MIXED_STATE_REUSE'
    for key,path in (('source_sha256',HERE/'fullstar_dlx.c'),('exe_sha256',HERE/'fullstar_dlx.exe'),('wrapper_sha256',Path(__file__))):
        assert control[key]==hashlib.sha256(path.read_bytes()).hexdigest()
    started=time.monotonic();engine=NativeEngine(trace_prefix=HERE/'benchmark');out=dict(scope='Verification only: replay closed core4/core8 criticals with independent native C; not a new family exclusion.',node_limit=node_limit,inputs=[],records=[],status='RUNNING')
    for path in paths:
        cases,provenance=load_critical(path);out['inputs'].append(provenance)
        for index,core,extras in cases:
            result=engine.solve(core,extras,node_limit);record=dict(source=str(path),index=index,**result);out['records'].append(record)
            if result['status']=='FOUND':
                candidate=HERE/f'benchmark_found_{len(out["records"])}.rules.json';record['direct_audit']=export(candidate,result,extras,15052)
                out['status']='FOUND_CONTRADICTS_PRIOR_PROOF_AUDIT_IMMEDIATELY';write(HERE/'benchmark.json',out);raise AssertionError(out['status'])
            if len(out['records'])%25==0:
                out.update(seconds=time.monotonic()-started,counts=dict(Counter(r['status'] for r in out['records'])));write(HERE/'benchmark.json',out)
            if len(out['records'])%250==0:print('NATIVE',len(out['records']),out.get('counts'),round(time.monotonic()-started,3),flush=True)
    engine.close();out.update(status='COMPLETE_BENCHMARK',counts=dict(Counter(r['status'] for r in out['records'])),seconds=time.monotonic()-started,
                             total_nodes=sum(r['nodes'] for r in out['records']),unknown_cases=[dict(source=r['source'],index=r['index']) for r in out['records'] if r['status'].startswith('UNKNOWN')])
    write(HERE/'benchmark.json',out);print('NATIVE_FINAL',out['counts'],out['seconds'],out['total_nodes'],flush=True);return out

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=('matrix','controls','benchmark'));p.add_argument('--critical',action='append');p.add_argument('--node-limit',type=int,default=2000000);a=p.parse_args()
    (HERE/'fullstar_matrix.txt').write_text(MATRIX,encoding='ascii')
    if a.command=='controls':controls()
    elif a.command=='benchmark':
        if not a.critical:raise ValueError('Critical files required.')
        benchmark(a.critical,a.node_limit)

if __name__=='__main__':main()
