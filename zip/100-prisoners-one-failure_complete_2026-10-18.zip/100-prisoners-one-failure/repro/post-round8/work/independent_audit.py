"""Independent simulation; reads certificates as data only. Python standard library."""
import itertools,json,collections,pathlib,hashlib
BASE=pathlib.Path(__file__).parent/'inputs'
def audit(path):
    data=json.loads(path.read_text(encoding='utf-8-sig'))
    table={}
    for a,h,t in data['rules']:
        assert len(h)==3 and len(set([a]+h))==4
        assert t not in [a]+h and t!=h[-1]
        key=(a,tuple(h));assert key not in table;table[key]=t
    counts=collections.Counter();lost=[];rescued=collections.Counter()
    for p in itertools.permutations(range(1,9)):
        success=0;cf_success=0
        for a in range(1,9):
            b=a;hist=[]
            for step in range(4):
                seen=p[b-1];hist.append(seen)
                if seen==a:success+=1;break
                b=table.get((a,tuple(hist)),seen) if step==2 else seen
            b=a
            for step in range(4):
                b=p[b-1]
                if b==a:cf_success+=1;break
        counts[success]+=1
        if cf_success>=7 and success<7:lost.append(p)
        if success>=7 and cf_success<7:
            rem=set(range(1,9));cycles=[]
            while rem:
                a=min(rem);c=[];b=a
                while b not in c:c.append(b);rem.remove(b);b=p[b-1]
                cycles.append(tuple(c))
            rescued[max(cycles,key=len)]+=1
    return dict(file=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),rules=len(table),placements=sum(counts.values()),wins=sum(v for k,v in counts.items() if k>=7),success_histogram=dict(sorted(counts.items())),lost_cf=len(lost),rescued_cycles={str(k):sum(len(c)==k for c in rescued) for k in range(5,9)},rescued_multiplicities=dict(collections.Counter(rescued.values())))
if __name__=='__main__':
    result=[audit(BASE/name) for name in ('baseline15051.rules.json','new15051.rules.json','neutral15051.rules.json')]
    out=pathlib.Path(__file__).with_name('independent_audit.json');out.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))
