"""Independently enumerate all 5**6 supplier assignments for canonical six rules.

No construction or completion solver is called. A required rule is supplied
by one of its four actual four-rule blocks or by its singleton. All source
blocks are regenerated over all eight labels; no full-star restriction is
assumed in their generation.
"""
from pathlib import Path
from itertools import permutations, product
from collections import defaultdict, Counter
import hashlib, json, time

H = Path(__file__).resolve().parent
START = time.monotonic()

def normalize(w):
    return min(w[i:] + w[:i] for i in range(len(w)))

def correct(c):
    return frozenset((c[i:] + c[:i])[:4] + ((c[i:] + c[:i])[-1],)
                     for i in range(len(c)))

def key(blocks, extras):
    return (tuple(sorted(tuple(sorted(tuple(r) for r in b)) for b in blocks)),
            tuple(sorted(tuple(r) for r in extras)))

def main():
    # No catalogue or generator is imported from the submitted scripts.
    groups = {correct(p) for p in permutations(range(1, 9), 5)}
    blocks = {g - {r} for g in groups for r in g}
    required = tuple((i+1, (i+1) % 7 + 1, (i+2) % 7 + 1,
                      (i+3) % 7 + 1, (i-1) % 7 + 1) for i in range(6))
    suppliers = []
    for r in required:
        options = sorted((b for b in blocks if r in b), key=lambda b: tuple(sorted(b)))
        assert len(options) == 4
        assert all(set().union(*map(set, b)) <= set(range(1, 8)) for b in options)
        assert all(len(set(required) & b) == 1 for b in options)
        suppliers.append(options + [None])
    accepted = set()
    raw_assignments = 0
    budget_passing = 0
    collisions = 0
    histogram = Counter()
    for choice in product(*suppliers):
        raw_assignments += 1
        extras = [r for r, b in zip(required, choice) if b is None]
        if len(extras) > 2: continue
        budget_passing += 1
        selected = [b for b in choice if b is not None]
        actual = [r for b in selected for r in b] + extras
        slots = [normalize(r[:4]) for r in actual]
        if len(slots) != len(set(slots)):
            collisions += 1
            continue
        assert set(required) <= set(actual)
        assert len(set(selected)) == len(selected)
        accepted.add(key(selected, extras))
        histogram[len(extras)] += 1
    assert raw_assignments == 5**6
    assert len(accepted) == 70
    assert histogram == {0: 4, 1: 21, 2: 45}

    submitted = json.loads((H/'canonical_six_witness_preparation.json').read_text())
    assert tuple(map(tuple, submitted['required_rules'])) == required
    assert len(submitted['records']) == 70
    primary = {key(r['actual_blocks'], r['extras']) for r in submitted['records']}
    assert accepted == primary
    per_file = []
    cycles = {k: [(p, correct(p)) for p in permutations(range(1, 9), k)
                  if p[0] == min(p)] for k in (6, 7)}
    blockstar = sorted((b for b in blocks if all(8 not in r for r in b)),
                       key=lambda b: tuple(sorted(b)))
    assert len(blockstar) == 2520
    records_by_id = {r['representative_index']: r for r in submitted['records']}
    actual_file_keys = set()
    for i in range(70):
        path = H/'canonical_six_witness_cores'/f'core_{i:03}.json'
        data = json.loads(path.read_text())
        k = key(data['actual_blocks'], data['extras'])
        assert k in accepted and k == key(records_by_id[i]['actual_blocks'], records_by_id[i]['extras'])
        actual_file_keys.add(k)
        rs = set().union(*(set(b) for b in k[0])) | set(k[1])
        assert len(rs) == 4*len(k[0]) + len(k[1])
        own_slots = sorted(normalize(r[:4]) for r in rs)
        own_supports = sorted({tuple(sorted(r[:4])) for r in rs})
        assert own_slots == [tuple(w) for w in data['occupied_losswords']]
        assert own_supports == [tuple(s) for s in data['forced_active_supports']]
        assert len(own_slots) == data['occupied_lossword_count']
        assert len(k[0]) == data['block_count'] and len(k[1]) == data['extra_count']
        assert [tuple(sorted(blockstar[j])) for j in data['block_ids_in_fullstar_catalogue']] == list(k[0])
        r6 = [c for c, rr in cycles[6] if len(rr & rs) >= 5]
        r7 = [c for c, rr in cycles[7] if len(rr & rs) >= 6]
        assert len(r6) == data['R6_in_partial_core'] == 0
        assert len(r7) == data['R7_in_partial_core'] == 1
        per_file.append({'index': i, 'blocks': len(k[0]), 'extras': len(k[1]),
                         'slots': len(own_slots), 'R6_partial': len(r6),
                         'R7_partial': len(r7),
                         'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    assert actual_file_keys == accepted
    digest = hashlib.sha256(json.dumps(sorted(accepted), separators=(',', ':')).encode()).hexdigest()
    out = {'status': 'PASS', 'scope': __doc__, 'Solve_called': False,
           'source_generator_imported': False, 'all_eight_label_blocks': len(blocks),
           'required_rules': required, 'block_suppliers_per_required_rule': [4]*6,
           'total_supplier_assignments': raw_assignments,
           'singleton_budget_passing_assignments': budget_passing,
           'slot_collision_assignments': collisions,
           'accepted_unique_cores': len(accepted),
           'extras_histogram': dict(sorted(histogram.items())),
           'actual_core_set_sha256': digest,
           'submitted_set_exact_match': accepted == primary,
           'all_70_exported_files_exact_match': actual_file_keys == accepted,
           'files': per_file,
           'completeness_argument': [
               'Each valid rule fixes a unique five-cycle and has exactly four four-rule-block suppliers, plus its singleton supplier.',
               'The six canonical correct rules have different five-supports, so a supplier block cannot supply two of them.',
               'In any modeled completion, every required present rule has exactly one selected supplier because cyclic-word columns are disjoint.',
               'At most two selected suppliers can be singletons. Thus its six suppliers occur among the 5**6 assignments checked.',
               'All supplier blocks necessarily use only labels1..7 because their five-support equals that of their required rule; this leaves all unspecified supports free.',
               'All selected rules here use labels1..7, so support-complement conflicts are impossible locally. Only actual cyclic-word collisions and singleton budget are rejected.'],
           'seconds': time.monotonic() - START}
    (H/'canonical_six_witness_independent_review_20261018.json').write_text(json.dumps(out, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in out.items() if k != 'files'}, indent=2))

if __name__ == '__main__':
    main()
