"""Enumerate every critical fourth-seven core with the fixed18-block seed.

No CP solving or completion search. For each of720 seven-cycles, omit one
of its7 windows, skip rules already fixed, and supply every remaining rule
by an actual four-rule block or the correct singleton. All lossword slots
are noncolliding; at most2 singleton rules; R6=0 is checked incrementally.
Dedup core+extras, then remove supersets of another enumerated witness.
"""
from fullstar_prepare_basic import H,RULES,ROWS,WORDS,correct,canon
from itertools import permutations,combinations
from collections import defaultdict,Counter
from pathlib import Path
import argparse,hashlib,json,time

def read_json(path):
    for attempt in range(5):
        try:return json.loads(Path(path).read_text())
        except json.JSONDecodeError:
            if attempt==4:raise

def enumerate_cores():
    started=time.monotonic();d=read_json(H/'fullstar_prepare_baseline.json')
    seed=frozenset(d['mandatory_three_witness_union']);assert len(seed)==18
    fixed=set().union(*(RULES[b] for b in seed))
    initial_slots=set().union(*(ROWS[b] for b in seed));assert len(initial_slots)==72
    words=set(WORDS);inc=defaultdict(list)
    for b,rs in enumerate(RULES):
        if ROWS[b]&initial_slots:continue
        for r in rs:inc[r].append(b)
    six=[correct((s[0],)+p) for s in combinations(range(1,8),6) for p in permutations(s[1:])]
    rule_sixes=defaultdict(list)
    for i,rr in enumerate(six):
        for r in rr:rule_sixes[r].append(i)
    bdelta=[]
    for rs in RULES:bdelta.append(tuple(Counter(i for r in rs for i in rule_sixes[r]).items()))
    counts=[sum(r in fixed for r in rr) for rr in six];assert max(counts)<=4
    slots=[ROWS[b] for b in range(len(RULES))]
    nodes=leaves=0;found={};cycle_stats=[]
    for tail in permutations(range(2,8)):
        cycle=(1,)+tail;rr=correct(cycle)
        if len(rr&fixed)>=6:continue
        before=len(found);local_leaves=0
        for ignored in rr:
            needed=rr-{ignored}-fixed
            if any(canon(r[:4]) in initial_slots for r in needed):continue
            def dfs(todo,used,chosen,extras):
                nonlocal nodes,leaves,local_leaves
                nodes+=1
                if not todo:
                    leaves+=1;local_leaves+=1
                    core=tuple(sorted(seed|chosen));extra=tuple(sorted(extras));key=(core,extra)
                    if key not in found:found[key]={'core_blocks':core,'critical_extra_rules':extra,'fourth_cycles':set()}
                    found[key]['fourth_cycles'].add(cycle);return
                options=[]
                for r in todo:
                    bs=[b for b in inc[r] if not slots[b]&used and all(counts[i]+n<=4 for i,n in bdelta[b])]
                    can_single=len(extras)<2 and canon(r[:4]) not in used and all(counts[i]<4 for i in rule_sixes[r])
                    n=len(bs)+int(can_single)
                    if n==0:return
                    options.append((n,r,bs,can_single))
                _,r,bs,can_single=min(options)
                for b in bs:
                    for i,n in bdelta[b]:counts[i]+=n
                    dfs(todo-RULES[b],used|slots[b],chosen|{b},extras)
                    for i,n in bdelta[b]:counts[i]-=n
                if can_single:
                    for i in rule_sixes[r]:counts[i]+=1
                    dfs(todo-{r},used|{canon(r[:4])},chosen,extras|{r})
                    for i in rule_sixes[r]:counts[i]-=1
            dfs(needed,frozenset(initial_slots),frozenset(),frozenset())
        if local_leaves:cycle_stats.append({'cycle':cycle,'leaves':local_leaves,'new_unique_cores':len(found)-before})
    records=[]
    for key,r in sorted(found.items()):
        r['fourth_cycles']=sorted(r['fourth_cycles']);records.append(r)
    # Antichain reduction is safe: every removed core contains an explicitly
    # retained smaller witness with a subset of its fixed external rules.
    accepted=defaultdict(list);minimal=[];subsumed=0
    for r in sorted(records,key=lambda r:(len(r['core_blocks'])-18+len(r['critical_extra_rules']),len(r['critical_extra_rules']),r['core_blocks'],r['critical_extra_rules'])):
        bm=sum(1<<b for b in r['core_blocks']);er=tuple(r['critical_extra_rules'])
        er_subsets=[tuple(c) for n in range(len(er)+1) for c in combinations(er,n)]
        if any(bm&small==small for subset in er_subsets for small in accepted[subset]):subsumed+=1;continue
        accepted[er].append(bm);minimal.append(r)
    catalogue=json.dumps([sorted(b) for b in RULES],separators=(',',':')).encode()
    out={'status':'EXHAUSTED_CRITICAL_CORE_ENUMERATION_ONLY','scope':__doc__,'fixed_core':sorted(seed),'flipped_supports':[],'required_completed_blocks':52,'completed_single_rules_max':2,'R6':0,'R7_target':4,'block_catalogue_sha256':hashlib.sha256(catalogue).hexdigest(),'dfs_nodes':nodes,'dfs_leaves':leaves,'unique_core_extra_sets':len(records),'minimal_core_extra_sets':len(minimal),'subsumed_core_extra_sets':subsumed,'distinct_fourth_cycles':len(cycle_stats),'cycle_stats':cycle_stats,'core_size_histogram':dict(Counter(len(r['core_blocks']) for r in records)),'extra_count_histogram':dict(Counter(len(r['critical_extra_rules']) for r in records)),'seconds':time.monotonic()-started,'records':records,'minimal_records':minimal}
    return out

def compare_frontier(out,paths):
    candidates={(tuple(r['core_blocks']),tuple(map(tuple,r['critical_extra_rules']))):r for r in out['records']}
    proofs={};sources=[]
    for path in paths:
        p=Path(path)
        if not p.exists():continue
        d=read_json(p);sources.append({'path':str(p),'status':d['status'],'seconds':d.get('seconds'),'new_records':len(d['records'])})
        for r in list(d.get('replayed_no_goods',[]))+d['records']:
            if r['completion_status']!='INFEASIBLE' or not r['no_good_added']:continue
            key=(tuple(r['core_blocks']),tuple(map(tuple,r['critical_extra_rules'])))
            assert key in candidates,('sampledCPcore_not_in_direct_enumeration',key)
            proofs[key]=r
    indexed=defaultdict(list)
    for blocks,extras in proofs:indexed[extras].append(sum(1<<b for b in blocks))
    def resolved(r):
        bm=sum(1<<b for b in r['core_blocks']);er=tuple(map(tuple,r['critical_extra_rules']))
        return any(bm&small==small for n in range(len(er)+1) for subset in combinations(er,n) for small in indexed[tuple(subset)])
    all_resolved=sum(resolved(r) for r in out['records']);minimal_resolved=sum(resolved(r) for r in out['minimal_records'])
    return {'sources':sources,'distinct_proved_infeasible_keys':len(proofs),'all_sampled_proofs_match_direct_enumeration':True,'all_candidates_resolved_by_proof_inclusion':all_resolved,'all_candidates_still_unresolved':len(out['records'])-all_resolved,'minimal_candidates_resolved_by_proof_inclusion':minimal_resolved,'minimal_candidates_still_unresolved':len(out['minimal_records'])-minimal_resolved}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--frontier-only',action='store_true');a=p.parse_args()
    target=H/'fullstar_fixed_core_enumeration.json'
    out=read_json(target) if a.frontier_only else enumerate_cores()
    out['frontier_snapshot']=compare_frontier(out,[H/'post_audit_fullstar_20261018_result.json',H/'post_audit_fullstar_20261018_resume1_result.json'])
    target.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print({k:v for k,v in out.items() if k not in ('scope','records','minimal_records','cycle_stats')},flush=True)
if __name__=='__main__':main()
