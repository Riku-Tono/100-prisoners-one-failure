"""Read-only cross-file consistency audit of the final 913-seed proof frontier.
Writes only final913_external_audit_prep.json/.txt. Does not run constructions,
CP-SAT, DLX, or the existing proof-producing aggregation scripts.
"""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json,time
H=Path(__file__).parent
def read(name):return json.loads((H/name).read_text(encoding='utf-8-sig'))
def sha(name):return hashlib.sha256((H/name).read_bytes()).hexdigest()
def corekey(r):return (tuple(sorted(r['core_blocks'])),tuple(sorted(map(tuple,r['extras']))))
def keydigest(keys):
    return hashlib.sha256(json.dumps(sorted(keys),separators=(',',':')).encode()).hexdigest()

def main():
    start=time.monotonic();f=read('WITNESS_FRONTIER.json');seedraw=(H/'witness_pair_seeds.json').read_bytes();seeds=json.loads(seedraw)['seeds']
    assert len(seeds)==913 and set(map(int,f['closed']))==set(range(913))
    assert f['closed_count']==913 and f['open_count']==0 and f['open_indices']==[] and f['total_pair_union_orbits']==913
    assert hashlib.sha256(seedraw).hexdigest()==f['seed_file_sha256']
    selected=[];methodcounts=Counter();chosenkeys=set();chosencount=0;sources={}
    for index in range(913):
        chosen=f['closed'][str(index)];name=chosen['file'];d=sources.setdefault(name,read(name));method=chosen['method'];methodcounts[method]+=1
        if method=='reduced CP-SAT':
            rr=[r for r in d['records'] if r['index']==index];assert len(rr)==1 and rr[0]['status']=='INFEASIBLE'
            assert not d.get('local_relaxation',False) and '_local.' not in name
            rec=rr[0];ncores=0;status=rec['status']
        else:
            assert method=='local CP-SAT + exhaustive exact cover'
            assert d['seed_index']==index and d['status']=='LOCAL_INFEASIBLE'
            assert d['completion_counts']==dict(Counter(r['status'] for r in d['records']))
            assert all(r['status'] in ('EXHAUSTED_NO_COMPLETION','EXHAUSTED_R6_CONFLICT') for r in d['records'])
            assert [r['iteration'] for r in d['records']]==list(range(len(d['records'])))
            for r in d['records']:
                assert set(seeds[index]['blocks'])<=set(r['core_blocks'])
                assert len(r['extras'])==2 and len(set(map(tuple,r['extras'])))==2
                assert r['core_blocks']==sorted(set(r['core_blocks'])) and r['extras']==sorted(r['extras'])
                chosenkeys.add(corekey(r));chosencount+=1
            ncores=len(d['records']);status=d['status'];rec=d['stats']
        assert rec['mandatory']==len(seeds[index]['blocks'])==12
        assert rec['remaining_slots']==186-4*rec['mandatory']==138
        selected.append(dict(index=index,method=method,file=name,status=status,core_records=ncores,sha256=sha(name)))
    assert methodcounts=={'reduced CP-SAT':23,'local CP-SAT + exhaustive exact cover':890}

    # Inventory every root-level per-seed local record independently of the
    # aggregation's filename patterns, so a missing pattern is visible.
    allattempts=[];allkeys=set();alloccurrences=0;attemptstatus=Counter();history=[];localfiles={}
    for path in sorted(H.glob('*.json')):
        try:d=json.loads(path.read_text(encoding='utf-8-sig'))
        except (json.JSONDecodeError,UnicodeError):continue
        if not isinstance(d,dict) or 'seed_index' not in d or 'records' not in d:continue
        if not isinstance(d['records'],list):continue
        if 'stats' not in d:continue
        index=d['seed_index'];assert index in range(913);localfiles[path.name]=d
        attemptstatus[d.get('status','UNKNOWN')]+=1;allattempts.append(path.name)
        if d['status']!='LOCAL_INFEASIBLE':
            replacement=f['closed'][str(index)];replacementdata=read(replacement['file'])
            assert replacement['file']!=path.name
            assert replacementdata.get('status')=='LOCAL_INFEASIBLE' or any(r.get('index')==index and r['status']=='INFEASIBLE' for r in replacementdata.get('records',[]))
            history.append(dict(index=index,prior_file=path.name,prior_status=d['status'],final_file=replacement['file'],final_status='LOCAL_INFEASIBLE'))
        for r in d['records']:
            if r['status'].startswith('EXHAUSTED'):
                assert r['status'] in ('EXHAUSTED_NO_COMPLETION','EXHAUSTED_R6_CONFLICT')
                assert r['core_blocks']==sorted(set(r['core_blocks'])) and r['extras']==sorted(r['extras'])
                allkeys.add(corekey(r));alloccurrences+=1
    assert attemptstatus==f['attempt_status_counts']
    assert len(allkeys)==f['unique_exhausted_local_cores']==2791
    assert chosenkeys<=allkeys

    independent=read('local_completions_independent_sets.json');indkeys=set();indrefs=set()
    for c in independent['cases']:
        name=c['file'];i=c['iteration'];assert name in localfiles
        d=localfiles[name];assert i in range(len(d['records']))
        r=d['records'][i];assert r['iteration']==i and r['status'].startswith('EXHAUSTED')
        assert c['status']=='EXHAUSTED_NO_R6ZERO_COMPLETION'
        ref=(name,i);assert ref not in indrefs;indrefs.add(ref)
        key=corekey(r);assert key not in indkeys;indkeys.add(key)
    assert len(indkeys)==independent['total']==2791 and indkeys==allkeys and chosenkeys<=indkeys
    assert independent['positive_control']['status']=='FOUND' and independent['positive_control']['recovered_blocks']==13

    # Earlier reduced CP timeouts are historical, not selected exclusions.
    reduced_unknown=[]
    for name in ('agent_seed_pair_reduced_0.json','agent_seed_pair_reduced_5.json'):
        for r in read(name)['records']:
            if r['status']=='UNKNOWN':
                chosen=f['closed'][str(r['index'])];assert chosen['file']!=name
                assert read(chosen['file'])['status']=='LOCAL_INFEASIBLE'
                reduced_unknown.append(dict(index=r['index'],prior_file=name,final_file=chosen['file']))

    dependencies={}
    orbit=read('agent_witness_orbit_independent.json')
    assert orbit['pair_seed_set_matches_exactly'] and orbit['triangle_seed_set_matches_exactly']
    assert orbit['pair_orbits']==913 and orbit['triangle_orbits']==248 and orbit['compatible_pairs']==32076
    assert orbit['pair_seeds_sha256']==sha('witness_pair_seeds.json') and orbit['triangle_seeds_sha256']==sha('agent_seed_triangles.json')
    dependencies['orbit_coverage']=dict(status='PASS_RECORDED_INDEPENDENT_ENUMERATION',pairs=32076,pair_orbits=913,triangle_orbits=248)
    tri=read('agent_seed_triangle_completion.json');tricp=read('agent_seed_triangle_cpcheck.json')
    assert len(tri['cases'])==248 and tri['counts']=={'EXHAUSTED_NO_COMPLETION':248}
    assert len(tricp['cases'])==248 and tricp['counts']=={'INFEASIBLE':248}
    assert set(r['case'] for r in tri['cases'])==set(range(248)) and set(r['case'] for r in tricp['cases'])==set(range(248))
    assert all(r['status']=='EXHAUSTED_NO_COMPLETION' for r in tri['cases']) and all(r['status']=='INFEASIBLE' for r in tricp['cases'])
    dependencies['block_base_at_most_two']=dict(status='PASS_LOG_COVERAGE',dlx_cases=248,independent_cp_cases=248)
    synergy=read('verify_two_rule_synergy.json');single=read('verify_single_rule_local.json')
    assert synergy['status']=='PASS' and len(synergy['cases'])==12 and not synergy['found_compatible_pair'] and all(r['compatible']==0 for r in synergy['cases'])
    assert single['status']=='PASS' and single['pair_checks']==441 and not single['found_compatible_pair']
    dependencies['extra_rule_lemmas']=dict(status='PASS_RECORDED_FINITE_RESULTS',single_pair_checks=441,useful_second_rules=12,logical_bridge='agent_pair_model_review.txt; shared-correct-rule fact is necessary for sn==1')
    split=read('agent_full_split_check.json');assert split['slots']==dict(total=210,contains8=18,**{'4567':6},old=186)
    assert split['long_cycle_support_windows']['6']['eligible_containing8']==0 and split['long_cycle_support_windows']['7']['eligible_containing8']==0 and split['long_cycle_support_windows']['8']['eligible']==0
    dependencies['old_new_split_and_long_cycles']=dict(status='PASS_RECORDED_FINITE_COUNTS',old_slots=186,new_slots=24,six_or_seven_with8_eligible=0,eight_eligible=0)
    manifest=read('WITNESS_FINAL_SHA256.json');manifestresults={name:sha(name)==expected for name,expected in manifest.items()};assert all(manifestresults.values())

    out=dict(status='PASS_AGGREGATION_AND_EVIDENCE_LINKAGE',scope=f['scope'],frontier_sha256=sha('WITNESS_FRONTIER.json'),seed_sha256=sha('witness_pair_seeds.json'),all_indices_present_exactly_once=True,closed=913,open=0,method_counts=dict(methodcounts),selected_core_occurrences=chosencount,selected_unique_cores=len(chosenkeys),all_exhausted_core_occurrences=alloccurrences,all_unique_exhausted_cores=len(allkeys),unique_core_keys_sha256=keydigest(allkeys),independent_audit_core_set_exactly_equal=True,independent_audit_nodes=sum(c['nodes'] for c in independent['cases']),independent_positive_control=independent['positive_control'],historical_local_attempt_statuses=dict(attemptstatus),historical_local_unknown_replacements=history,historical_reduced_unknown_replacements=reduced_unknown,proof_dependencies=dependencies,final_manifest_hash_checks=manifestresults,selected_sources=selected,limits=['This audit checks saved-file coverage, source linkage, statuses, canonical core deduplication, and dependency-log consistency. It does not rerun the local CP models or all completion searches.','General block/slot decomposition remains an inherited mathematical dependency.','LOCAL_INFEASIBLE is a CP-SAT solver result; no independently checkable formal UNSAT certificates are supplied.','The external Claude audit is pending; this audit is not that audit.','No conclusion for other support orientations, R5<=51, earlier deviations, arbitrary strategies, or global optimality.'],seconds=time.monotonic()-start)
    (H/'final913_external_audit_prep.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    lines=['FINAL 913 EXTERNAL AUDIT PREPARATION','2026-10-17','',out['status'],'','Checked saved files without running CP-SAT, DLX, or new construction searches.',f"Frontier: all 913 indices 0..912 exactly once; closed 913, open 0.",f"Selected methods: {dict(methodcounts)}",f"Selected completion records: {chosencount} occurrences, {len(chosenkeys)} distinct cores.",f"All historical exhausted records: {alloccurrences} occurrences, {len(allkeys)} distinct cores.",f"Independent set audit refers to real source records and covers exactly those 2791 distinct cores; {out['independent_audit_nodes']} nodes.",f"Historical local status counts: {dict(attemptstatus)}",'','The three historical LOCAL_UNKNOWN files were not selected as exclusions:']
    lines += [f"  seed {r['index']}: {r['prior_file']} -> {r['final_file']} (LOCAL_INFEASIBLE)" for r in history]
    lines += ['',f"Earlier reduced-CP UNKNOWN records: {len(reduced_unknown)}; each has a separate final LOCAL_INFEASIBLE source.",'','Proof-dependency evidence checked: exact independent 913/248 orbit-set matches;','248/248 DLX triangle exclusions and 248/248 independent CP exclusions;','441 canonical one-extra pair checks; all 12 useful-second-rule cases;','old/new split and no eligible long cycles containing 8; final manifest hashes.','','No coverage, status-upgrade, source-linkage, or distinct-core count discrepancy found.','','Limits:']
    lines += ['  '+s for s in out['limits']]
    lines += ['',f"Frontier SHA256: {out['frontier_sha256']}",f"Seed SHA256: {out['seed_sha256']}",f"Core-key-set SHA256: {out['unique_core_keys_sha256']}"]
    (H/'final913_external_audit_prep.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
    print(json.dumps({k:out[k] for k in ('status','closed','open','method_counts','selected_core_occurrences','selected_unique_cores','all_exhausted_core_occurrences','all_unique_exhausted_cores','independent_audit_nodes','historical_local_attempt_statuses','seconds')}),flush=True)

if __name__=='__main__':main()
