"""Run-ready full-star witness-first search; default action is static prep.

Do not pass --run until the coordinating agent has confirmed the requested
Desktop Claude audit gate. Without --run this file never calls solve().

Scope is the supplied fixed 18-block, three-seven witness core. An exhausted
result excludes target4 only with that core fixed, not every full-star table.
UNKNOWN is always unresolved and never authorizes a witness no-good.
"""
from pathlib import Path
from collections import Counter
from itertools import permutations,combinations
import argparse,json,time,traceback
from fullstar_prepare_model import build,cp_model
from fullstar_prepare_basic import H,WORDS,RULES,ROWS,correct,canon
from independent_audit import audit

def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2),encoding='utf-8')

def static_prepare():
    """Verify the known certificate and generator correspondence, no solving."""
    raw=json.loads((H/'inputs/baseline15051.rules.json').read_text())
    baseline={(a,*h,t) for a,h,t in raw['rules']}
    selected={b for b,rs in enumerate(RULES) if rs<=baseline}
    assert len(selected)==52 and len(baseline)==208
    assert set().union(*(RULES[b] for b in selected))==baseline
    used=[w for b in selected for w in ROWS[b]]
    assert len(used)==len(set(used))==208
    holes=set(WORDS)-set(used);assert len(holes)==2
    padding={tuple(w)+(8,) for w in holes}
    positive=baseline|padding;assert len(positive)==210
    prepared=json.loads((H/'fullstar_prepare_baseline.json').read_text())
    seed=set(prepared['mandatory_three_witness_union'])
    assert len(seed)==18 and seed<=selected
    actual=[sorted(RULES[b]) for b in sorted(seed)]
    assert actual==[[tuple(r) for r in block] for block in prepared['actual_mandatory_rules']]
    fixedrules=set().union(*(RULES[b] for b in seed))
    assert all(len(correct(tuple(c))&fixedrules)>=6 for c in prepared['rescued_sevens'])
    # A separate permutation generator reproduces the generic full-star block
    # set; it does not use the combinations generator in fullstar_prepare_basic.
    generic=set()
    for c in permutations(range(1,8),5):
        if c[0]!=min(c):continue
        rr=tuple((c[k],c[(k+1)%5],c[(k+2)%5],c[(k+3)%5],c[(k+4)%5]) for k in range(5))
        for omit in range(5):generic.add(frozenset(rr[:omit]+rr[omit+1:]))
    assert len(generic)==2520 and generic==set(RULES)
    R={k:0 for k in (5,6,7,8)}
    for k in (5,6,7):
        for s in combinations(range(1,8),k):
            for p in permutations(s[1:]):R[k]+=len(correct((s[0],)+p)&positive)>=k-1
    assert R=={5:52,6:0,7:3,8:0}
    model,bs,ss,zs,stats=build(seed,target=4,local=False)
    assert model.validate()==''
    out={'status':'STATIC_READY_NO_SOLVE_CALLED','scope':__doc__,'generic_regeneration_matches_all_2520_blocks':True,'baseline_rules_match_exactly_52_blocks':True,'baseline_rule_count':len(baseline),'known_positive_padded_rule_count':len(positive),'known_padding_rules':sorted(padding),'known_positive_static_window_counts':R,'mandatory_core_blocks':sorted(seed),'mandatory_core_count':len(seed),'known_positive_block_ids':sorted(selected),'baseline_three_cycles':prepared['rescued_sevens'],'model_stats':stats,'direct_40320_audit_run':False}
    return out,seed,selected,padding

def export_table(path,block_ids,extras,metadata):
    block_ids=set(block_ids);extras=set(extras)
    assert len(block_ids)==52 and len(extras)==2
    blockrules=set().union(*(RULES[b] for b in block_ids))
    used=[w for b in block_ids for w in ROWS[b]]
    assert len(used)==len(set(used))==208
    assert not set(used)&{canon(r[:4]) for r in extras}
    assert len({canon(r[:4]) for r in extras})==2
    full=blockrules|extras;assert len(full)==210
    save(path,{'n':8,'rules':[[r[0],list(r[1:4]),r[4]] for r in sorted(full)],'selected_block_ids':sorted(block_ids),'extra_rules':sorted(extras),'metadata':metadata})
    return full

def independent_check(path,minimum_wins):
    checked=audit(path)
    assert checked['placements']==40320
    assert checked['wins']>=minimum_wins and checked['lost_cf']==0
    assert checked['rescued_cycles']['5']==52 and checked['rescued_cycles']['6']==0
    if minimum_wins>=15052:assert checked['rescued_cycles']['7']>=4
    return checked

def positive_control(seed,selected,padding,prefix,deadline):
    m,bs,ss,zs,stats=build(seed,target=3,local=False)
    for b,v in bs.items():m.add(v==int(b in selected))
    for r,v in ss.items():m.add(v==int(r in padding))
    s=cp_model.CpSolver();s.parameters.num_search_workers=1
    s.parameters.max_time_in_seconds=max(.001,min(5,deadline-time.monotonic()))
    st=s.solve(m);out={'status':s.status_name(st),'seconds':s.wall_time}
    if st not in (cp_model.FEASIBLE,cp_model.OPTIMAL):return out
    path=H/f'{prefix}_positive_control.rules.json'
    export_table(path,selected,padding,{'kind':'known baseline, padded at its two unused slots'})
    checked=independent_check(path,15051)
    assert checked['wins']==15051 and checked['rescued_cycles']['7']==3
    out.update(certificate=str(path),direct_audit=checked)
    return out

def critical_core(seed,selected,extras):
    """Retain the fixed three witnesses and one new rescued seven-cycle."""
    base=set().union(*(RULES[b] for b in selected));full=base|extras
    fixed=set().union(*(RULES[b] for b in seed))
    new=[]
    for p in permutations(range(2,8)):
        c=(1,)+p;rr=correct(c)
        if len(rr&fixed)<6 and len(rr&full)>=6:new.append((c,rr))
    assert new
    # Fewer required external rules yields a smaller, stronger completion
    # obligation; all choices remain certificates of the same fourth rescue.
    possibilities=[]
    for c,rr in new:
        available=sorted(rr&full)
        for six in combinations(available,6):
            needed=set(six);external=needed-base
            suppliers={b for b in selected if RULES[b]&(needed-external)}
            core=set(seed)|suppliers
            possibilities.append((len(external),len(core),tuple(sorted(core)),tuple(sorted(external)),c))
    _,_,core,critical_extras,cycle=min(possibilities)
    core=set(core);critical_extras=set(critical_extras)
    assert critical_extras<=extras and len(core)<=24
    rules=set().union(*(RULES[b] for b in core))|critical_extras
    assert all(len(correct((s[0],)+p)&rules)<=4 for s in combinations(range(1,8),6) for p in permutations(s[1:]))
    assert sum(len(correct((1,)+p)&rules)>=6 for p in permutations(range(2,8)))>=4
    return core,critical_extras,cycle

def search(args):
    ready,seed,known,padding=static_prepare()
    start=time.monotonic();deadline=start+args.wall_seconds;prefix=args.output_prefix
    out={'scope':__doc__,'static_readiness':ready,'records':[],'status':'NOT_STARTED'}
    control=positive_control(seed,known,padding,prefix,deadline)
    out['positive_control']=control
    if control['status'] not in ('FEASIBLE','OPTIMAL'):
        out['status']='POSITIVE_CONTROL_'+control['status'];save(H/f'{prefix}_result.json',out);return out
    local,lb,ls,lz,lstats=build(seed,target=4,local=True)
    out['local_model_stats']=lstats
    status='WITNESS_LIMIT'
    for iteration in range(args.max_witnesses):
        remaining=deadline-time.monotonic()
        if remaining<=0:status='WALL_LIMIT';break
        solver=cp_model.CpSolver();solver.parameters.num_search_workers=1
        solver.parameters.random_seed=iteration+1
        solver.parameters.max_time_in_seconds=min(args.local_seconds,remaining)
        lst=solver.solve(local);lname=solver.status_name(lst)
        if lst not in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            status='EXHAUSTED_NO_TARGET4_WITH_FIXED_CORE' if lst==cp_model.INFEASIBLE else 'LOCAL_'+lname
            out['last_local_status']=lname;break
        selected=set(seed)|{b for b,v in lb.items() if solver.value(v)}
        extras={r for r,v in ls.items() if solver.value(v)}
        core,critical_extras,cycle=critical_core(seed,selected,extras)
        remaining=deadline-time.monotonic()
        if remaining<=0:status='WALL_LIMIT';break
        completion,cb,cs,cz,cstats=build(core,target=4,local=False)
        for r in critical_extras:
            assert r in cs;completion.add(cs[r]==1)
        finish=cp_model.CpSolver();finish.parameters.num_search_workers=1
        finish.parameters.random_seed=iteration+1
        finish.parameters.max_time_in_seconds=min(args.completion_seconds,remaining)
        cst=finish.solve(completion);cname=finish.status_name(cst)
        rec={'iteration':iteration,'local_status':lname,'local_seconds':solver.wall_time,'core_blocks':sorted(core),'critical_extra_rules':sorted(critical_extras),'fourth_cycle':cycle,'completion_status':cname,'completion_seconds':finish.wall_time,'completion_model_stats':cstats,'no_good_added':False}
        if cst in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            allblocks=core|{b for b,v in cb.items() if finish.value(v)}
            allextras={r for r,v in cs.items() if finish.value(v)}
            path=H/f'{prefix}_found_{iteration}.rules.json'
            export_table(path,allblocks,allextras,{'kind':'full-star target4 completion','iteration':iteration,'fixed_core':sorted(seed)})
            rec['certificate']=str(path)
            try:
                rec['direct_audit']=independent_check(path,15052);status='FOUND_INDEPENDENTLY_VERIFIED'
            except Exception:
                rec['audit_error']=traceback.format_exc();status='FAILED_INDEPENDENT_AUDIT'
            out['records'].append(rec);break
        if cst==cp_model.INFEASIBLE:
            literals=[lb[b].Not() for b in core-set(seed)]+[ls[r].Not() for r in critical_extras]
            assert literals
            local.add_bool_or(literals);rec['no_good_added']=True
        else:
            # The unresolved core stays pending. No no-good is added and the
            # run stops, so subsequent exhaustion cannot disguise this gap.
            status='COMPLETION_'+cname
            out['records'].append(rec);break
        out['records'].append(rec);out['status']='RUNNING';out['seconds']=time.monotonic()-start
        save(H/f'{prefix}_result.json',out)
        print(iteration,lname,cname,'core',len(core),'critical_extras',len(critical_extras),flush=True)
    out['status']=status;out['seconds']=time.monotonic()-start
    out['completion_counts']=dict(Counter(r['completion_status'] for r in out['records']))
    save(H/f'{prefix}_result.json',out)
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',action='store_true',help='Start solving only after the coordinating agent has confirmed the requested audit pass.')
    p.add_argument('--wall-seconds',type=float,default=120)
    p.add_argument('--local-seconds',type=float,default=3)
    p.add_argument('--completion-seconds',type=float,default=5)
    p.add_argument('--max-witnesses',type=int,default=1000)
    p.add_argument('--output-prefix',default='fullstar_ready_search')
    args=p.parse_args()
    if not args.run:
        ready,_,_,_=static_prepare();save(H/f'{args.output_prefix}_static.json',ready)
        print(ready['status'],ready['model_stats'],flush=True)
    else:
        out=search(args);print(out['status'],out.get('completion_counts',{}),out.get('seconds'),flush=True)
if __name__=='__main__':main()
