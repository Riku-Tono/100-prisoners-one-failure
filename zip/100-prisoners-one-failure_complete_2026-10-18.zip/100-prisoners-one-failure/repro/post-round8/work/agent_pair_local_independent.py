"""Independent static regeneration + bitset exact cover audits local cores.

No search or model code is imported. For each finite nogood certificate,
all 46-block completions respecting its two singleton rules and R6=0 are
searched. This validates the completion exclusions, not CP-SAT UNSAT logs.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict,Counter
import json,time,hashlib,sys
H=Path(__file__).parent

def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def rules(c):
    n=len(c)
    return frozenset((c[j],c[(j+1)%n],c[(j+2)%n],c[(j+3)%n],c[(j-1)%n]) for j in range(n))
def cycles(k):
    for s in combinations(range(1,8),k):
        for p in permutations(s[1:]):yield (s[0],)+p

forbid={frozenset(x) for x in ((1,2,3,4),(1,2,3,5),(1,2,3,6),(4,5,6,7))}
words=sorted(c for c in cycles(4) if frozenset(c) not in forbid);wordindex={w:i for i,w in enumerate(words)}
blocks=set()
for c in cycles(5):
    rr=rules(c)
    for omitted in rr:
        b=rr-{omitted}
        if all(canon(r[:4]) in wordindex for r in b):blocks.add(b)
blocks=sorted(blocks,key=lambda b:tuple(sorted(b)))
assert len(words)==186 and len(blocks)==1584
rows=[sum(1<<wordindex[canon(r[:4])] for r in b) for b in blocks]
columns=[0]*186
for b,row in enumerate(rows):
    for j in range(186):
        if row>>j&1:columns[j]|=1<<b
conflict=[0]*1584
for b,row in enumerate(rows):
    for j in range(186):
        if row>>j&1:conflict[b]|=columns[j]
six=[rules(c) for c in cycles(6)];inc=defaultdict(list)
for i,rr in enumerate(six):
    for r in rr:inc[r].append(i)
delta=[Counter(i for r in b for i in inc[r]) for b in blocks]

class Checker:
    def run(self,mandatory,extras):
        self.nodes=0;self.counts=[0]*len(six)
        left=(1<<186)-1;avail=(1<<1584)-1
        for b in mandatory:
            assert left&rows[b]==rows[b]
            left^=rows[b];avail&=~conflict[b]
            for i,d in delta[b].items():self.counts[i]+=d
        holes={canon(r[:4]) for r in extras};assert len(holes)==2
        for h in holes:
            j=wordindex[h];assert left>>j&1;left^=1<<j;avail&=~columns[j]
        for r in extras:
            for i in inc[r]:self.counts[i]+=1
        assert max(self.counts)<=4
        return self.search(left,avail)
    def search(self,left,avail):
        self.nodes+=1
        if not left:return True
        filtered=avail
        while filtered:
            bit=filtered&-filtered;filtered^=bit;b=bit.bit_length()-1
            if any(self.counts[i]+d>=5 for i,d in delta[b].items()):avail^=bit
        scan=left;small=100000;options=0
        while scan:
            bit=scan&-scan;scan^=bit;j=bit.bit_length()-1
            bs=columns[j]&avail;n=bs.bit_count()
            if not n:return False
            if n<small:small=n;options=bs
        while options:
            bit=options&-options;options^=bit;b=bit.bit_length()-1
            for i,d in delta[b].items():self.counts[i]+=d
            found=self.search(left^rows[b],avail&~conflict[b])
            for i,d in delta[b].items():self.counts[i]-=d
            if found:return True
        return False

def main():
    prefix=sys.argv[1] if len(sys.argv)>1 else 'agent_pair_local_batch'
    raw=(H/f'{prefix}_summary.json').read_bytes();data=json.loads(raw)
    t0=time.monotonic();out=dict(method=__doc__,input_sha256=hashlib.sha256(raw).hexdigest(),seeds=len(data['records']),records=[])
    checker=Checker()
    controlraw=(H/'r6zero_base.rules.json').read_bytes();control=json.loads(controlraw)
    crules={(a,*h,t) for a,h,t in control['rules']}
    chosen={b for b,rr in enumerate(blocks) if rr<=crules};assert len(chosen)==46
    used={canon(r[:4]) for b in chosen for r in blocks[b]}
    extras={w+(8,) for w in set(words)-used};assert len(extras)==2
    found=checker.run(set(sorted(chosen)[:33]),extras);assert found
    out['positive_control']=dict(status='FOUND',retained_blocks=33,recovered_blocks=13,nodes=checker.nodes,certificate_sha256=hashlib.sha256(controlraw).hexdigest())
    for seed in data['records']:
        for rec in seed['records']:
            assert rec['status']=='EXHAUSTED_NO_COMPLETION'
            found=checker.run(set(rec['core_blocks']),set(map(tuple,rec['extras'])))
            assert not found
            out['records'].append(dict(seed_index=seed['seed_index'],iteration=rec['iteration'],status='EXHAUSTED_NO_COMPLETION',nodes=checker.nodes))
    out['cores']=len(out['records']);out['nodes']=sum(r['nodes'] for r in out['records']);out['seconds']=time.monotonic()-t0
    (H/f'{prefix}_independent.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(out['seeds'],out['cores'],out['nodes'],out['seconds'],flush=True)

if __name__=='__main__':main()
