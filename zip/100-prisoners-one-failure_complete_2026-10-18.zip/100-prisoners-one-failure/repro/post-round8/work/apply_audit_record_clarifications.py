"""Preserve the audited input, then clarify the three Desktop Claude notes."""
from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent
report=H/'WITNESS_COMPLETION_FINAL_2026-10-17.txt'
manifest=H/'WITNESS_FINAL_SHA256.json'
before=report.read_bytes()
snap=H/'audit_input_snapshot_20261018'
snap.mkdir(exist_ok=True)
for p in (report,manifest):
    dest=snap/p.name
    if dest.exists():assert dest.read_bytes()==p.read_bytes()
    else:dest.write_bytes(p.read_bytes())
frontier=json.loads((H/'WITNESS_FRONTIER.json').read_text(encoding='utf-8-sig'))
indices=sorted(int(k) for k,v in frontier['closed'].items() if v['method']=='reduced CP-SAT')
assert indices==[0,4,5,6,7,8,9,12,13,14,15,17,18,19,21,22,23,25,27,29,32,33,34]
text=before.decode('utf-8-sig')
old='全913seedを終了。先頭の23seedは縮約CPによるINFEASIBLE。'
assert old in text
text=text.replace(old,'全913seedを終了。23seed（番号 '+','.join(map(str,indices))+'）は縮約CPによるINFEASIBLE。')
text=text.replace('異なる7巡回は正解規則を2本共有できない。全720巡回','[7]上の異なる7巡回は正解規則を2本共有できない。全720巡回')
text=text.replace('2791個の異なる補完排除coreを、','2791個の補完排除core（ブロック番号と追加規則の生の集合で区別、G36では2778軌道）を、')
text+='\n2026-10-18の監査追記\nClaudeデスクトップの独立監査はAUDIT_PASS。三角形248代表、witness対913代表、\n独自に列挙した複合core2938件をすべて補完不能・未決0で再確認した。\n上の23seedの表記、2791と対称軌道数の区別、共有規則補題の[7]への限定を明記した。\n監査時点の原文とSHA256一覧はaudit_input_snapshot_20261018に保存。\nその後に受領したChatGPTの208規則構成は、別実装40320配置で15050勝、\nR=(52,0,2,0)、CF損失0を確認。従ってこの支持族のR6=0の達成下界は15050。\n最新の監査と別向き探索の状況はCONTINUATION3_STATUS_2026-10-18.txtを参照。\n'
report.write_text(text,encoding='utf-8-sig')
m=json.loads(manifest.read_text(encoding='utf-8-sig'))
assert m[report.name]==hashlib.sha256(before).hexdigest()
m[report.name]=hashlib.sha256(report.read_bytes()).hexdigest()
manifest.write_text(json.dumps(m,indent=2),encoding='utf-8')
record=dict(date='2026-10-18',audit_status='AUDIT_PASS',audited_input_snapshot=str(snap),before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=m[report.name],reduced_CP_seed_indices=indices,changes=['Correct first23 wording to actual23 indices','Distinguish2791 raw cores from2778 G36orbits','Restrict shared-rule lemma to[7] seven-cycles','Append external audit and independently verified15050 lower bound'])
(H/'audit_record_clarifications_20261018.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2))
