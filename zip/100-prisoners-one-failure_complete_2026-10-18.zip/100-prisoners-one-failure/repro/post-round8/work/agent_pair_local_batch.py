"""Bounded disjoint batch of local four-seven witnesses + R6-zero DLX.

Only exhaustive DLX failures allow no-goods. Any CP/DLX timeout leaves
the seed unresolved. Imports the proposed method; this is a batch runner,
not an independent proof implementation.
"""
from agent_seed_local_completion import *
from independent_audit import audit
import hashlib

PREFIX='agent_pair_local_batch'

def run_seed(index,seed,global_deadline):
    t0=time.monotonic();m,bs,ss,stats=build(seed,True)
    solver=cp_model.CpSolver();solver.parameters.num_search_workers=1
    solver.parameters.random_seed=index+1
    matrix=NoSixDLX();records=[];status='WITNESS_LIMIT'
    for iteration in range(500):
        remaining=global_deadline-time.monotonic()
        if remaining<=0:status='WALL_LIMIT';break
        solver.parameters.max_time_in_seconds=min(2,remaining)
        st=solver.solve(m)
        if st not in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            status='LOCAL_'+solver.status_name(st);break
        selected=set(seed['blocks'])|{b for b,v in bs.items() if solver.value(v)}
        extras={r for r,v in ss.items() if solver.value(v)}
        supplied=set().union(*(RULES[b] for b in selected))
        newcycles=[rr for rr in CW[7] if sum(r in supplied for r in rr)<=5 and sum(r in supplied|extras for r in rr)>=6]
        assert len(extras)==2 and len(newcycles)==2
        required={r for rr in newcycles for r in rr if r in supplied}
        core=set(seed['blocks'])|{b for b in selected if RULES[b]&required}
        crules=set().union(*(RULES[b] for b in core))
        R=Counter(k for k in (6,7) for rr in CW[k] if sum(r in crules|extras for r in rr)>=k-1)
        assert R[6]==0 and R[7]>=4
        remaining=global_deadline-time.monotonic()
        if remaining<=0:status='WALL_LIMIT';break
        dlx_status,nodes,additional=matrix.run_nosix(core,extras,min(1,remaining))
        rec=dict(iteration=iteration,local_cp_seconds=solver.wall_time,status=dlx_status,nodes=nodes,core_blocks=sorted(core),extras=sorted(extras))
        records.append(rec)
        if dlx_status=='FOUND':
            allblocks=core|set(additional);assert len(allblocks)==46
            raw=json.loads((H/'inputs/new15051.rules.json').read_text())
            groups=defaultdict(set)
            for a,h,t in raw['rules']:
                r=(a,*h,t);groups[rotate_min((t,)+r[:4])].add(r)
            new=set().union(*(g for g in groups.values() if len(g)==4 and any(8 in r for r in g)))
            full=new|set().union(*(RULES[b] for b in allblocks))|extras
            assert len(new)==24 and len(full)==210
            path=H/f'{PREFIX}_found_{index}.rules.json'
            path.write_text(json.dumps(dict(n=8,rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(full)]),indent=2),encoding='utf-8')
            checked=audit(path)
            assert checked['wins']>=15052 and checked['lost_cf']==0 and checked['rescued_cycles']['6']==0 and checked['rescued_cycles']['7']>=4
            rec.update(certificate=str(path),direct_audit=checked);status='FOUND';break
        if dlx_status=='UNKNOWN':status='COMPLETION_UNKNOWN';break
        assert dlx_status.startswith('EXHAUSTED')
        m.add_bool_or([bs[b].Not() for b in core-set(seed['blocks'])]+[ss[r].Not() for r in extras])
    out=dict(seed_index=index,stats=stats,records=records,completion_counts=dict(Counter(r['status'] for r in records)),seconds=time.monotonic()-t0,status=status)
    (H/f'{PREFIX}_{index}.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    return out

def main():
    global PREFIX
    start=int(sys.argv[1]) if len(sys.argv)>1 else 35
    count=int(sys.argv[2]) if len(sys.argv)>2 else 100
    wall=float(sys.argv[3]) if len(sys.argv)>3 else 120
    if len(sys.argv)>4:PREFIX=sys.argv[4]
    raw=(H/'witness_pair_seeds.json').read_bytes();seeds=json.loads(raw)['seeds']
    t0=time.monotonic();deadline=t0+wall
    out=dict(scope=__doc__,seed_start=start,requested_count=count,input_sha256=hashlib.sha256(raw).hexdigest(),records=[])
    for index in range(start,min(start+count,len(seeds))):
        if time.monotonic()>=deadline:break
        result=run_seed(index,seeds[index],deadline)
        out['records'].append(result);out['counts']=dict(Counter(r['status'] for r in out['records']));out['seconds']=time.monotonic()-t0;out['not_run']=count-len(out['records'])
        (H/f'{PREFIX}_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        print(index,result['status'],result['completion_counts'],round(result['seconds'],3),'total',round(out['seconds'],3),flush=True)
        if result['status']=='FOUND':break
    print('FINAL',out['counts'],out['seconds'],out['not_run'],flush=True)

if __name__=='__main__':main()
