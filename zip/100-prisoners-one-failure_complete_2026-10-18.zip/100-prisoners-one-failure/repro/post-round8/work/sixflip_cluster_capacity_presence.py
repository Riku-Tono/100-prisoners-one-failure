"""Rule-presence necessary filters after the support-capacity allocations.
No CP solver, rule packing, witness completion, R6 feasibility, or target4 search.
"""
from pathlib import Path
from collections import Counter
import json,time,sys,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));import general_orientation_model as G
raw=(H/'sixflip_cluster_capacity_summary.json').read_bytes();cap=json.loads(raw);records=[];start=time.monotonic()
def pattern_key(new,old):return(frozenset(map(frozenset,new)),frozenset(map(frozenset,old)))
for spec in cap['records']:
 if not spec['allocations']:continue
 data=G.orientation_data(spec['flips']);pmap={pattern_key(p['new_supports'],p['old_supports']):i for i,p in enumerate(spec['patterns'])};branch_records=[];union_best={}
 for branch,alloc in enumerate(spec['allocations']):
  used={frozenset(r['support']):r['words']for r in alloc['support_word_usage']};fullold={frozenset(s)for s in alloc['fully_consumed_old_supports']};allowedblocks=[]
  for b in data.blocks:
   ns={frozenset(r[:4])for r in b if 8 in r[:4]};olds={frozenset(r[:4])for r in b if 8 not in r[:4]}
   if ns:
    pi=pmap[(frozenset(ns),frozenset(olds))]
    if alloc['pattern_block_counts'][pi]==0:continue
   elif olds&fullold:continue
   allowedblocks.append(b)
  blockrules=set().union(*allowedblocks)
  single_supp={s for s in data.active_supports if (8 in s and used.get(s,0)<6)or(8 not in s and alloc['old_word_holes_after52blocks']>0 and s not in fullold)}
  singles={r for r in data.singles if frozenset(r[:4])in single_supp};present=blockrules|singles;hist=Counter();bc=Counter();ec=Counter();seven=[]
  for c,rr in G.cycle_data(7):
   n=sum(r in present for r in rr)
   if n<6:continue
   bn=sum(r in blockrules for r in rr);extra=max(0,6-bn);hist[(8 in c,extra)]+=1
   if extra<=2:
    ec[8 in c]+=1;seven.append(c);union_best[c]=min(extra,union_best.get(c,99))
   if extra==0:bc[8 in c]+=1
  branch_records.append({'capacity_branch':branch,'pattern_block_counts':alloc['pattern_block_counts'],'new_blocks':alloc['new_blocks'],'old_blocks':alloc['remaining_old_blocks'],'new_holes':alloc['new_word_holes'],'old_holes':alloc['old_word_holes_after52blocks'],'possible_rule_blocks':len(allowedblocks),'permitted_single_supports':sorted(map(sorted,single_supp)),'possible_single_rules':len(singles),'possible_present_rules':len(present),'minimum_extras_histogram':[{'contains8':has8,'extras_at_least':e,'cycles':n}for(has8,e),n in sorted(hist.items())],'within_two_extras_total':sum(ec.values()),'within_two_extras_containing8':ec[True],'block_only_total':sum(bc.values()),'block_only_containing8':bc[True]})
 records.append({'orbit_index':spec['orbit_index'],'flips':spec['flips'],'branches':branch_records,'union_within_two_extras_total':len(union_best),'union_within_two_extras_containing8':sum(8 in c for c in union_best),'union_block_only_total':sum(e==0 for e in union_best.values()),'union_block_only_containing8':sum(e==0 and 8 in c for c,e in union_best.items())})
 print(spec['orbit_index'],'branches',len(branch_records),'union<=2',len(union_best),'with8',sum(8 in c for c in union_best),'blockonly',sum(e==0 for e in union_best.values()),flush=True)
out={'method':__doc__,'capacity_summary_sha256':hashlib.sha256(raw).hexdigest(),'records':records,'scope':'Necessary per-rule availability only; doesnot certify mutually compatible witnesses or a completed strategy. Capacity branches are necessary integer distributions.','solver_calls':0,'actual_rule_packing_search_performed':False,'seconds':time.monotonic()-start}
(H/'sixflip_cluster_capacity_presence.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
