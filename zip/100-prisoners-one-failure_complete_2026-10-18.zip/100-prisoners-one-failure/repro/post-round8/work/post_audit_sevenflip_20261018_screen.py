"""Seven-flip necessary screen by cluster unions, with independent brutecheck.
No strategy solver runs in thisscreen. Genericfull8search is a separatestep.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import Counter
import json,time,hashlib
Hdir=Path(__file__).resolve().parent;start=time.monotonic();L7=frozenset(range(1,8));L8=frozenset(range(1,9));T=list(map(frozenset,combinations(range(1,8),3)));ti={t:i for i,t in enumerate(T)};U4=list(map(frozenset,combinations(range(1,8),4)));progress=Hdir/'post_audit_sevenflip_20261018_screen_progress.json'
def note(phase,**kw):progress.write_text(json.dumps({'phase':phase,'seconds':time.monotonic()-start,**kw},indent=2),encoding='utf-8')
def sethash(masks):return hashlib.sha256((''.join(f'{m:09x}\n'for m in sorted(masks))).encode('ascii')).hexdigest()
patterns=[];clusters=[]
for U in U4:
 ix=[ti[t]for t in T if t<U];cm=sum(1<<i for i in ix);clusters.append(cm)
 patterns.extend(sum(1<<i for i in p)for p in combinations(ix,3));patterns.append(cm)
assert len(patterns)==175 and len(set(patterns))==175
accepted6=set();accepted7=set();note('UNION_GENERATION')
for a,b in combinations(patterns,2):
 u=a|b;k=u.bit_count()
 if k==6:accepted6.add(u)
 elif k==7:accepted7.add(u)
for a,b,c in combinations(patterns,3):
 u=a|b|c;k=u.bit_count()
 if k==6:accepted6.add(u)
 elif k==7:accepted7.add(u)
assert len(accepted6)==8995
before_extension=len(accepted7)
for a in accepted6:
 for p in patterns:
  u=a|p
  if u.bit_count()==7:accepted7.add(u)
assert all(sum(1 for i in range(35)if m>>i&1)==7 for m in accepted7)
for m in accepted7:
 covered=0
 for cm in clusters:
  x=m&cm
  if x.bit_count()>=3:covered|=x
 assert covered==m
note('ORBIT_EXPANSION',accepted_masks=len(accepted7));perm_maps=[]
for p in permutations(range(1,8)):
 perm_maps.append(tuple(1<<ti[frozenset(p[x-1]for x in t)]for t in T))
seen=set();representatives=[]
for m in sorted(accepted7):
 if m in seen:continue
 combo=tuple(i for i in range(35)if m>>i&1);orb={sum(mp[i]for i in combo)for mp in perm_maps};assert orb<=accepted7 and not orb&seen;seen|=orb
 representatives.append({'canonical_mask_hex':f'{m:09x}','combo':combo,'S7_orbit_size':len(orb)})
assert seen==accepted7
# Actual cyclicfour-word ruleblocks, regeneratedonall8labels once.
ALL4=list(map(frozenset,combinations(range(1,9),4)));sindex={s:i for i,s in enumerate(ALL4)}
def norm(w):
 w=tuple(w);j=w.index(min(w));return w[j:]+w[:j]
def cycles(k):
 for sub in combinations(range(1,9),k):
  for p in permutations(sub[1:]):yield(sub[0],)+p
W=list(cycles(4));wi={w:i for i,w in enumerate(W)};new_word_mask=sum(1<<i for i,w in enumerate(W)if 8 in w);vectors=[];rule_check=set()
for c in cycles(5):
 rs=tuple((c[j],c[(j+1)%5],c[(j+2)%5],c[(j+3)%5],c[(j+4)%5])for j in range(5))
 for omit in range(5):
  b=frozenset(rs[:omit]+rs[omit+1:]);rule_check.add(b);sm=sum(1<<sindex[frozenset(r[:4])]for r in b);wm=sum(1<<wi[norm(r[:4])]for r in b);vectors.append((sm,wm,(wm&new_word_mask).bit_count()))
assert len(vectors)==len(rule_check)==6720
cycle_supports={}
for k in (6,7,8):
 rows=[]
 for c in cycles(k):
  sm=sum(1<<sindex[frozenset(c[(j+i)%k]for i in range(4))]for j in range(k));assert sm.bit_count()==k;rows.append((8 in c,sm))
 cycle_supports[k]=rows
records=[];base=set(map(frozenset,combinations(range(1,8),4)));note('CAPACITY_SCREEN',accepted_masks=len(accepted7),orbits=len(representatives))
for index,rep in enumerate(representatives):
 ts={T[i]for i in rep['combo']};flips={L7-t for t in ts};S=base-flips|{t|{8}for t in ts};sm=sum(1<<sindex[s]for s in S);usable=0;bn=Counter()
 for needed,wm,nnew in vectors:
  if needed&sm==needed:usable|=wm;bn[nnew]+=1
 long={}
 for k,rows in cycle_supports.items():
  hist=Counter(has8 for has8,cs in rows if(cs&sm).bit_count()>=k-1);long[k]={'eligible_total':sum(hist.values()),'eligible_containing8':hist[True],'eligible_without8':hist[False]}
 rec={'index':index,'canonical_mask_hex':rep['canonical_mask_hex'],'new_complement_triples':sorted(map(sorted,ts)),'flips':sorted(map(sorted,flips)),'S7_orbit_size':rep['S7_orbit_size'],'S7_stabilizer_order':5040//rep['S7_orbit_size'],'actual_rule_blocks':sum(bn.values()),'block_types':[{'new_word_slots':n,'blocks':c}for n,c in sorted(bn.items())],'usable_word_slots':usable.bit_count(),'usable_old_word_slots':(usable&~new_word_mask).bit_count(),'usable_new_word_slots':(usable&new_word_mask).bit_count(),'R5_word_capacity_upperbound':usable.bit_count()//4,'passes_52_word_capacity':usable.bit_count()>=208,'long_cycle_support_eligibility':long,'new_triple_union_size':len(set().union(*ts)),'cluster_count':sum((int(rep['canonical_mask_hex'],16)&cm).bit_count()>=3 for cm in clusters)}
 records.append(rec)
viable=[r for r in records if r['passes_52_word_capacity']];priority=sorted(viable,key=lambda r:(-r['actual_rule_blocks'],-r['long_cycle_support_eligibility'][7]['eligible_total'],-r['long_cycle_support_eligibility'][7]['eligible_containing8']))
for rank,r in enumerate(priority,1):r['preparation_priority']=rank
out={'method':__doc__,'all_labelled_seven_flips':6724520,'accepted_six_masks_used':len(accepted6),'accepted_seven_from_pair_or_triple_before_extension':before_extension,'accepted_seven_masks':len(accepted7),'accepted_set_sha256':sethash(accepted7),'accepted_hash_encoding':'ascending35bitmasks,9lowercasehexplusLF,tripleslexcombinations([7],3)','S7_orbit_count':len(records),'orbits':records,'capacity_eligible_orbits':len(viable),'priority_orbit_indices':[r['index']for r in priority],'phase':'BRUTE_CHECK_PENDING','alternative_enumeration_complete':True,'completeness_argument':'UsemaximalclustersHintersectD_Uofsize3or4. DistinctUclustersshareatmostoneedge. IfapairortriplecoversH7,itisenumerateddirectly. Otherwisenoclusterhas4edges(4+3coversatleast6andathirdcoversthe7th),andnopairhasunion6. Thusallclustershave3edgesandpairwiseintersect1. Any3clustershaveunion6unlessalreadycover7. Addaclustercoveringthe7thedgetothisaccepted6uniontogetH7. Converselyanyenumerated7-edgeclusterunionisclustercovered.','scope':'Necessarysevenflipclusterand52blockwordcapacityonly. A pass isnotafeasible52packingor15052construction. No sixflipauxiliarysplitassumptionsused.','solver_calls':0,'seconds':time.monotonic()-start}
result=Hdir/'post_audit_sevenflip_20261018_screen.json';result.write_text(json.dumps(out,indent=2),encoding='utf-8');note('BRUTE_CHECK',accepted_masks=len(accepted7),orbits=len(records),capacity_eligible_orbits=len(viable));print('PHASE1',len(accepted7),len(records),len(viable),out['seconds'],flush=True)
# Independent allcombination check: testthefourneighbourfour-sets ofeachedge.
neighbours=[[cm for U,cm in zip(U4,clusters)if t<U]for t in T];assert all(len(x)==4 for x in neighbours);bits=[1<<i for i in range(35)]
def brute_check(deadline):
 accepted=set();tested=0;complete=True
 for combo in combinations(range(35),7):
  m=sum(bits[i]for i in combo);valid=True
  for i in combo:
   a,b,c,d=neighbours[i]
   if(m&a).bit_count()<3 and(m&b).bit_count()<3 and(m&c).bit_count()<3 and(m&d).bit_count()<3:valid=False;break
  if valid:accepted.add(m)
  tested+=1
  if tested%100000==0:
   note('BRUTE_CHECK',tested=tested,accepted_sofar=len(accepted),capacity_eligible_orbits=len(viable))
   if time.monotonic()>deadline:complete=False;break
 return accepted,tested,complete
bt=time.monotonic();brute,tested,complete=brute_check(bt+55);out.update(brute_tested=tested,brute_complete=complete,brute_not_tested=6724520-tested,brute_seconds=time.monotonic()-bt,brute_accepted_sofar=len(brute))
if complete:assert brute==accepted7;out['brute_accepted_set_sha256']=sethash(brute);out['independent_sets_match']=True
else:out['independent_sets_match']=None
out['phase']='SCREEN_COMPLETE'if complete else'ALTERNATIVE_COMPLETE_BRUTE_PARTIAL';out['seconds']=time.monotonic()-start;result.write_text(json.dumps(out,indent=2),encoding='utf-8');note(out['phase'],tested=tested,accepted_masks=len(accepted7),orbits=len(records),capacity_eligible_orbits=len(viable));print('FINAL',out['phase'],tested,len(brute),out['seconds'],flush=True)
