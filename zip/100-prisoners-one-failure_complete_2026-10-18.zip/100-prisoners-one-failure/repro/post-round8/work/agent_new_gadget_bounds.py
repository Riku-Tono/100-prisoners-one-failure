"""Enumerate all 12 new-side covers and bound long cycles containing 8.

Old 186 slots are allowed arbitrary correct rules, an over-approximation.
Each 6/7/8-cycle containing 8 still has too few possible correct windows.
"""
from completion_dlx_recheck import correct,rotate_min,WORDS
from itertools import permutations,combinations
from pathlib import Path
from collections import defaultdict,Counter
import json
H=Path(__file__).resolve().parent
supports={frozenset(s) for s in ((4,5,6,7),(4,5,7,8),(4,6,7,8),(5,6,7,8))}
words={rotate_min(p) for s in supports for p in permutations(s)}
blocks=set()
for tail in permutations((5,6,7,8)):
    rr=correct((4,)+tail)
    for i in range(5):
        b=frozenset(rr[:i]+rr[i+1:])
        if all(rotate_min(r[:4]) in words for r in b):blocks.add(b)
blocks=sorted(blocks,key=lambda b:tuple(sorted(b)))
rows=[{rotate_min(r[:4]) for r in b} for b in blocks];inc=defaultdict(set)
for b,row in enumerate(rows):
    for w in row:inc[w].add(b)
covers=[]
def dfs(rem,chosen):
    if not rem:covers.append(chosen);return
    options=[(len(bs),w,bs) for w in rem for bs in [[b for b in inc[w] if rows[b]<=rem]]]
    _,w,bs=min(options)
    for b in bs:dfs(rem-rows[b],chosen+[b])
dfs(words,[])
assert len(words)==24 and len(blocks)==24 and len(covers)==12
old=set(WORDS);data={k:[correct((s[0],)+p) for s in combinations(range(1,9),k) if 8 in s for p in permutations(s[1:])] for k in (6,7,8)}
records=[]
for i,cover in enumerate(covers):
    new=set().union(*(blocks[b] for b in cover));assert len(new)==24
    hist={k:Counter(sum(rotate_min(r[:4]) in old or r in new for r in rr) for rr in cc) for k,cc in data.items()}
    records.append({'cover':i,'blocks':cover,'max_possible_correct':{k:max(h) for k,h in hist.items()},'histograms':{k:dict(h) for k,h in hist.items()}})
    assert all(max(h)<k-1 for k,h in hist.items())
out={'status':'EXHAUSTED_ALL_COVERS_AND_CYCLES','scope':__doc__,'slots':len(words),'blocks':len(blocks),'covers':len(covers),'cycle_counts':{k:len(v) for k,v in data.items()},'records':records}
(H/'agent_new_gadget_bounds.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(out['status'],out['cycle_counts'],[r['max_possible_correct'] for r in records],flush=True)
