"""Fresh enumeration of5-block+one-extra witnesses and compound seeds.

No research model/solver module is imported. Existing913 base representatives
are used as input data; their full orbit coverage has a separate audit.
This script changes only chatgpt_compound_audit_* files.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict,Counter
import json,time,hashlib
H=Path(__file__).resolve().parent

def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def correct(c):
    n=len(c)
    return frozenset((c[j],c[(j+1)%n],c[(j+2)%n],c[(j+3)%n],c[(j-1)%n]) for j in range(n))
def cycles(k):
    for s in combinations(range(1,8),k):
        for p in permutations(s[1:]):yield (s[0],)+p
def bitids(mask):
    result=[]
    while mask:
        bit=mask&-mask;mask^=bit;result.append(bit.bit_length()-1)
    return result
def encodekeys(keys):
    return hashlib.sha256(json.dumps(sorted(keys),separators=(',',':')).encode()).hexdigest()

def main():
    start=time.monotonic();forbidden={frozenset(s) for s in ((1,2,3,4),(1,2,3,5),(1,2,3,6),(4,5,6,7))}
    words=tuple(c for c in cycles(4) if frozenset(c) not in forbidden);wi={w:i for i,w in enumerate(words)}
    blocks=set()
    for c in cycles(5):
        rr=correct(c)
        for omitted in rr:
            b=rr-{omitted}
            if all(canon(r[:4]) in wi for r in b):blocks.add(b)
    blocks=tuple(sorted(blocks,key=lambda b:tuple(sorted(b))));assert len(words)==186 and len(blocks)==1584
    rowmasks=[sum(1<<wi[canon(r[:4])] for r in b) for b in blocks]
    inc=defaultdict(list)
    for b,rr in enumerate(blocks):
        for r in rr:inc[r].append(b)
    sevens=[(c,correct(c)) for c in cycles(7)]
    local=[];globalkeys=set()
    for c,rr in sevens:
        assert all(sum(r in b for r in rr)<=1 for b in blocks)
        for extra in sorted(rr):
            if canon(extra[:4]) not in wi:continue
            slot=1<<wi[canon(extra[:4])]
            for ignored in sorted(rr-{extra}):
                needed=rr-{extra,ignored}
                choices=sorted(([b for b in inc[r] if not rowmasks[b]&slot] for r in needed),key=len)
                if any(not opts for opts in choices):continue
                def visit(j,occupied,chosen):
                    if j==len(choices):
                        selected=tuple(sorted(chosen));key=(c,extra,selected)
                        if key in globalkeys:return
                        globalkeys.add(key);bm=sum(1<<b for b in selected);wm=occupied^slot
                        local.append(dict(cycle=c,extra=extra,blocks=selected,blockmask=bm,wordmask=wm,extraslot=slot))
                        return
                    for b in choices[j]:
                        if not rowmasks[b]&occupied:visit(j+1,occupied|rowmasks[b],chosen+[b])
                visit(0,slot,[])
    local.sort(key=lambda w:(w['cycle'],w['extra'],w['blocks']))
    print('GLOBAL',len(local),'seconds',round(time.monotonic()-start,3),flush=True)
    (H/'chatgpt_compound_audit_global_witnesses.json').write_text(json.dumps(dict(count=len(local),witnesses=[{k:v for k,v in w.items() if k not in ('blockmask','wordmask','extraslot')} for w in local]),indent=2),encoding='utf-8')

    seedraw=(H/'witness_pair_seeds.json').read_bytes();bases=json.loads(seedraw)['seeds'];assert len(bases)==913
    compatible_total=0;compatible_before_new_only=0;pair_occurrences=0;compoundkeys=set();perbase=[];coreprovenance=defaultdict(list)
    for index,base in enumerate(bases):
        bs=set(base['blocks']);bm=sum(1<<b for b in bs);wm=sum(rowmasks[b] for b in bs);assert wm.bit_count()==4*len(bs)==48
        supplied=set().union(*(blocks[b] for b in bs));basecycles={c for c,rr in sevens if len(rr&supplied)>=6};assert len(basecycles)==2
        compatible=[];before_new=0
        for localid,w in enumerate(local):
            if wm&w['extraslot']:continue
            overlap=wm&w['wordmask']
            if overlap:
                common=bm&w['blockmask']
                if not common:continue
                shared=0
                for b in bitids(common):shared|=rowmasks[b]
                if overlap!=shared:continue
            before_new+=1
            if w['cycle'] not in basecycles:compatible.append(localid)
        compatible_before_new_only+=before_new;compatible_total+=len(compatible)
        basekeys=set();pairs=0
        for a,b in combinations(compatible,2):
            x=local[a];y=local[b]
            if x['cycle']==y['cycle'] or x['extraslot']==y['extraslot']:continue
            if x['extraslot']&y['wordmask'] or y['extraslot']&x['wordmask']:continue
            overlap=x['wordmask']&y['wordmask']
            if overlap:
                common=x['blockmask']&y['blockmask']
                if not common:continue
                shared=0
                for bb in bitids(common):shared|=rowmasks[bb]
                if overlap!=shared:continue
            core=tuple(bitids(bm|x['blockmask']|y['blockmask']));extras=tuple(sorted((x['extra'],y['extra'])))
            key=(core,extras);pairs+=1;basekeys.add(key);compoundkeys.add(key)
            coreprovenance[key].append(dict(base_index=index,local_witness_ids=[a,b],cycles=[x['cycle'],y['cycle']]))
        pair_occurrences+=pairs;perbase.append(dict(index=index,compatible_local_witnesses=len(compatible),compatible_before_new_only=before_new,compatible_pairs=pairs,distinct_core_extra_keys=len(basekeys)))
        if index%100==0:print('BASE',index,'locals',compatible_total,'pairs',pair_occurrences,'unique',len(compoundkeys),flush=True)
    print('COMPOUNDS',compatible_total,compatible_before_new_only,pair_occurrences,len(compoundkeys),flush=True)

    frontier=json.loads((H/'WITNESS_FRONTIER.json').read_text());legacy=set();legacycount=0
    for index,source in frontier['closed'].items():
        if source['method']!='local CP-SAT + exhaustive exact cover':continue
        d=json.loads((H/source['file']).read_text())
        for r in d['records']:
            assert r['status'].startswith('EXHAUSTED');legacycount+=1
            legacy.add((tuple(sorted(r['core_blocks'])),tuple(sorted(map(tuple,r['extras'])))))
    assert len(legacy)==legacycount==2791
    oldonly=legacy-compoundkeys;newonly=compoundkeys-legacy;common=legacy&compoundkeys
    missing_by_base=Counter(p['base_index'] for key in newonly for p in coreprovenance[key])
    missing_by_method=Counter(frontier['closed'][str(i)]['method'] for i,n in missing_by_base.items() for _ in range(n))
    assert missing_by_method=={'reduced CP-SAT':147}
    six=[correct(c) for c in cycles(6)];allmeta=[];difference=Counter()
    for key in sorted(compoundkeys):
        core,extras=key;rules=set().union(*(blocks[b] for b in core));final=rules|set(extras)
        baseR7=sum(len(rr&rules)>=6 for c,rr in sevens);R6=sum(len(rr&final)>=5 for rr in six)
        newR7=sum(len(rr&final)>=6 for c,rr in sevens)
        family='legacy2791' if key in legacy else 'compound_only'
        difference[(family,R6>0,baseR7,newR7)]+=1
        allmeta.append(dict(core_blocks=core,extras=extras,provenance=coreprovenance[key],in_existing2791=key in legacy,partial_R6=R6,partial_base_R7=baseR7,partial_final_R7=newR7))
    (H/'chatgpt_compound_audit_compound_seeds.json').write_text(json.dumps(dict(scope=__doc__,seeds=allmeta,perbase=perbase),indent=2),encoding='utf-8')
    summary=dict(status='REGENERATED',global_local_witnesses=len(local),base_representatives=len(bases),compatible_local_witnesses=compatible_total,compatible_including_already_base=compatible_before_new_only,compound_pair_occurrences=pair_occurrences,compound_unique_core_extra_keys=len(compoundkeys),existing_core_occurrences=legacycount,existing_unique_cores=len(legacy),common_cores=len(common),existing_only_cores=len(oldonly),compound_only_cores=len(newonly),compound_keyset_sha256=encodekeys(compoundkeys),legacy_keyset_sha256=encodekeys(legacy),seed_file_sha256=hashlib.sha256(seedraw).hexdigest(),difference_histogram=[dict(family=k[0],has_rescued_six=k[1],partial_base_R7=k[2],partial_final_R7=k[3],count=v) for k,v in sorted(difference.items())],seconds=time.monotonic()-start)
    summary['matches_chatgpt_counts']=(len(local),compatible_total,pair_occurrences)==(6552,18842,2938)
    summary['compound_only_source_methods']=dict(missing_by_method)
    summary['compound_only_counts_by_base']={str(i):n for i,n in sorted(missing_by_base.items())}
    summary['compound_only_reason']='These147 cores belong to18of the23 base representatives closed directly by reduced CP-SAT; their local-core enumeration was unnecessary in the prior913-seed proof. This difference is not caused by R6 pruning.'
    (H/'chatgpt_compound_audit_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()
