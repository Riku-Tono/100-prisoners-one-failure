"""Fresh four-flip triangle orbits + pure52-block/2-hole exact cover.

No R6 constraint, CP-SAT, orientation model import, or extra-rule gain lemma.
Incomplete searches stay UNKNOWN. All data regenerated from directed cycles.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict,Counter
import json,time,hashlib,sys
H=Path(__file__).resolve().parent
FOUR=((1,2,3,4),(1,2,3,5),(1,2,3,6),(1,2,3,7))

def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def correct(c):
    n=len(c)
    return frozenset((c[j],c[(j+1)%n],c[(j+2)%n],c[(j+3)%n],c[(j-1)%n]) for j in range(n))
def cycles(k):
    for s in combinations(range(1,9),k):
        for p in permutations(s[1:]):yield (s[0],)+p

def data(flips):
    active={frozenset(s) for s in combinations(range(1,8),4)}
    for s in flips:active.remove(frozenset(s));active.add(frozenset(range(1,9))-set(s))
    words=tuple(c for c in cycles(4) if frozenset(c) in active);wi={w:i for i,w in enumerate(words)}
    blocks=set()
    for c in cycles(5):
        rr=correct(c)
        for omit in rr:
            b=rr-{omit}
            if all(canon(r[:4]) in wi for r in b):blocks.add(b)
    blocks=tuple(sorted(blocks,key=lambda rr:tuple(sorted(rr))))
    rows=[tuple(sorted(wi[canon(r[:4])] for r in b)) for b in blocks]
    assert len(words)==210 and all(len(set(r))==4 for r in rows)
    return words,blocks,rows

class FlexibleCover:
    def __init__(self,words,rows):
        self.words=words;self.rows=rows;n=len(words)
        self.L=list(range(-1,n));self.L[0]=n;self.R=list(range(1,n+2));self.R[n]=0
        self.U=list(range(n+1));self.D=list(range(n+1));self.C=list(range(n+1));self.S=[0]*(n+1);self.B=[-1]*(n+1);self.row_nodes=[]
        for b,row in enumerate(rows):
            nodes=[]
            for word in row:
                c=word+1;k=len(self.C);nodes.append(k);self.C.append(c);self.B.append(b)
                self.U.append(self.U[c]);self.D.append(c);self.D[self.U[c]]=k;self.U[c]=k;self.S[c]+=1;self.L.append(k);self.R.append(k)
            for a,z in zip(nodes,nodes[1:]+nodes[:1]):self.R[a]=z;self.L[z]=a
            self.row_nodes.append(nodes)
    def cover(self,c):
        self.R[self.L[c]]=self.R[c];self.L[self.R[c]]=self.L[c];i=self.D[c]
        while i!=c:
            j=self.R[i]
            while j!=i:self.D[self.U[j]]=self.D[j];self.U[self.D[j]]=self.U[j];self.S[self.C[j]]-=1;j=self.R[j]
            i=self.D[i]
    def uncover(self,c):
        i=self.U[c]
        while i!=c:
            j=self.L[i]
            while j!=i:self.S[self.C[j]]+=1;self.D[self.U[j]]=j;self.U[self.D[j]]=j;j=self.L[j]
            i=self.U[i]
        self.R[self.L[c]]=c;self.L[self.R[c]]=c
    def search(self,chosen,holes,budget):
        self.nodes+=1
        if self.nodes>self.node_limit:raise TimeoutError('NODE_LIMIT')
        if self.nodes%1000==0 and time.monotonic()>self.deadline:raise TimeoutError('WALL_LIMIT')
        if not self.R[0]:
            if budget:return False
            self.answer=chosen[:];self.holes=holes[:];return True
        c=self.R[0];j=c;zeros=0
        while j:
            if self.S[j]<self.S[c]:c=j
            zeros+=self.S[j]==0
            if zeros>budget:return False
            j=self.R[j]
        self.cover(c);options=[];i=self.D[c]
        while i!=c:options.append(i);i=self.D[i]
        options.sort(key=lambda i:self.B[i] not in self.hint)
        found=False
        for i in options:
            j=self.R[i]
            while j!=i:self.cover(self.C[j]);j=self.R[j]
            found=self.search(chosen+[self.B[i]],holes,budget)
            j=self.L[i]
            while j!=i:self.uncover(self.C[j]);j=self.L[j]
            if found:break
        if not found and budget:found=self.search(chosen,holes+[c-1],budget-1)
        self.uncover(c);return found
    def run(self,mandatory,seconds=2,node_limit=100000,hint=()):
        # A fresh matrix is used for every run; timeout unwinding is unnecessary.
        seen=set()
        for b in sorted(mandatory):
            assert not seen&set(self.rows[b]);seen.update(self.rows[b])
            for k in self.row_nodes[b]:self.cover(self.C[k])
        self.nodes=0;self.answer=None;self.holes=None;self.hint=set(hint);self.node_limit=node_limit;self.deadline=time.monotonic()+seconds;t=time.monotonic()
        try:found=self.search([],[],2)
        except TimeoutError as e:return dict(status='UNKNOWN',reason=str(e),nodes=self.nodes,seconds=time.monotonic()-t)
        result=dict(status='FOUND' if found else 'EXHAUSTED_NO_COMPLETION',nodes=self.nodes,seconds=time.monotonic()-t)
        if found:
            chosen=set(mandatory)|set(self.answer);used=[w for b in chosen for w in self.rows[b]]
            assert len(chosen)==52 and len(used)==len(set(used))==208 and set(used)|set(self.holes)==set(range(210))
            result.update(block_ids=sorted(chosen),holes=[self.words[w] for w in self.holes])
        return result

def enumerate_seeds(words,blocks,rows):
    start=time.monotonic();inc=defaultdict(list);rm=[sum(1<<w for w in r) for r in rows]
    for b,rr in enumerate(blocks):
        for r in rr:inc[r].append(b)
    witnesses=[];parents=[]
    for c in cycles(7):
        rr=correct(c)
        if sum(bool(inc[r]) for r in rr)<6:continue
        found=set()
        for ignore in rr:
            choices=sorted((inc[r] for r in rr-{ignore}),key=len)
            if any(not a for a in choices):continue
            def visit(j,used,chosen):
                if j==6:found.add(tuple(sorted(chosen)));return
                for b in choices[j]:
                    if not used&rm[b]:visit(j+1,used|rm[b],chosen+[b])
            visit(0,0,[])
        for w in sorted(found):witnesses.append(w);parents.append(c)
    occupied=[sum(rm[b] for b in w) for w in witnesses];adj=[set() for w in witnesses];edges=[]
    for i,j in combinations(range(len(witnesses)),2):
        if parents[i]==parents[j]:continue
        common=set(witnesses[i])&set(witnesses[j]);shared=sum(rm[b] for b in common)
        if occupied[i]&occupied[j]!=shared:continue
        adj[i].add(j);adj[j].add(i);edges.append((i,j))
    lookup={rr:b for b,rr in enumerate(blocks)};groups=[];maps=[]
    for a in permutations((1,2,3)):
        for b in permutations((4,5,6,7)):
            mp=dict(zip(range(1,9),a+b+(8,)));groups.append(mp)
            maps.append([lookup[frozenset(tuple(mp[x] for x in r) for r in rr)] for rr in blocks])
    seen=set();seeds=[];triangles=k4=0
    for i,j in edges:
        for k in sorted(q for q in adj[i]&adj[j] if q>j):
            triangles+=1;k4+=sum(q>k for q in adj[i]&adj[j]&adj[k]);u=tuple(sorted(set(witnesses[i])|set(witnesses[j])|set(witnesses[k])))
            if u in seen:continue
            orbit={tuple(sorted(m[b] for b in u)) for m in maps};seen.update(orbit);key=min(orbit)
            gi=next(g for g,m in enumerate(maps) if tuple(sorted(m[b] for b in u))==key)
            cs=[canon(tuple(groups[gi][x] for x in parents[t])) for t in (i,j,k)]
            supplied=set().union(*(blocks[b] for b in key));used=[w for b in key for w in rows[b]]
            assert len(used)==len(set(used))==4*len(key) and all(len(correct(c)&supplied)>=6 for c in cs)
            seeds.append(dict(block_ids=key,cycles=cs,orbit_size=len(orbit),actual_rules=[sorted(blocks[b]) for b in key]))
    out=dict(status='FRESH_ENUMERATION_COMPLETE',flips=FOUR,slots=len(words),blocks=len(blocks),witnesses=len(witnesses),witness_cycles=len(set(parents)),edges=len(edges),raw_triangles=triangles,raw_K4=k4,group_order=len(groups),triangle_orbits=len(seeds),orbit_size_sum=sum(s['orbit_size'] for s in seeds),union_size_histogram=dict(Counter(len(s['block_ids']) for s in seeds)),seconds=time.monotonic()-start,seeds=sorted(seeds,key=lambda s:s['block_ids']))
    assert (len(witnesses),len(edges),triangles,k4)==(576,25344,6144,0)
    assert sum(s['orbit_size'] for s in seeds)==triangles
    return out

def main():
    seconds=float(sys.argv[1]) if len(sys.argv)>1 else 2
    node_limit=int(sys.argv[2]) if len(sys.argv)>2 else 100000
    wall=float(sys.argv[3]) if len(sys.argv)>3 else 120
    words,blocks,rows=data(FOUR);assert len(blocks)==1920
    enumeration=enumerate_seeds(words,blocks,rows);path=H/'fourflip_triangle_pure_seeds.json';path.write_text(json.dumps(enumeration,indent=2),encoding='utf-8')
    print('ENUMERATION',{k:v for k,v in enumeration.items() if k!='seeds'},flush=True)
    cw,cb,cr=data(());raw=(H/'inputs/baseline15051.rules.json').read_bytes();rr={(a,*h,t) for a,h,t in json.loads(raw)['rules']};known={b for b,r in enumerate(cb) if r<=rr};assert len(known)==52
    fixed=set(sorted(known)[:39]);control=FlexibleCover(cw,cr).run(fixed,10,100000,known);assert control['status']=='FOUND' and len(set(control['block_ids'])-fixed)==13
    out=dict(scope=__doc__,enumeration_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),R6_constraint_used=False,seconds_per_seed=seconds,node_limit_per_seed=node_limit,positive_control=dict(status='FOUND',retained_blocks=39,recovered_blocks=13,nodes=control['nodes'],control_sha256=hashlib.sha256(raw).hexdigest()),cases=[])
    start=time.monotonic();deadline=start+wall
    for index,seed in enumerate(enumeration['seeds']):
        remaining=deadline-time.monotonic()
        if remaining<=0:break
        rec=FlexibleCover(words,rows).run(seed['block_ids'],min(seconds,remaining),node_limit);rec['index']=index
        if rec['status']=='FOUND':
            full=set().union(*(blocks[b] for b in rec['block_ids']));cert=H/f'fourflip_triangle_pure_found_{index}.rules.json'
            cert.write_text(json.dumps(dict(n=8,flipped_supports=FOUR,rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(full)],block_ids=rec['block_ids'],holes=rec['holes']),indent=2),encoding='utf-8')
            from independent_audit import audit
            checked=audit(cert);assert checked['rules']==208 and checked['lost_cf']==0 and checked['rescued_cycles']['5']==52 and checked['rescued_cycles']['7']>=3
            rec.update(certificate=str(cert),direct_audit=checked)
        out['cases'].append(rec);out['counts']=dict(Counter(c['status'] for c in out['cases']));out['seconds']=time.monotonic()-start;out['not_run']=len(enumeration['seeds'])-len(out['cases'])
        (H/'fourflip_triangle_pure_completion.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        print(index,rec['status'],rec['nodes'],round(rec['seconds'],3),'total',round(out['seconds'],2),flush=True)
        if rec['status']=='FOUND':break
    print('FINAL',out.get('counts',{}),out.get('seconds'),out.get('not_run'),flush=True)

if __name__=='__main__':main()
