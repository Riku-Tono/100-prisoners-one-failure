"""Solver-free local witness enumeration, independently implemented.
Only the standard three-support-flip family, R5=52,R6=1.
Does not solve completion to 52 blocks.
"""
from itertools import combinations,permutations,product
from collections import defaultdict
from pathlib import Path
import json
L=tuple(range(1,9))
def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def cycles(k,labels=L):
    for s in combinations(labels,k):
        for q in permutations(s[1:]):yield (s[0],)+q
def rules(c):
    return [(c[j],c[(j+1)%len(c)],c[(j+2)%len(c)],c[(j+3)%len(c)],c[(j-1)%len(c)]) for j in range(len(c))]
active={frozenset(s) for s in combinations(range(1,8),4)}
for s in ((1,2,3,4),(1,2,3,5),(1,2,3,6)):
    active.remove(frozenset(s));active.add(frozenset(L)-frozenset(s))
slots={c:i for i,c in enumerate(c for c in cycles(4) if frozenset(c) in active)}
blocks=[];opts=defaultdict(list)
for c in cycles(5):
    rr=rules(c)
    for omit in range(5):
        rs=tuple(r for j,r in enumerate(rr) if j!=omit)
        if any(frozenset(r[:4]) not in active for r in rs):continue
        mask=sum(1<<slots[canon(r[:4])] for r in rs)
        bid=len(blocks);blocks.append((c,omit,rs,mask))
        for r in rs:opts[r].append(bid)
cases=[((1,4,2,5,6,7),6),((1,4,2,5,7,6),7),((1,4,2,7,5,6),5),((1,4,5,6,2,7),5)]
results=[]
newfixed=frozenset()
# The six new blocks occupy all 24 slots on 45678; only their
# occupied slots matter to the old-side compatibility question.
newmask=sum(1<<i for c,i in slots.items() if set(c)<={4,5,6,7,8})
assert newmask.bit_count()==24
eight_counts=[sum(frozenset(r[:4]) in active for r in rules(c)) for c in cycles(7) if 8 in c]
assert max(eight_counts)<6
for r in list(opts):opts[r]=[b for b in opts[r] if not blocks[b][3]&newmask]
def six_seeds(c6,f):
    required=[r for r in rules(c6) if r[0]!=f]
    if any(canon(r[:4]) not in slots for r in required):return []
    seeds=[]
    for choice in product(*(opts[r]+[-1] for r in required)):
        if choice.count(-1)!=2:continue
        singles=tuple(r for r,b in zip(required,choice) if b==-1)
        smask=sum(1<<slots[canon(r[:4])] for r in singles)
        if smask&newmask:continue
        chosen=frozenset(b for b in choice if b!=-1);occ=smask|newmask
        for b in chosen:
            if occ&blocks[b][3]:break
            occ|=blocks[b][3]
        else:seeds.append((chosen,occ,singles))
    return seeds
# Independently verify the reduction to the four listed representatives.
group=[]
for p in permutations((1,2,3)):
    for q in permutations((4,5,6)):
        group.append(dict(zip(L,p+q+(7,8))))
representatives=set()
for c in cycles(6,tuple(range(1,8))):
    for f in c:
        representatives.add(min((canon(tuple(g[x] for x in c)),g[f]) for g in group))
assert len(representatives)==140
feasible=[(c,f) for c,f in sorted(representatives) if six_seeds(c,f)]
assert feasible==cases,(feasible,cases)
six8max=max(sum(frozenset(r[:4]) in active for r in rules(c)) for c in cycles(6) if 8 in c)
assert six8max<5
Path(__file__).with_name('six_reduction.json').write_text(json.dumps(dict(total_pairs=5040,group_size=len(group),orbits=len(representatives),feasible=feasible,max_active_windows_six_with_8=six8max,max_active_windows_seven_with_8=max(eight_counts)),indent=2),encoding='utf-8')
for c6,f in cases:
    required=[r for r in rules(c6) if r[0]!=f]
    # The two rules without an admissible four-rule block must be external.
    seeds=six_seeds(c6,f)
    assert len(seeds)==1,(c6,len(seeds))
    fixed,occupied,singles=seeds[0]
    fixedrules=set(singles)
    for b in fixed:fixedrules.update(blocks[b][2])
    witnesses=[];parents=[];cc=[]
    for c in cycles(7):
        rr=rules(c);found=set()
        for ignore in range(7):
            needs=[r for j,r in enumerate(rr) if j!=ignore and r not in fixedrules]
            options=[[b for b in opts[r] if not blocks[b][3]&occupied] for r in needs]
            if any(not o for o in options):continue
            options.sort(key=len)
            def visit(j,mask,chosen):
                if j==len(options):found.add(frozenset(chosen));return
                for b in options[j]:
                    if b in chosen:visit(j+1,mask,chosen);continue
                    if mask&blocks[b][3]:continue
                    visit(j+1,mask|blocks[b][3],chosen|{b})
            visit(0,occupied,set())
        if found:
            cid=len(cc);cc.append(c)
            for w in found:witnesses.append(w);parents.append(cid)
    masks=[sum(blocks[b][3] for b in w) for w in witnesses]
    edges=[];adj=[set() for _ in witnesses];pairs=set();triangles=0
    for i in range(len(witnesses)):
        for j in range(i+1,len(witnesses)):
            if parents[i]==parents[j]:continue
            shared=sum(blocks[b][3] for b in witnesses[i]&witnesses[j])
            if masks[i]&masks[j]!=shared:continue
            adj[i].add(j);adj[j].add(i);edges.append((i,j))
            pairs.add(tuple(sorted((cc[parents[i]],cc[parents[j]]))))
    for i,j in edges:
        triangles+=sum(k>j for k in adj[i]&adj[j])
    rec=dict(six_cycle=c6,failing=f,forced_blocks=len(fixed),external_rules=singles,seven_cycles=len(cc),witnesses=len(witnesses),edges=len(edges),triangles=triangles,pair_count=len(pairs),pairs=sorted(pairs))
    detail=dict(six_cycle=c6,failing=f,fixed_blocks=sorted(fixed),occupied_mask=str(occupied),cycles=cc,parents=parents,witness_blocks=[sorted(w) for w in witnesses],edges=edges,blocks=[dict(cycle=b[0],omitted_prisoner=b[0][b[1]],rules=b[2],mask=str(b[3])) for b in blocks])
    Path(__file__).with_name('witnesses_'+str(len(results)+1)+'.json').write_text(json.dumps(detail),encoding='utf-8')
    results.append(rec);print({k:v for k,v in rec.items() if k!='pairs'},flush=True)
source=Path(__file__).parent/'inputs'/'relax_pairs.json'
old=json.loads(source.read_text())
for a,b in zip(results,old):
    aa={tuple(tuple(c) for c in p) for p in a['pairs']}
    bb={tuple(sorted(tuple(c) for c in p)) for p in b['pairs']}
    a['matches_claude_pairs']=aa==bb
    a['claude_only']=len(bb-aa);a['independent_only']=len(aa-bb)
out=Path(__file__).with_suffix('.json');out.write_text(json.dumps(results,indent=2),encoding='utf-8')
print('pairs',sum(r['pair_count'] for r in results),'all_match',all(r['matches_claude_pairs'] for r in results))
