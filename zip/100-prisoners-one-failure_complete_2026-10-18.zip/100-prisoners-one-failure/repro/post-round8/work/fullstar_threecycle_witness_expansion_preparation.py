"""Prepare all compatible six-window witnesses of the same3 known sevens.

All28 witnesses per cycle are generated from the full2520-block universe.
The21952 raw triples are checked by actual lossword compatibility. Distinct
mandatory block unions are quotiented by the full S7 stabilizer of the
unordered3-cycle set. No completion search or global full-star bound.
"""
from fullstar_prepare_basic import H,RULES,ROWS,WORDS,correct,canon,witnesses
from itertools import product,combinations,permutations
from collections import Counter,defaultdict
import json,time,hashlib

def main():
    started=time.monotonic();baseline=json.loads((H/'fullstar_prepare_baseline.json').read_text())
    cycles=list(map(tuple,baseline['rescued_sevens']));cycle_set=set(cycles);assert len(cycles)==3
    ws=[witnesses(c) for c in cycles];assert list(map(len,ws))==[28,28,28]
    WI={w:i for i,w in enumerate(WORDS)};rowmask=[sum(1<<WI[w] for w in row) for row in ROWS]
    occupied={w:sum(rowmask[b] for b in w) for group in ws for w in group}
    def compatible(a,b):return occupied[a]&occupied[b]==sum(rowmask[q] for q in a&b)
    unions=defaultdict(int);triples=0;pair_count=Counter()
    for i,j in combinations(range(3),2):pair_count[f'{i},{j}']=sum(compatible(a,b) for a in ws[i] for b in ws[j])
    for a in ws[0]:
        for b in ws[1]:
            if not compatible(a,b):continue
            for c in ws[2]:
                if not compatible(a,c) or not compatible(b,c):continue
                u=a|b|c;used=[w for q in u for w in ROWS[q]];assert len(used)==len(set(used))
                assert all(len(correct(t)&set().union(*(RULES[q] for q in u)))>=6 for t in cycles)
                triples+=1;unions[frozenset(u)]+=1
    groups={}
    for target in cycles:
        for shift in range(7):
            g={cycles[0][k]:target[(k+shift)%7] for k in range(7)}
            if {canon(tuple(g[x] for x in c)) for c in cycles}==cycle_set:groups[tuple(g[x] for x in range(1,8))]=g
    group=[groups[k] for k in sorted(groups)];assert group
    lookup={b:i for i,b in enumerate(RULES)};relevant=set().union(*unions) if unions else set()
    maps=[{b:lookup[frozenset(tuple(g[x] for x in r) for r in RULES[b])] for b in relevant} for g in group]
    keys={};orbit_sizes=Counter()
    for u in unions:
        orbit={frozenset(mp[b] for b in u) for mp in maps};assert orbit<=unions.keys()
        key=min(tuple(sorted(v)) for v in orbit)
        if key not in keys:keys[key]=len(orbit);orbit_sizes[len(orbit)]+=1
    assert sum(keys.values())==len(unions)
    closed_path=H/'fullstar_fixed18_complete_summary.json';closedraw=closed_path.read_bytes();closed=json.loads(closedraw)
    assert closed['status']=='EXHAUSTED_NO_TARGET4_WITH_FIXED_18_CORE' and closed['all3735_verified_by_non_CP_cover']
    closedcore=frozenset(closed['fixed_core']);assert closedcore in unions
    closed_key=min(tuple(sorted(mp[b] for b in closedcore)) for mp in maps)
    six=[correct((s[0],)+p) for s in combinations(range(1,8),6) for p in permutations(s[1:])]
    sevens=[correct((1,)+p) for p in permutations(range(2,8))]
    reps=[];r6hist=Counter();r7hist=Counter()
    for key,size in sorted(keys.items(),key=lambda t:(len(t[0]),t[0])):
        rr=set().union(*(RULES[b] for b in key));R6=sum(len(q&rr)>=5 for q in six);R7=sum(len(q&rr)>=6 for q in sevens)
        r6hist[R6]+=1;r7hist[R7]+=1
        reps.append({'blocks':key,'actual_rules':[sorted(RULES[b]) for b in key],'orbit_size':size,'already_closed_by_previous_18core_orbit':key==closed_key,'R6_in_partial_core':R6,'R7_in_partial_core':R7})
    out={'status':'PREPARED_ENUMERATION_ONLY_NO_COMPLETION','scope':__doc__,'known_three_cycles':cycles,'witnesses_per_cycle':list(map(len,ws)),'raw_triples':28**3,'compatible_pair_counts':dict(pair_count),'compatible_triples':triples,'distinct_mandatory_unions':len(unions),'mandatory_union_size_histogram':dict(Counter(map(len,unions))),'union_witness_multiplicity_histogram':dict(Counter(unions.values())),'threecycle_set_stabilizer_order':len(group),'stabilizer_permutations':list(groups),'union_orbits':len(keys),'orbit_size_histogram':dict(orbit_sizes),'previously_closed_union_orbits':1,'remaining_union_orbits':len(keys)-1,'R6_core_histogram_over_orbits':dict(r6hist),'R7_core_histogram_over_orbits':dict(r7hist),'closed_summary_source':str(closed_path),'closed_summary_sha256':hashlib.sha256(closedraw).hexdigest(),'closed_canonical_key':closed_key,'seconds':time.monotonic()-started,'representatives':reps}
    (H/'fullstar_threecycle_witness_expansion_preparation.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print({k:v for k,v in out.items() if k not in ('scope','representatives','stabilizer_permutations','closed_canonical_key')},flush=True)
if __name__=='__main__':main()
