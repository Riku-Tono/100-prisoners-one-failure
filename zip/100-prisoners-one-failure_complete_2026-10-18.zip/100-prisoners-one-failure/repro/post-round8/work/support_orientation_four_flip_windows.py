from pathlib import Path
from itertools import combinations,permutations
from collections import Counter
import json
H=Path('work');d=json.loads((H/'support_orientation_four_flip_classification.json').read_text());r=d['orbits'][0];L7=frozenset(range(1,8));L8=frozenset(range(1,9));F=list(map(frozenset,r['removed_supports']));S=set(map(frozenset,combinations(range(1,8),4)))-set(F)|{L8-f for f in F};counts={}
for n in (6,7,8):
 c=Counter()
 for sub in combinations(range(1,9),n):
  for p in permutations(sub[1:]):
   t=(sub[0],)+p;k=sum(frozenset(t[(j+i)%n]for i in range(4))in S for j in range(n));c[(8 in t,k)]+=1
 counts[n]={'max_containing8':max(k for(has8,k),num in c.items()if has8),'eligible_total':sum(num for(has8,k),num in c.items()if k>=n-1),'eligible_containing8':sum(num for(has8,k),num in c.items()if has8 and k>=n-1),'distribution':[{'contains8':has8,'allowed_windows':k,'cycles':num}for(has8,k),num in sorted(c.items())]}
out={'scope':'unique four-flip orientation passing necessary52blockcapacity; support-window counts only','removed_supports':r['removed_supports'],'long_cycle_support_windows':counts,'construction_search_performed':False};(H/'support_orientation_four_flip_windows.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print({n:{k:v for k,v in c.items()if k!='distribution'}for n,c in counts.items()})
