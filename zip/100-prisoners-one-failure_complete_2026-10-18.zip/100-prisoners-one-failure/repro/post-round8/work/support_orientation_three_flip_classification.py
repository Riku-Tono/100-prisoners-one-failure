"""Classify all three-flip support orientations under S7; necessary capacities only.

Base supports are all 35 four-subsets of [7]. Flip three distinct supports
F_i to their complements in [8]. The Venn-cell count vector of the three
removed sets, modulo S3 permutations of those sets, is a complete S7 orbit
invariant. No strategy-construction feasibility search is performed.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict,Counter
from math import factorial
import json,hashlib,time
H=Path(__file__).resolve().parent;t0=time.monotonic();L7=frozenset(range(1,8));L8=frozenset(range(1,9));F=list(map(frozenset,combinations(range(1,8),4)))
P3=list(permutations(range(3)))
def signature(fs):
 counts=[0]*8
 for x in L7:counts[sum(1<<i for i,f in enumerate(fs)if x in f)]+=1
 candidates=[]
 for p in P3:
  changed=[0]*8
  for mask,n in enumerate(counts):changed[sum(1<<j for j in range(3)if mask&(1<<p[j]))]=n
  candidates.append(tuple(changed))
 return min(candidates)
classes={}
for triple in combinations(F,3):
 sig=signature(triple);key=tuple(tuple(sorted(f))for f in triple)
 if sig not in classes:classes[sig]={'representative':key,'labelled_triples':0}
 classes[sig]['labelled_triples']+=1
 assert classes[sig]['representative']<=key
standard=tuple(map(frozenset,((1,2,3,4),(1,2,3,5),(1,2,3,6))));standsig=signature(standard)
out={'method':__doc__,'total_labelled_triples':sum(c['labelled_triples']for c in classes.values()),'orbit_count':len(classes),'group':'S7 on labels1..7 fixing8','orbits':[]}
for index,(sig,info)in enumerate(sorted(classes.items(),key=lambda p:p[1]['representative'])):
 fs=tuple(map(frozenset,info['representative']));S=set(F)-set(fs)|{L8-f for f in fs};new={s for s in S if 8 in s};assert len(S)==35 and len(new)==3
 kinds=Counter();fiveprofile=Counter();used=set();blocks_total=0
 for sub in combinations(range(1,9),5):
  X=frozenset(sub);inside={s for s in S if s<X};q=len(inside);fiveprofile[(8 in X,q)]+=1
  if q>=4:
   # q=5 permits all5 omissions per24 directed cycles; q=4 forces one.
   num=24*(5 if q==5 else 1);kept_new=sum(8 in s for s in inside)-(1 if q==5 else 0)
   blocks_total+=num;used|=inside
   if q==4:kinds[(sum(8 in s for s in inside),4-sum(8 in s for s in inside))]+=num
   else:
    # Three flips cannot give q=5 with8, but split omissions exactly.
    for omitted in inside:kinds[(sum(8 in s for s in inside-{omitted}),sum(8 not in s for s in inside-{omitted}))]+=24
 usable_slots=6*len(used);upper=usable_slots//4;newblocks=sum(n for(k,old),n in kinds.items()if k)
 cell_stabilizer=1
 for n in sig:cell_stabilizer*=factorial(n)
 orbit=info['labelled_triples'];assert 5040%orbit==0
 rec={'index':index,'removed_supports':info['representative'],'added_supports':sorted(tuple(sorted(L8-f))for f in fs),'complement_triples_in_1_to_7':sorted(tuple(sorted(L7-f))for f in fs),'venn_signature_cells_mask0_to_7':sig,'labelled_triples':orbit,'S7_stabilizer_order':5040//orbit,'common_intersection_size':len(set.intersection(*(set(f)for f in fs))),'union_size':len(set.union(*(set(f)for f in fs))),'pair_intersection_sizes':sorted(len(a&b)for a,b in combinations(fs,2)),'five_subset_support_profile':[{'contains8':has8,'allowed_4_subsets':q,'five_subsets':n}for(has8,q),n in sorted(fiveprofile.items())],'four_rule_blocks':blocks_total,'block_types':[{'new_slots':newcount,'old_slots':oldcount,'blocks':n}for(newcount,oldcount),n in sorted(kinds.items())],'usable_supports':len(used),'usable_cyclic_word_slots':usable_slots,'R5_slot_capacity_upperbound':upper,'passes_necessary_52_block_test':upper>=52,'is_standard_three_flip_orbit':sig==standsig}
 assert (newblocks>0)==(rec['common_intersection_size']==3)==rec['is_standard_three_flip_orbit']
 assert upper==(52 if rec['is_standard_three_flip_orbit'] else 48)
 out['orbits'].append(rec)
assert out['total_labelled_triples']==6545
out['eligible_orbit_indices']=[r['index']for r in out['orbits']if r['passes_necessary_52_block_test']]
out['standard_orbit_index']=next(r['index']for r in out['orbits']if r['is_standard_three_flip_orbit'])
out['necessary_argument']='Any four-rule five-cycle block containing an8-history has its five labels {8} union U, |U|=4. At most one of its five cyclic words avoids8, so at least three of its four retained words contain8. Only three support sets containing8 exist; their triples T_i must all be subsets of U. Hence union(T_i) has size4, equivalently intersection(F_i) has size3. Three distinct four-subsets with acommon triple are exactly the standard orbit. All other orbits have no block meeting any of18 new words; their blocks use only192 old words, hence at most48 pairwise-disjoint four-rule blocks. This is an upper bound, not an attainment or infeasibility search.'
out['scope']='Exactlythree flips from allfour-subsets of[7], quotientS7fixing8. Necessary52blockcapacityonly. No claim about orientations obtained by4ormore flips or constructions withR5<52.'
out['seconds']=time.monotonic()-t0
p=H/'support_orientation_three_flip_classification.json';p.write_text(json.dumps(out,indent=2),encoding='utf-8')
print({k:v for k,v in out.items()if k not in('orbits','method','necessary_argument')});print([(r['index'],r['removed_supports'],r['labelled_triples'],r['four_rule_blocks'],r['R5_slot_capacity_upperbound'])for r in out['orbits']])

