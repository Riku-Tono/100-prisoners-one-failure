import sys
import agent_pair_local_batch as runner
start=int(sys.argv[1]);count=int(sys.argv[2]);wall=sys.argv[3]
runner.PREFIX='agent_local_'+str(start)
sys.argv=['agent_witness_resume_range',str(start),str(count),wall]
runner.main()
