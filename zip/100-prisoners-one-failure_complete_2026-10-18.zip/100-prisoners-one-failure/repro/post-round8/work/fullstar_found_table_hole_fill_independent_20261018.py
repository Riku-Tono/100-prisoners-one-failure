"""Check every289 singleton fillings of newly found full-star52-block tables.

Independent cycle-delta implementation: rescue bitsets use the base deficit
one/two layers and the union/intersection of the two rule-incidence masks.
All 8-label cycles of lengths5..8 are retained. New successful target tables
are exported and independently simulated over40320 placements. Source tables
and their neutral target8 padding remain unchanged. Dedup uses pure208 rules.
"""
from pathlib import Path
from itertools import permutations,combinations,product
from collections import Counter,defaultdict
import argparse,hashlib,json,time
from independent_audit import audit

H=Path(__file__).resolve().parent
PREFIX=H/'fullstar_found_table_hole_fill_independent_20261018'

def cycle_rules(c):
 n=len(c)
 return frozenset((c[j],c[(j+1)%n],c[(j+2)%n],c[(j+3)%n],c[(j+n-1)%n]) for j in range(n))

def normalize(w):
 w=tuple(w);return min(w[j:]+w[:j] for j in range(4))

def digest_rules(rs):return hashlib.sha256(json.dumps(sorted(rs),separators=(',',':')).encode()).hexdigest()

def write_table(path,rs,selected,extras,source):
 path.write_text(json.dumps({'n':8,'rules':[[r[0],list(r[1:4]),r[4]] for r in sorted(rs)],
                            'selected_block_ids':sorted(selected),'extra_rules':sorted(extras),
                            'source_packing':str(source)},indent=2),encoding='utf-8')

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--checkpoint',default=str(H/'fullstar_priority62_screen1.result.json'))
 args=parser.parse_args();checkpoint=Path(args.checkpoint);start=time.monotonic()
 d=json.loads(checkpoint.read_text(encoding='utf-8-sig'))
 source_records=[r for r in d['records'] if r.get('certificate') and r.get('engine_status')=='FOUND']
 ownfive={cycle_rules(c) for c in permutations(range(1,8),5)}
 blocks=sorted({rs-{r} for rs in ownfive for r in rs},key=lambda b:tuple(sorted(b)))
 assert len(blocks)==2520
 catalogue_hash=hashlib.sha256(json.dumps([sorted(b) for b in blocks],separators=(',',':')).encode()).hexdigest()
 assert catalogue_hash==d['block_catalogue_sha256']
 words={normalize(w) for w in permutations(range(1,8),4)};assert len(words)==210
 cycles={k:[(c,cycle_rules(c)) for support in combinations(range(1,9),k)
            for tail in permutations(support[1:]) for c in [(support[0],)+tail]] for k in (5,6,7,8)}
 incidence={k:defaultdict(int) for k in cycles}
 for k,rows in cycles.items():
  for i,(c,rr) in enumerate(rows):
   bit=1<<i
   for r in rr:incidence[k][r]|=bit
 output=PREFIX.with_suffix('.result.json')
 if output.exists():
  state=json.loads(output.read_text());records=state['records']
 else:
  state={'scope':__doc__,'block_catalogue_sha256':catalogue_hash,'records':[]};records=state['records']
 by_hash={r['pure208_rules_sha256']:r for r in records};new=0
 for src in source_records:
  cert=Path(src['certificate']);data=json.loads(cert.read_text(encoding='utf-8-sig'))
  actual={(a,*hist,t) for a,hist,t in data['rules']}
  selected=set(data['selected_block_ids']);assert len(selected)==52
  pure=set().union(*(blocks[b] for b in selected));assert len(pure)==208
  purewords=[normalize(r[:4]) for r in pure];assert len(set(purewords))==208
  neutral=actual-pure
  assert pure<=actual and len(neutral)==2 and len(actual)==210
  assert all(r[-1]==8 and 8 not in r[:4] for r in neutral)
  if 'extra_rules' in data:assert set(map(tuple,data['extra_rules']))==neutral
  holes=sorted(words-set(purewords));assert len(holes)==2
  assert {normalize(r[:4]) for r in neutral}==set(holes)
  assert selected==set(src['hint_block_ids'])
  purehash=digest_rules(pure)
  if purehash in by_hash:
   record=by_hash[purehash]
   if src['core_index'] not in record['source_core_indices']:record['source_core_indices'].append(src['core_index'])
   continue
  new+=1
  counts={k:[len(rr&pure) for c,rr in rows] for k,rows in cycles.items()}
  layers={}
  for k,ns in counts.items():
   threshold=k-1;layers[k]=(sum(1<<i for i,n in enumerate(ns) if n>=threshold),
                            sum(1<<i for i,n in enumerate(ns) if n==threshold-1),
                            sum(1<<i for i,n in enumerate(ns) if n==threshold-2))
  base={k:layers[k][0].bit_count() for k in layers}
  assert base[5]==52 and base[6]==0
  options=[]
  for hole in holes:
   options.append([None]+[hole[j:]+hole[:j]+(t,) for j in range(4) for t in range(1,9) if t not in hole])
  assert list(map(len,options))==[17,17]
  def evaluate(a,b):
   result={}
   for k in layers:
    inc_a=incidence[k].get(a,0);inc_b=incidence[k].get(b,0)
    rescued,one,two=layers[k]
    result[k]=rescued|((inc_a|inc_b)&one)|((inc_a&inc_b)&two)
   return result
  hist=Counter();best=-1;best_choice=None;best_layers=None;variants=[]
  for a,b in product(*options):
   masks=evaluate(a,b);signature=tuple(masks[k].bit_count() for k in (5,6,7,8))
   hist[signature]+=1;assert signature[0]==52
   variants.append({'extras':[r for r in (a,b) if r is not None],
                    'R5':signature[0],'R6':signature[1],'R7':signature[2],'R8':signature[3]})
   score=signature[2]+signature[3]
   if signature[1]==0 and score>best:best=score;best_choice=(a,b);best_layers=masks
  assert sum(hist.values())==289
  # Prefer existing neutral210 padding when it attains the same best score.
  neutral_pair=tuple(next(r for r in neutral if normalize(r[:4])==hole) for hole in holes)
  neutral_layers=evaluate(*neutral_pair)
  if neutral_layers[6]==0 and neutral_layers[7].bit_count()+neutral_layers[8].bit_count()==best:
   best_choice=neutral_pair;best_layers=neutral_layers
  bestextras={r for r in best_choice if r is not None}
  core=src['core_index'];pure_path=H/f'fullstar_holefill_core{core:03}_pure208_20261018.rules.json'
  best_path=H/f'fullstar_holefill_core{core:03}_best_20261018.rules.json'
  write_table(pure_path,pure,selected,set(),cert);write_table(best_path,pure|bestextras,selected,bestextras,cert)
  pureaudit=audit(pure_path);bestaudit=audit(best_path)
  assert pureaudit['rescued_cycles']=={str(k):base[k] for k in (5,6,7,8)}
  assert pureaudit['lost_cf']==bestaudit['lost_cf']==0
  assert bestaudit['rescued_cycles']=={str(k):best_layers[k].bit_count() for k in (5,6,7,8)}
  assert bestaudit['rescued_cycles']['6']==0
  near7=[{'cycle':c,'base_correct':n} for (c,rr),n in zip(cycles[7],counts[7]) if n>=4 and n<6]
  record={'source_core_indices':[core],'source_certificate':str(cert.resolve()),
          'source_certificate_sha256':hashlib.sha256(cert.read_bytes()).hexdigest(),
          'pure208_rules_sha256':purehash,'selected_block_ids':sorted(selected),
          'removed_neutral_rules':sorted(neutral),'holes':holes,'variants_checked':289,
          'base_rescued_cycles':base,'base_rescued_sevens':[c for (c,rr),n in zip(cycles[7],counts[7]) if n>=6],
          'unrescued_sevens_base_correct_at_least4':near7,
          'rescue_histogram':[{'R5':s[0],'R6':s[1],'R7':s[2],'R8':s[3],'count':n} for s,n in sorted(hist.items())],
          'best_R6zero_R7plusR8':best,'best_extras':sorted(bestextras),
          'pure208_certificate':str(pure_path),'pure208_direct_40320_audit':pureaudit,
          'best_certificate':str(best_path),'best_direct_40320_audit':bestaudit,
          'target4_found':best>=4,'variants':variants}
  records.append(record);by_hash[purehash]=record
  state.update(status='TARGET4_FOUND' if best>=4 else 'AVAILABLE_FOUND_TABLES_PROCESSED_NO_TARGET4',
               latest_checkpoint=str(checkpoint.resolve()),latest_checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
               source_code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               distinct_packings_checked=len(records),latest_run_new_packings=new,latest_run_seconds=time.monotonic()-start)
  output.write_text(json.dumps(state,indent=2),encoding='utf-8')
  print('HOLES_COMPLETE','core',core,'best',bestaudit['wins'],'R',bestaudit['rescued_cycles'],'hist',record['rescue_histogram'],flush=True)
  if best>=4:print('TARGET4_FOUND_AND_DIRECTLY_AUDITED',str(best_path),flush=True)
 state.update(distinct_packings_checked=len(records),latest_run_new_packings=new,
              available_found_table_records=len(source_records),latest_run_seconds=time.monotonic()-start,
              latest_checkpoint=str(checkpoint.resolve()),latest_checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest())
 state['status']='TARGET4_FOUND' if any(r['target4_found'] for r in records) else 'AVAILABLE_FOUND_TABLES_PROCESSED_NO_TARGET4'
 output.write_text(json.dumps(state,indent=2),encoding='utf-8')
 print('FINAL',state['status'],'packings',len(records),'new',new,flush=True)

if __name__=='__main__':main()
