"""Static pure-block templates for7/7 and6/7 correct windows.

The unique7-block all-correct template is a local fact only. A six-window
witness outside it may still extend to a52-block strategy; it must never be
discarded on that basis. No52-block completion or global solver is called.
"""
from pathlib import Path
from itertools import product
import json,time
H=Path(__file__).resolve().parent
C=tuple(range(1,8))
def correct(c):
    n=len(c);return frozenset((c[i],c[(i+1)%n],c[(i+2)%n],c[(i+3)%n],c[(i-1)%n]) for i in range(n))
def word(r):
    c=r[:4];j=c.index(min(c));return c[j:]+c[:j]
R=tuple((C[i],C[(i+1)%7],C[(i+2)%7],C[(i+3)%7],C[(i-1)%7]) for i in range(7))
OPTIONS=[]
for r in R:
    five=correct((r[4],)+r[:4]);assert r in five and len(five)==5
    OPTIONS.append(sorted((five-{omit} for omit in five-{r}),key=lambda b:tuple(sorted(b))))
    assert len(OPTIONS[-1])==4
def compatible(bs):
    slots=[word(r) for b in bs for r in b]
    return len(slots)==len(set(slots))
def key(bs):return tuple(sorted(tuple(sorted(tuple(r) for r in b)) for b in bs))
started=time.monotonic()
seven={key(bs) for bs in product(*OPTIONS) if compatible(bs)};assert len(seven)==1
template=next(iter(seven));template_set={frozenset(b) for b in template}
six=[]
for omitted in range(7):
    found={key(bs) for bs in product(*(OPTIONS[i] for i in range(7) if i!=omitted)) if compatible(bs)}
    assert len(found)==4
    for bs in sorted(found):six.append({'unrequired_position':omitted,'actual_blocks':bs,'contained_in_unique_seven_block_template':all(frozenset(b) in template_set for b in bs)})
assert len(six)==28 and sum(r['contained_in_unique_seven_block_template'] for r in six)==7
fixedsix=json.loads((H/'canonical_six_witness_preparation.json').read_text())
canonical_zero=[r for r in fixedsix['records'] if r['extra_count']==0]
fixedsets={key(r['actual_blocks']):r['representative_index'] for r in canonical_zero}
assert set(fixedsets)=={tuple(tuple(tuple(r) for r in b) for b in s['actual_blocks']) for s in six if s['unrequired_position']==6}
for s in six:
    if s['unrequired_position']==6:s['canonical_six_core_index']=fixedsets[tuple(tuple(tuple(r) for r in b) for b in s['actual_blocks'])]
out={'status':'EXHAUSTED_STATIC_TEMPLATE_ENUMERATION_NO_COMPLETION','scope':__doc__,'canonical_cycle':C,'seven_correct_required_rules':R,'supplier_choices_per_rule':4,'full_product_candidates':4**7,'seven_correct_block_templates':len(seven),'unique_template_actual_blocks':template,'six_correct_block_witnesses':len(six),'six_witnesses_extendable_to_pure_seven_template':7,'six_witnesses_not_extendable_to_pure_seven_template':21,'canonical_fixed_six_extendable_indices':[r['canonical_six_core_index'] for r in six if r['unrequired_position']==6 and r['contained_in_unique_seven_block_template']],'six_witnesses':six,'seconds':time.monotonic()-started}
(H/'canonical_seven_block_template_static.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print({k:v for k,v in out.items() if k not in ('scope','unique_template_actual_blocks','six_witnesses')})
