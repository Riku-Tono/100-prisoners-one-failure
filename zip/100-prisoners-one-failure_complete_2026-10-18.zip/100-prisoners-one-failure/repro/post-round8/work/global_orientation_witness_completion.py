"""All complementary support orientations,52 blocks and<=2 extra rules.

The35 support choices are variables; no fixed-flip-family, degree, old/new,
or marginal-gain restriction is imposed. Canonical normalization fixes six
correct rules of the seven-cycle(1,...,7), positions0..5. Any rescued seven
cycle has a missing rule (or an arbitrary ignored rule if all seven hold);
rotate that position to6 and relabel its labels in order to1..7, with the
remaining label8. This S8 relabeling preserves the entire model universe.

This searches the inherited four-rule-five-cycle-block plus<=2 extra-rule
representation. The exact52-block requirement is a structural assumption,
not a claim that arbitrary strategies admit the representation. Import and
build do not solve. Every feasible export is independently simulated40320.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from itertools import combinations
from collections import defaultdict,Counter
from functools import lru_cache
import argparse,hashlib,json,time
from general_orientation_model import cp_model,H,canon,correct,cycle_data,read_rules

ALL=frozenset(range(1,9))
CANONICAL=tuple(range(1,8))
CANONICAL_SIX=tuple((CANONICAL[i],CANONICAL[(i+1)%7],CANONICAL[(i+2)%7],CANONICAL[(i+3)%7],CANONICAL[(i-1)%7]) for i in range(6))
R8_PROOF='The histories at offsets i and i+4 in an8-cycle have complementary four-supports. Exactly one side of each support pair is enabled, so at most4 correct rules exist, below the rescue threshold7.'

@lru_cache(maxsize=1)
def universe():
    words=tuple(c for c,rr in cycle_data(4))
    blocks=tuple(sorted({rr-{omitted} for c,rr in cycle_data(5) for omitted in rr},key=lambda b:tuple(sorted(b))))
    singles=tuple(sorted({r for c,rr in cycle_data(5) for r in rr}))
    pairs=tuple((frozenset(s),ALL-frozenset(s)) for s in combinations(range(1,8),4))
    assert len(words)==420 and len(blocks)==6720 and len(singles)==6720 and len(pairs)==35
    assert len({s for p in pairs for s in p})==70
    assert all(len({canon(r[:4]) for r in b})==4 for b in blocks)
    return words,blocks,singles,pairs

@dataclass
class GlobalModel:
    model:object
    target:int
    canonical:bool
    blocks:list
    singles:dict
    present:dict
    orientation:list
    flags:dict
    stats:dict

    def fix_core(self,actual_blocks=(),extras=()):
        """Require a witness core by actual rules, with no unsupported no-good."""
        _,allblocks,allsingles,_=universe();lookup={b:i for i,b in enumerate(allblocks)}
        selected=set()
        for b in actual_blocks:
            key=frozenset(map(tuple,b))
            if key not in lookup:raise ValueError('Core includes an invalid four-rule block.')
            selected.add(lookup[key])
        extras=frozenset(map(tuple,extras))
        if len(extras)>2 or not extras<=self.singles.keys():raise ValueError('Core extras are invalid.')
        for i in selected:self.model.add(self.blocks[i]==1)
        for r in extras:self.model.add(self.singles[r]==1)
        return dict(mandatory_blocks=len(selected),mandatory_extras=len(extras))

    def certificate_assignment(self,rules):
        _,allblocks,_,_=universe();rules=frozenset(map(tuple,rules))
        if not rules<=self.singles.keys():raise ValueError('Invalid certificate rule.')
        groups=defaultdict(set);lookup=defaultdict(list)
        for r in rules:groups[canon((r[4],)+r[:4])].add(r)
        for i,b in enumerate(allblocks):
            r=next(iter(b));lookup[canon((r[4],)+r[:4])].append(i)
        selected=set()
        for five,rs in groups.items():
            if len(rs)>=4:
                options=[i for i in lookup[five] if allblocks[i]<=rs]
                if not options:raise ValueError('Invalid certificate five-cycle group.')
                selected.add(min(options))
        if len(selected)!=52:raise ValueError(f'Expected52 blocks, got{len(selected)}.')
        supplied=set().union(*(allblocks[i] for i in selected));extras=rules-supplied
        slots=[canon(r[:4]) for r in rules]
        if len(supplied)!=208 or len(extras)>2 or len(slots)!=len(set(slots)):
            raise ValueError('Certificate is not52 noncolliding blocks plus<=2extras.')
        return selected,extras

    def fix_certificate(self,rules,active_supports=None):
        selected,extras=self.certificate_assignment(rules)
        for i,v in enumerate(self.blocks):self.model.add(v==int(i in selected))
        for r,v in self.singles.items():self.model.add(v==int(r in extras))
        if active_supports is not None:
            active=frozenset(frozenset(s) for s in active_supports)
            _,_,_,pairs=universe()
            if len(active)!=35 or any(sum(s in active for s in p)!=1 for p in pairs):
                raise ValueError('Certificate orientation must choose one side of each support pair.')
            for i,(a,b) in enumerate(pairs):self.model.add(self.orientation[i]==int(a in active))
        return dict(fixed_blocks=len(selected),fixed_singles=len(extras),rules=208+len(extras),orientation_fully_fixed=active_supports is not None)

    def export_and_audit(self,solver,path,audit_path=None):
        path=Path(path);_,allblocks,_,pairs=universe()
        selected=[i for i,v in enumerate(self.blocks) if solver.value(v)]
        extras={r for r,v in self.singles.items() if solver.value(v)}
        rules=set().union(*(allblocks[i] for i in selected))|extras
        active=[sorted(a if solver.value(self.orientation[i]) else b) for i,(a,b) in enumerate(pairs)]
        slots=[canon(r[:4]) for r in rules]
        assert len(selected)==52 and len(extras)<=2 and len(rules)==208+len(extras)
        assert len(slots)==len(set(slots)) and all(frozenset(r[:4]) in map(frozenset,active) for r in rules)
        prediction=sum(solver.value(v) for v in self.flags.values())
        cert=dict(schema='mixed-n8-v1',n=8,rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(rules)],
                  active_supports=active,flipped_supports=[sorted(a) for i,(a,b) in enumerate(pairs) if not solver.value(self.orientation[i])],
                  selected_block_ids=selected,single_rules=sorted(extras),canonical_six_required=self.canonical,
                  model_prediction=dict(R5=52,R6=0,R7=prediction,R8=0))
        path.write_text(json.dumps(cert,indent=2),encoding='utf-8')
        from independent_audit import audit
        checked=audit(path)
        assert checked['placements']==40320 and checked['lost_cf']==0
        assert checked['rescued_cycles']=={'5':52,'6':0,'7':prediction,'8':0}
        assert prediction>=self.target and checked['wins']==14736+6*52+prediction
        audit_path=Path(audit_path) if audit_path is not None else path.with_suffix('.audit.json')
        audit_path.write_text(json.dumps(checked,indent=2),encoding='utf-8')
        return dict(certificate=str(path),direct_audit=str(audit_path),audit=checked)

def build(target=4,canonical=True):
    if not isinstance(target,int) or target<0:raise ValueError('target must be nonnegative integer.')
    started=time.monotonic();words,allblocks,allsingles,pairs=universe();m=cp_model.CpModel()
    bs=[m.new_bool_var(f'b{i}') for i in range(len(allblocks))]
    ss={r:m.new_bool_var(f's{i}') for i,r in enumerate(allsingles)}
    columns=defaultdict(list);terms=defaultdict(list)
    for i,b in enumerate(allblocks):
        for r in b:columns[canon(r[:4])].append(bs[i]);terms[r].append(bs[i])
    for r,v in ss.items():columns[canon(r[:4])].append(v);terms[r].append(v)
    for w in words:m.add_at_most_one(columns[w])
    m.add(sum(bs)==52);m.add(sum(ss.values())<=2)
    orientation=[m.new_bool_var(f'orientation{i}') for i in range(35)]
    support_terms=defaultdict(list)
    for w in words:support_terms[frozenset(w)].extend(columns[w])
    for i,(a,b) in enumerate(pairs):
        assert len([w for w in words if frozenset(w)==a])==6
        m.add(sum(support_terms[a])<=6*orientation[i])
        m.add(sum(support_terms[b])<=6*(1-orientation[i]))
    present={r:m.new_bool_var(f'p{i}') for i,r in enumerate(allsingles)}
    for r,v in present.items():
        assert len(terms[r])==5
        m.add(v==sum(terms[r]))
    for c,rr in cycle_data(6):m.add(sum(present[r] for r in rr)<=4)
    flags={}
    for i,(c,rr) in enumerate(cycle_data(7)):
        z=m.new_bool_var(f'R7_{i}');flags[c]=z;count=sum(present[r] for r in rr)
        m.add(count>=6).only_enforce_if(z)
        m.add(count<=5).only_enforce_if(z.Not())
    m.add(sum(flags.values())>=target)
    if canonical:
        for r in CANONICAL_SIX:m.add(present[r]==1)
    stats=dict(words=len(words),four_supports=70,complement_pair_variables=len(orientation),blocks=len(bs),singles=len(ss),
               presence_variables=len(present),six_constraints=len(cycle_data(6)),seven_iff_flags=len(flags),R8=0,R8_proof=R8_PROOF,
               canonical_six_required=canonical,canonical_cycle=CANONICAL,canonical_six=CANONICAL_SIX,
               target=target,build_seconds=time.monotonic()-started)
    return GlobalModel(m,target,canonical,bs,ss,present,orientation,flags,stats)

def canonicalize(rules,active_supports):
    """Relabel a known table using one actually rescued seven-cycle."""
    rules=frozenset(rules)
    for c,rr in cycle_data(7):
        if len(rr & rules)<6:continue
        for shift in range(7):
            d=c[shift:]+c[:shift]
            six=tuple((d[i],d[(i+1)%7],d[(i+2)%7],d[(i+3)%7],d[(i-1)%7]) for i in range(6))
            if not set(six)<=rules:continue
            mp={x:i+1 for i,x in enumerate(d)};mp[next(iter(ALL-set(d)))]=8
            moved=frozenset(tuple(mp[x] for x in r) for r in rules)
            assert set(CANONICAL_SIX)<=moved
            active=[sorted(mp[x] for x in s) for s in active_supports]
            return moved,active,dict(source_rescued_cycle=c,rotated_cycle=d,label_map=mp)
    raise ValueError('Known control has no rescued seven-cycle.')

def solve_once(model,seconds,prefix,seed=1):
    prefix=Path(prefix);error=model.model.validate()
    if error:raise ValueError(error)
    solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.max_time_in_seconds=seconds;solver.parameters.random_seed=seed
    solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
    with prefix.with_suffix('.log.txt').open('w',encoding='utf-8') as log:
        solver.log_callback=lambda line:log.write(line+'\n')
        status=solver.solve(model.model)
    result=dict(scope=__doc__,stats=model.stats,validation_error=error,status=solver.status_name(status),
                solve_seconds=solver.wall_time,response_stats=solver.response_stats(),workers=1,limit_seconds=seconds,random_seed=seed)
    if status in (cp_model.FEASIBLE,cp_model.OPTIMAL):result.update(model.export_and_audit(solver,prefix.with_suffix('.rules.json')))
    prefix.with_suffix('.result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(prefix.name,result['status'],'seconds',result['solve_seconds'],flush=True)
    return result

def run_controls():
    from independent_audit import audit
    from general_orientation_model import orientation_data
    std3=((1,2,3,4),(1,2,3,5),(1,2,3,6))
    specs=[('baseline208',(),3,H/'inputs/baseline15051.rules.json','OPTIMAL'),
           ('standard3_r6zero',std3,1,H/'agent_full_r6zero_control.rules.json','OPTIMAL'),
           ('standard3_r6one_negative',std3,1,H/'inputs/new15051.rules.json','INFEASIBLE')]
    out=dict(scope='All rule, block, single and orientation variables fixed to relabelings of existing controls; no new construction search.',records=[])
    for label,flips,target,path,expected in specs:
        original=audit(path)
        moved,active,normalization=canonicalize(read_rules(path),orientation_data(flips).active_supports)
        src=H/f'global_orientation_control_{label}.normalized.json'
        src.write_text(json.dumps(dict(rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(moved)],active_supports=active,normalization=normalization),indent=2),encoding='utf-8')
        moved_audit=audit(src)
        for k in ('rules','placements','wins','success_histogram','lost_cf','rescued_cycles','rescued_multiplicities'):
            assert original[k]==moved_audit[k],(label,k)
        model=build(target,canonical=True);fixed=model.fix_certificate(moved,active)
        assert model.model.validate()==''
        result=solve_once(model,15,H/f'global_orientation_control_{label}')
        assert result['status']==expected,(label,result['status'])
        if expected=='INFEASIBLE':assert moved_audit['rescued_cycles']['6']==1
        out['records'].append(dict(label=label,original=str(path),original_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                                  normalization=normalization,fixed=fixed,original_direct_audit=original,normalized_direct_audit=moved_audit,result=result))
        (H/'global_orientation_controls.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    out['status']='PASS';(H/'global_orientation_controls.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('controls');sub.add_parser('validate')
    s=sub.add_parser('search');s.add_argument('--seconds',type=float,default=120);s.add_argument('--target',type=int,default=4);s.add_argument('--seed',type=int,default=1);s.add_argument('--prefix',required=True);s.add_argument('--core',help='JSON containing actual_blocks and extras; optional witness core.')
    a=p.parse_args()
    if a.command=='controls':run_controls();return
    m=build(target=getattr(a,'target',4),canonical=True)
    if a.command=='validate':
        out=dict(stats=m.stats,validation_error=m.model.validate(),variables=len(m.model.proto.variables),constraints=len(m.model.proto.constraints),Solve_called=False)
        (H/'global_orientation_static_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2));return
    controls=json.loads((H/'global_orientation_controls.json').read_text())
    if controls.get('status')!='PASS':raise ValueError('Controls must pass before construction search.')
    if a.core:
        core=json.loads(Path(a.core).read_text(encoding='utf-8-sig'));m.fix_core(core.get('actual_blocks',()),core.get('extras',()))
    solve_once(m,a.seconds,Path(a.prefix),a.seed)

if __name__=='__main__':main()
