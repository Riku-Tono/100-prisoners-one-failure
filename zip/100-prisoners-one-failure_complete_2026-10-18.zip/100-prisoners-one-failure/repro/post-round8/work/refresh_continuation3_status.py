"""Summarize completed evidence and unresolved searches without changing logs."""
from pathlib import Path
from collections import Counter
import json,hashlib,datetime
H=Path(__file__).resolve().parent
def read(n):return json.loads((H/n).read_text(encoding='utf-8-sig'))
def digest(n):return hashlib.sha256((H/n).read_bytes()).hexdigest()

def main():
    audit=read('claude_desktop_continuation3/audit_status.json')
    assert audit['status']=='AUDIT_PASS'
    four=read('fourflip_independent_regenerate_cover.json')
    assert four['exhausted']==four['total']==21097 and four['found']==four['unknown']==0
    six=read('post_audit_sixflip_20261018_all_results.json')
    assert six['counts']=={'INFEASIBLE':8}
    seven=read('post_audit_sevenflip_20261018_all_results.json')
    sevcp=read('post_audit_sevenflip_independent_cp_summary.json')
    assert len(sevcp['records'])==12 and all(x['status']=='INFEASIBLE' for x in sevcp['records'])
    sevbound=read('sevenflip_independent_rulepair_bound.json')
    assert {x['orbit'] for x in sevbound['orientations']}=={9,15}
    assert all(x['R7_upper_bound']==3 for x in sevbound['orientations'])
    fixed=read('fullstar_fixed18_complete_summary.json')
    assert fixed['total_core_count']==3735 and fixed['unknown']==fixed['unprocessed']==fixed['found']==0
    canonical=read('canonical_six_witness_preparation.json')
    assert canonical['unique_cores']==70 and canonical['extra_count_histogram']=={'0':4,'1':21,'2':45}
    source_names=[
        'claude_desktop_continuation3/audit_status.json','chatgpt_15050_received.audit.json',
        'chatgpt_compound_audit_completion.json','support_orientation_three_flip_classification.json',
        'support_orientation_four_flip_classification.json','support_orientation_five_flip_screen.json',
        'fourflip_independent_regenerate_cover.json','sixflip_screen_independent_20261018.json',
        'post_audit_sixflip_20261018_all_results.json','post_audit_independent_orientation_summary.json',
        'post_audit_sevenflip_20261018_screen.json','post_audit_sevenflip_20261018_all_results.json',
        'post_audit_sevenflip_independent_cp_summary.json','sevenflip_independent_rulepair_bound.json',
        'fullstar_fixed18_complete_summary.json','fullstar_six_witness_pure_completion_20261018.json',
        'canonical_six_witness_preparation.json','canonical_six_witness_independent_review_20261018.json',
        'global_orientation_independent_static_review_20261018.json','global_orientation_controls.json']
    results=[]
    result_paths=set(H.glob('global_orientation*.result.json'))|set(H.glob('post_audit_global_extra2*.result.json'))
    for p in sorted(result_paths):
        d=json.loads(p.read_text());results.append(dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),kind='CONTROL' if 'control' in p.name or 'positive' in p.name else 'CONSTRUCTION_SEARCH',status=d.get('status'),solve_seconds=d.get('solve_seconds'),R7=d.get('R7'),scope=d.get('scope')))
    checkpoints=[]
    checkpoint_paths=set(H.glob('global_orientation*.checkpoint.json'))|set(H.glob('post_audit_global_extra2*.checkpoint.json'))
    for p in sorted(checkpoint_paths):
        d=json.loads(p.read_text());checkpoints.append(dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),counts=dict(Counter(x['status'] for x in d.get('records',[]))),records=[{k:x[k] for k in ['representative_index','status','result_file','result_sha256','solve_seconds'] if k in x} for x in d.get('records',[])]))
    new_sources=['independent_allcore_support_screen_20261018.json','independent_orientation_S8_partition_20261018.json',
        'canonical_orientation_capacity_0_4.json','canonical_orientation_capacity_4_25.json','canonical_orientation_capacity_25_70.json',
        'canonical_orientation_S8_classification.json','canonical_orientation_support_relaxation.json',
        'canonical_support_independent_fraction_audit.json','canonical_support_fraction_certificate_verify.json',
        'canonical_orientation_five_survivors.json','canonical_orientation_five_survivors_presence_independent.json',
        'canonical_orientation_logical_chain_review.json']
    source_names.extend(n for n in new_sources if (H/n).exists())
    allcore_total=sum(2**(11+3*e)*n for e,n in [(0,4),(1,21),(2,45)])
    nonstar=dict(status='AWAITING_LAST_INDEPENDENT_CHECKS',allcore_orientation_assignments=allcore_total,
        core_orientation_entries=53392,distinct_necessary_orientations=27423,min_degree_at_least8_masks=22610,S8_orbits=1378,
        exact_fraction_dual_exclusions=1372,two_integer_engine_capacity_exclusions=1,remaining_full_CP_orbits=[1255,1291,1305,1319,1376],
        fullstar_status='UNRESOLVED; retained, not excluded')
    last=H/'canonical_orientation_five_survivors_presence_independent.json'
    if last.exists():
        proof=json.loads(last.read_text(encoding='utf-8-sig'))
        nonstar['last_independent_cp_status']=proof.get('status')
        if proof.get('complete') and proof.get('controls_passed') and proof.get('all_five_independent_infeasible'):
            assert {r['index'] for r in proof['records']}=={1255,1291,1305,1319,1376}
            assert all(r['status']=='INFEASIBLE' for r in proof['records'])
            nonstar['status']='NONSTAR_TARGET4_EXCLUDED_WITH_INDEPENDENT_CHECKS'
            nonstar['claim']='Under52 blocks+<=2 extras and R6=0, every non-full-star support orientation has R7<=3. Full-star remains unresolved. No general strategy optimum.'
    out=dict(updated_local=datetime.datetime.now().isoformat(timespec='seconds'),
      scope='CF preserving, final-box-only; exactly52 disjoint four-rule five-cycle blocks plus<=2 extras, complementary support orientation; R6=0,R7>=4. No global optimality claim.',
      claude_913_audit='AUDIT_PASS',new_15052_found=False,
      flip_family_frontier=[
        dict(flips=0,status='UNRESOLVED',closed_fixed18_core_count=3735,scope='Only one fixed18-block witness branch exhausted; other full-star cores open.'),
        dict(flips=1,status='CAPACITY_EXCLUDED',argument='No block can use the6 new slots; at most204 block-usable slots<208.'),
        dict(flips=2,status='CAPACITY_EXCLUDED',argument='Every new block needs>=3 active new supports; none exist. At most198 block-usable slots<208.'),
        dict(flips=3,status='TARGET4_EXCLUDED',S7_orbits=10,capacity_candidates=1,independent_core_count=2938,source='claude_desktop_continuation3/audit_status.json'),
        dict(flips=4,status='TARGET4_EXCLUDED',S7_orbits=38,capacity_candidates=1,independent_core_count=21097,source='fourflip_independent_regenerate_cover.json'),
        dict(flips=5,status='CAPACITY_EXCLUDED',labelled_tested=324632,S7_screen_orbits=2,R5_upper_bound=49,source='support_orientation_five_flip_screen.json'),
        dict(flips=6,status='TARGET4_EXCLUDED',labelled_tested=1623160,S7_screen_orbits=11,capacity_candidates=8,two_formulation_CP_infeasible=8,source='post_audit_sixflip_20261018_all_results.json'),
        dict(flips=7,status='TARGET4_EXCLUDED',labelled_tested=6724520,S7_screen_orbits=17,capacity_candidates=14,two_formulation_CP_infeasible=12,combinatorial_R7_bound_orbits=[9,15],source='sevenflip_independent_rulepair_bound.json'),
        dict(flips='8..35',status='NOT_INDIVIDUALLY_CLASSIFIED',scope='Included in all-orientation global model; no claim of exclusion.')],
      canonical_witness_cover=dict(total=70,by_extra_count={'0':4,'1':21,'2':45},independent_cartesian_assignments=15625,review='canonical_six_witness_independent_review_20261018.json'),
      global_results=results,global_checkpoints=checkpoints,nonstar_all_orientation_reduction=nonstar,
      evidence_sha256={n:digest(n) for n in source_names})
    (H/'SUPPORT_FRONTIER_2026-10-18.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    text='''続行3：Claude独立監査と別支持向きの探索　2026-10-18

結論
Claudeデスクトップの913代表完了資料に対する独立監査は AUDIT_PASS。
監査通過後、支持向きを変えた探索を実行した。15,052勝の新構成は現時点で未発見。
既知の15,051勝は達成下界であり、全戦略の最適性は主張しない。

今回の範囲
8人・4箱、最初3箱はCF、最後の箱だけ変更、CF勝ちを保存。
相補4支持35組から片側を選び、52個の4規則5巡回ブロック＋追加2規則以内。
R6=0、救済7巡回4本以上を目標とする。一般の支持向きでもR8=0。
W=14736+6R5+2R6+R7+R8 なので、この枝の目標は15,052勝。
R5<52、早い開封への変更、一般戦略の上界は今回の結論に含まない。

Claudeデスクトップによる独立監査
会話：https://claude.ai/chat/a4abed8c-182f-48b9-a4b3-582e259e3b31
監査書：claude_desktop_continuation3/audit_status.json
Claude自身の別生成・直接開封シミュレーター・C補完器で確認した。
既知3構成を全40,320配置で再現し、全て15,051勝・CF損失0。
1896ブロック、12新側被覆、913対代表、248三角形代表を独立再生成して一致。
三角形248件、独立複合core2938件とも補完なし、未決0。
結論は標準3支持反転の限定結論。軽微な集計説明と補題の適用範囲を修正済み。
原監査入力はaudit_input_snapshot_20261018に元のハッシュ付きで保存。

ChatGPT既存相談の独立照合
全208規則を返信本文から取得し、直接40,320配置で15,050勝を確認。
R=(52,0,2,0)、CF損失0。標準3支持反転内の達成下界を15,050に更新。
chatgpt_15050_received.rules.json / chatgpt_15050_received.audit.json
強い列挙の主張も自前再生成し、2938件すべてR6を使わない補完で排除。
先方添付ZIP実体は未取得なので、添付ZIPの直接同一性確認とは区別する。

別支持向きの完了結果
反転数は[7]の全35支持から、8を含む相補支持へ入れ替えた数。
1・2反転：ブロックで使える語数の容量だけで52ブロックを排除。
3反転：全10軌道中、52候補は標準向きだけ。913件の監査で目標を排除。
4反転：全38軌道中、52候補は1軌道だけ。
  新規三角形48代表を別の2補完器で排除し、block部分のR7<=2を確認。
  複合core21,097件すべて補完不能。Claude独立生成器を用いた別列挙・
  別bitset補完でも実規則集合が完全一致し、全21,097件を排除、未決0。
5反転：全324,632向きを必要条件で分類。残る2軌道もR5<=49で排除。
6反転：全1,623,160向きを分類、11軌道中の容量候補8件すべてINFEASIBLE。
  ブロック生成と規則供給の表現を変えた別CPモデルでも8件一致。
7反転：全6,724,520向きを分類、17軌道中の容量候補14件。
  12件は別CPモデルでもINFEASIBLEを再現。残り9・15番は元CPのUNKNOWNを
  そのまま保存し、別の容量・規則共有数の議論と独立再生成でR7<=3を証明。
  したがって7反転の目標枝は閉じた。UNKNOWN自体を不存在とは扱っていない。
4反転の詳細：FOURFLIP_PURE_COMPLETION_2026-10-18.txt
7反転の詳細：SEVENFLIP_9_15_R7_BOUND_2026-10-18.txt

全starの残る範囲
既知3巡回を支える特定18ブロックを固定した枝では、3,735核心すべて補完不能。
全件をCP以外のcover探索でも確認し、未処理0・UNKNOWN0。
これは全star全体の上界ではなく、別witnessの21,951代表等は未探索。
また「救済7巡回は必ず7人全員正解」という還元には、52ブロック・R6=0・
15,050勝で6人のみ正解の具体反例があるため、その還元を採用しない。
fullstar_fixed18_complete_summary.json
fullstar_nonextension_counterexample_details_20261018.json

全支持向きを変数にしたwitness先行探索
35個の支持選択をすべて変数にし、特定の反転数やラベルの次数を仮定しない。
救済7巡回の欠落位置を回転・S8で再ラベルすると、正準7巡回の位置0..5の
6正解規則を固定できる。この正規化を全40,320の巡回・欠落位置で独立確認。
全6,720ブロック・6,720規則・420語、モデル全22,099制約を別生成で照合済み。
既知陽性・R6=1陰性対照も通過。モデル自体の独立静的監査はPASS。
6正解の供給方法は70核心（追加0本4、1本21、2本45）に完全分類。
全5^6=15,625供給割当による別列挙でも実規則集合が完全一致。
この70枝は当該モデル内の目標構成を正規化後に漏れなく覆う。
各枝の残り支持向きは自由。UNKNOWNは未決として保存し、枝の排除に使わない。
最新の個別結果・未処理数・証拠ハッシュはSUPPORT_FRONTIER_2026-10-18.json参照。

主張の区別
AUDIT_PASS：標準3反転の913件完了資料に対するClaudeの独立監査。
有限計算確認：列挙集合照合、全件cover補完、40,320配置の直接検算。
CPによる限定排除：記録したモデル・支持向き・終了INFEASIBLEの範囲。
未解決：全starの別witness、全支持向きモデルのUNKNOWN、一般戦略の最適性。
新しい15,052勝構成が出た場合は、全規則を保存し、別実装の直接40,320配置
検算が通ったものだけを発見として報告する。
'''
    assert nonstar['status']=='NONSTAR_TARGET4_EXCLUDED_WITH_INDEPENDENT_CHECKS'
    text+='''\n全支持向きに対する追加の還元
全70coreの残り11/14/17支持ペアをすべて列挙、全6,250,496割当を検査した。
必要容量を通る53,392 core-orientation組、相異なる支持向き27,423を独立再生成し一致。
最小支持次数0は全star。1..7なら対応ラベルを8に置くと既閉鎖の反転族に入る。
最小次数8以上の22,610向きはS8で1,378軌道。別の正準化でも所属集合まで一致。
実ブロックを4支持patternへ緩和した整数容量モデルで、1,373軌道を排除。
別実装で1,372件の有理数双対証明を厳密検証し、残1件は別整数engineでも排除。
残5軌道は支持向きを固定した完全な規則モデルで全てINFEASIBLE。
その5件の別生成presence/iffモデルでも、全5件INFEASIBLEが一致。
既知陽性・R6=1陰性の固定対照も通過し、全独立照合が完了した。
したがって、この52ブロック＋追加2本以内・R6=0の範囲では、
全star以外の全支持向きにR7>=4の構成がないことを有限計算で確認した。
この還元でも全star全体の未解決枝は残す。15,051を最適値とは呼ばない。
'''
    (H/'CONTINUATION3_STATUS_2026-10-18.txt').write_text(text,encoding='utf-8-sig')
    print(json.dumps({'frontier':'SUPPORT_FRONTIER_2026-10-18.json','global_results':Counter(x['status'] for x in results),'checkpoints':[x['file'] for x in checkpoints]},ensure_ascii=False))

if __name__=='__main__':main()
