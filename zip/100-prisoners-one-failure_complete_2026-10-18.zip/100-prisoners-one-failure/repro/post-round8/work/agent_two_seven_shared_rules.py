"""Regenerate all 720 directed seven-cycles and audit correct-rule overlap.

No imports from witness generation or completion solvers. Each rule has
exactly two seven-cycle extensions, which differ only in the order of the
two labels outside the rule. The two extensions share exactly this rule.
"""
from itertools import permutations,combinations
from collections import defaultdict,Counter
from pathlib import Path
import json
cycles=[(1,)+tail for tail in permutations(range(2,8))]
inc=defaultdict(list)
for cid,c in enumerate(cycles):
    for i,a in enumerate(c):
        r=(a,c[(i+1)%7],c[(i+2)%7],c[(i+3)%7],c[(i+6)%7])
        inc[r].append(cid)
assert len(inc)==2520 and all(len(v)==2 for v in inc.values())
shared=Counter(pair for ids in inc.values() for pair in combinations(ids,2))
assert len(shared)==2520 and max(shared.values())==1
out={'status':'EXHAUSTED_ALL_720_CYCLES','cycles':len(cycles),'distinct_correct_rules':len(inc),'rule_extension_count_histogram':dict(Counter(map(len,inc.values()))),'cycle_pairs':len(cycles)*(len(cycles)-1)//2,'cycle_pair_shared_rule_histogram':{'0':len(cycles)*(len(cycles)-1)//2-len(shared),'1':len(shared)},'max_shared_correct_rules':1,'proof':'For r=(a,b,c,d,t), the only seven-cycle extensions are (a,b,c,d,x,y,t) and (a,b,c,d,y,x,t). Each extension pair shares just r, verified exhaustively.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(out)
