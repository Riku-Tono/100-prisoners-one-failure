"""All orientations, maximize rescued sevens from a verified 15051 hint.

The hint adds no restriction. Uses the same independently audited model,
with target0 and an explicit maximization objective. R7>=4 is a discovery;
R7=3 with FEASIBLE is only the known lower bound, not an upper bound.
"""
import json,time,hashlib
from pathlib import Path
from global_orientation_witness_completion import build,universe
from general_orientation_model import H,read_rules,cycle_data,cp_model

def main():
    assert json.loads((H/'global_orientation_controls.json').read_text())['status']=='PASS'
    source=H/'global_orientation_control_baseline208.normalized.json'
    data=json.loads(source.read_text());rules=read_rules(source)
    m=build(target=0,canonical=True)
    selected,extras=m.certificate_assignment(rules)
    _,_,_,pairs=universe();active={frozenset(s) for s in data['active_supports']}
    for i,v in enumerate(m.blocks):m.model.add_hint(v,int(i in selected))
    for r,v in m.singles.items():m.model.add_hint(v,int(r in extras))
    for r,v in m.present.items():m.model.add_hint(v,int(r in rules))
    for i,(a,b) in enumerate(pairs):m.model.add_hint(m.orientation[i],int(a in active))
    for c,rr in cycle_data(7):m.model.add_hint(m.flags[c],int(len(rr & rules)>=6))
    m.model.maximize(sum(m.flags.values()))
    assert not m.model.validate()
    prefix=H/'global_orientation_optimize300'
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=300
    solver.parameters.num_search_workers=4;solver.parameters.random_seed=29
    solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
    class Progress(cp_model.CpSolverSolutionCallback):
        def __init__(self):super().__init__();self.records=[]
        def on_solution_callback(self):
            count=sum(self.value(v) for v in m.flags.values())
            record=dict(R7=count,seconds=self.wall_time)
            self.records.append(record)
            prefix.with_suffix('.progress.json').write_text(json.dumps(self.records,indent=2),encoding='utf-8')
            print('incumbent R7',count,'seconds',self.wall_time,flush=True)
    progress=Progress()
    prefix.with_suffix('.parameters.txt').write_text(str(solver.parameters),encoding='utf-8')
    with prefix.with_suffix('.log.txt').open('w',encoding='utf-8') as log:
        solver.log_callback=lambda line:log.write(line+'\n')
        status=solver.solve(m.model,progress)
    out=dict(scope=__doc__,stats=m.stats,status=solver.status_name(status),workers=4,limit_seconds=300,
             solve_seconds=solver.wall_time,response_stats=solver.response_stats(),incumbents=progress.records,
             hint_is_constraint=False,hint_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    if status in (cp_model.FEASIBLE,cp_model.OPTIMAL):
        out.update(m.export_and_audit(solver,prefix.with_suffix('.rules.json')))
        out.update(R7=sum(solver.value(v) for v in m.flags.values()),objective=solver.objective_value,best_objective_bound=solver.best_objective_bound)
    prefix.with_suffix('.result.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(out['status'],out.get('R7'),out.get('best_objective_bound'),flush=True)

if __name__=='__main__':main()
