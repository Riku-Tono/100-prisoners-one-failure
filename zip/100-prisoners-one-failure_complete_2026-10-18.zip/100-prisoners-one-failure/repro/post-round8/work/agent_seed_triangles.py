"""Witness-first triangle seeds, reduced under the actual S3 x S3 stabilizer.

Enumeration covers block-only 7-cycle witnesses in the 186-slot old side of
the standard three-flip orientation.  It is not a search of all orientations.
"""
from completion_dlx_recheck import RULES, ROWS, WORDS, correct
from itertools import permutations, combinations
from collections import defaultdict, Counter
from pathlib import Path
import json, time

t0=time.monotonic(); rows=list(map(frozenset, ROWS)); inc=defaultdict(set)
for i,rs in enumerate(RULES):
    for r in rs: inc[r].add(i)
cycles=[]; parents=[]; witnesses=[]
for tail in permutations(range(2,8)):
    c=(1,)+tail; rr=frozenset(correct(c)); found=set()
    for ignore in rr:
        def visit(todo, occupied, chosen):
            if not todo:
                found.add(frozenset(chosen)); return
            opts=[]
            for r in todo:
                bs=[b for b in inc[r] if not occupied & rows[b]]
                if not bs: return
                opts.append((len(bs),r,bs))
            for b in min(opts)[2]:
                visit(todo-RULES[b],occupied|rows[b],chosen|{b})
        visit(rr-{ignore},frozenset(),frozenset())
    if found:
        for w in sorted(found,key=lambda x:tuple(sorted(x))):
            witnesses.append(w);parents.append(len(cycles))
        cycles.append(c)
occupied=[frozenset().union(*(rows[b] for b in w)) for w in witnesses]
adj=[set() for _ in witnesses]
for i,j in combinations(range(len(witnesses)),2):
    if parents[i]==parents[j]:continue
    shared=frozenset().union(*(rows[b] for b in witnesses[i]&witnesses[j]))
    if occupied[i]&occupied[j]!=shared:continue
    adj[i].add(j);adj[j].add(i)

lookup={rs:i for i,rs in enumerate(RULES)};group=[]
for a in permutations((1,2,3)):
    for b in permutations((4,5,6)):
        mp=dict(zip((1,2,3,4,5,6,7),a+b+(7,)))
        group.append([lookup[frozenset(tuple(mp[x] for x in r) for r in rs)] for rs in RULES])

union_seeds={};raw=0
for i in range(len(witnesses)):
    for j in sorted(q for q in adj[i] if q>i):
        for k in sorted(q for q in adj[i]&adj[j] if q>j):
            raw+=1; blocks=witnesses[i]|witnesses[j]|witnesses[k]
            key=min(tuple(sorted(g[b] for b in blocks)) for g in group)
            if key not in union_seeds:
                matching=[g for g in group if tuple(sorted(g[b] for b in blocks))==key][0]
                # Source-cycle triples retained as provenance.  Canonical blocks
                # themselves form the portable seed; the cycles may be unmapped.
                union_seeds[key]={'block_ids':list(key),'source_cycles':[cycles[parents[q]] for q in (i,j,k)],'raw_triangles_in_orbit':0}
            union_seeds[key]['raw_triangles_in_orbit']+=1
out={'status':'EXHAUSTED_ENUMERATION','scope':'standard three-flip old side; block-only three distinct 7-cycle witnesses','group_order':len(group),'cycles':len(cycles),'witnesses':len(witnesses),'raw_triangles':raw,'orbit_count':len(union_seeds),'block_count_histogram':dict(Counter(map(len,union_seeds))),'block_definition_sha256_note':'IDs correspond to completion_dlx_recheck.RULES; actual rules supplied below','seeds':[]}
for key,seed in sorted(union_seeds.items()):
    seed['rules']=[sorted(RULES[b]) for b in key]
    seed['covered_slots']=len(key)*4
    seed['remaining_blocks']=46-len(key)
    seed['remaining_slots']=186-len(key)*4
    supplied=set().union(*(RULES[b] for b in key))
    seed['rescued_cycles']=[c for c in cycles if sum(r in supplied for r in correct(c))>=6]
    assert len(seed['rescued_cycles'])==3
    out['seeds'].append(seed)
out['seconds']=time.monotonic()-t0
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print({k:v for k,v in out.items() if k!='seeds'},flush=True)
