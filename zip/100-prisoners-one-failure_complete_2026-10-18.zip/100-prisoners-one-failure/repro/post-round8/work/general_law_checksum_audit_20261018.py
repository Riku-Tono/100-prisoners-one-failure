"""Small finite cross-checks for the general anchored checksum proof.

No construction search,8-person search,solver,or100! enumeration is run.
The general theorem is justified by the separate self-contained proof audit;
these finite checks only catch implementation and boundary mistakes.
"""
from pathlib import Path
from itertools import permutations,product,combinations
from collections import defaultdict,Counter
from math import factorial
from fractions import Fraction
from decimal import Decimal,localcontext
import hashlib,json,time

H=Path(__file__).resolve().parent
START=time.monotonic()

def sig(w):return tuple(int(a>b) for a,b in zip(w,w[1:]))
def major(w):return sum(i for i,(a,b) in enumerate(zip(w,w[1:]),1) if a>b)
def delete(w,j):return w[:j]+w[j+1:]

def main():
 code_results=[];zero_classes={}
 for m in range(2,6):
  n=2*m-1;classes=defaultdict(list)
  for w in permutations(range(n),m):classes[(sum(w)%n,major(w)%m)].append(w)
  expected=factorial(2*m-2)//factorial(m)
  assert len(classes)==n*m and {len(ws) for ws in classes.values()}=={expected}
  collisions=0
  for syndrome,ws in classes.items():
   seen={}
   for w in ws:
    for j in range(m):
     u=delete(w,j)
     if u in seen and seen[u]!=w:collisions+=1
     seen[u]=w
  assert not collisions
  zero_classes[m]=classes[(0,0)]
  code_results.append({'m':m,'words':sum(map(len,classes.values())),
                       'classes':len(classes),'all_class_sizes':expected,
                       'different_word_deletion_collisions':collisions})
 vt_cases=0
 for length in range(1,13):
  seen={}
  for b in product((0,1),repeat=length):
   syndrome=sum(i*x for i,x in enumerate(b,1))%(length+1)
   for j in range(length):
    key=(syndrome,delete(b,j))
    assert key not in seen or seen[key]==b
    seen[key]=b;vt_cases+=1
 signature_cases=0;insertion_checks=0
 for length in range(2,8):
  insertions=defaultdict(dict)
  for w in permutations(range(length)):
   for j in range(length):
    u=delete(w,j);shortsig=sig(u);s=sig(w)
    assert any(delete(s,t)==shortsig for t in range(length-1))
    signature_cases+=1
    owner=insertions[(u,w[j])]
    assert s not in owner or owner[s]==w
    owner[s]=w;insertion_checks+=1
 rank_checks=[]
 for m in range(2,9):
  count=0
  for w in permutations(range(m)):
   rotated=tuple((x+1)%m for x in w)
   assert (major(rotated)-major(w))%m==(-1)%m
   count+=1
  rank_checks.append({'m':m,'permutations':count})
 sum_balance=[]
 for m in range(2,8):
  n=2*m-1;hist=Counter(sum(s)%n for s in combinations(range(n),m))
  assert len(hist)==n and len(set(hist.values()))==1
  sum_balance.append({'m':m,'residues':n,'subsets_per_residue':next(iter(hist.values()))})

 strategy=[]
 for m in (2,3):
  n=2*m;anchor=n;cycles=[(anchor,)+tuple(x+1 for x in w) for w in zero_classes[m]]
  rules={}
  for c in cycles:
   for j,a in enumerate(c):
    if a==c[1]:continue
    key=(a,tuple(c[(j+s)%(m+1)] for s in range(1,m)))
    assert key not in rules
    rules[key]=c[(j-1)%(m+1)]
  oldwins=newwins=lost=0
  for p in permutations(range(1,n+1)):
   old_success=new_success=0
   for a in range(1,n+1):
    box=a
    for step in range(m):
     box=p[box-1]
     if box==a:old_success+=1;break
    box=a;hist=[];opened=set()
    for step in range(m):
     if step==m-1:box=rules.get((a,tuple(hist)),box)
     assert box not in opened;opened.add(box)
     seen=p[box-1]
     if seen==a:new_success+=1;break
     hist.append(seen);box=seen
   old=old_success==n;new=new_success>=n-1
   assert (old_success>=n-1)==old
   oldwins+=old;newwins+=new;lost+=old and not new
  assert lost==0 and newwins-oldwins==len(cycles)*factorial(m-1)
  strategy.append({'m':m,'n':n,'fixed_class':[0,0],'cycles':len(cycles),
                   'placements':factorial(n),'CF_wins':oldwins,'modified_wins':newwins,'lost_CF':lost})

 cf=Fraction(1)-sum((Fraction(1,k) for k in range(51,101)),Fraction(0))
 delta=Fraction(1,2*50**2*99);upper=Fraction(1,2*50**3)
 with localcontext() as ctx:
  ctx.prec=60
  decimal=lambda q:str(Decimal(q.numerator)/Decimal(q.denominator))
  hundred={'CF_exact':str(cf),'CF_decimal':decimal(cf),'improvement_exact':str(delta),
           'improvement_decimal':decimal(delta),'constructed_probability_decimal':decimal(cf+delta),
           'anchored_family_improvement_upper_exact':str(upper),
           'all_final_box_CF_preserving_shortest_long_cycle_contribution_upper_exact':str(upper),
           'percentage_point_increase':decimal(100*delta)}
 proof=Path(r'C:\Users\yauki\Desktop\100prisoners\results\4ラウンド同じ番号集合で異なる巡回順も安全に詰め込めるか\Cluade\安全な巡回詰め込み構成の証明監査.txt')
 coexistence=Path(r'C:\Users\yauki\Documents\Codex\2026-10-08\new-chat\outputs\例外ルールの損失衝突と安全な合成条件_整形・監査版.md')
 sources=[proof,Path(r'C:\Users\yauki\Documents\Codex\2026-10-08\new-chat\outputs\packing_audit_Windows.py'),
          Path(r'C:\Users\yauki\Documents\Codex\2026-10-08\new-chat-2\work\README.md'),coexistence]
 sections=[{'path':str(p),'line_start':a,'line_end':b,'subject':subject,
            'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
           for p,a,b,subject in [
            (proof,241,258,'anchored safe packing and deletion condition'),
            (proof,259,268,'self-contained signature deletion, binary VT and insertion uniqueness lemmas'),
            (proof,269,274,'checksum construction and general probability lower bound'),
            (coexistence,247,256,'anchor-free final-box CF-preserving m+1-cycle contribution upper bound'),
            (coexistence,263,263,'higher cycle lengths not bounded by that contribution upper bound')]]
 out={'status':'SELF_CONTAINED_CHECKSUM_PROOF_RECONSTRUCTED_NO_GAP_FOUND',
      'scope':__doc__,'construction_search_called':False,'eight_person_search_called':False,
      'general_proof_basis':['deletion of distinct-letter word induces one-bit deletion of descent signature',
                            'self-contained binary VT residue decoder proof',
                            'distinct missing-letter insertion positions have different descent signatures',
                            'anchored loss cycles are distinct and intersect at the anchor',
                            'pigeonhole code size and exact rescued-cycle counting'],
      'extra_self_contained_result':'Every checksum class has exact size(2m-2)!/m! for allm>=2, by uniform subset-sum residues and rank-rotation major-index residues. Thus fixed class(0,0) requires no maximal-class search.',
      'code_finite_checks':code_results,'binary_VT_lengths_checked':[1,12],'binary_VT_deletion_cases':vt_cases,
      'signature_deletion_cases':signature_cases,'insertion_signature_checks':insertion_checks,
      'rank_rotation_checks':rank_checks,'subset_sum_balance_checks':sum_balance,
      'direct_strategy_finite_checks':strategy,'hundred_prisoner_consequence':hundred,
      'assumptions':['n=2m,m>=2,uniform random permutation','each prisoner opens at mostm boxes; success means physically finding own card',
                     'team succeeds with at mostone failure','firstm-1 steps follow own cycle; only final box may change',
                     'common anchor; injective lengthm words on2m-1 other labels','both checksum residues fixed',
                     'at every selected(m+1)-cycle, omit only the anchor-successor prisoner exception'],
      'important_qualification':'LemmaU needs genuine admissible exceptions: target is unopened and differs from the ordinary CF final box. The audited anchored construction satisfies this automatically.',
      'upper_bound_scope':{
       'formula':'1/(2m^3)',
       'anchored_deletion_code_family':'Bounds total improvement, since this family cannot rescue longer than(m+1)-cycles.',
       'wider_final_box_CF_preserving_family':'Also bounds contribution from(m+1)-cycle placements, without a common anchor.',
       'proof':'At most C(2m,m)*(m-1)!/2 proper exceptions; each rescued(m+1)-cycle consumes at leastm distinct rules, each rule has exactlyone(m+1)-cycle; each cycle has(m-1)! placements.',
       'does_not_bound':'Total improvement including cycles of lengthm+2 or more, or strategies changing earlier boxes.'},
      'not_proved_here':['global optimality for100 prisoners','optimality for all adaptive or early-box strategies',
                         'attaining the anchored1/(2m^3) upper bound at m50','generalizing the recent8-person15051 mechanism to100'],
      'different_from_current_fullstar':'Anchored checksum loss supports contain one anchor. Current n8 fullstar supports avoid one label. Degree vectors are(35,15,15,15,15,15,15,15) versus(0,20,20,20,20,20,20,20), so they are not S8 equivalent.',
      'finite_checks_are_not_general_proof':True,'historical_attribution_or_novelty_audited':False,
      'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
      'source_sections':sections,
      'seconds':time.monotonic()-START}
 output=H/'general_law_checksum_audit_20261018.json';output.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8-sig')
 print(json.dumps({k:v for k,v in out.items() if k not in ('assumptions','source_sha256')},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
