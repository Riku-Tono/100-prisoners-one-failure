"""Static logical and artifact audit of the non-full-star orientation reduction.

No construction solver is called. The low-minimum-degree images are mapped
as actual support sets to all earlier S7 families, with terminal evidence
checked separately from the old bounded UNKNOWN records.
"""
from pathlib import Path
from itertools import combinations, permutations
from collections import Counter, defaultdict
import hashlib, json, time

H = Path(__file__).resolve().parent
V = frozenset(range(1, 9))
SEVEN = frozenset(range(1, 8))
A = tuple(map(frozenset, combinations(range(1, 8), 4)))
AI = {s: i for i, s in enumerate(A)}


def main():
    started = time.monotonic()
    inputs = {}

    def read(name):
        raw = (H / name).read_bytes()
        inputs[name] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)

    capacity = [read(f'canonical_orientation_capacity_{a}_{b}.json')
                for a, b in ((0, 4), (4, 25), (25, 70))]
    assert all(d['complete'] for d in capacity)
    records = [r for d in capacity for r in d['records']]
    assert sorted(r['core_index'] for r in records) == list(range(70))
    submitted = read('canonical_six_witness_preparation.json')
    core_review = read('canonical_six_witness_independent_review_20261018.json')
    assert submitted['unique_cores'] == 70 and core_review['status'] == 'PASS'
    assert core_review['submitted_set_exact_match']
    for r in records:
        core = H / f"canonical_six_witness_cores/core_{r['core_index']:03d}.json"
        assert hashlib.sha256(core.read_bytes()).hexdigest() == r['input_sha256']
    masks = {int(h, 16) for r in records for h in r['accepted_masks_hex']}
    assert sum(r['tested'] for r in records) == 6250496
    assert len(masks) == 27423

    three = read('support_orientation_three_flip_classification.json')
    four = read('support_orientation_four_flip_classification.json')
    five = read('support_orientation_five_flip_screen.json')
    six = read('support_orientation_six_flip_screen.json')
    seven = read('post_audit_sevenflip_20261018_screen.json')
    assert six['enumeration_complete'] and six['orbit_classification_complete']
    assert seven['brute_complete'] and seven['independent_sets_match']
    assert three['eligible_orbit_indices'] == [0]
    assert four['eligible_orbit_indices'] == [0]
    assert five['refined_52_block_eligible_orbits'] == []
    families = {
        3: [r for r in three['orbits'] if r['passes_necessary_52_block_test']],
        4: [r for r in four['orbits'] if r['passes_necessary_52_block_test']],
        5: five['orbits'], 6: six['orbits'], 7: seven['orbits']}
    # Independent actual S7 images, rather than a canonical-key comparison.
    permutations7 = tuple(permutations(range(1, 8)))
    family_lookup = {}
    orbit_coverage = {}
    for k, rows in families.items():
        lookup = {}
        for r in rows:
            fs = tuple(map(frozenset, r.get('flips', r.get('removed_supports'))))
            assert len(fs) == k
            orbit = {sum(1 << AI[frozenset(p[v-1] for v in s)] for s in fs)
                     for p in permutations7}
            assert len(orbit) == r.get('S7_orbit_size', r.get('labelled_triples', r.get('labelled_quadruples')))
            assert not lookup.keys() & orbit
            lookup.update((mask, r['index']) for mask in orbit)
        family_lookup[k] = lookup
        orbit_coverage[k] = dict(orbits=len(rows), labelled_images=len(lookup))

    degree_counts = Counter()
    matched = Counter()
    examples = {}
    for mask in sorted(masks):
        active = {s if not mask >> i & 1 else V - s for i, s in enumerate(A)}
        degree = {v: sum(v in s for s in active) for v in V}
        k = min(degree.values())
        degree_counts[k] += 1
        if k >= 8:
            continue
        v = min(v for v, d in degree.items() if d == k)
        if k == 0:
            assert active == set(map(frozenset, combinations(sorted(V - {v}), 4)))
            continue
        # Move a minimum-degree vertex to8. Exactly k active supports contain8,
        # so exactly k base [7] supports have been complemented.
        others = sorted(V - {v})
        relabel = {old: i + 1 for i, old in enumerate(others)} | {v: 8}
        moved = {frozenset(relabel[x] for x in s) for s in active}
        flips = set(A) - moved
        assert len(flips) == k and moved == set(A) - flips | {V - s for s in flips}
        flipped_mask = sum(1 << AI[s] for s in flips)
        assert k in family_lookup and flipped_mask in family_lookup[k]
        index = family_lookup[k][flipped_mask]
        matched[k, index] += 1
        examples.setdefault((k, index), dict(mask_hex=f'{mask:09x}',
                                             minimum_vertex=v,
                                             relabel=relabel,
                                             mapped_flips=sorted(map(sorted, flips))))
    assert degree_counts[1] == degree_counts[2] == 0
    assert sum(n for k, n in degree_counts.items() if 0 < k < 8) == 4812

    # Terminal evidence, preserving old UNKNOWN as historical solver statuses.
    std3 = read('claude_desktop_continuation3/audit_status.json')
    assert std3['status'] == 'AUDIT_PASS'
    f4 = read('fourflip_independent_regenerate_cover.json')
    assert f4['total'] == f4['exhausted'] == 21097 and not f4['found'] and not f4['unknown']
    f6 = read('post_audit_sixflip_20261018_all_results.json')
    f6_status = {r['orbit_index']: r['status'] for r in f6['records']}
    f7 = read('post_audit_sevenflip_20261018_all_results.json')
    f7_status = {r['orbit_index']: r['status'] for r in f7['records']}
    lemmas = read('sevenflip_independent_rulepair_bound.json')
    lemma_status = {r['orbit']: r['R7_upper_bound'] for r in lemmas['orientations']}
    capacity6 = {r['index'] for r in six['orbits'] if not r['passes_slot_52_test']}
    capacity7 = {r['index'] for r in seven['orbits'] if not r['passes_52_word_capacity']}
    low_rows = []
    for (k, index), count in sorted(matched.items()):
        if k == 3:
            assert index == 0
            evidence = 'Independent Desktop Claude audited standard3 exclusion'
        elif k == 4:
            assert index == 0
            evidence = 'All21097 compound cores independently exhausted by pure cover'
        elif k == 5:
            evidence = 'Refined four-rule block-capacity upper bound49'
        elif k == 6:
            if index in capacity6:
                evidence = 'Unusable-word capacity below52 blocks'
            else:
                assert f6_status[index] == 'INFEASIBLE'
                evidence = 'Full eight-label fixed-orientation target4 CP INFEASIBLE'
        elif k == 7:
            if index in capacity7:
                evidence = 'Unusable-word capacity below52 blocks'
            elif f7_status[index] == 'INFEASIBLE':
                evidence = 'Full eight-label fixed-orientation target4 CP INFEASIBLE'
            else:
                assert f7_status[index] == 'UNKNOWN' and lemma_status[index] == 3
                evidence = 'Old CP UNKNOWN retained; later independent finite rulepair R7<=3'
        low_rows.append(dict(minimum_degree=k, earlier_orbit_index=index,
                             capacity_passing_canonical_masks=count,
                             terminal_evidence=evidence, example=examples[k, index]))

    s8 = read('canonical_orientation_S8_classification.json')
    assert s8['distinct_capacity_passing_masks'] == len(masks)
    assert s8['minimum_degree_at_least8_masks'] == sum(n for k, n in degree_counts.items() if k >= 8) == 22610
    relax = read('canonical_orientation_support_relaxation.json')
    assert relax['complete'] and len(relax['records']) == 1378
    assert Counter(r['status'] for r in relax['records']) == {'INFEASIBLE': 1373, 'OPTIMAL': 5}
    survivors = read('canonical_orientation_five_survivors.json')
    assert {r['index'] for r in survivors['records']} == {1255, 1291, 1305, 1319, 1376}
    assert all(r['status'] == 'INFEASIBLE' for r in survivors['records'])
    assert hashlib.sha256((H/'canonical_orientation_S8_classification.json').read_bytes()).hexdigest() == survivors['classification_sha256']
    assert hashlib.sha256((H/'canonical_orientation_support_relaxation.json').read_bytes()).hexdigest() == survivors['relaxation_sha256']
    fraction = read('canonical_support_independent_fraction_audit.json')
    five_independent = read('canonical_orientation_five_survivors_independent_cp.json')
    presence_independent = read('canonical_orientation_five_survivors_presence_independent.json')
    assert presence_independent['complete'] and presence_independent['controls_passed']
    assert presence_independent['all_five_independent_infeasible']
    assert {r['orbit_index'] for r in presence_independent['survivors']} == {1255,1291,1305,1319,1376}
    assert all(r['status'] == 'INFEASIBLE' and r['fixed_control'] is None
               for r in presence_independent['survivors'])
    assert presence_independent['classification_sha256'] == survivors['classification_sha256']
    assert presence_independent['primary_result_sha256'] == hashlib.sha256((H/'canonical_orientation_five_survivors.json').read_bytes()).hexdigest()

    implications = [
        'Within the inherited lossword/CF-preserving orientation representation, R5=52 has52 disjoint four-rule five-cycle blocks. They use208 slots, with at most2 other rules among210 slots.',
        'A full five-correct-rule group is represented by choosing any4 as its block and its fifth as an extra. Choosing52 such groups uses208 distinct rules; all other rules fit the <=2 extra budget. The fifth-rule case is not lost.',
        'R7>=4 supplies at least one directed7-cycle with>=6 correct rules. Rotate/relabel so a possibly failed window is position6 of(1..7), unused label8. If all7 rules are correct any window can be unrequired. Exactly6 correct rules suffice; the seventh is never imposed.',
        'Every required correct five-tuple has4 possible four-rule block suppliers, all on the same five labels within[7], or its correct singleton. Thus the2520-block source is complete for these supplier choices even while all remaining support orientations are free on[8].',
        'A block supplies at most one correct rule of this7-cycle. The exhaustive5^6 supplier product, <=2 extras, and slot compatibility gives the70 cores. Every target table contains one of these cores after normalization.',
        '208 used block slots force all35 complementary support pairs to contribute a support:34 supports allow only204 words. A used support must lie in a five-set with at least4 active four-subsets. The capacity screen is only this necessary condition.',
        'Moving a minimum-active-degree vertex to8 makes its degree exactly the number of flips from the fullstar avoiding8. Degree0 is fullstar; degree1..7 belongs to earlier complete families. This audit maps every retained low-degree mask as actual supports, including later finite closures of old7flip UNKNOWN orbits9/15.',
        'All minimum>=8 masks are quotiented by S8. Degree-ordered equal-cell permutations give an exact orbit invariant: relabellings can only permute equal-degree positions after sorting degrees. The no-witness-core fixed-orientation solver searches all7-cycles, so losing the original canonical core during S8 relabelling cannot remove a valid table.',
        'Each actual four-rule block has4 distinct support types from its five-label set. Summing block multiplicities yields feasible integer support counts total52 and <=6 per active support. Extras may use remaining slots but cannot invalidate this necessary relaxation. Relaxation INFEASIBLE excludes actual packing; its feasible solutions are not constructions.',
        'The five relaxation survivors are checked by a full fixed-orientation model with52 blocks, all3360 single-rule options, <=2 extras, exactR6zero, and R7+R8>=4. No canonical core, marginal-gain lemma, old/new split, or relaxation pattern counts are fixed. Each primary result is strictly INFEASIBLE.',
        'R8=0 for every complementary support orientation: opposite4-windows of an8-cycle are complementary, so at most4 of8 rules are eligible, below threshold7. Thus the target R7+R8>=4 is equivalent to R7>=4 here.'
    ]
    caveats = [
        'The inherited final-box-only, CF-preserving lossword/complement orientation/block representation is a scope premise. This review does not prove that premise for strategies with earlier deviations or arbitrary non-CF-preserving strategies.',
        'The result leaves all fullstar orientations under S8 unresolved. Only one specific fixed18-block fullstar core was completely excluded earlier; that exclusion is not substituted for fullstar completeness.',
        'It is not a global15051 optimum or an exclusion ofR5<52,R6>0, other rule budgets, or other decision models.',
        'The1373 primary relaxation exclusions are independent of a proof that all1373 have exact LP duals. Current independent fraction audit has1372 rational-dual exclusions and one independently integer-infeasible case. Exact-dual wording must preserve this distinction.',
        'Independent direct-supplier CP results are recorded with their actual statuses. UNKNOWN independently rerunning a primary-INFEASIBLE orientation is not a contradiction and does not itself verify infeasibility.'
    ]
    out = dict(status='PASS_STATIC_LOGICAL_CHAIN_WITH_SCOPED_EXTERNAL_FINITE_DEPENDENCIES',
               scope='No construction Solve. Static implication audit and exact low-degree support-family mapping; detailed capacity/orbit enumeration and solver verification remain separate audited dependencies.',
               tested_compatible_core_orientations_with_multiplicity=6250496,
               distinct_capacity_passing_orientations=len(masks),
               minimum_degree_histogram=dict(sorted(degree_counts.items())),
               earlier_family_S7_images=orbit_coverage,
               all_low_degree_nonstar_masks_mapped=4812,
               low_degree_terminal_records=low_rows,
               logical_implications=implications,claim_caveats=caveats,
               primary_high_degree_relaxation_counts=dict(Counter(r['status'] for r in relax['records'])),
               independent_relaxation_counts=fraction.get('counts'),
               independent_five_survivor_statuses=[dict(label=r['label'], status=r['status']) for r in five_independent['records']],
               independent_presence_five_survivor_statuses=[dict(index=r['orbit_index'],status=r['status']) for r in presence_independent['survivors']],
               evidence_sha256=inputs,seconds=time.monotonic()-started)
    (H/'canonical_orientation_logical_chain_review.json').write_text(json.dumps(out,indent=2), encoding='utf-8')
    print({k:v for k,v in out.items() if k not in ('logical_implications','claim_caveats','low_degree_terminal_records','evidence_sha256')}, flush=True)


if __name__ == '__main__':
    main()
