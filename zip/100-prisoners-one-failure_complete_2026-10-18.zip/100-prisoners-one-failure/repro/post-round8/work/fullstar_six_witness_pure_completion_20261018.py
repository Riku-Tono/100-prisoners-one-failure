"""Independentfullstar six-correctwitness test: pure52blockpacking, noR6.
Finite node/timeUNKNOWNdoesnotexcludeawitness. Onlycompleteexhaustioncan
justifytheunique7-correcttemplate reduction requestedbytheparenttask.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict,Counter
import json,time,hashlib
H=Path(__file__).resolve().parent;start=time.monotonic()
def norm(w):
 w=tuple(w);return min(w[j:]+w[:j]for j in range(len(w)))
def correct(c):
 n=len(c);return frozenset((c[j],c[(j+1)%n],c[(j+2)%n],c[(j+3)%n],c[(j-1)%n])for j in range(n))
W=sorted({norm(p)for p in permutations(range(1,8),4)});WI={w:i for i,w in enumerate(W)};B=set()
for s in combinations(range(1,8),5):
 for tail in permutations(s[1:]):
  rr=correct((s[0],)+tail)
  for omit in rr:B.add(rr-{omit})
B=sorted(B,key=lambda b:tuple(sorted(b)));BI={b:i for i,b in enumerate(B)};RM=[sum(1<<WI[norm(r[:4])]for r in b)for b in B];COL=[0]*210
for b,mask in enumerate(RM):
 x=mask
 while x:
  bit=x&-x;x^=bit;COL[bit.bit_length()-1]|=1<<b
CONFLICT=[]
for mask in RM:
 x=mask;bad=0
 while x:
  bit=x&-x;x^=bit;bad|=COL[bit.bit_length()-1]
 CONFLICT.append(bad)
assert len(W)==210 and len(B)==2520
inc=defaultdict(list)
for b,rs in enumerate(B):
 for r in rs:inc[r].append(b)
def witnesses(c,misses):
 rs=sorted(correct(c));result=set()
 ignorelist=list(combinations(rs,misses))
 for ignored in ignorelist:
  need=set(rs)-set(ignored)
  def dfs(todo,used,chosen):
   if not todo:result.add(frozenset(chosen));return
   choices=[]
   for r in todo:
    opts=[b for b in inc[r]if not RM[b]&used]
    if not opts:return
    choices.append((len(opts),r,opts))
   for b in min(choices)[2]:dfs(todo-B[b],used|RM[b],chosen+[b])
  dfs(need,0,[])
 return result
C=tuple(range(1,8));ws=witnesses(C,1);full=witnesses(C,0);assert len(ws)==28 and len(full)==1
maps=[]
for shift in range(7):
 mp={x:(x-1+shift)%7+1 for x in range(1,8)};maps.append([BI[frozenset(tuple(mp[x]for x in r)for r in b)]for b in B])
reps=sorted({min(tuple(sorted(mp[b]for b in w))for mp in maps)for w in ws});assert len(reps)==4
source=(H/'fullstar_prepare_basic.json').read_bytes();d=json.loads(source);assert set(reps)=={tuple(s['blocks'])for s in d['seeds']}
class Limited(Exception):pass
class Engine:
 def run(self,mandatory,seconds=30,node_limit=2000000,hint=()):
  remaining=(1<<210)-1;available=(1<<2520)-1
  for b in mandatory:
   assert remaining&RM[b]==RM[b];remaining^=RM[b];available&=~CONFLICT[b]
  self.nodes=0;self.deadline=time.monotonic()+seconds;self.limit=node_limit;self.hint=sum(1<<b for b in hint);self.answer=None;self.holes=None;st=time.monotonic()
  try:found=self.dfs(remaining,available,[],[],2)
  except Limited as e:return {'status':'UNKNOWN_'+str(e),'nodes':self.nodes,'seconds':time.monotonic()-st}
  out={'status':'FOUND'if found else'EXHAUSTED_NO_COMPLETION','nodes':self.nodes,'seconds':time.monotonic()-st}
  if found:
   rows=set(mandatory)|set(self.answer);assert len(rows)==52;used=[norm(r[:4])for b in rows for r in B[b]];assert len(used)==len(set(used))==208
   out.update(blocks=sorted(rows),holes=[W[j]for j in self.holes])
  return out
 def dfs(self,left,avail,selected,holes,budget):
  self.nodes+=1
  if self.nodes>self.limit:raise Limited('NODE_LIMIT')
  if self.nodes%128==0 and time.monotonic()>self.deadline:raise Limited('WALL_LIMIT')
  if not left:
   if budget:return False
   self.answer=selected[:];self.holes=holes[:];return True
  scan=left;best=None;small=10**9;chosen=0;zeros=0
  while scan:
   bit=scan&-scan;scan^=bit;opts=COL[bit.bit_length()-1]&avail;n=opts.bit_count()
   if n==0:
    zeros+=1
    if zeros>budget:return False
   if n<small:best=opts;small=n;chosen=bit
  if small==0:
   return self.dfs(left^chosen,avail,selected,holes+[chosen.bit_length()-1],budget-1)
  while best:
   preferred=best&self.hint;bit=(preferred&-preferred)if preferred else best&-best;best^=bit;b=bit.bit_length()-1
   if self.dfs(left^RM[b],avail&~CONFLICT[b],selected+[b],holes,budget):return True
  if budget:return self.dfs(left^chosen,avail&~COL[chosen.bit_length()-1],selected,holes+[chosen.bit_length()-1],budget-1)
  return False
baseline=json.loads((H/'inputs/baseline15051.rules.json').read_text());brs={(a,*h,t)for a,h,t in baseline['rules']};known={i for i,b in enumerate(B)if b<=brs};assert len(known)==52
engine=Engine();control=engine.run(set(sorted(known)[:39]),5,2000000,known);assert control['status']=='FOUND'and len(control['blocks'])==52
out={'method':__doc__,'source_basic_sha256':hashlib.sha256(source).hexdigest(),'fullstar_blocks':len(B),'slots':len(W),'canonical_cycle':C,'six_correct_witnesses':len(ws),'C7_orbits':len(reps),'all_seven_correct_templates':[sorted(w)for w in full],'pure_packing_positive_control':control,'records':[],'status':'RUNNING'}
for index,rep in enumerate(reps):
 ext=sum(set(rep)<=u for u in full);rec={'index':index,'fixed_blocks':rep,'fixed_rules':[sorted(B[b])for b in rep],'extends_to_7correct_template':bool(ext)};rec.update(engine.run(rep,30,2000000,known));out['records'].append(rec);out['seconds']=time.monotonic()-start
 if rec['status']=='FOUND':
  rules=set().union(*(B[b]for b in rec['blocks']));path=H/f'fullstar_six_witness_pure_completion_20261018_found_{index}.rules.json';path.write_text(json.dumps({'n':8,'rules':[[r[0],list(r[1:4]),r[4]]for r in sorted(rules)],'selected_block_ids':rec['blocks'],'holes':rec['holes']},indent=2),encoding='utf-8')
  from independent_audit import audit
  checked=audit(path);assert checked['lost_cf']==0 and checked['rescued_cycles']['5']==52;rec['certificate']=str(path);rec['independent_40320_audit']=checked
 (H/'fullstar_six_witness_pure_completion_20261018.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(index,'extension',bool(ext),rec['status'],rec['nodes'],rec['seconds'],flush=True)
nonext=[r for r in out['records']if not r['extends_to_7correct_template']];out['nonextension_all_exhausted']=all(r['status']=='EXHAUSTED_NO_COMPLETION'for r in nonext);out['nonextension_found']=any(r['status']=='FOUND'for r in nonext);out['status']='UNIQUE_TEMPLATE_REDUCTION_SUPPORTED'if out['nonextension_all_exhausted']else'REDUCTION_NOT_ESTABLISHED';out['seconds']=time.monotonic()-start;(H/'fullstar_six_witness_pure_completion_20261018.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('FINAL',out['status'],out['seconds'],flush=True)
