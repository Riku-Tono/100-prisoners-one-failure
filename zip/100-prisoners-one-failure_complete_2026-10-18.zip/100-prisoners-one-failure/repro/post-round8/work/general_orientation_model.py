"""Full 210-slot CP-SAT model for arbitrary support flips from the [7] star.

R5=52 is represented by 52 noncolliding four-rule five-cycle blocks and at
most two other rules. All 8 labels, every active slot and every admissible
single rule are retained. No old/new split, base-seven bound, or extra-rule
marginal-gain lemma is used. R6 is exactly zero; the target is R7+R8>=target.

Import/build is inert. `controls` fixes existing certificates completely.
`search` is an explicit future entry point; it is not run by the controls.
The general block/slot representation is an inherited structural assumption.
"""
from __future__ import annotations
from pathlib import Path
from itertools import combinations,permutations
from collections import defaultdict,Counter
from dataclasses import dataclass
from functools import lru_cache
import argparse,hashlib,json,sys,time

ORTOOLS_RUNTIME=Path(r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
if str(ORTOOLS_RUNTIME) not in sys.path:sys.path.insert(0,str(ORTOOLS_RUNTIME))
from ortools.sat.python import cp_model

H=Path(__file__).resolve().parent
LABELS=frozenset(range(1,9))
Rule=tuple[int,int,int,int,int]
Cycle=tuple[int,...]

def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]

def correct(c):
    n=len(c)
    return frozenset((c[j],c[(j+1)%n],c[(j+2)%n],c[(j+3)%n],c[(j-1)%n]) for j in range(n))

@lru_cache(maxsize=None)
def cycle_data(k):
    return tuple(((s[0],)+p,correct((s[0],)+p)) for s in combinations(range(1,9),k) for p in permutations(s[1:]))

def normalize_flips(flips):
    result=[]
    for support in flips:
        s=tuple(sorted(support))
        if len(s)!=4 or len(set(s))!=4 or not set(s)<=set(range(1,8)):
            raise ValueError('Every flipped support must be a four-subset of labels 1..7.')
        result.append(s)
    if len(set(result))!=len(result):raise ValueError('Duplicate flipped supports are not allowed.')
    return tuple(sorted(result))

@dataclass(frozen=True)
class OrientationData:
    flips:tuple[tuple[int,...],...]
    active_supports:frozenset[frozenset[int]]
    words:tuple[Cycle,...]
    blocks:tuple[frozenset[Rule],...]
    singles:tuple[Rule,...]

@lru_cache(maxsize=16)
def _orientation_data(flips):
    active={frozenset(s) for s in combinations(range(1,8),4)}
    for support in flips:
        s=frozenset(support);active.remove(s);active.add(LABELS-s)
    assert len(active)==35
    words=tuple(c for c,rr in cycle_data(4) if frozenset(c) in active)
    wordset=set(words);blocks=set()
    for c,rr in cycle_data(5):
        for omitted in rr:
            b=rr-{omitted}
            if all(canon(r[:4]) in wordset for r in b):blocks.add(b)
    blocks=tuple(sorted(blocks,key=lambda rs:tuple(sorted(rs))))
    singles=tuple(sorted(w[j:]+w[:j]+(t,) for w in words for j in range(4) for t in sorted(LABELS-set(w))))
    assert len(words)==210 and len(singles)==3360 and len(set(singles))==3360
    assert all(len({canon(r[:4]) for r in b})==4 for b in blocks)
    return OrientationData(flips,frozenset(active),words,blocks,singles)

def orientation_data(flips=()):
    return _orientation_data(normalize_flips(flips))

@dataclass
class OrientationModel:
    data:OrientationData
    target:int
    model:object
    blocks:list
    singles:dict
    present:dict
    rescue_flags:dict
    stats:dict

    def certificate_assignment(self,rules):
        """Represent a fixed known table as exactly52 blocks + <=2 singles.

        A full five-rule group contributes one chosen four-rule block and
        its remaining rule as a singleton. No rule table is silently padded.
        """
        rules=frozenset(map(tuple,rules));groups=defaultdict(set)
        if not rules<=self.singles.keys():raise ValueError('The certificate has an inactive or invalid rule.')
        for r in rules:groups[canon((r[4],)+r[:4])].add(r)
        lookup=defaultdict(list)
        for i,b in enumerate(self.data.blocks):lookup[canon((next(iter(b))[4],)+next(iter(b))[:4])].append(i)
        selected=set()
        for five,rr in groups.items():
            if len(rr)>=4:
                options=[i for i in lookup[five] if self.data.blocks[i]<=rr]
                if not options:raise ValueError('A rescued five-cycle group has no permitted four-rule block.')
                selected.add(min(options))
        if len(selected)!=52:raise ValueError(f'Expected52 rescued five-cycle groups, got{len(selected)}.')
        supplied=set().union(*(self.data.blocks[i] for i in selected))
        extras=rules-supplied
        if len(supplied)!=208 or len(extras)>2:raise ValueError('The table does not have the requested52-block representation.')
        slots=[canon(r[:4]) for r in rules]
        if len(slots)!=len(set(slots)):raise ValueError('The certificate has colliding lossword slots.')
        return selected,extras

    def fix_certificate(self,rules):
        selected,extras=self.certificate_assignment(rules)
        for i,v in enumerate(self.blocks):self.model.add(v==int(i in selected))
        for r,v in self.singles.items():self.model.add(v==int(r in extras))
        return dict(fixed_blocks=len(selected),fixed_singles=len(extras),rules=208+len(extras))

    def export_and_audit(self,solver,path,audit_path=None):
        """Export an actual feasible solution, then directly simulate40320 layouts."""
        path=Path(path)
        selected=[i for i,v in enumerate(self.blocks) if solver.value(v)]
        extras={r for r,v in self.singles.items() if solver.value(v)}
        rules=set().union(*(self.data.blocks[i] for i in selected))|extras
        assert len(selected)==52 and len(extras)<=2 and len(rules)==208+len(extras)
        predicted={str(k):sum(solver.value(v) if not isinstance(v,int) else v for v in self.rescue_flags[k].values()) for k in (7,8)}
        cert=dict(schema='mixed-n8-v1',n=8,flipped_supports=self.data.flips,rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(rules)],selected_block_ids=selected,single_rules=sorted(extras),model_prediction=dict(R5=52,R6=0,R7=predicted['7'],R8=predicted['8']))
        path.write_text(json.dumps(cert,indent=2),encoding='utf-8')
        from independent_audit import audit
        checked=audit(path)
        assert checked['placements']==40320 and checked['lost_cf']==0 and checked['rescued_cycles']['5']==52 and checked['rescued_cycles']['6']==0
        assert all(checked['rescued_cycles'][str(k)]==predicted[str(k)] for k in (7,8))
        assert predicted['7']+predicted['8']>=self.target
        assert checked['wins']==14736+6*52+predicted['7']+predicted['8']
        audit_path=Path(audit_path) if audit_path is not None else path.with_suffix('.audit.json')
        audit_path.write_text(json.dumps(checked,indent=2),encoding='utf-8')
        return dict(certificate=str(path),direct_audit=str(audit_path),audit=checked)

def build(flips=(),target=4):
    if not isinstance(target,int) or target<0:raise ValueError('target must be a nonnegative integer.')
    start=time.monotonic();data=orientation_data(flips);m=cp_model.CpModel()
    bs=[m.new_bool_var(f'b{i}') for i in range(len(data.blocks))]
    ss={r:m.new_bool_var(f's{i}') for i,r in enumerate(data.singles)}
    columns=defaultdict(list);terms=defaultdict(list)
    for i,rs in enumerate(data.blocks):
        for r in rs:columns[canon(r[:4])].append(bs[i]);terms[r].append(bs[i])
    for r,v in ss.items():columns[canon(r[:4])].append(v);terms[r].append(v)
    for w in data.words:m.add_at_most_one(columns[w])
    m.add(sum(bs)==52);m.add(sum(ss.values())<=2)
    present={r:m.new_bool_var(f'p{i}') for i,r in enumerate(data.singles)}
    for r,v in present.items():m.add(v==sum(terms[r]))
    six_constraints=0
    for c,rr in cycle_data(6):
        eligible=[present[r] for r in rr if r in present]
        if len(eligible)>=5:m.add(sum(eligible)<=4);six_constraints+=1
    flags={};nonzero={}
    for k in (7,8):
        flags[k]={};nonzero[k]=0
        for c,rr in cycle_data(k):
            eligible=[present[r] for r in rr if r in present]
            if len(eligible)<k-1:
                flags[k][c]=0 # Impossible positive flag is identically false.
                continue
            z=m.new_bool_var(f'R{k}_{nonzero[k]}');nonzero[k]+=1;flags[k][c]=z
            count=sum(eligible)
            m.add(count>=k-1).only_enforce_if(z)
            m.add(count<=k-2).only_enforce_if(z.Not())
    m.add(sum(flags[7].values())+sum(flags[8].values())>=target)
    stats=dict(flips=data.flips,slots=len(data.words),blocks=len(bs),all_single_options=len(ss),six_cycles=len(cycle_data(6)),six_constraints=six_constraints,seven_cycles=len(flags[7]),seven_variable_flags=nonzero[7],eight_cycles=len(flags[8]),eight_variable_flags=nonzero[8],target=target,build_seconds=time.monotonic()-start)
    return OrientationModel(data,target,m,bs,ss,present,flags,stats)

def read_rules(path):
    d=json.loads(Path(path).read_text(encoding='utf-8-sig'))
    return frozenset((a,*h,t) for a,h,t in d['rules'])

def run_controls():
    std3=((1,2,3,4),(1,2,3,5),(1,2,3,6))
    specs=[('fullstar_baseline208',(),3,H/'inputs/baseline15051.rules.json','OPTIMAL'),('standard3_r6zero15049',std3,1,H/'agent_full_r6zero_control.rules.json','OPTIMAL'),('standard3_known_r6one_rejected',std3,1,H/'inputs/new15051.rules.json','INFEASIBLE')]
    out=dict(scope='completely fixed positive/negative controls only; no new construction search',records=[])
    for label,flips,target,source,expected in specs:
        model=build(flips,target);fixed=model.fix_certificate(read_rules(source))
        solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.max_time_in_seconds=15
        st=solver.solve(model.model);name=solver.status_name(st)
        assert name==expected,(label,name)
        rec=dict(label=label,source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),stats=model.stats,fixed=fixed,status=name,solve_seconds=solver.wall_time)
        if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            rec.update(model.export_and_audit(solver,H/f'general_orientation_control_{label}.rules.json',H/f'general_orientation_control_{label}.audit.json'))
        else:
            from independent_audit import audit
            checked=audit(source);assert checked['rescued_cycles']['6']==1
            rec['rejected_certificate_direct_audit']=checked
        out['records'].append(rec)
        (H/'general_orientation_controls.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        print(label,name,fixed,'R',rec.get('audit',rec.get('rejected_certificate_direct_audit',{})).get('rescued_cycles'),flush=True)
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('controls')
    s=sub.add_parser('search');s.add_argument('--flips',required=True,help='JSON array of four-subsets of1..7, e.g. []')
    s.add_argument('--target',type=int,default=4);s.add_argument('--seconds',type=float,default=120);s.add_argument('--workers',type=int,default=1);s.add_argument('--seed',type=int,default=1);s.add_argument('--output',required=True)
    a=p.parse_args()
    if a.command=='controls':run_controls();return
    model=build(json.loads(a.flips),a.target);solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=a.seconds;solver.parameters.num_search_workers=a.workers;solver.parameters.random_seed=a.seed
    st=solver.solve(model.model);result=dict(scope=__doc__,stats=model.stats,status=solver.status_name(st),solve_seconds=solver.wall_time,response_stats=solver.response_stats())
    output=Path(a.output)
    if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):result.update(model.export_and_audit(solver,output))
    output.with_suffix('.result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result),flush=True)

if __name__=='__main__':main()
