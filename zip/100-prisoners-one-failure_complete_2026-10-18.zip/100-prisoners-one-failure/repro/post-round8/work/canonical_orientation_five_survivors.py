"""Target4 search in the five S8 support-relaxation survivors.

Uses the full fixed-orientation eight-label model, with no witness core
fixed and no support-relaxation pattern counts imposed. UNKNOWN is open.
"""
from pathlib import Path
import json,time,hashlib
from general_orientation_model import build,H,cp_model
def main():
    source=H/'canonical_orientation_S8_classification.json';data=json.loads(source.read_text());orbits={x['index']:x for x in data['orbits']}
    relax=H/'canonical_orientation_support_relaxation.json';rr=json.loads(relax.read_text());assert rr['complete']
    survivors=[r['index'] for r in rr['records'] if r['status']!='INFEASIBLE'];assert survivors==[1255,1291,1305,1319,1376]
    out=dict(scope=__doc__,classification_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),relaxation_sha256=hashlib.sha256(relax.read_bytes()).hexdigest(),records=[])
    for i in survivors:
        record=orbits[i];m=build(record['flips'],4);assert not m.model.validate()
        s=cp_model.CpSolver();s.parameters.num_search_workers=1;s.parameters.max_time_in_seconds=120
        s.parameters.log_search_progress=True;s.parameters.log_to_stdout=False
        prefix=H/f'canonical_orientation_survivor_{i}'
        with prefix.with_suffix('.log.txt').open('w',encoding='utf-8') as f:
            s.log_callback=lambda x:f.write(x+'\n');st=s.solve(m.model)
        r=dict(index=i,canonical_S8_key_hex=record['canonical_S8_key_hex'],stats=m.stats,status=s.status_name(st),solve_seconds=s.wall_time,response_stats=s.response_stats(),workers=1,limit=120)
        if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):r.update(m.export_and_audit(s,prefix.with_suffix('.rules.json')))
        prefix.with_suffix('.result.json').write_text(json.dumps(r,indent=2),encoding='utf-8');out['records'].append(r)
        (H/'canonical_orientation_five_survivors.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        print(i,r['status'],r['solve_seconds'],flush=True)
if __name__=='__main__':main()
