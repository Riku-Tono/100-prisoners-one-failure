"""Post-audit sevenflip fullgeneric8label target4 searches, remainingassignedorbits."""
from pathlib import Path
import sys,json,time,datetime,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));import general_orientation_model as G
raw=(H/'post_audit_sevenflip_20261018_screen.json').read_bytes();screen=json.loads(raw);byid={r['index']:r for r in screen['orbits']};order=[5,15,1,0,10,7,2,6,14,13,4];start=time.monotonic();batch={'scope':__doc__,'model_scope':G.__doc__,'screen_sha256':hashlib.sha256(raw).hexdigest(),'general_model_sha256':hashlib.sha256((H/'general_orientation_model.py').read_bytes()).hexdigest(),'assigned_orbits':order,'workers':1,'seconds_per_solve':120,'records':[],'status':'RUNNING'}
def save():
 batch['seconds']=time.monotonic()-start;(H/'post_audit_sevenflip_20261018_search_remaining_summary.json').write_text(json.dumps(batch,indent=2),encoding='utf-8')
# Keep total solverworkers atonefor thisagent: waitfortop3beforecontinuing.
waitstart=time.monotonic()
while True:
 try:prior=json.loads((H/'post_audit_sevenflip_20261018_search_top3_summary.json').read_text())
 except(json.JSONDecodeError,FileNotFoundError):time.sleep(2);continue
 if prior['status']!='RUNNING':break
 time.sleep(2)
batch['waiting_for_top3_seconds']=time.monotonic()-waitstart
if prior['status'].startswith('TARGET4_FOUND'):
 batch['status']='SKIPPED_TARGET4_ALREADY_FOUND';save();raise SystemExit(0)
for index in order:
 spec=byid[index];assert spec['passes_52_word_capacity'];label=f'post_audit_sevenflip_20261018_orbit{index}_target4';model=G.build(spec['flips'],target=4);assert model.model.validate()=='';assert len(model.blocks)==spec['actual_rule_blocks'];assert model.stats['seven_variable_flags']==spec['long_cycle_support_eligibility']['7']['eligible_total'];modelpath=H/(label+'.model.txt');assert model.model.export_to_file(str(modelpath));record={'orbit_index':index,'flip_count':7,'target':4,'scope':G.__doc__,'flips':model.data.flips,'stats':model.stats,'validation_passed':True,'independent_block_and_eligible7_counts_match':True,'status':'RUNNING','workers':1,'random_seed':20261018+1000+index,'model_proto_text':str(modelpath),'model_proto_sha256':hashlib.sha256(modelpath.read_bytes()).hexdigest(),'auxiliary_sixflip_structure_assumptions_used':False,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};path=H/(label+'.result.json');path.write_text(json.dumps(record,indent=2),encoding='utf-8');batch['current']={'orbit_index':index,'result':str(path)};save();print('START',index,flush=True)
 solver=G.cp_model.CpSolver();solver.parameters.max_time_in_seconds=120;solver.parameters.num_search_workers=1;solver.parameters.random_seed=record['random_seed'];(H/(label+'.parameters.txt')).write_text(str(solver.parameters),encoding='utf-8');status=solver.solve(model.model);record.update(status=solver.status_name(status),solve_seconds=solver.wall_time,response_stats=solver.response_stats(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());response=H/(label+'.response.txt');response.write_text(str(solver.response_proto),encoding='utf-8');record['solver_response_proto_text']=str(response)
 if status in(G.cp_model.FEASIBLE,G.cp_model.OPTIMAL):record.update(model.export_and_audit(solver,H/(label+'.rules.json'),H/(label+'.audit.json')))
 path.write_text(json.dumps(record,indent=2),encoding='utf-8');batch['records'].append(record);batch.pop('current',None);save();print('END',index,record['status'],record['solve_seconds'],record.get('audit',{}).get('wins'),flush=True)
 if status in(G.cp_model.FEASIBLE,G.cp_model.OPTIMAL):batch['status']='TARGET4_FOUND';batch['found_orbit']=index;save();break
else:batch['status']='ASSIGNED_BOUNDED_SEARCHES_FINISHED';save()
print('FINAL',batch['status'],batch['seconds'],flush=True)
