"""Enumerate four-flip seven-cycle witnesses; no CP solving/completion.

Uses general_orientation_model.orientation_data's actual1920 blocks and
210 lossword columns. Every witness respects full lossword noncollision.
The group S{1,2,3} x S{4,5,6,7} fixes8 and has144 elements. No block-only
seven-cycle bound from another orientation is assumed.
"""
from general_orientation_model import orientation_data,canon,correct
from itertools import permutations,combinations
from collections import defaultdict,Counter
from pathlib import Path
import json,time
H=Path(__file__).resolve().parent
FLIPS=((1,2,3,4),(1,2,3,5),(1,2,3,6),(1,2,3,7))

def prepare():
    start=time.monotonic();data=orientation_data(FLIPS)
    blocks=data.blocks;rows=[frozenset(canon(r[:4]) for r in b) for b in blocks]
    lookup={b:i for i,b in enumerate(blocks)};inc=defaultdict(set)
    for i,b in enumerate(blocks):
        for r in b:inc[r].add(i)
    group=[]
    for a in permutations((1,2,3)):
        for b in permutations((4,5,6,7)):
            group.append(dict(zip(range(1,9),a+b+(8,))))
    cycles=[(1,)+p for p in permutations(range(2,8))]
    remaining=set(cycles);cycle_orbits=[]
    while remaining:
        rep=min(remaining);orbit={canon(tuple(g[x] for x in rep)) for g in group}
        assert len(orbit)==144 and orbit<=set(cycles)
        cycle_orbits.append((rep,orbit));remaining-=orbit
    assert len(cycle_orbits)==5
    def witnesses(c):
        rr=correct(c);found=set()
        for ignore in rr:
            def dfs(todo,used,chosen):
                if not todo:found.add(frozenset(chosen));return
                opts=[]
                for r in todo:
                    bb=[b for b in inc[r] if not rows[b]&used]
                    if not bb:return
                    opts.append((len(bb),r,bb))
                for b in min(opts)[2]:dfs(todo-blocks[b],used|rows[b],chosen|{b})
            dfs(rr-{ignore},frozenset(),frozenset())
        return sorted(found,key=lambda w:tuple(sorted(w)))
    reps=[];orbit_stats=[]
    for c,orbit in cycle_orbits:
        ws=witnesses(c)
        orbit_stats.append({'representative_cycle':c,'cycle_orbit_size':len(orbit),'active_four_window_count':sum(canon(r[:4]) in data.words for r in correct(c)),'witnesses_per_cycle':len(ws)})
        for w in ws:reps.append({'cycle':c,'blocks':sorted(w),'actual_rules':[sorted(blocks[b]) for b in sorted(w)]})
    # Construct full block permutations only after representative enumeration.
    maps=[]
    for g in group:
        maps.append([lookup[frozenset(tuple(g[x] for x in r) for r in b)] for b in blocks])
    global_w=[];parents=[];witness_type=[];normalizers={}
    for rep_id,rep in enumerate(reps):
        for gi,(g,mp) in enumerate(zip(group,maps)):
            c=canon(tuple(g[x] for x in rep['cycle']))
            w=frozenset(mp[b] for b in rep['blocks'])
            # The cycle stabilizer in a144-element group is trivial, because
            # any nonidentity stabilizing a directed7cycle has order7.
            key=(c,w);assert key not in normalizers
            normalizers[key]=(rep_id,gi)
            global_w.append(w);parents.append(c);witness_type.append(rep_id)
            supplied=set().union(*(blocks[b] for b in w))
            used=[s for b in w for s in rows[b]]
            assert len(w)==6 and len(used)==len(set(used))==24
            assert len(correct(c)&supplied)>=6
            assert all(8 not in r for r in supplied)
    assert len(global_w)==144*len(reps)
    assert len(set(global_w))==len(global_w)
    result={'status':'PREPARED_ENUMERATION_ONLY_NO_SOLVE','scope':__doc__,'flipped_supports':FLIPS,'slots':len(data.words),'all_blocks':len(blocks),'old_label_blocks':sum(all(8 not in r for r in b) for b in blocks),'group_order':len(group),'seven_cycles':len(cycles),'cycle_orbits':orbit_stats,'witness_cycles':sum(x['cycle_orbit_size'] for x in orbit_stats if x['witnesses_per_cycle']),'all_witnesses':len(global_w),'witness_orbits':len(reps),'witness_size_histogram':dict(Counter(map(len,global_w))),'seconds':time.monotonic()-start,'representative_witnesses':reps,'all_witness_data':[{'cycle':c,'blocks':sorted(w),'orbit':o} for c,w,o in zip(parents,global_w,witness_type)]}
    return result,data,rows,group,maps,global_w,parents,witness_type,normalizers

def main():
    result,*_=prepare()
    (H/'fourflip_witness_preparation_data.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print({k:v for k,v in result.items() if k not in ('scope','representative_witnesses','all_witness_data')},flush=True)
if __name__=='__main__':main()
