"""Bounded exact-cover probe; TIMEOUT is unresolved, never infeasible."""
import json,time,itertools,sys
from pathlib import Path
root=Path(__file__).parent
out=[]
retry='--retry' in sys.argv
previous=json.loads((root/'completion_probe.json').read_text()) if retry else []
for case in range(1,5):
    d=json.loads((root/f'witnesses_{case}.json').read_text())
    masks=[int(b['mask']) for b in d['blocks']]
    cols=[0]*210
    for j,m in enumerate(masks):
        for c in range(210):
            if m>>c&1:cols[c]|=1<<j
    conflict=[]
    for m in masks:
        x=0
        while m:
            bit=m&-m;m-=bit;x|=cols[bit.bit_length()-1]
        conflict.append(x)
    hintmask=0
    def dfs(rem,avail,selected):
        global nodes
        nodes+=1
        if nodes%256==0 and time.perf_counter()>deadline:raise TimeoutError
        if not rem:return selected
        x=rem;best=None;bestn=10**9
        while x:
            bit=x&-x;x-=bit;o=cols[bit.bit_length()-1]&avail;n=o.bit_count()
            if n<bestn:best,bestn=o,n
            if n<=1:break
        if not best:return None
        while best:
            preferred=best&hintmask
            bit=(preferred&-preferred) if preferred else (best&-best)
            best-=bit;b=bit.bit_length()-1
            ans=dfs(rem^masks[b],avail&~conflict[b],selected+[b])
            if ans is not None:return ans
        return None
    if case==2:
        raw=json.loads((root/'inputs/new15051.rules.json').read_text())
        rr={(a,*h,t) for a,h,t in raw['rules']}
        def cr(c):return [(c[k],c[(k+1)%len(c)],c[(k+2)%len(c)],c[(k+3)%len(c)],c[(k-1)%len(c)]) for k in range(len(c))]
        found=[]
        for s in itertools.combinations(range(1,9),6):
            for tail in itertools.permutations(s[1:]):
                c=(s[0],)+tail;bad=[r[0] for r in cr(c) if r not in rr]
                if len(bad)<=1:found.append((c,bad))
        assert len(found)==1 and len(found[0][1])==1
        c,bad=found[0];t=d['six_cycle'];f=d['failing'];a=c.index(bad[0]);b=t.index(f)
        mp={c[(a+k)%6]:t[(b+k)%6] for k in range(6)}
        for u,v in zip(sorted(set(range(1,9))-set(c)),sorted(set(range(1,9))-set(t))):mp[u]=v
        mapped={tuple(mp[x] for x in r) for r in rr}
        hintmask=sum(1<<k for k,bl in enumerate(d['blocks']) if all(tuple(r) in mapped for r in bl['rules']))
    tasks=[('control',None)] if case==2 else []
    edges=[r['edge'] for r in previous if r['case']==case and r['kind']=='pair' and r['status']=='TIMEOUT'] if retry else d['edges']
    tasks += [('pair',edge) for edge in edges]
    summary=dict(case=case,tested=0,exhausted=0,timeouts=0,found=0,total_nodes=0)
    for kind,edge in tasks:
        chosen=set(d['fixed_blocks'])
        if edge:
            i,j=edge;chosen|=set(d['witness_blocks'][i])|set(d['witness_blocks'][j])
        occ=int(d['occupied_mask']);alive=(1<<len(masks))-1
        for c in range(210):
            if occ>>c&1:alive&=~cols[c]
        for bl in chosen:occ|=masks[bl];alive&=~conflict[bl]
        start=time.perf_counter();deadline=start+(1.0 if retry else 0.15);nodes=0
        try:
            ans=dfs(((1<<210)-1)^occ,alive,[])
            status='FOUND' if ans is not None else 'EXHAUSTED_NO_COMPLETION'
        except TimeoutError:status='TIMEOUT';ans=None
        if kind=='control':
            assert status=='FOUND',(status,nodes)
            print('positive control FOUND',len(ans),'additional blocks',flush=True)
        else:
            summary['tested']+=1;summary['total_nodes']+=nodes
            summary['exhausted' if status=='EXHAUSTED_NO_COMPLETION' else 'timeouts' if status=='TIMEOUT' else 'found']+=1
        rec=dict(case=case,kind=kind,edge=edge,status=status,nodes=nodes,seconds=time.perf_counter()-start,additional_blocks=ans)
        out.append(rec)
        if status=='FOUND' and kind=='pair':print(rec,flush=True)
    print(summary,flush=True)
(root/('completion_retry.json' if retry else 'completion_probe.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
