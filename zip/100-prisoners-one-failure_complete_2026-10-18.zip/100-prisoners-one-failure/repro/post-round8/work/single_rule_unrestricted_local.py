"""Control: remove all forbidden supports; test one canonical extra rule.
Permutation symmetry makes all five-distinct-label rules equivalent here.
Still a local block-packing question, not a completed 52-block strategy.
"""
from itertools import permutations
from collections import defaultdict
from pathlib import Path
import json
def canon(c):
    c=tuple(c);return min(c[i:]+c[:i] for i in range(len(c)))
def rules(c):
    n=len(c);return frozenset((c[i],c[(i+1)%n],c[(i+2)%n],c[(i+3)%n],c[(i-1)%n]) for i in range(n))
bb=set()
for c in permutations(range(1,8),5):
    if c[0]!=min(c):continue
    rr=rules(c)
    for omitted in rr:bb.add(rr-{omitted})
blocks=sorted(bb,key=lambda rs:tuple(sorted(rs)))
slots=[frozenset(canon(r[:4]) for r in b) for b in blocks]
inc=defaultdict(set)
for i,b in enumerate(blocks):
    for r in b:inc[r].add(i)
r=(1,2,3,4,5);cc=[(1,2,3,4,6,7,5),(1,2,3,4,7,6,5)]
def wit(c):
    out=set()
    for omit in rules(c)-{r}:
        def dfs(todo,occupied,chosen):
            if not todo:out.add(frozenset(chosen));return
            candidates=[]
            for q in todo:
                options=[b for b in inc[q] if not slots[b]&occupied]
                if not options:return
                candidates.append((len(options),q,options))
            for b in min(candidates)[2]:dfs(todo-blocks[b],occupied|slots[b],chosen|{b})
        dfs(rules(c)-{r,omit},frozenset({canon(r[:4])}),frozenset())
    return out
ww=[wit(c) for c in cc];result={'allowed_blocks':len(blocks),'witness_counts':list(map(len,ww)),'found':False}
occupied=[[(w,frozenset().union(*(slots[i] for i in w))) for w in ws] for ws in ww]
core=[set.intersection(*(set(s) for w,s in ws)) for ws in occupied]
result['common_forced_slots']=[sorted(s) for s in core]
result['minimum_slot_conflicts']=min(len((sa&sb)-frozenset().union(*(slots[i] for i in a&b))) for a,sa in occupied[0] for b,sb in occupied[1])
result['maximum_shared_blocks']=max(len(a&b) for a in ww[0] for b in ww[1])
for a in ww[0]:
    for b in ww[1]:
        used=[s for i in a|b for s in slots[i]]
        if len(used)!=len(set(used)):continue
        rs=frozenset().union(*(blocks[i] for i in a|b))
        before=[len(rs&rules(c)) for c in cc]
        if max(before)>5:continue
        result.update(found=True,before=before,rule=r,cycles=cc,selected_blocks=[sorted(blocks[i]) for i in sorted(a|b)])
        break
    if result['found']:break
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print({k:v for k,v in result.items() if k!='selected_blocks'})
