"""Independent residual-row CP for an already target4 critical core.

No main or generic builder is imported. All actual rows come from Claude's
cycle generator. Once a critical core has four rescued sevens, other useful
singletons can be removed; remaining holes may be filled by neutral target8
rules in fullstar only. Search therefore keeps only mandatory extras and
52 disjoint blocks, with every six-cycle count<=4. UNKNOWN stays unresolved.
"""
from pathlib import Path
from itertools import combinations
from collections import defaultdict,Counter
import sys,json,time,hashlib,argparse
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'claude_desktop_continuation3'))
sys.path.insert(0,r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
from c3_model import Orientation,cyc_rules,directed_cycles,word
from ortools.sat.python import cp_model
from independent_audit import audit
o=Orientation(list(map(frozenset,combinations(range(1,8),4))))
B=tuple(sorted(map(frozenset,o.blocks),key=lambda b:tuple(sorted(b))))
W=tuple(sorted(o.words));BS=[frozenset(word(r) for r in b) for b in B]
SIX=tuple(frozenset(cyc_rules(c)) for s in combinations(range(1,8),6) for c in directed_cycles(s))
RI=defaultdict(list)
for i,rs in enumerate(SIX):
    for r in rs:RI[r].append(i)
DELTA=[Counter(i for r in b for i in RI[r]) for b in B]
CAT=hashlib.sha256(json.dumps([sorted(b) for b in B],separators=(',',':')).encode()).hexdigest()
def solve(mandatory,extras,seconds,prefix,hint=(),minimum=15052):
    mandatory=frozenset(mandatory);extras=frozenset(map(tuple,extras));assert len(extras)<=2
    rr=frozenset().union(*(B[b] for b in mandatory))|extras
    slots=[word(r) for r in rr];assert len(rr)==4*len(mandatory)+len(extras) and len(slots)==len(set(slots))
    occupied=frozenset(slots);left=set(W)-occupied;rows=[b for b in range(len(B)) if not BS[b]&occupied]
    initial=[len(rs&rr) for rs in SIX];assert max(initial)<=4
    m=cp_model.CpModel();xs={b:m.new_bool_var(f'b{b}') for b in rows};cols=defaultdict(list);terms=defaultdict(list)
    for b,v in xs.items():
        for w in BS[b]:cols[w].append(v)
        for k,n in DELTA[b].items():terms[k].append(n*v)
    m.add(sum(xs.values())==52-len(mandatory))
    for w in left:m.add_at_most_one(cols[w])
    for k,terms_k in terms.items():m.add(sum(terms_k)<=4-initial[k])
    for b,v in xs.items():
        if hint:m.add_hint(v,int(b in hint))
    assert not m.validate();prefix=Path(prefix)
    s=cp_model.CpSolver();s.parameters.num_search_workers=1;s.parameters.max_time_in_seconds=seconds;s.parameters.random_seed=37
    s.parameters.log_search_progress=True;s.parameters.log_to_stdout=False
    m.export_to_file(str(prefix.with_suffix('.model.pbtxt')));prefix.with_suffix('.parameters.txt').write_text(str(s.parameters))
    with prefix.with_suffix('.log.txt').open('w',encoding='utf-8') as f:
        s.log_callback=lambda x:f.write(x+'\n');st=s.solve(m)
    result=dict(scope=__doc__,status=s.status_name(st),seconds=s.wall_time,mandatory_blocks=len(mandatory),mandatory_extras=len(extras),
        candidate_rows=len(rows),free_words=len(left),required_additional_blocks=52-len(mandatory),six_constraints=len(terms),
        response_stats=s.response_stats(),catalogue_sha256=CAT)
    if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):
        chosen=mandatory|{b for b,v in xs.items() if s.value(v)};base=frozenset().union(*(B[b] for b in chosen))|extras
        holes=set(W)-{word(r) for r in base};assert len(holes)==2-len(extras)
        rules=base|{tuple(w)+(8,) for w in holes};assert len(chosen)==52 and len(rules)==210
        path=prefix.with_suffix('.rules.json');path.write_text(json.dumps(dict(rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(rules)],selected_block_ids=sorted(chosen)),indent=2))
        checked=audit(path);assert checked['placements']==40320 and checked['lost_cf']==0 and checked['rescued_cycles']['5']==52 and checked['rescued_cycles']['6']==0 and checked['wins']>=minimum
        result.update(certificate=str(path),independent_direct_audit=checked)
    prefix.with_suffix('.result.json').write_text(json.dumps(result,indent=2));print(prefix.name,result['status'],result['seconds'],flush=True);return result
def main():
    p=argparse.ArgumentParser();p.add_argument('--index',type=int,default=909);p.add_argument('--seconds',type=float,default=120);a=p.parse_args()
    cert=json.loads((H/'inputs/baseline15051.rules.json').read_text());rules={(x,*h,t) for x,h,t in cert['rules']};known={i for i,b in enumerate(B) if b<=rules};assert len(known)==52
    control=solve(set(sorted(known)[:39]),[],10,H/'fullstar_critical_small_cp_positive',hint=known,minimum=15051);assert control['status']=='OPTIMAL'
    src=H/'fullstar_priority63_first.critical.json';d=json.loads(src.read_text());assert d['block_catalogue_sha256']==CAT
    core=d['records'][a.index];assert core['index']==a.index
    actual=frozenset(frozenset(map(tuple,b)) for b in d['fixed_actual_blocks']+core['additional_actual_blocks'])
    assert actual==frozenset(B[b] for b in core['core_blocks'])
    fixed=frozenset().union(*actual)|frozenset(map(tuple,core['critical_extra_rules']))
    assert sum(len(fixed&frozenset(cyc_rules(c)))>=6 for c in directed_cycles(range(1,8)))>=4
    result=solve(core['core_blocks'],core['critical_extra_rules'],a.seconds,H/f'fullstar_core4_critical{a.index}_small_cp')
    proof=dict(source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),index=a.index,control=control,result=result)
    (H/f'fullstar_core4_critical{a.index}_small_cp_provenance.json').write_text(json.dumps(proof,indent=2))
if __name__=='__main__':main()
