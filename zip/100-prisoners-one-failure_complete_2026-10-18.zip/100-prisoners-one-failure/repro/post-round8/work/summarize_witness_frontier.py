"""Merge successful exclusions without upgrading UNKNOWN or unfinished work."""
from pathlib import Path
from collections import Counter
import json,hashlib
H=Path(__file__).parent
closed={};attempts=Counter();cores={}
for name in ('agent_seed_pair_reduced_0.json','agent_seed_pair_reduced_5.json'):
    data=json.loads((H/name).read_text())
    for r in data['records']:
        if r['status']=='INFEASIBLE':closed[r['index']]=dict(method='reduced CP-SAT',file=name)
patterns=('agent_seed_local_completion_[0-9]*.json','agent_pair_local_batch_[0-9]*.json','agent_pair_local_batch835_[0-9]*.json','agent_local_batch_*_[0-9]*.json','agent_local_[0-9]*_[0-9]*.json','root_pair_local_*_[0-9]*.json')
for path in sorted({p for pattern in patterns for p in H.glob(pattern)}):
    try:data=json.loads(path.read_text())
    except json.JSONDecodeError:continue # Concurrent checkpoint, reconsider next run.
    if 'seed_index' not in data:continue
    status=data.get('status','UNKNOWN');attempts[status]+=1
    index=data['seed_index']
    if status=='LOCAL_INFEASIBLE':closed[index]=dict(method='local CP-SAT + exhaustive exact cover',file=path.name)
    for r in data.get('records',[]):
        if r['status'].startswith('EXHAUSTED'):
            key=(tuple(r['core_blocks']),tuple(map(tuple,r['extras'])))
            cores[key]=dict(file=path.name,iteration=r['iteration'])
total=913
out=dict(scope='standard three-flip,R5=52,R6=0,R7>=4; conditional on block decomposition and finite extra-rule lemmas',total_pair_union_orbits=total,closed_count=len(closed),open_count=total-len(closed),closed={str(k):v for k,v in sorted(closed.items())},open_indices=sorted(set(range(total))-closed.keys()),unique_exhausted_local_cores=len(cores),attempt_status_counts=dict(attempts),seed_file_sha256=hashlib.sha256((H/'witness_pair_seeds.json').read_bytes()).hexdigest())
(H/'WITNESS_FRONTIER.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print({k:v for k,v in out.items() if k not in ('closed','open_indices')})
print('open indices:',out['open_indices'])
