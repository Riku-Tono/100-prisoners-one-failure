"""Independent Dancing Links check. No imports from prior research scripts.

Regenerates old-side blocks from four-letter words and an extra label.
Reads the previous witness selections only as certificate data, translates
them by their actual rules (not row IDs or integer masks), and validates
each selection before solving. No time limit or cached search outcomes.
"""
from itertools import permutations
from pathlib import Path
from collections import Counter
import json, time, hashlib

HERE=Path(__file__).resolve().parent
OUT=HERE/'completion_dlx_recheck.json'
def rotate_min(c):
    c=tuple(c);return min(c[k:]+c[:k] for k in range(len(c)))
def correct(c):
    n=len(c)
    return tuple((c[k],c[(k+1)%n],c[(k+2)%n],c[(k+3)%n],c[(k-1)%n]) for k in range(n))
forbidden={frozenset(x) for x in ((1,2,3,4),(1,2,3,5),(1,2,3,6),(4,5,6,7))}
WORDS=sorted({rotate_min(w) for w in permutations(range(1,8),4) if frozenset(w) not in forbidden})
assert len(WORDS)==186
wordset=set(WORDS)
rule_blocks=set()
for w in WORDS:
    for offset in range(4):
        r=w[offset:]+w[:offset]
        for target in set(range(1,8))-set(w):
            full=correct((target,)+r)
            for skip in range(5):
                kept=frozenset(full[:skip]+full[skip+1:])
                if all(rotate_min(rule[:4]) in wordset for rule in kept):rule_blocks.add(kept)
RULES=sorted(rule_blocks,key=lambda rs:tuple(sorted(rs)))
ROWS=[tuple(sorted({rotate_min(r[:4]) for r in rs})) for rs in RULES]
assert len(ROWS)==1584 and all(len(row)==4 for row in ROWS)
lookup={rs:i for i,rs in enumerate(RULES)}

class DLX:
    def __init__(self):
        n=len(WORDS);self.left=list(range(-1,n));self.left[0]=n
        self.right=list(range(1,n+2));self.right[n]=0
        self.up=list(range(n+1));self.down=list(range(n+1));self.col=list(range(n+1))
        self.size=[0]*(n+1);self.row=[-1]*(n+1);self.row_nodes=[];self.active=set(range(1,n+1))
        wi={w:i+1 for i,w in enumerate(WORDS)};self.headers=wi
        for bid,words in enumerate(ROWS):
            nodes=[]
            for word in words:
                c=wi[word];k=len(self.col);nodes.append(k)
                self.col.append(c);self.row.append(bid)
                self.up.append(self.up[c]);self.down.append(c)
                self.down[self.up[c]]=k;self.up[c]=k;self.size[c]+=1
                self.left.append(k);self.right.append(k)
            for a,b in zip(nodes,nodes[1:]+nodes[:1]):self.right[a]=b;self.left[b]=a
            self.row_nodes.append(nodes)
        self.nodes=0;self.answer=None
    def cover(self,c):
        assert c in self.active
        self.active.remove(c)
        self.right[self.left[c]]=self.right[c];self.left[self.right[c]]=self.left[c]
        i=self.down[c]
        while i!=c:
            j=self.right[i]
            while j!=i:
                self.down[self.up[j]]=self.down[j];self.up[self.down[j]]=self.up[j]
                self.size[self.col[j]]-=1;j=self.right[j]
            i=self.down[i]
    def uncover(self,c):
        i=self.up[c]
        while i!=c:
            j=self.left[i]
            while j!=i:
                self.size[self.col[j]]+=1
                self.down[self.up[j]]=j;self.up[self.down[j]]=j;j=self.left[j]
            i=self.up[i]
        self.right[self.left[c]]=c;self.left[self.right[c]]=c
        self.active.add(c)
    def force_row(self,bid):
        cc=[self.col[k] for k in self.row_nodes[bid]]
        assert all(c in self.active for c in cc)
        for c in cc:self.cover(c)
        return cc
    def search(self,selected):
        self.nodes+=1
        if self.right[0]==0:self.answer=selected[:];return True
        c=self.right[0];j=self.right[c]
        while j:
            if self.size[j]<self.size[c]:c=j
            if self.size[c]==0:return False
            j=self.right[j]
        if self.size[c]==0:return False
        self.cover(c);i=self.down[c];found=False
        while i!=c:
            j=self.right[i]
            while j!=i:self.cover(self.col[j]);j=self.right[j]
            found=self.search(selected+[self.row[i]])
            j=self.left[i]
            while j!=i:self.uncover(self.col[j]);j=self.left[j]
            if found:break
            i=self.down[i]
        self.uncover(c);return found
    def run(self,mandatory,singles):
        removed=[]
        for s in sorted(singles):c=self.headers[s];self.cover(c);removed.append(c)
        for b in sorted(mandatory):removed.extend(self.force_row(b))
        self.nodes=0;self.answer=None
        found=self.search([])
        for c in reversed(removed):self.uncover(c)
        assert len(self.active)==186 and self.right[0]!=0
        return found,self.nodes,self.answer

def normalized_control():
    raw=json.loads((HERE/'inputs/new15051.rules.json').read_text())
    rs={(a,*h,t) for a,h,t in raw['rules']}
    long=[]
    for c in permutations(range(1,9),6):
        if c[0]!=min(c):continue
        missing=[r[0] for r in correct(c) if r not in rs]
        if len(missing)==1:long.append((c,missing[0]))
    assert len(long)==1
    c,f=long[0];t=(1,4,2,5,7,6);tf=7;p=c.index(f);q=t.index(tf)
    mp={c[(p+j)%6]:t[(q+j)%6] for j in range(6)}
    mp.update(zip(sorted(set(range(1,9))-set(c)),sorted(set(range(1,9))-set(t))))
    mapped={tuple(mp[x] for x in r) for r in rs}
    chosen={i for i,rr in enumerate(RULES) if rr<=mapped}
    assert len(chosen)==46
    old_rules=set().union(*(RULES[i] for i in chosen))
    singles={rotate_min(r[:4]) for r in mapped-old_rules if rotate_min(r[:4]) in wordset}
    assert len(singles)==2
    return chosen,singles

def main():
    start=time.perf_counter();answer={'method':'independent regenerated tuple rows + array Dancing Links','old_slots':186,'old_blocks':1584,'timeouts':0,'cases':[]}
    matrix=DLX();control,singles=normalized_control()
    for retain in (33,):
        fixed=set(sorted(control)[:retain])
        # This control actually searches thirteen missing rows, unhinted.
        found,nodes,extra=matrix.run(fixed,singles)
        assert found and len(extra)==46-retain
        allrows=fixed|set(extra);covered=[w for b in allrows for w in ROWS[b]]
        assert len(covered)==184 and len(set(covered))==184 and set(covered)|singles==wordset
        answer['positive_control']={'retained':retain,'recovered':len(extra),'nodes':nodes,'status':'FOUND'}
        print('positive control',answer['positive_control'],flush=True)
    for case in range(1,5):
        path=HERE/f'witnesses_{case}.json';d=json.loads(path.read_text())
        translate={}
        for old,b in enumerate(d['blocks']):
            rs=frozenset(map(tuple,b['rules']))
            cyc=tuple(b['cycle']);assert rs==frozenset(r for r in correct(cyc) if r[0]!=b['omitted_prisoner'])
            if rs in lookup:translate[old]=lookup[rs]
        fixed={translate[b] for b in d['fixed_blocks']}
        # Derive external rules from the six-cycle, rather than reading a
        # serialized occupied bit mask or the previous search's singles.
        fixedrules=set().union(*(RULES[i] for i in fixed))
        required={r for r in correct(tuple(d['six_cycle'])) if r[0]!=d['failing']}
        single_rules=required-fixedrules
        assert len(fixed)==3 and len(single_rules)==2
        singles={rotate_min(r[:4]) for r in single_rules}
        witness_sets=[]
        for w,cid in zip(d['witness_blocks'],d['parents']):
            translated={translate[b] for b in w}
            allrules=fixedrules|single_rules|set().union(*(RULES[b] for b in translated))
            assert sum(r in allrules for r in correct(tuple(d['cycles'][cid])))>=6
            witness_sets.append(translated)
        results=[];union_keys=set();case_nodes=0
        for i,j in d['edges']:
            mandatory=fixed|witness_sets[i]|witness_sets[j]
            used=[s for b in mandatory for s in ROWS[b]]
            assert len(used)==len(set(used)) and not set(used)&singles
            key=frozenset(mandatory);assert key not in union_keys;union_keys.add(key)
            found,nodes,extra=matrix.run(mandatory,singles);case_nodes+=nodes
            rec={'edge':[i,j],'status':'FOUND' if found else 'EXHAUSTED_NO_COMPLETION','nodes':nodes}
            if found:rec['additional_blocks']=extra
            results.append(rec)
        counts=Counter(r['status'] for r in results)
        record={'case':case,'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'edges':len(results),'counts':dict(counts),'nodes':case_nodes,'records':results}
        answer['cases'].append(record);answer['seconds']=time.perf_counter()-start
        OUT.write_text(json.dumps(answer,indent=2),encoding='utf-8')
        print({k:v for k,v in record.items() if k!='records'},flush=True)
    answer['all_edges']=sum(c['edges'] for c in answer['cases'])
    answer['exhausted']=sum(c['counts'].get('EXHAUSTED_NO_COMPLETION',0) for c in answer['cases'])
    answer['found']=sum(c['counts'].get('FOUND',0) for c in answer['cases'])
    answer['seconds']=time.perf_counter()-start
    OUT.write_text(json.dumps(answer,indent=2),encoding='utf-8')
    print('FINAL',answer['all_edges'],answer['exhausted'],answer['found'],answer['seconds'],flush=True)

if __name__=='__main__':main()
