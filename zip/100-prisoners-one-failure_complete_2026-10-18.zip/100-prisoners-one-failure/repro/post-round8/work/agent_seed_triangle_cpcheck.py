"""Independent CP-SAT packing check of every triangle seed's impossibility.

Regenerates blocks from canonical five-cycles, and translates only actual
rule tuples from the seed JSON. Does not import the DLX generator or solver.
"""
import sys,json,time
sys.path.insert(0,r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
from ortools.sat.python import cp_model
from itertools import combinations,permutations
from pathlib import Path
from collections import defaultdict,Counter
H=Path(__file__).resolve().parent
def canon(w):
    i=w.index(min(w));return w[i:]+w[:i]
def rules(c):
    return tuple((c[i],c[(i+1)%5],c[(i+2)%5],c[(i+3)%5],c[(i+4)%5]) for i in range(5))
forbid={frozenset(s) for s in ((1,2,3,4),(1,2,3,5),(1,2,3,6),(4,5,6,7))}
words={canon(p) for s in combinations(range(1,8),4) if frozenset(s) not in forbid for p in permutations(s)}
blocks=set()
for s in combinations(range(1,8),5):
    for tail in permutations(s[1:]):
        rr=rules((s[0],)+tail)
        for omit in range(5):
            block=frozenset(rr[:omit]+rr[omit+1:])
            if all(canon(r[:4]) in words for r in block):blocks.add(block)
blocks=sorted(blocks,key=lambda r:tuple(sorted(r))); lookup={r:i for i,r in enumerate(blocks)}
assert len(blocks)==1584 and len(words)==186
blockwords=[{canon(r[:4]) for r in b} for b in blocks]
data=json.loads((H/'agent_seed_triangles.json').read_text()); records=[];start=time.monotonic()
solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.max_time_in_seconds=5
for i,seed in enumerate(data['seeds']):
    mandatory=[lookup[frozenset(map(tuple,b))] for b in seed['rules']]
    assert len(mandatory)==18
    occupied=set().union(*(blockwords[b] for b in mandatory))
    assert len(occupied)==72
    compatible=[b for b in range(len(blocks)) if not blockwords[b]&occupied]
    model=cp_model.CpModel();inc=defaultdict(list)
    x=[model.new_bool_var(f'b{b}') for b in compatible]
    for b,var in zip(compatible,x):
        for w in blockwords[b]:inc[w].append(var)
    for w in words-occupied:model.add(sum(inc[w])<=1)
    model.add(sum(x)==28)
    status=solver.solve(model)
    rec={'case':i,'status':solver.status_name(status),'compatible_blocks':len(compatible),'branches':solver.num_branches,'conflicts':solver.num_conflicts,'seconds':solver.wall_time}
    records.append(rec)
    if i%25==0 or status!=cp_model.INFEASIBLE:print(rec,flush=True)
    out={'scope':data['scope']+'; packing exactly46 old blocks with2 holes','method':'independent five-cycle regeneration + CP-SAT feasibility, singleworker5sec per orbit','blocks':len(blocks),'slots':len(words),'cases':records,'counts':dict(Counter(r['status'] for r in records)),'seconds':time.monotonic()-start}
    (H/'agent_seed_triangle_cpcheck.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print('FINAL',out['counts'],out['seconds'],flush=True)
