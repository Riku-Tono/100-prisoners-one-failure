"""Independent finite verification of the four three-flip R6 cases.

Python standard library only. No submitted research module is imported.
The scope is the relaxation, not completion to 52 old five-cycle blocks.
"""
from collections import defaultdict
from hashlib import sha256
from itertools import combinations, permutations
from pathlib import Path
import json
import time

HERE = Path(__file__).resolve().parent
CLAUDE_PAIRS = Path("C:/Users/yauki/Documents/Codex/claude-codex-exchange-2026-10-17/claude_work/runs/relax_pairs.json")
LABELS = frozenset(range(1, 9))
CASES = [((1,4,2,5,6,7),6), ((1,4,2,5,7,6),7),
         ((1,4,2,7,5,6),5), ((1,4,5,6,2,7),5)]

def rotate_min(t):
    t = tuple(t)
    j = t.index(min(t))
    return t[j:] + t[:j]

def directed_cycles(labels, k):
    for support in combinations(sorted(labels), k):
        for tail in permutations(support[1:]):
            yield (support[0],) + tail

def member_rules(c):
    """p[c[i]]=c[i+1]; tuple is (prisoner,h1,h2,h3,final box)."""
    k = len(c)
    return tuple((c[i], c[(i+1)%k], c[(i+2)%k], c[(i+3)%k], c[(i-1)%k])
                 for i in range(k))

active = {frozenset(s) for s in combinations(range(1, 8), 4)}
for support in ((1,2,3,4),(1,2,3,5),(1,2,3,6)):
    active.remove(frozenset(support))
    active.add(LABELS - frozenset(support))
slots = tuple(c for c in directed_cycles(LABELS,4) if frozenset(c) in active)
slot_id = {c:i for i,c in enumerate(slots)}
def rule_slot(r):
    return slot_id.get(rotate_min(r[:4]))

special = sum(1 << i for i,c in enumerate(slots)
              if 8 in c or frozenset(c)==frozenset((4,5,6,7)))
eight_slots = sum(1 << i for i,c in enumerate(slots) if 8 in c)
blocks=[]
by_five = defaultdict(list)
rule_blocks = defaultdict(list)
for c in directed_cycles(LABELS, 5):
    rs = member_rules(c)
    for missing in range(5):
        chosen = frozenset(r for i,r in enumerate(rs) if i != missing)
        ids = [rule_slot(r) for r in chosen]
        if None in ids:
            continue
        mask = sum(1 << i for i in ids)
        b=len(blocks)
        blocks.append((c,missing,chosen,mask))
        by_five[c].append(b)
        for r in chosen:
            rule_blocks[r].append(b)

new_blocks = [b for b,(_,_,_,mask) in enumerate(blocks) if mask & eight_slots]
eight_support_faces={tuple(s):sum(frozenset(q) in active for q in combinations(s,4))
                     for s in combinations(sorted(LABELS),5) if 8 in s}
eight_block_supports=[s for s,n in eight_support_faces.items() if n>=4]
assert eight_block_supports==[(4,5,6,7,8)]
assert len(new_blocks)==24
assert all(member_rules(blocks[b][0])[blocks[b][1]][-1]==7 for b in new_blocks)
assert all((blocks[b][3]&eight_slots).bit_count()==3 for b in new_blocks)
assert all(blocks[b][3]&special==blocks[b][3] for b in new_blocks)
assert special.bit_count()==24 and eight_slots.bit_count()==18
assert all(not (mask&special) or (mask&special).bit_count() in (1,4)
           for _,_,_,mask in blocks)

# Each rule on an 8-containing slot is either a singleton or belongs to
# one of these blocks, which supplies 3 such slots.  18-3*b<=2 forces b=6
# and no singleton there.  Their six fourth slots occupy every 4567 slot.
new_covers=[]
def cover_special(used, chosen):
    if used==special:
        new_covers.append(tuple(chosen)); return
    pending=special & ~used
    best=None
    while pending:
        bit=pending & -pending; pending-=bit
        options=[b for b in new_blocks if blocks[b][3]&bit and not blocks[b][3]&used]
        if best is None or len(options)<len(best):
            best=options
    for b in best:
        cover_special(used|blocks[b][3], chosen+[b])
cover_special(0,[])
assert new_covers and all(len(c)==6 for c in new_covers)

old_blocks={b for b,(_,_,_,mask) in enumerate(blocks) if not mask&special}
old_by_five={c:[b for b in bs if b in old_blocks] for c,bs in by_five.items()}

def six_seeds(required):
    """Enumerate ALL local covers of required rules with <=2 singletons.

    A rule determines its unique 5-cycle. In one 5-cycle, distinct blocks
    overlap in slots, so there can be at most one block. We explicitly
    try each allowed block plus singletons for any uncovered requirements.
    """
    grouped=defaultdict(set)
    for r in required:
        grouped[rotate_min(r)].add(r)
    options=[]
    for c,needs in grouped.items():
        choices=[]
        for b in [None]+old_by_five.get(c,[]):
            singles=needs if b is None else needs-blocks[b][2]
            if len(singles)>2:
                continue
            mask=0 if b is None else blocks[b][3]
            ok=True
            for r in singles:
                sid=rule_slot(r)
                if sid is None or (1<<sid)&(mask|special):
                    ok=False; break
                mask |= 1<<sid
            if ok:
                choices.append((b,frozenset(singles),mask))
        options.append(choices)
    found=set()
    def visit(j,occupied,chosen,singles):
        if len(singles)>2:
            return
        if j==len(options):
            found.add((frozenset(chosen),frozenset(singles))); return
        for b,new_singles,mask in options[j]:
            if occupied&mask:
                continue
            visit(j+1, occupied|mask, chosen if b is None else chosen|{b}, singles|new_singles)
    visit(0,special,set(),set())
    return found

def seven_witnesses(c, fixed, singles):
    assert len(singles)==2  # independently obtained by six_seeds, not an input assumption
    present=set(singles)
    occupied=special | sum(1 << rule_slot(r) for r in singles)
    for b in fixed:
        present.update(blocks[b][2]); occupied |= blocks[b][3]
    rs=member_rules(c)
    answers=set()
    for fail in range(7):
        needed={r for i,r in enumerate(rs) if i!=fail}-present
        if any(rule_slot(r) is None for r in needed):
            continue
        # Different 7-cycle member rules lie on distinct 5-cycle supports.
        groups=defaultdict(set)
        for r in needed:
            groups[rotate_min(r)].add(r)
        choices=[]
        for five,needs in groups.items():
            choices.append([b for b in old_by_five.get(five,[]) if needs<=blocks[b][2]
                            and not occupied&blocks[b][3]])
        if any(not x for x in choices):
            continue
        choices.sort(key=len)
        def visit(j,mask,chosen):
            if j==len(choices):
                answers.add(frozenset(chosen)); return
            for b in choices[j]:
                if b in chosen:
                    visit(j+1,mask,chosen)
                elif not mask&blocks[b][3]:
                    visit(j+1,mask|blocks[b][3],chosen|{b})
        visit(0,occupied,set())
    return answers

def union_mask(ids):
    m=0
    for b in ids:
        m |= blocks[b][3]
    return m

def audit_all_six_cases():
    """Generate every active (6-cycle, omitted member) and its G orbit.

    G permutes 123 and 456 independently and fixes 7,8. No saved
    orbit list or submitted case-generation implementation is used.
    """
    group=[]
    for p in permutations((1,2,3)):
        for q in permutations((4,5,6)):
            group.append(dict(zip(range(1,9),p+q+(7,8))))
    assert len(group)==36
    assert all({frozenset(g[x] for x in s) for s in active}==active for g in group)
    representatives=defaultdict(int)
    total=active_count=containing_eight=0
    for c in directed_cycles(LABELS,6):
        rr=member_rules(c)
        for failing in c:
            total+=1
            if any(rule_slot(r) is None for r in rr if r[0]!=failing):
                continue
            active_count+=1
            containing_eight += 8 in c
            rep=min((rotate_min(g[x] for x in c),g[failing]) for g in group)
            representatives[rep]+=1
    # Otherwise the selected special cover would have to be considered
    # explicitly for the required 6-cycle, instead of just its occupied mask.
    assert containing_eight==0
    rows=[]
    for (c,f),size in sorted(representatives.items()):
        seeds=six_seeds({r for r in member_rules(c) if r[0]!=f})
        rows.append({"six_cycle":c,"failing":f,"orbit_size":size,"seed_count":len(seeds),
                     "seed_block_single_counts":sorted((len(bs),len(ss)) for bs,ss in seeds)})
    feasible=[(tuple(r["six_cycle"]),r["failing"]) for r in rows if r["seed_count"]]
    assert feasible==CASES, feasible
    assert total==20160 and active_count==3168 and len(rows)==88
    assert sum(r["seed_count"]==0 for r in rows)==84
    return {"all_cycle_failure_cases":total,"active_cases":active_count,
            "active_cases_containing_8":containing_eight,"group_size":len(group),
            "orbits":len(rows),"orbits_with_no_seed":sum(r["seed_count"]==0 for r in rows),
            "orbits_with_one_seed":sum(r["seed_count"]==1 for r in rows),"orbit_details":rows}

def audit_case(c6,failing):
    seeds=six_seeds({r for r in member_rules(c6) if r[0]!=failing})
    assert len(seeds)==1, (c6, len(seeds))
    fixed,singles=next(iter(seeds))
    assert len(fixed)==3 and len(singles)==2
    witnesses=[]
    for c in directed_cycles(LABELS,7):
        for w in sorted(seven_witnesses(c,fixed,singles),key=lambda s:tuple(sorted(s))):
            witnesses.append((c,w,union_mask(w)))
    # Directly check the meaning of every enumerated witness, separately
    # from the recursion that generated it. Include occupied singleton slots.
    for c,w,_ in witnesses:
        occupied=special | sum(1 << rule_slot(r) for r in singles)
        actual=set(singles)
        for b in fixed|w:
            assert not occupied & blocks[b][3]
            occupied |= blocks[b][3]
            actual.update(blocks[b][2])
        assert sum(r in actual for r in member_rules(c))>=6
        assert all(r in actual for r in member_rules(c6) if r[0]!=failing)
    adj=[set() for _ in witnesses]
    edges=[]
    pairs=set()
    for i,(ci,wi,mi) in enumerate(witnesses):
        for j in range(i+1,len(witnesses)):
            cj,wj,mj=witnesses[j]
            if ci==cj:
                continue
            # Sharing an identical block is permitted; sharing any other
            # slot would require two different rules/blocks in that slot.
            if mi & mj != union_mask(wi & wj):
                continue
            edges.append((i,j)); adj[i].add(j); adj[j].add(i)
            pairs.add(tuple(sorted((ci,cj))))
    triangles=[]
    for i,j in edges:
        triangles.extend((i,j,k) for k in adj[i]&adj[j] if k>j)
    used_cycles={c for pair in pairs for c in pair}
    return {"six_cycle":c6,"failing":failing,"seed_count":len(seeds),
            "fixed_blocks":[{"cycle":blocks[b][0],"missing_prisoner":blocks[b][0][blocks[b][1]]} for b in sorted(fixed)],
            "single_rules":sorted(singles),
            "individual_seven_cycles":len({c for c,_,_ in witnesses}),
            "witness_count":len(witnesses),"compatible_witness_edges":len(edges),
            "triangle_count":len(triangles),"pair_count":len(pairs),
            "cycles_used_in_pairs":len(used_cycles),"cycles_used_in_pairs_containing_8":sum(8 in c for c in used_cycles),
            "pairs":sorted(pairs),
            "witnesses":[{"cycle":c,"blocks":sorted(w)} for c,w,_ in witnesses]}

if __name__=="__main__":
    started=time.time()
    result={"scope":"standard three support flips; all R6 cases and four feasible representatives; relaxation only",
            "method":"solver-free complete local witness enumeration and triangle test",
            "active_supports":len(active),"active_slots":len(slots),"all_blocks":len(blocks),
            "special_slots":special.bit_count(),"new_blocks":len(new_blocks),
            "five_supports_containing_8_with_four_active_faces":eight_block_supports,
            "max_active_rules_in_seven_cycle_containing_8":max(sum(rule_slot(r) is not None for r in member_rules(c))
                                                               for c in directed_cycles(LABELS,7) if 8 in c),
            "special_exact_covers":len(new_covers),"special_covers_block_ids":new_covers,
            "blocks":[{"cycle":c,"missing_prisoner":c[missing],"rules":sorted(rs)}
                      for c,missing,rs,_ in blocks],"cases":[]}
    result["six_case_audit"]=audit_all_six_cases()
    for c,f in CASES:
        rec=audit_case(c,f)
        result["cases"].append(rec)
        print(json.dumps({k:v for k,v in rec.items() if k not in ("pairs","witnesses")}),flush=True)
    raw=CLAUDE_PAIRS.read_bytes()
    submitted=json.loads(raw)
    assert len(submitted)==len(CASES)
    for ours,theirs in zip(result["cases"],submitted):
        assert tuple(theirs["six_cycle"])==tuple(ours["six_cycle"]) and theirs["failing"]==ours["failing"]
        their_pairs={tuple(sorted(tuple(c) for c in pair)) for pair in theirs["pairs"]}
        our_pairs=set(ours["pairs"])
        ours["comparison"]={"missing_from_ours":len(their_pairs-our_pairs),
                            "additional_in_ours":len(our_pairs-their_pairs),"exact_match":our_pairs==their_pairs}
    result["submitted_pairs_sha256"]=sha256(raw).hexdigest()
    result["source_code_sha256"]=sha256(Path(__file__).read_bytes()).hexdigest()
    result["elapsed_seconds"]=round(time.time()-started,3)
    target=HERE/"relaxation_enumeration.json"
    target.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"saved":str(target),"elapsed_seconds":result["elapsed_seconds"],
                      "pair_counts":[c["pair_count"] for c in result["cases"]],
                      "triangle_counts":[c["triangle_count"] for c in result["cases"]],
                      "all_pair_lists_match":all(c["comparison"]["exact_match"] for c in result["cases"])}))
