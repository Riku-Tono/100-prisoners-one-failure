"""Assemble a scope-labelled research record after both finite audits finish."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone, timedelta
import json

HERE = Path(__file__).resolve().parent

def read(name):
    return json.loads((HERE / name).read_text(encoding='utf-8-sig'))

first = read('completion/completion_result.json')
second = read('archive_audit/completion_set_audit.json')
local = read('independent/relaxation_enumeration.json')
six_audit = local['six_case_audit']
assert six_audit['all_cycle_failure_cases'] == 20160
assert six_audit['active_cases'] == 3168 and six_audit['active_cases_containing_8'] == 0
assert six_audit['group_size'] == 36 and six_audit['orbits'] == 88
assert six_audit['orbits_with_no_seed'] == 84 and six_audit['orbits_with_one_seed'] == 4
assert first['status'] == 'ENUMERATED_ALL_REQUIRED_UNIONS_INFEASIBLE'
assert len(first['case_results']) == 4
assert all(c['timeouts'] == 0 and c['infeasible'] == c['distinct_required_row_unions']
           and len(c['records']) == c['distinct_required_row_unions'] for c in first['case_results'])
assert second['four_cases_present'] and second['all_saved_cases_independently_infeasible']
assert len(second['cases']) == 4
for a, b in zip(first['case_results'], second['cases']):
    assert a['six_cycle'] == b['six_cycle']
    assert a['failing'] == b['failing_prisoner']
    assert b['source_union_set_is_complete']
    assert b['independent_required_row_unions'] == len(a['records']) == len(b['records'])
    assert all(r['status'] in {'ROOT_EMPTY_COLUMN', 'INFEASIBLE_SET_EXACT_COVER'} for r in b['records'])
    assert all(r['status'] == 'INFEASIBLE_EXACT_COVER' for r in a['records'])
total = sum(len(c['records']) for c in first['case_results'])
assert total == 4644
control = first['known_certificate_control']
assert control['placements'] == 40320 and control['wins'] == 15051 and control['lost_cf'] == 0
positive = read('completion/positive_partial_control.json')
assert positive['recovered'] and not positive['timeout'] and positive['total_blocks'] == 52

counts = [len(c['records']) for c in first['case_results']]
nodes = sum(r['nodes'] for c in first['case_results'] for r in c['records'])
record = {
    'date_jst': datetime.now(timezone(timedelta(hours=9))).isoformat(),
    'claim_status': 'finite_exhaustive_result_with_two_completion_implementations',
    'scope': {'n': 8, 'max_openings': 4, 'required_successes': 7,
              'first_three': 'cycle following', 'preserve_all_cf_wins': True,
              'R5': 52, 'R6': 1, 'rule_count': 210,
              'support_orientation': 'all four-subsets of 1..7 except 1234,1235,1236; add 5678,4678,4578',
              'representation': '52 disjoint four-rule five-cycle blocks plus two external rules'},
    'result': {'R7_maximum': 1, 'wins_maximum_in_this_branch': 15051,
               'attaining_certificate_fully_simulated': True,
               'pairs': 334, 'required_block_unions': total,
               'per_case_unions': counts, 'first_implementation_nodes': nodes,
               'first_implementation_seconds': first['elapsed_seconds'], 'timeouts': 0},
    'claim_boundary': [
        'The general reduction to 52 four-rule blocks plus two external rules is an existing structural result recorded in the supplied README, not freshly proved here.',
        'The new independent enumeration verifies all 20160 six-cycle/failure pairs, the four seeds, local seven-cycle witnesses, and all 4644 completion unions.',
        'No conclusion for R6=0, other support orientations, R5<=51, early changes, or arbitrary strategies.',
        'The best known overall attainable score remains 15051; global optimality is unresolved.'
    ],
    'source_links': ['https://chatgpt.com/s/cx_6ad377de7744819193b9ced9d8614c87',
                     'https://chatgpt.com/s/cx_6ad3733f11208191b3912ca4c01be9ed'],
    'known_control': control,
    'positive_partial_control': positive,
    'consultation': {'claude_code': 'claude_code_consultation.json; thought-only pruning suggestions; not used as proof',
                     'chatgpt': 'research question sent to existing chat; no final answer confirmed at compilation',
                     'parallel_chat': '99人問題の研究を開始; its root work files were read but not edited by this run'}
}
(HERE / 'research_summary.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')

text = f'''99人成功問題：標準3支持反転の6巡回枝を有限完全検証
2026-10-17 日本時間

分かったこと
標準3支持反転・210規則・R5=52,R6=1という限定枝では、R7の最大値は1。
したがって、この枝の最大勝数は 14736 + 6*52 + 2*1 + 1 = 15051。
15,052勝を与える「6巡回1本と7巡回2本」の構成は、この枝には存在しない。
これは明示した有限範囲の完全列挙結果。全戦略の最適性の証明ではない。

正確な問題
元の99人成功問題：100人・100箱・各50箱、本人の番号を実際に見た人が99人以上で勝ち。
今回の有限研究：8人・8箱・各4箱、7人以上成功。置換は一様ランダム。
開始前相談は可、開始後通信や配置変更は不可。本人の観測履歴への適応は可。
今回の族では最初3箱はCF、第4箱のみ変更し、CFの全14736勝ちを保存する。
活性4人支持は[7]の全4集合から1234,1235,1236を除き、5678,4678,4578を加えた35集合。

前提と証明の接続
添付READMEの既存構造結果 M=4R5+F5+E<=210, 2R6<=3E,
R6<=E(E-1)/2 から、R5=52,R6>=1なら52個の4規則ブロックと外部2規則が必要。
この既存の構造補題自体の一般証明を今回新しく再証明したわけではない。
今回の独立計算は、この表現を持つ全ての標準3支持反転戦略を対象にする。

1. 8入りの18損失語を供給できる新側ブロックは45678上のskip target7の24候補だけ。
   各新ブロックは8入り3語と4567上1語を使う。18=3b+s、単独規則s<=2、
   4567の容量からb<=6なのでb=6,s=0。特殊24語の予約は必須。被覆は12通り。
2. 全有向6巡回と失敗囚人20,160組から、活性条件を満たす3,168組を独立列挙。
   8を含むものは0。Sym(123)×Sym(456)の36元で88軌道になる。
   単独規則0,1,2をすべて許す局所配置列挙で84軌道が空、残る4軌道は各一意。
3. 各7巡回の正しい6窓を供給する全ブロック集合を列挙。同じブロックの共有は許す。
   全7窓が正しい場合も任意1窓を無視する列挙に含む。8入り7巡回は活性窓が最大5。
4. 互換な7巡回ペアは78+89+95+72=334。Claudeの保存ペア集合と完全一致。
   それを実現するブロック集合の和集合は{counts[0]}/{counts[1]}/{counts[2]}/{counts[3]}、計{total}通り。
5. 全{total}通りについて、残りの損失語を旧側46ブロックへ完全被覆できるかを検査。
   bitset DFS版と可変集合Algorithm X版の別実装で全件不可能。時間切れ・未検査0。
   実戦略で2本以上救えれば、そのうち2本の証人和集合が必ずこの列挙に現れる。
   その全てに補完がないためR7>=2は排除される。
6. 既知new15051を全40320配置で直接シミュレーションし15051勝・CF喪失0。
   同じ支持向き、52ブロック+2単独規則の構成なので上界1を達成する。

検算と終了状態
第1実装：全{total}件完了、{nodes:,} DFS節点、{first['elapsed_seconds']}秒、TIME_LIMIT 0。
第2実装：全{total}件を独立生成した和集合と照合し、集合版完全被覆で全件不可能。
本結果にCP-SATの最適性宣言やUNKNOWNを根拠として使っていない。
正例校正：既知構成から13ブロックを外しても、同じ第1DFSが14節点で52個へ復元。

なぜ候補が消えたか
334ペアは必要な規則を局所的に置けるという条件だけを満たす。
その規則が占めた損失語を残したまま、全186旧側語を4語ずつ埋め切る条件は強い。
今回、互換な部分集合と完全戦略の差を全件で検査した。
具体例：7巡回(1,5,2,4,3,7,6)と(1,6,2,7,5,3,4)の特定の証人選択では、
残る穴(1,2,3,7)と(1,2,7,3)を埋める候補がそれぞれ1ブロックしかない。
ところが、その必須2ブロックが同じ損失語(1,2,4,7)を使うため完成できない。
completion/small_obstruction_ja.txt と verify_small_obstruction.py で、この短い矛盾を独立確認できる。
この1例の矛盾だけで、その巡回ペアの他の証人選択まで除外したとは扱わない。

まだ未解決
R6=0,R7>=4の枝、他の支持向き（4支持反転など）、R5<=51のトレード、
最初3箱から変える戦略、8人の全戦略最適性、100人の全戦略最適性。
全体の最高確認値15051は更新していない。

次に試すこと
この334ペアの枝を繰り返さず、標準3支持反転のR6=0,R7>=4か4支持反転へ移る。
最初に新側損失語の容量・ブロック支持・外部規則数を整理し、小さな候補系へ還元する。
保存済み52ブロックの5個以下交換を除外した旧結果は、支持向き変更へ流用しない。

記録と再現
research_summary.json：主張と適用範囲。
independent/FINDINGS.md：全88軌道、特殊24語、全334ペアの独立証人列挙。
completion/completion_result.json：全4644完全被覆の第1実装の結果。
archive_audit/completion_set_audit.json：集合版の独立全件検査。
claude_code_consultation.json：Claude Codeへの不変量相談。助言は証明として採用していない。
SHA256SUMS.json：この作業フォルダーの成果物と外部入力の照合値。

作業ルート C:/Users/yauki/Documents/ChatGPT/99prisoners からPython標準ライブラリで再現：
python -X utf8 work/2026-10-17_initial/independent/enumerate_relaxation.py
python -X utf8 work/2026-10-17_initial/completion/search_completion.py 600 "C:/Users/yauki/Documents/Codex/claude-codex-exchange-2026-10-17/materials/new15051.rules.json"
python -X utf8 work/2026-10-17_initial/archive_audit/audit_completion_sets.py 600
python -X utf8 work/2026-10-17_initial/compile_record.py
時間内に完了しない追試はUNKNOWN/INCOMPLETEのまま扱う。上の集約コードも不完全結果を受け付けない。
'''
(HERE / 'RESULTS_ja.txt').write_text(text, encoding='utf-8-sig')

paths = [p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts
         and p.suffix in {'.py', '.json', '.txt', '.md'} and p.name != 'SHA256SUMS.json']
external = [Path('C:/Users/yauki/Desktop/100prisoners/GitHub/README.md'),
            Path('C:/Users/yauki/Documents/Codex/claude-codex-exchange-2026-10-17/materials/new15051.rules.json'),
            Path('C:/Users/yauki/Documents/Codex/claude-codex-exchange-2026-10-17/claude_work/runs/relax_pairs.json')]
manifest = {'files': {str(p.relative_to(HERE)).replace('\\', '/'): sha256(p.read_bytes()).hexdigest()
                      for p in sorted(paths)},
            'external_inputs': {str(p): sha256(p.read_bytes()).hexdigest() for p in external}}
(HERE / 'SHA256SUMS.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps({'compiled': True, 'unions': total, 'new_R7_upper': 1,
                  'conditional_optimum': 15051, 'result': str(HERE / 'RESULTS_ja.txt')}, ensure_ascii=False))
