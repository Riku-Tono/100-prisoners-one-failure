"""Independent standard-library audit of Claude's relaxation input/output data.

Does not import or execute any submitted research program.  The CP-SAT
optimality claim is read as a solver record, not reproduced by this audit.
"""
from collections import Counter
from itertools import combinations, permutations
from pathlib import Path
import hashlib
import json
import time

HERE = Path(__file__).resolve().parent
EXCHANGE = Path(r"C:\Users\yauki\Documents\Codex\claude-codex-exchange-2026-10-17")
L = tuple(range(1, 9))


def canon(c):
    i = c.index(min(c))
    return c[i:] + c[:i]


def cycles(k):
    for support in combinations(L, k):
        for tail in permutations(support[1:]):
            yield (support[0],) + tail


def rules(c):
    n = len(c)
    return [tuple(c[(i + d) % n] for d in (0, 1, 2, 3, -1)) for i in range(n)]


def main():
    started = time.perf_counter()
    reply_path = EXCHANGE / "to_codex/0003_research_reply.json"
    reply = json.loads(reply_path.read_text(encoding="utf-8-sig"))
    hashes = []
    for rel, expected in reply["code_and_outputs"]["sha256"].items():
        actual = hashlib.sha256((EXCHANGE / "claude_work" / rel).read_bytes()).hexdigest()
        hashes.append({"file": rel, "expected": expected, "actual": actual,
                       "matches": actual == expected})
    assert all(row["matches"] for row in hashes)

    flips = {frozenset(s) for s in ((1, 2, 3, 4), (1, 2, 3, 5), (1, 2, 3, 6))}
    active = set()
    for support in combinations(range(1, 8), 4):
        support = frozenset(support)
        active.add(frozenset(L) - support if support in flips else support)
    assert len(active) == 35
    special = {s for s in active if 8 in s or s == frozenset((4, 5, 6, 7))}
    assert len(special) == 4

    group = []
    for a in permutations((1, 2, 3)):
        for b in permutations((4, 5, 6)):
            g = dict(zip(L, a + b + (7, 8)))
            assert {frozenset(g[x] for x in s) for s in active} == active
            group.append(g)

    eligible = set()
    all_c6 = 0
    for c in cycles(6):
        all_c6 += 1
        rr = rules(c)
        for failed_index, f in enumerate(c):
            if all(frozenset(r[:4]) in active for i, r in enumerate(rr) if i != failed_index):
                eligible.add((c, f))

    remaining = set(eligible)
    orbits = {}
    while remaining:
        c, f = min(remaining)
        orbit = {(canon(tuple(g[x] for x in c)), g[f]) for g in group}
        assert orbit <= eligible
        assert len(orbit) == 36
        orbits[(c, f)] = len(orbit)
        remaining.difference_update(orbit)
    assert all_c6 == 3360
    assert len(eligible) == 3168
    assert len(orbits) == 88

    raw_results = json.loads((EXCHANGE / "claude_work/runs/relax_all.json").read_text())
    rows = raw_results["results"]
    records = {(tuple(row["six_cycle"]), row["failing"]): row for row in rows}
    assert len(records) == len(rows) == 88
    assert set(records) == set(orbits)
    assert all(records[key]["orbit_size"] == size for key, size in orbits.items())
    status_counts = Counter(row["status"] for row in rows)
    assert status_counts == {"INFEASIBLE": 84, "OPTIMAL": 4}
    solved_keys = {key for key, row in records.items() if row["status"] == "OPTIMAL"}
    expected_keys = {
        ((1, 4, 2, 5, 6, 7), 6), ((1, 4, 2, 5, 7, 6), 7),
        ((1, 4, 2, 7, 5, 6), 5), ((1, 4, 5, 6, 2, 7), 5),
    }
    assert solved_keys == expected_keys
    assert all(records[key]["relax_R7_best"] == records[key]["relax_R7_bound"] == 2
               for key in solved_keys)

    pair_rows = json.loads((EXCHANGE / "claude_work/runs/relax_pairs.json").read_text())
    assert {(tuple(row["six_cycle"]), row["failing"]) for row in pair_rows} == solved_keys
    summaries = []
    known_control = (1, 6, 2, 7, 5, 3, 4)
    for row in pair_rows:
        key = (tuple(row["six_cycle"]), row["failing"])
        normalized_pairs = set()
        all_sevens = set()
        for pair in row["pairs"]:
            assert len(pair) == 2
            pair = tuple(sorted(tuple(c) for c in pair))
            assert len(set(pair)) == 2
            for c in pair:
                assert len(c) == len(set(c)) == 7
                assert set(c) <= set(L)
                assert c == canon(c)
                assert sum(frozenset(r[:4]) in active for r in rules(c)) >= 6
                all_sevens.add(c)
            normalized_pairs.add(pair)
        assert len(normalized_pairs) == len(row["pairs"]) == row["n_pairs"]
        assert row["complete"] and row["final_status"] == "INFEASIBLE"
        summaries.append({"six_cycle": list(key[0]), "failing_prisoner": key[1],
                          "pairs": len(normalized_pairs), "distinct_seven_cycles": len(all_sevens),
                          "seven_cycles_containing_8": sum(8 in c for c in all_sevens),
                          "pairs_containing_known_orbit115_control_seven":
                          sum(known_control in pair for pair in normalized_pairs),
                          "saved_solver_enumeration_complete": True})
    assert [s["pairs"] for s in summaries] == [78, 89, 95, 72]
    assert [s["distinct_seven_cycles"] for s in summaries] == [40, 41, 44, 37]
    assert all(s["seven_cycles_containing_8"] == 0 for s in summaries)

    control_path = Path(r"C:\Users\yauki\Documents\ChatGPT\the-infinite-library\outputs\prisoners-15052-hunt-2026-10-17\four-seven\four-six-orbits\orbit115.control.rules.json")
    control = json.loads(control_path.read_text(encoding="utf-8-sig"))
    control_rules = {(p, *history, target) for p, history, target in control["rules"]}
    assert len(control_rules) == 210
    assert all(frozenset(r[:4]) in active for r in control_rules)
    assert len({canon(r[:4]) for r in control_rules}) == 210
    block_rule_set = set()
    for c, omitted_target in control["blocks"]:
        rr = {r for r in rules(tuple(c)) if r[4] != omitted_target}
        assert len(rr) == 4 and rr <= control_rules and not rr & block_rule_set
        block_rule_set.update(rr)
    assert len(control["blocks"]) == 52
    assert len(block_rule_set) == 208
    assert len(control_rules - block_rule_set) == 2
    six = (1, 4, 2, 5, 7, 6)
    failed = 7
    assert all(r in control_rules for r in rules(six) if r[0] != failed)
    assert sum(r in control_rules for r in rules(known_control)) >= 6
    control_summary = {
        "path": str(control_path),
        "sha256": hashlib.sha256(control_path.read_bytes()).hexdigest(),
        "rules": 210, "disjoint_four_rule_blocks": 52, "single_rules": 2,
        "active_slots_occupied_exactly_once": 210,
        "six_cycle": list(six), "failing_prisoner": failed,
        "seven_cycle": list(known_control),
        "satisfies_relaxation_by_direct_rule_checks": True,
        "new_whole_placement_simulation_performed": False,
    }
    result = {
        "status": "PASS",
        "scope": "Independent input/orbit/data consistency audit; no solver optimality reproduction",
        "source_reply_sha256": hashlib.sha256(reply_path.read_bytes()).hexdigest(),
        "source_hashes": hashes,
        "active_supports": [sorted(s) for s in sorted(active, key=lambda s: sorted(s))],
        "exact_special_supports": [sorted(s) for s in sorted(special, key=lambda s: sorted(s))],
        "active_slots": len(active) * 6,
        "exact_special_slots": len(special) * 6,
        "all_directed_six_cycles_on_8_labels": all_c6,
        "all_cycle_failure_pairs": all_c6 * 6,
        "support_eligible_cycle_failure_pairs": len(eligible),
        "support_eligible_pairs_containing_8": sum(8 in c for c, f in eligible),
        "group_order": len(group),
        "eligible_orbits": len(orbits),
        "orbit_size_histogram": dict(Counter(orbits.values())),
        "saved_solver_statuses": dict(status_counts),
        "saved_pair_results": summaries,
        "pair_total": sum(s["pairs"] for s in summaries),
        "known_full_strategy_embedding": control_summary,
        "solver_claim_reproduced": False,
        "seconds": round(time.perf_counter() - started, 3),
    }
    (HERE / "claude_relaxation_input_audit.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
