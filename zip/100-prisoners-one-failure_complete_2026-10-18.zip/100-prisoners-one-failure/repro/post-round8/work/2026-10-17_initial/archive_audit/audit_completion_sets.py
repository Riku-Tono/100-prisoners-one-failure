"""Set-based independent exact-cover and witness audit.

No imports from the completion or Claude research programs.  Source rule data
and recorded row IDs are read as data.  Explicit budgets remain UNKNOWN.
"""
from collections import defaultdict, Counter
from itertools import combinations, permutations, product
from pathlib import Path
import json
import time
import sys
import hashlib

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "completion/completion_result.json"
L = tuple(range(1, 9))


def normalize(c):
    c = tuple(c)
    pos = c.index(min(c))
    return c[pos:] + c[:pos]


def cycles(size):
    for labels in combinations(L, size):
        for tail in permutations(labels[1:]):
            yield (labels[0],) + tail


def windows(c):
    return frozenset(tuple(c[(pos + step) % len(c)] for step in (0, 1, 2, 3, -1))
                     for pos in range(len(c)))


def set_cover(columns, rows, deadline):
    """Mutable-set Algorithm X; restore all columns before returning."""
    nodes = 0
    timed_out = False
    answer = None

    def search(chosen):
        nonlocal nodes, timed_out, answer
        nodes += 1
        if nodes % 256 == 0 and time.monotonic() >= deadline:
            timed_out = True
            return False
        if not columns:
            answer = chosen[:]
            return True
        col = min(columns, key=lambda c: (len(columns[c]), c))
        for bid in sorted(columns[col]):
            popped = []
            for c in sorted(rows[bid]):
                conflicting_rows = columns.pop(c)
                popped.append((c, conflicting_rows))
                for conflicting in conflicting_rows:
                    for other in rows[conflicting]:
                        if other in columns:
                            columns[other].discard(conflicting)
            success = search(chosen + [bid])
            for c, conflicting_rows in reversed(popped):
                columns[c] = conflicting_rows
                for restored in conflicting_rows:
                    for other in rows[restored]:
                        if other in columns:
                            columns[other].add(restored)
            if success:
                return True
            if timed_out:
                return False
        return False

    success = search([])
    return ("FEASIBLE" if success else "UNKNOWN_BUDGET" if timed_out else
            "INFEASIBLE_SET_EXACT_COVER"), nodes, answer


def main():
    started = time.monotonic()
    seconds = float(sys.argv[1]) if len(sys.argv) > 1 else 100
    deadline = started + seconds
    previous_path = HERE / "completion_set_audit.json"
    previous = (json.loads(previous_path.read_text()) if len(sys.argv) > 2
                and sys.argv[2] == "resume" and previous_path.exists() else {})
    cached = {(tuple(case["six_cycle"]), case["failing_prisoner"],
               frozenset(record["required_rows"])): record
              for case in previous.get("cases", []) for record in case["records"]
              if record["status"] in {"ROOT_EMPTY_COLUMN", "INFEASIBLE_SET_EXACT_COVER"}}
    active = {frozenset(s) for s in combinations(range(1, 8), 4)}
    for s in ((1, 2, 3, 4), (1, 2, 3, 5), (1, 2, 3, 6)):
        active.remove(frozenset(s))
        active.add(frozenset(L) - frozenset(s))
    special = frozenset(c for c in cycles(4) if frozenset(c) in active and set(c) <= {4, 5, 6, 7, 8})
    universe = frozenset(c for c in cycles(4) if frozenset(c) in active)
    old_universe = universe - special

    blocks = []
    block_rules = []
    byrule = defaultdict(set)
    for c in cycles(5):
        rr = [tuple(c[(pos + step) % 5] for step in (0, 1, 2, 3, -1)) for pos in range(5)]
        for omit in range(5):
            selected = frozenset(r for i, r in enumerate(rr) if i != omit)
            if not all(frozenset(r[:4]) in active for r in selected):
                continue
            row = frozenset(normalize(r[:4]) for r in selected)
            assert len(row) == 4
            bid = len(blocks)
            blocks.append(row)
            block_rules.append(selected)
            for r in selected:
                byrule[r].add(bid)
    blocks = tuple(blocks)
    block_rules = tuple(block_rules)
    old_ids = frozenset(i for i, row in enumerate(blocks) if not row & special)
    incidences = {col: frozenset(i for i in old_ids if col in blocks[i]) for col in old_universe}
    support_classes = Counter(len(row & special) for row in blocks)
    assert support_classes == {0: 1584, 1: 288, 4: 24}
    sevens = [c for c in cycles(7)
              if sum(frozenset(r[:4]) in active for r in windows(c)) >= 6]
    assert len(sevens) == 648 and all(8 not in c for c in sevens)

    control_path = Path(r"C:\Users\yauki\Documents\ChatGPT\the-infinite-library\outputs\prisoners-15052-hunt-2026-10-17\four-seven\four-six-orbits\orbit115.control.rules.json")
    control = json.loads(control_path.read_text(encoding="utf-8-sig"))
    all_control_rules = frozenset((a, *h, t) for a, h, t in control["rules"])
    row_by_rule_set = {rr: bid for bid, rr in enumerate(block_rules)}
    control_rows = []
    for c, skipped_target in control["blocks"]:
        rr = frozenset(r for r in windows(tuple(c)) if r[4] != skipped_target)
        control_rows.append(row_by_rule_set[rr])
    control_old = sorted(set(control_rows) & old_ids)
    control_singles = all_control_rules - frozenset().union(*(block_rules[i] for i in control_rows))
    assert len(control_rows) == 52 and len(control_old) == 46 and len(control_singles) == 2
    # Retain 33 of the 46 old rows, then genuinely recover the other 13.
    reserved = frozenset(normalize(r[:4]) for r in control_singles)
    reserved = reserved.union(*(blocks[i] for i in control_old[:33]))
    allowed = frozenset(i for i in old_ids if not blocks[i] & reserved)
    columns = {c: set(incidences[c] & allowed) for c in old_universe - reserved}
    control_status, control_nodes, recovered = set_cover(columns, blocks, deadline)
    assert control_status == "FEASIBLE" and len(recovered) == 13
    recovered_slots = frozenset().union(*(blocks[i] for i in recovered))
    assert len(recovered_slots) == 52 and recovered_slots == old_universe - reserved

    # Independent standard-template-free derivation of forced old rows/singles.
    def get_seed_answers(c6, failed):
        needed = sorted(r for r in windows(c6) if r[0] != failed)
        answers = set()
        for single_rules in (s for count in range(3) for s in combinations(needed, count)):
            remain = [r for r in needed if r not in single_rules]
            occupied = frozenset(normalize(r[:4]) for r in single_rules)
            if occupied & special:
                continue
            options = [sorted(byrule[r] & old_ids) for r in remain]
            for rr in product(*options):
                ids = frozenset(rr)
                slots = set(occupied)
                for bid in ids:
                    if slots & blocks[bid]:
                        break
                    slots.update(blocks[bid])
                else:
                    answers.add((ids, frozenset(single_rules)))
        return answers

    group = [dict(zip(L, a + b + (7, 8))) for a in permutations((1, 2, 3))
             for b in permutations((4, 5, 6))]
    eligible_pairs = {(c, failed) for c in cycles(6) for failed in c
                      if all(frozenset(r[:4]) in active for r in windows(c) if r[0] != failed)}
    orbit_reps = set()
    remaining_pairs = set(eligible_pairs)
    while remaining_pairs:
        c, failed = min(remaining_pairs)
        orbit = {(normalize(tuple(g[x] for x in c)), g[failed]) for g in group}
        assert len(orbit) == 36 and orbit <= eligible_pairs
        orbit_reps.add((c, failed))
        remaining_pairs.difference_update(orbit)
    all_seed_answers = {key: get_seed_answers(*key) for key in orbit_reps}
    seed_counts = Counter(len(answers) for answers in all_seed_answers.values())
    assert len(eligible_pairs) == 3168 and len(orbit_reps) == 88
    assert seed_counts == {0: 84, 1: 4}
    assert all(len(singles) == 2 for answers in all_seed_answers.values()
               for fixed, singles in answers)
    expected_cases = {((1, 4, 2, 5, 6, 7), 6), ((1, 4, 2, 5, 7, 6), 7),
                      ((1, 4, 2, 7, 5, 6), 5), ((1, 4, 5, 6, 2, 7), 5)}
    assert {key for key, answers in all_seed_answers.items() if answers} == expected_cases

    # Choose a still-uncovered required rule, then remove all rules supplied by
    # its chosen block.  This is independent of the submitted positional DFS.
    def witnesses(c, fixed_rules, occupied):
        found = set()
        rr = windows(c)
        for ignored in rr:
            needs = rr - {ignored} - fixed_rules

            def visit(todo, used_slots, selected):
                if not todo:
                    found.add(frozenset(selected))
                    return
                options = []
                for rule in todo:
                    available = [bid for bid in byrule[rule] & old_ids
                                 if not blocks[bid] & used_slots]
                    if not available:
                        return
                    options.append((len(available), rule, available))
                _, rule, available = min(options)
                for bid in available:
                    visit(todo - block_rules[bid], used_slots | blocks[bid], selected | {bid})

            visit(needs, occupied, set())
        return found

    snapshot = json.loads(PARENT.read_text(encoding="utf-8-sig"))
    result = {
        "scope": "Standard three-flip R5=52 R6=1 completion, independent sets",
        "block_counts_by_special_slot_usage": dict(support_classes),
        "support_eligible_seven_cycles": len(sevens),
        "support_eligible_seven_cycles_containing_8": sum(8 in c for c in sevens),
        "source_snapshot_status": snapshot["status"],
        "source_snapshot_sha256": hashlib.sha256(PARENT.read_bytes()).hexdigest(),
        "positive_control": {"status": control_status, "retained_old_rows": 33,
                             "recovered_old_rows": len(recovered), "nodes": control_nodes},
        "independent_full_seed_reduction": {
            "eligible_cycle_failure_pairs": len(eligible_pairs),
            "group_order": len(group), "orbits": len(orbit_reps),
            "single_counts_tested_per_seed": [0, 1, 2],
            "orbits_by_number_of_compatible_seeds": dict(seed_counts),
            "surviving_four_representatives": [[list(c), f] for c, f in sorted(expected_cases)]},
        "cases": [],
    }
    for saved in snapshot["case_results"]:
        c6, failed = tuple(saved["six_cycle"]), saved["failing"]
        seed_answers = all_seed_answers[c6, failed]
        assert len(seed_answers) == 1
        fixed, singles = next(iter(seed_answers))
        fixed_rules = frozenset(singles).union(*(block_rules[i] for i in fixed))
        seed_slots = frozenset(normalize(r[:4]) for r in fixed_rules)
        occupied = special | seed_slots
        local = []
        for c in sevens:
            ww = witnesses(c, fixed_rules, occupied)
            if ww:
                local.append((c, ww))
        generated_unions = set()
        pair_set = set()
        for (a, aa), (b, bb) in combinations(local, 2):
            for left in aa:
                for right in bb:
                    united = left | right
                    row_union = set()
                    for bid in united:
                        if row_union & blocks[bid]:
                            break
                        row_union.update(blocks[bid])
                    else:
                        generated_unions.add(frozenset(fixed | united))
                        pair_set.add(tuple(sorted((a, b))))
        saved_unions = {frozenset(row["required_rows"]) for row in saved["records"]}
        assert len(saved_unions) == len(saved["records"])
        assert saved_unions <= generated_unions
        assert len(generated_unions) == saved["distinct_required_row_unions"]

        # Independent Algorithm X using mutable column sets and cover/uncover.
        stats = Counter()
        checked = []
        for record in saved["records"]:
            req = frozenset(record["required_rows"])
            req_slots = frozenset().union(*(blocks[i] for i in req))
            singles_slots = frozenset(normalize(r[:4]) for r in singles)
            assert len(req_slots) == 4 * len(req)
            assert not req_slots & singles_slots
            reserved = req_slots | singles_slots
            available_ids = frozenset(i for i in old_ids if not blocks[i] & reserved)
            remaining = old_universe - reserved
            columns = {col: set(incidences[col] & available_ids) for col in remaining}
            empty = sorted(col for col, rows in columns.items() if not rows)
            cached_record = cached.get((c6, failed, req))
            if empty:
                status, nodes = "ROOT_EMPTY_COLUMN", 1
            elif cached_record:
                status, nodes = cached_record["status"], cached_record["nodes"]
            elif time.monotonic() >= deadline:
                status, nodes = "NOT_RUN_BUDGET", 0
            else:
                status, nodes, answer = set_cover(columns, blocks, deadline)
            stats[status] += 1
            checked.append({"required_rows": sorted(req), "status": status, "nodes": nodes,
                            "reused_completed_audit": bool(cached_record),
                            "root_empty_columns": [list(c) for c in empty]})
        case = {
            "six_cycle": list(c6), "failing_prisoner": failed,
            "independent_forced_old_rows": sorted(fixed),
            "independent_singles": [list(r) for r in sorted(singles)],
            "independent_witness_cycle_count": len(local),
            "independent_compatible_cycle_pairs": len(pair_set),
            "independent_required_row_unions": len(generated_unions),
            "source_saved_union_count": len(saved_unions),
            "source_union_set_is_subset": saved_unions <= generated_unions,
            "source_union_set_is_complete": saved_unions == generated_unions,
            "independent_cover_statuses": dict(stats), "records": checked,
        }
        result["cases"].append(case)
        (HERE / "completion_set_audit.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
        print({k: v for k, v in case.items() if k != "records"}, flush=True)
    result["elapsed_seconds"] = round(time.monotonic() - started, 3)
    result["all_saved_cases_independently_infeasible"] = all(
        all(row["status"] in {"ROOT_EMPTY_COLUMN", "INFEASIBLE_SET_EXACT_COVER"} for row in case["records"])
        and case["source_union_set_is_complete"] for case in result["cases"])
    result["four_cases_present"] = len(result["cases"]) == 4
    (HERE / "completion_set_audit.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print({k: v for k, v in result.items() if k != "cases"}, flush=True)


if __name__ == "__main__":
    main()
