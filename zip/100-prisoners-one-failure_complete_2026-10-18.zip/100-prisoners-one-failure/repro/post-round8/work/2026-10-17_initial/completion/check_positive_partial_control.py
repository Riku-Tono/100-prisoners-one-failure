"""Positive calibration: remove 13 known blocks and ask exact cover to recover."""
import json
from collections import defaultdict
from pathlib import Path
import search_completion as M

SOURCE=Path('C:/Users/yauki/Documents/Codex/claude-codex-exchange-2026-10-17/materials/new15051.rules.json')
data=json.loads(SOURCE.read_text(encoding='utf-8-sig'))
groups=defaultdict(list)
for a,h,t in data['rules']:groups[M.canon((t,a,*h))].append((a,*h,t))
rows=[];singles=[]
for c,rs in groups.items():
    if len(rs)==4:
        rows.append(next(i for i,b in enumerate(M.blocks) if b[0]==c and set(b[2])==set(rs)))
    else:singles.extend(rs)
required=[b for i,b in enumerate(rows) if i%4]
occupied=sum(1<<M.slots[M.canon(r[:4])] for r in singles)
solver=M.ExactCover(10);solution=solver.solve(occupied,required)
result={'source':str(SOURCE),'required_blocks':len(required),'blocks_to_recover':52-len(required),
    'recovered':solution is not None,'timeout':solver.timedout,'nodes':solver.nodes,
    'total_blocks':len(solution) if solution else None}
assert solution is not None and len(solution)==52
assert (sum(M.blocks[b][3] for b in solution)|occupied)==M.FULL
Path(__file__).with_name('positive_partial_control.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(result)
