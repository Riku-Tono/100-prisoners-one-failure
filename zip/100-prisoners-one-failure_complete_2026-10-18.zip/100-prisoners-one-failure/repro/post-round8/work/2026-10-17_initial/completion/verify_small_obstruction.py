"""Independent set-based verification of the short certificate; no search import."""
from itertools import combinations,permutations
from pathlib import Path
import json
P=Path(__file__).parent
d=json.loads((P/'small_obstruction.json').read_text())
def canon(c):
    c=tuple(c);i=c.index(min(c));return c[i:]+c[:i]
def rs(c):
    k=len(c);return [(c[j],c[(j+1)%k],c[(j+2)%k],c[(j+3)%k],c[(j-1)%k]) for j in range(k)]
def decode(b):
    c=tuple(b['cycle']);rr=[r for r in rs(c) if r[0]!=b['omitted_prisoner']]
    assert rr==[tuple(r) for r in b['rules']]
    slots=frozenset(canon(r[:4]) for r in rr)
    assert slots==frozenset(map(tuple,b['slots']))
    return slots,tuple(rr)
active=set(map(frozenset,d['active_supports']))
allslots=set()
for support in active:
    c=sorted(support)
    allslots.update((c[0],)+p for p in permutations(c[1:]))
blocks=[]
for support in combinations(range(1,9),5):
    for p in permutations(support[1:]):
        c=(support[0],)+p;rr=rs(c)
        for omit in range(5):
            keep=tuple(r for j,r in enumerate(rr) if j!=omit)
            ss=frozenset(canon(r[:4]) for r in keep)
            if ss<=allslots:blocks.append((ss,keep))
reserved=set(map(tuple,d['reserved_new_slots']))
assert reserved=={s for s in allslots if set(s)<={4,5,6,7,8}}
occupied=set(reserved);available=set(map(tuple,d['fixed_external_rules']))
for r in d['fixed_external_rules']:
    s=canon(r[:4]);assert s not in occupied;occupied.add(s)
for b in d['required_blocks']:
    ss,rr=decode(b);assert ss<=allslots and not ss&occupied
    occupied.update(ss);available.update(rr)
assert len(allslots-occupied)==d['initial_uncovered_slots']
assert all(sum(r in available for r in rs(c))==6 for c in d['seven_cycle_pair'])
forced=[]
for col in d['forced_columns']:
    s=tuple(col['uncovered_slot']);assert s not in occupied
    incident=[b for b in blocks if s in b[0]]
    legal=[b for b in incident if not b[0]&occupied]
    assert len(incident)==12 and len(legal)==1
    assert decode(col['unique_forced_block'])==legal[0]
    # Audit all 12 candidate entries, including the declared collision sets.
    assert {decode(x['block']) for x in col['candidate_audit']}==set(incident)
    for x in col['candidate_audit']:
        ss,_=decode(x['block'])
        assert ss&occupied=={tuple(z['slot']) for z in x['collisions_with_initial_occupied_slots']}
    forced.append(legal[0][0])
assert forced[0]!=forced[1]
assert forced[0]&forced[1]=={(1,2,4,7)}
out={'verified':True,'method':'independent set-based full incident-block enumeration',
     'uncovered_slots':len(allslots-occupied),'incident_counts':[12,12],
     'compatible_counts':[1,1],'forced_conflict_slot':[1,2,4,7]}
(P/'small_obstruction_check.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(out)
