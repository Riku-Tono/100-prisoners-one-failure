"""Extract one short, readable forced-block contradiction from the full search."""
from pathlib import Path
import json
import search_completion as M

D=Path(__file__).parent
data=json.loads((D/'completion_result.json').read_text())
case=data['case_results'][0]
record=min(case['records'],key=lambda r:r['nodes'])
fixed,_,singles,smask=M.seed(tuple(case['six_cycle']),case['failing'])
reserved=[c for c,i in M.slots.items() if M.newmask>>i&1]
occupied=M.newmask|smask
owner={c:'reserved_new_slot' for c in reserved}
for r in singles:owner[M.canon(r[:4])]='fixed_external_rule'
def describe(b):
    c,omit,rr,mask=M.blocks[b]
    return {'cycle':c,'omitted_prisoner':c[omit],'rules':rr,
        'slots':[M.canon(r[:4]) for r in rr]}
required=[]
for b in record['required_rows']:
    assert not occupied&M.blocks[b][3]
    occupied|=M.blocks[b][3]
    required.append(describe(b))
    for r in M.blocks[b][2]:owner[M.canon(r[:4])]=f'required_block_{len(required)}'
proofslots=[(1,2,3,7),(1,2,7,3)]
columns=[];unique=[]
for slot in proofslots:
    incident=[b for b,x in enumerate(M.blocks) if M.canon(slot) in [M.canon(r[:4]) for r in x[2]]]
    good=[b for b in incident if not M.blocks[b][3]&occupied]
    assert len(good)==1
    unique.append(good[0]);candidates=[]
    for b in incident:
        collisions=[{'slot':M.canon(r[:4]),'occupied_by':owner[M.canon(r[:4])]}
            for r in M.blocks[b][2] if M.canon(r[:4]) in owner]
        candidates.append({'block':describe(b),'collisions_with_initial_occupied_slots':collisions})
    columns.append({'uncovered_slot':slot,'all_incident_blocks':len(incident),
        'compatible_blocks':len(good),'unique_forced_block':describe(good[0]),'candidate_audit':candidates})
inter=M.blocks[unique[0]][3]&M.blocks[unique[1]][3]
common=[c for c,i in M.slots.items() if inter>>i&1]
assert common==[(1,2,4,7)]
available=set(singles)
for b in record['required_rows']:available.update(M.blocks[b][2])
obj={'scope':'One specific local-witness selection for one C7 pair; not by itself all witness selections for this pair.',
    'rule_convention':'(prisoner, obs1, obs2, obs3, final_box); c_i box contains c_(i+1)',
    'active_supports':sorted([sorted(s) for s in M.active]),
    'six_cycle':case['six_cycle'],'six_failing_prisoner':case['failing'],
    'seven_cycle_pair':record['pair'],
    'seven_satisfied_rules':[sum(r in available for r in M.rules(c)) for c in record['pair']],
    'reserved_new_slots':reserved,'fixed_external_rules':singles,'required_blocks':required,
    'initial_uncovered_slots':(M.FULL^occupied).bit_count(),
    'forced_columns':columns,'forced_blocks_conflict_on_slots':common,
    'conclusion':'No exact-cover completion of this specific local witness selection: two uncovered columns force distinct blocks sharing an already mutually exclusive slot.'}
(D/'small_obstruction.json').write_text(json.dumps(obj,indent=2),encoding='utf-8')
text='''局所 witness の短い破綻例（全334ペアのうち1ペア、その1つの witness 選択）

6巡回: (1,4,2,5,6,7)、失敗囚人6。
7巡回の組: (1,5,2,4,3,7,6) と (1,6,2,7,5,3,4)。
この witness は双方の7巡回の必要6規則を持ち、局所的には両立する。
固定するもの: 新側24スロット、外部規則P=(2,5,6,7,4)、Q=(5,6,7,1,2)、JSONに列記した15個の4規則ブロック。
これらは互いにスロット衝突しない。残りは124スロット（31ブロック）。

未被覆スロット (1,2,3,7) を覆える候補は全12ブロック。
固定済みスロットと衝突しない候補は、次の1個だけ:
  5巡回 (1,2,3,4,7)、規則を除く囚人1。
  使用スロット: SLOT_LIST_A

未被覆スロット (1,2,7,3) についても候補は全12個、非衝突候補は次の1個だけ:
  5巡回 (1,2,4,7,3)、規則を除く囚人3。
  使用スロット: SLOT_LIST_B

この2個の必須ブロックは、同じスロット (1,2,4,7) を使う。
したがって両方を置けず、この witness 選択は完成できない。
これは「1つ目の必須ブロックを置くと、2つ目の列の候補が0個になる」という深さ1の完全な矛盾証明でもある。

各12候補の一覧と、どの固定済みスロットで妨げられるかは small_obstruction.json に全件記載。
verify_small_obstruction.py は探索コードをimportせず、全許容ブロックを集合で再生成して証明を確認する。
この短い例だけでは、このペアの別witness選択や他のペアを排除したとは主張しない。
'''
for marker,col in zip(('SLOT_LIST_A','SLOT_LIST_B'),columns):
    text=text.replace(marker,', '.join(str(tuple(s)) for s in col['unique_forced_block']['slots'])+'。')
(D/'small_obstruction_ja.txt').write_text(text,encoding='utf-8-sig')
print({'seven_cycle_pair':record['pair'],'DFS_nodes':record['nodes'],'remaining_slots':obj['initial_uncovered_slots'],'conflict':common})
