"""Independent exact-cover completion of explicitly enumerated local witnesses.

Standard 3-flip support family only. Status TIME_LIMIT is never infeasibility.
No imported submitted research code. All combinatorics below rebuilt from rules.
"""
from itertools import combinations, permutations, product
from collections import defaultdict, Counter
from pathlib import Path
import json, time, sys

OUT=Path(__file__).parent
L=tuple(range(1,9))
def canon(c):
    c=tuple(c);j=c.index(min(c));return c[j:]+c[:j]
def cycles(k):
    for s in combinations(L,k):
        for p in permutations(s[1:]):yield (s[0],)+p
def rules(c):
    return tuple((c[j],c[(j+1)%len(c)],c[(j+2)%len(c)],c[(j+3)%len(c)],c[(j-1)%len(c)]) for j in range(len(c)))
active={frozenset(s) for s in combinations(range(1,8),4)}
for s in ((1,2,3,4),(1,2,3,5),(1,2,3,6)):
    active.remove(frozenset(s));active.add(frozenset(L)-frozenset(s))
slots={c:i for i,c in enumerate(c for c in cycles(4) if frozenset(c) in active)}
FULL=(1<<len(slots))-1
blocks=[];opts=defaultdict(list)
for c in cycles(5):
    rr=rules(c)
    for omit in range(5):
        rs=tuple(r for j,r in enumerate(rr) if j!=omit)
        if any(frozenset(r[:4]) not in active for r in rs):continue
        mask=sum(1<<slots[canon(r[:4])] for r in rs)
        b=len(blocks);blocks.append((c,omit,rs,mask))
        for r in rs:opts[r].append(b)
newmask=sum(1<<i for c,i in slots.items() if set(c)<={4,5,6,7,8})
assert newmask.bit_count()==24
colrows=[0]*len(slots)
for b,(_,_,rs,mask) in enumerate(blocks):
    for r in rs:colrows[slots[canon(r[:4])]]|=1<<b
conflicts=[]
for _,_,rs,_ in blocks:
    conflict=0
    for r in rs:conflict|=colrows[slots[canon(r[:4])]]
    conflicts.append(conflict)
ALLROWS=(1<<len(blocks))-1
class ExactCover:
    def __init__(self, seconds):self.deadline=time.monotonic()+seconds;self.nodes=0;self.timedout=False
    def solve(self, occupied=0, required=(), target=FULL):
        self.nodes=0;self.timedout=False
        live=ALLROWS
        for b in required:
            if occupied&blocks[b][3]:return None
            occupied|=blocks[b][3];live&=~conflicts[b]
        # Disallow all rows touching preoccupied slots, or any slot outside target.
        forbidden=occupied|(FULL^target)
        x=forbidden
        while x:
            bit=x&-x;x^=bit;live&=~colrows[bit.bit_length()-1]
        result=self.visit(target&~occupied,live,[])
        return None if result is None else list(required)+result
    def visit(self, remain, live, chosen):
        self.nodes+=1
        if not remain:return chosen[:]
        if self.nodes%1024==0 and time.monotonic()>self.deadline:
            self.timedout=True;return None
        best=0;degree=10**9;x=remain
        while x:
            bit=x&-x;x^=bit
            cand=colrows[bit.bit_length()-1]&live
            d=cand.bit_count()
            if d==0:return None
            if d<degree:degree=d;best=cand
            if d==1:break
        while best:
            bit=best&-best;best^=bit;b=bit.bit_length()-1
            result=self.visit(remain^blocks[b][3],live&~conflicts[b],chosen+[b])
            if result is not None:return result
            if self.timedout:return None
        return None

def audit_rule_table(table):
    wins=0;lost=0;hist=Counter();cfwins=0
    for p in permutations(L):
        ok=0;cf=0
        for a in L:
            b=a;h=[]
            for j in range(4):
                seen=p[b-1];h.append(seen)
                if seen==a:ok+=1;break
                b=table.get((a,tuple(h)),seen) if j==2 else seen
            b=a
            for j in range(4):
                b=p[b-1]
                if b==a:cf+=1;break
        hist[ok]+=1;wins+=ok>=7;cfwins+=cf>=7;lost+=cf>=7 and ok<7
    return dict(placements=40320,wins=wins,cf_wins=cfwins,lost_cf=lost,success_histogram=dict(hist))

def seed(c6,f):
    need=[r for r in rules(c6) if r[0]!=f];out=[]
    options={r:[b for b in opts[r] if not blocks[b][3]&newmask] for r in need}
    for choice in product(*(options[r]+[-1] for r in need)):
        if choice.count(-1)!=2:continue
        singles=tuple(r for r,b in zip(need,choice) if b==-1)
        fixed=frozenset(b for b in choice if b!=-1)
        smask=sum(1<<slots[canon(r[:4])] for r in singles)
        occ=newmask|smask
        for b in fixed:
            if occ&blocks[b][3]:break
            occ|=blocks[b][3]
        else:out.append((fixed,occ,singles,smask))
    assert len(out)==1
    return out[0]

def local_witnesses(fixed,occupied,singles):
    fixedrules=set(singles)
    for b in fixed:fixedrules.update(blocks[b][2])
    witnesses=[];parents=[];cc=[]
    for c in cycles(7):
        rr=rules(c);found=set()
        for ignore in range(7):
            needs=[r for j,r in enumerate(rr) if j!=ignore and r not in fixedrules]
            options=[[b for b in opts[r] if not blocks[b][3]&occupied] for r in needs]
            if any(not o for o in options):continue
            options.sort(key=len)
            def visit(j,mask,chosen):
                if j==len(options):found.add(frozenset(chosen));return
                for b in options[j]:
                    if b in chosen:visit(j+1,mask,chosen);continue
                    if mask&blocks[b][3]:continue
                    visit(j+1,mask|blocks[b][3],chosen|{b})
            visit(0,occupied,set())
        if found:
            cid=len(cc);cc.append(c)
            for w in sorted(found,key=lambda w:tuple(sorted(w))):witnesses.append(w);parents.append(cid)
    masks=[sum(blocks[b][3] for b in w) for w in witnesses]
    for i in range(len(witnesses)):
        for j in range(i+1,len(witnesses)):
            if parents[i]==parents[j]:continue
            shared=sum(blocks[b][3] for b in witnesses[i]&witnesses[j])
            if masks[i]&masks[j]!=shared:continue
            yield (cc[parents[i]],cc[parents[j]],witnesses[i]|witnesses[j])

def main():
    seconds=float(sys.argv[1]) if len(sys.argv)>1 else 240
    start=time.monotonic();deadline=start+seconds
    report={'scope':'standard three-support-flip, 210 slots, 52 four-rule blocks + 2 fixed singles; 4 specified R6 representatives',
        'algorithm':'pure Python exact cover with column minimum branching and bitset conflicting row removal',
        'case_results':[],'status':'RUNNING'}
    # Verify independent cover engine can tile the six new-side blocks.
    cover=ExactCover(5);newblocks=cover.solve(target=newmask)
    assert newblocks and len(newblocks)==6
    report['new_side_control']={'six_blocks':len(newblocks),'nodes':cover.nodes}
    control=Path(sys.argv[2]) if len(sys.argv)>2 else None
    if control:
        raw=json.loads(control.read_text(encoding='utf-8-sig'));rs=[(a,*h,t) for a,h,t in raw['rules']]
        report['known_certificate_control']=audit_rule_table({(r[0],r[1:4]):r[4] for r in rs})
        assert report['known_certificate_control']['wins']==15051
        groups=defaultdict(list)
        for r in rs:groups[canon((r[4],)+r[:4])].append(r)
        rows=[];singles=[]
        for c,gr in groups.items():
            if len(gr)==4:
                candidates=[b for b,x in enumerate(blocks) if x[0]==c and set(x[2])==set(gr)]
                assert len(candidates)==1;rows+=candidates
            else:singles+=gr
        assert len(rows)==52 and len(singles)==2
        occupied=sum(1<<slots[canon(r[:4])] for r in singles)
        cover=ExactCover(5);sol=cover.solve(occupied,rows)
        assert sol and len(sol)==52
        report['known_certificate_control']['decomposition_and_exact_cover_pass']=True
    cases=[((1,4,2,5,6,7),6),((1,4,2,5,7,6),7),((1,4,2,7,5,6),5),((1,4,5,6,2,7),5)]
    for c6,f in cases:
        fixed,occ,singles,smask=seed(c6,f)
        distinct={}
        for ca,cb,w in local_witnesses(fixed,occ,singles):
            distinct.setdefault(tuple(sorted(w)),(ca,cb))
        cr={'six_cycle':c6,'failing':f,'distinct_required_row_unions':len(distinct),'completed':0,'infeasible':0,'timeouts':0,'records':[]}
        report['case_results'].append(cr)
        for ws,pair in distinct.items():
            remain=deadline-time.monotonic()
            if remain<=0:break
            req=tuple(sorted(fixed|frozenset(ws)))
            solver=ExactCover(min(2,remain));sol=solver.solve(newmask|smask,req)
            status='FOUND' if sol is not None else ('TIME_LIMIT' if solver.timedout else 'INFEASIBLE_EXACT_COVER')
            cr['records'].append({'pair':pair,'required_rows':list(req),'status':status,'nodes':solver.nodes})
            cr['completed']+=status=='FOUND';cr['infeasible']+=status=='INFEASIBLE_EXACT_COVER';cr['timeouts']+=status=='TIME_LIMIT'
            if sol is not None:
                allrows=sol+newblocks;rr=[r for b in allrows for r in blocks[b][2]]+list(singles)
                assert len(rr)==210 and len({canon(r[:4]) for r in rr})==210
                name=OUT/'FOUND.rules.json';name.write_text(json.dumps({'schema':'mixed-n8-v1','rules':[[r[0],list(r[1:4]),r[4]] for r in sorted(rr)]},indent=2),encoding='utf-8')
                report['found_certificate']=str(name);report['independent_full_simulation']=audit_rule_table({(r[0],r[1:4]):r[4] for r in rr})
                report['status']='FOUND';break
            (OUT/'completion_result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print({k:v for k,v in cr.items() if k!='records'},flush=True)
        if report['status']=='FOUND' or time.monotonic()>=deadline:break
    if report['status']!='FOUND':
        report['status']='ENUMERATED_ALL_REQUIRED_UNIONS_INFEASIBLE' if len(report['case_results'])==4 and all(len(x['records'])==x['distinct_required_row_unions'] and x['timeouts']==0 for x in report['case_results']) else 'INCOMPLETE'
    report['elapsed_seconds']=round(time.monotonic()-start,3)
    (OUT/'completion_result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print({k:v for k,v in report.items() if k!='case_results'},flush=True)
if __name__=='__main__':main()
