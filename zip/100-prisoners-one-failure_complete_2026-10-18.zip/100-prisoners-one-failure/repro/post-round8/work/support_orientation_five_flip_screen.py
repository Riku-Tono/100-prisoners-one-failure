"""Exhaustive five-flip necessary screen; no target construction search.

Represent new8-supports by five triples H on[7]. Every support contributes
six cyclic-word slots. Since52blocks need208of210slots, every new support
must occur in a four-rule block. Such a block needs at leastthree H-triples
inside a four-set U. First screen enumerates every C(35,5) H exactly.
"""
from pathlib import Path
from itertools import combinations,permutations
from collections import Counter
import json,time,hashlib
Hdir=Path(__file__).resolve().parent;start=time.monotonic();L7=frozenset(range(1,8));L8=frozenset(range(1,9));triples=list(map(frozenset,combinations(range(1,8),3)));ti={t:i for i,t in enumerate(triples)};foursets=list(map(frozenset,combinations(range(1,8),4)));clusters=[sum(1<<ti[t]for t in triples if t<U)for U in foursets]
passed=[];tested=0
for combo in combinations(range(35),5):
 mask=sum(1<<i for i in combo);covered=0;tested+=1
 for cluster in clusters:
  meet=mask&cluster
  if meet.bit_count()>=3:covered|=meet
 if covered==mask:passed.append((combo,mask))
assert tested==324632;passed_masks={m for c,m in passed};seen=set();records=[]
def normal(w):
 w=tuple(w);i=w.index(min(w));return w[i:]+w[:i]
for combo,mask in passed:
 if mask in seen:continue
 ts=[triples[i]for i in combo];orbit=set()
 for p in permutations(range(1,8)):
  orbit.add(sum(1<<ti[frozenset(p[x-1]for x in t)]for t in ts))
 assert not orbit&seen and orbit<=passed_masks;seen|=orbit
 fs={L7-t for t in ts};S=set(foursets)-fs|{t|{8}for t in ts};words={normal(p)for s in S for p in permutations(s)};validclusters=[(U,frozenset(t for t in ts if t<U))for U in foursets if sum(t<U for t in ts)>=3]
 assert len(validclusters)==2 and all(len(c)==3 for U,c in validclusters)
 shared=validclusters[0][1]&validclusters[1][1];assert len(shared)==1;sharedtriple=next(iter(shared));assert len(set().union(*ts))==5
 blocks=set()
 for labels in combinations(range(1,9),5):
  for tail in permutations(labels[1:]):
   c=(labels[0],)+tail;rr=tuple((c[i],c[(i+1)%5],c[(i+2)%5],c[(i+3)%5],c[(i+4)%5])for i in range(5))
   for omit in range(5):
    b=frozenset(rr[:omit]+rr[omit+1:])
    if all(normal(r[:4])in words for r in b):blocks.add(b)
 used={normal(r[:4])for b in blocks for r in b};newblocks=[b for b in blocks if any(8 in r[:4]for r in b)];assert len(newblocks)==48
 sharedsupport=sharedtriple|{8};assert all(sum(frozenset(r[:4])==sharedsupport for r in b)==1 for b in newblocks)
 assert all(sum(8 in r[:4]for r in b)==3 for b in newblocks);assert len(used)==210
 windows={}
 for n in (6,7,8):
  counter=Counter()
  for sub in combinations(range(1,9),n):
   for tail in permutations(sub[1:]):
    c=(sub[0],)+tail;k=sum(frozenset(c[(j+i)%n]for i in range(4))in S for j in range(n));counter[(8 in c,k)]+=1
  windows[n]={'max_containing8':max(k for(has8,k),cnt in counter.items()if has8),'eligible_total':sum(cnt for(has8,k),cnt in counter.items()if k>=n-1),'eligible_containing8':sum(cnt for(has8,k),cnt in counter.items()if has8 and k>=n-1),'distribution':[{'contains8':has8,'allowed_windows':k,'cycles':cnt}for(has8,k),cnt in sorted(counter.items())]}
 records.append({'index':len(records),'new_complement_triples':sorted(map(sorted,ts)),'removed_supports':sorted(map(sorted,fs)),'added_supports':sorted(map(sorted,(t|{8}for t in ts))),'S7_orbit_size':len(orbit),'S7_stabilizer_order':5040//len(orbit),'clusters':[{'four_set':sorted(U),'triples':sorted(map(sorted,cs))}for U,cs in validclusters],'common_new_triple':sorted(sharedtriple),'common_new_support':sorted(sharedsupport),'actual_blocks':len(blocks),'actual_new_blocks':len(newblocks),'usable_cyclic_word_slots':len(used),'first_slot_capacity_upperbound':len(used)//4,'common_word_bottleneck_max_new_blocks':6,'new_word_slots_total':30,'max_new_word_slots_in_blocks':18,'old_word_slots_total':180,'refined_R5_block_capacity_upperbound':49,'passes_refined_52_block_test':False,'long_cycle_support_windows':windows})
assert seen==passed_masks and len(records)==2
out={'method':__doc__,'labelled_five_flips_tested':tested,'first_screen_passing_labelled_masks':len(passed),'first_screen_S7_orbits':len(records),'refined_52_block_eligible_orbits':[],'orbits':records,'geometry_argument':'Allfive triples must be cluster-covered. Onecluster holds at leastthree triples. Ifitheldfour, thefifthwouldneedanothercluster sharingatleasttwo withthefirst; two sharedtriples determinethefour-set, contradiction. Thusclustershavethreeedges. Two distinctsuchclusters shareatmostoneedgeand musttherefore shareexactlyone tofitfiveedges. TheirunionisH. Thetwoomittedpairchoicesoncommontriplearealignedordifferent, givingtwoS7orbits.','refined_obstruction':'Inbothorbits everynewblock usesoneofthe6cyclicwordsonthesharednew support. Thusatmost6newblocks, eachcovering3newwords. Atmost18of30newwords canlieinblocks. 52blocksneed208words, butonly180old+18new=198areavailabletoanypacking, givingR5<=floor(198/4)=49. Extrasarenotassumedzero; thisboundsfour-ruleblockpackingitself.','scope':'Exactlyfive flips and52rescuedfive-cyclesinthisfinal-box-onlyCF-preservingsupportfamily. No claim excluding15052throughR5<52orotherflipcounts.','seconds':time.monotonic()-start}
(Hdir/'support_orientation_five_flip_screen.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print({k:v for k,v in out.items()if k not in('orbits','method','geometry_argument','refined_obstruction')});print([{k:r[k]for k in('new_complement_triples','S7_orbit_size','actual_blocks','actual_new_blocks','refined_R5_block_capacity_upperbound','long_cycle_support_windows')}for r in records])
