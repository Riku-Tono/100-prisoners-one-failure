"""Enumerate support orientations extending each canonical six-rule core.

If 52 disjoint blocks use208 of210 active slots, every active four-support
must be usable by at least one block, since an unused support has six slots.
A block's four distinct four-supports lie in its five-label set. Thus every
active support must meet a five-set with at least four active four-subsets.
This is a necessary capacity screen, not block-packing feasibility.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import json,time,hashlib,argparse
H=Path(__file__).resolve().parent
ALL=frozenset(range(1,9))
A=tuple(map(frozenset,combinations(range(1,8),4)))
SUP=A+tuple(ALL-s for s in A);si={s:i for i,s in enumerate(SUP)}
BASE=(1<<35)-1
CLUSTERS=tuple(sum(1<<si[frozenset(s)] for s in combinations(t,4)) for t in combinations(range(1,9),5))
assert len(CLUSTERS)==56 and all(x.bit_count()==5 for x in CLUSTERS)

def capacity_ok(mask):
    covered=0
    for c in CLUSTERS:
        x=mask&c
        if x.bit_count()>=4:covered|=x
    return covered==mask

def main():
    p=argparse.ArgumentParser();p.add_argument('--start',type=int,default=0);p.add_argument('--stop',type=int,default=70)
    a=p.parse_args();started=time.monotonic();records=[]
    for i in range(a.start,a.stop):
        path=H/f'canonical_six_witness_cores/core_{i:03}.json';d=json.loads(path.read_text())
        forced={frozenset(r[:4]) for b in d['actual_blocks'] for r in b}|{frozenset(r[:4]) for r in d['extras']}
        assert all(s in A for s in forced)
        free=tuple(j for j,s in enumerate(A) if s not in forced)
        accepted=[];by_count=Counter();orientation=BASE;flip=0;last=0
        for k in range(1<<len(free)):
            gray=k^(k>>1)
            if k:
                change=gray^last;bit=free[change.bit_length()-1]
                flip^=1<<bit;orientation^=(1<<bit)|(1<<(bit+35))
            if capacity_ok(orientation):accepted.append(flip);by_count[flip.bit_count()]+=1
            last=gray
        accepted.sort()
        rec=dict(core_index=i,extras=len(d['extras']),forced_supports=len(forced),free_support_pairs=len(free),
            tested=1<<len(free),capacity_accepted=len(accepted),by_flip_count=dict(sorted(by_count.items())),
            accepted_masks_hex=[f'{x:09x}' for x in accepted],
            accepted_sha256=hashlib.sha256(''.join(f'{x:09x}\n' for x in accepted).encode('ascii')).hexdigest(),
            input_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        records.append(rec)
        out=dict(method=__doc__,records=records,core_range=[a.start,a.stop],complete=len(records)==a.stop-a.start,seconds=time.monotonic()-started)
        (H/f'canonical_orientation_capacity_{a.start}_{a.stop}.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        print(i,rec['tested'],rec['capacity_accepted'],rec['by_flip_count'],flush=True)

if __name__=='__main__':main()
