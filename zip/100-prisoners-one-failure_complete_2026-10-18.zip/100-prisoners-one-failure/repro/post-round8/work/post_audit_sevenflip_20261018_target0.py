"""Assignedtarget0 controlsforunresolvedsevenfliporbits9and15.
Fullgeneric8labelmodel,R5=52,R6=0; no rescue-target requirement.
Actualtablesaredirectlycheckedonall40320placementsbeforeexportreport.
"""
from pathlib import Path
import sys,json,time,datetime,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));import general_orientation_model as G
raw=(H/'post_audit_sevenflip_20261018_screen.json').read_bytes();screen=json.loads(raw);byid={r['index']:r for r in screen['orbits']};order=[9,15];start=time.monotonic();batch={'scope':__doc__,'model_scope':G.__doc__,'screen_sha256':hashlib.sha256(raw).hexdigest(),'general_model_sha256':hashlib.sha256((H/'general_orientation_model.py').read_bytes()).hexdigest(),'assigned_orbits':order,'workers':1,'seconds_per_solve':120,'records':[],'status':'RUNNING'}
def save():
 batch['seconds']=time.monotonic()-start;(H/'post_audit_sevenflip_20261018_target0_summary.json').write_text(json.dumps(batch,indent=2),encoding='utf-8')
def witness_report(model,solver,label):
 selected={i for i,v in enumerate(model.blocks)if solver.value(v)};extras={r for r,v in model.singles.items()if solver.value(v)};core=set().union(*(model.data.blocks[i]for i in selected));rules=core|extras;coreholes=set(model.data.words)-{G.canon(r[:4])for r in core};allholes=set(model.data.words)-{G.canon(r[:4])for r in rules};assert len(coreholes)==2 and len(allholes)==2-len(extras)
 provenance={r:{'kind':'block','block_id':i}for i in selected for r in model.data.blocks[i]};provenance.update({r:{'kind':'single'}for r in extras});seven=[]
 for c,rr in G.cycle_data(7):
  correct=rr&rules
  if len(correct)>=6:seven.append({'cycle':c,'correct_rule_count':len(correct),'failing_prisoners':sorted(r[0]for r in rr-rules),'correct_rules':[{'rule':r,'source':provenance[r]}for r in sorted(correct)]})
 six=[c for c,rr in G.cycle_data(6)if len(rr&rules)>=5];assert not six
 report={'orbit_flips':model.data.flips,'rules':len(rules),'selected_block_ids':sorted(selected),'single_rules':sorted(extras),'block_core_holes':sorted(coreholes),'remaining_unused_word_holes':sorted(allholes),'rescued_seven_cycles':seven,'R7':len(seven),'R6':0,'all6cycle_rule_check_count':len(G.cycle_data(6)),'scope':'Actual exportedtable,witnessdetailsforfuturehint/completion. Thisreportisafterindependent40320directaudit.'};p=H/(label+'.witnesses.json');p.write_text(json.dumps(report,indent=2),encoding='utf-8');return str(p),report
for index in order:
 spec=byid[index];label=f'post_audit_sevenflip_20261018_orbit{index}_target0';model=G.build(spec['flips'],target=0);assert model.model.validate()=='';assert len(model.blocks)==spec['actual_rule_blocks'];mp=H/(label+'.model.txt');assert model.model.export_to_file(str(mp));record={'orbit_index':index,'flip_count':7,'target':0,'flips':model.data.flips,'stats':model.stats,'validation_passed':True,'status':'RUNNING','workers':1,'random_seed':20261018+2000+index,'model_proto_text':str(mp),'model_proto_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'auxiliary_sixflip_assumptions_used':False,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};rp=H/(label+'.result.json');rp.write_text(json.dumps(record,indent=2),encoding='utf-8');batch['current']={'orbit_index':index,'result':str(rp)};save();print('START',index,flush=True)
 solver=G.cp_model.CpSolver();solver.parameters.max_time_in_seconds=120;solver.parameters.num_search_workers=1;solver.parameters.random_seed=record['random_seed'];(H/(label+'.parameters.txt')).write_text(str(solver.parameters),encoding='utf-8');status=solver.solve(model.model);record.update(status=solver.status_name(status),solve_seconds=solver.wall_time,response_stats=solver.response_stats(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());response=H/(label+'.response.txt');response.write_text(str(solver.response_proto),encoding='utf-8');record['solver_response_proto_text']=str(response)
 if status in(G.cp_model.FEASIBLE,G.cp_model.OPTIMAL):
  record.update(model.export_and_audit(solver,H/(label+'.rules.json'),H/(label+'.audit.json')));wp,witness=witness_report(model,solver,label);record['witness_report']=wp;record['R7']=witness['R7'];record['block_core_holes']=witness['block_core_holes'];record['single_rules']=witness['single_rules'];record['remaining_unused_word_holes']=witness['remaining_unused_word_holes']
 rp.write_text(json.dumps(record,indent=2),encoding='utf-8');batch['records'].append(record);batch.pop('current',None);save();print('END',index,record['status'],record['solve_seconds'],record.get('audit',{}).get('wins'),record.get('R7'),flush=True)
 if record.get('audit',{}).get('wins',0)>=15052:batch['status']='TARGET4_FOUND_DURING_TARGET0';batch['found_orbit']=index;save();break
else:batch['status']='ASSIGNED_TARGET0_CONTROLS_FINISHED';save()
print('FINAL',batch['status'],batch['seconds'],flush=True)
