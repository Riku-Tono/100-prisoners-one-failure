"""Full four-flip model, begun after Desktop Claude AUDIT_PASS."""
import json,time
from pathlib import Path
import general_orientation_model as g

H=Path(__file__).resolve().parent
gate=json.loads((H/'claude_desktop_continuation3/audit_status.json').read_text(encoding='utf-8-sig'))
assert gate['status']=='AUDIT_PASS'
flips=((1,2,3,4),(1,2,3,5),(1,2,3,6),(1,2,3,7))
om=g.build(flips,target=4)
assert om.model.validate()==''
print('MODEL_VALIDATED',json.dumps(om.stats),flush=True)
s=g.cp_model.CpSolver()
s.parameters.max_time_in_seconds=120
s.parameters.num_search_workers=1
s.parameters.random_seed=1
st=s.solve(om.model)
out=dict(scope='All rules on the four-flip orientation; exactly52 four-rule blocks plus at most2 extra rules, CF-preserving final-box-only, R6=0, R7+R8>=4. UNKNOWN is unresolved.',audit_gate='AUDIT_PASS',flips=flips,status=s.status_name(st),seconds=s.wall_time,stats=om.stats,response=s.response_stats())
if st in (g.cp_model.FEASIBLE,g.cp_model.OPTIMAL):
    out.update(om.export_and_audit(s,H/'post_audit_fourflip_generic_20261018.rules.json'))
(H/'post_audit_fourflip_generic_20261018.result.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out),flush=True)
