"""Verify and summarize the 21 one-singleton bounded completion attempts."""
from pathlib import Path
import hashlib, json

H = Path(__file__).resolve().parent
PREFIX = H/'global_orientation_oneextra_20261018'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    checkpoint_path = PREFIX.with_suffix('.checkpoint.json')
    data = json.loads(checkpoint_path.read_text())
    assert data['provenance']['selected_extra_count'] == 1
    assert data['provenance']['selected_count'] == 21
    assert data['workers'] == 1 and data['seconds_per_core'] == 20
    assert [r['representative_index'] for r in data['records']] == list(range(4, 25))
    rows = []
    for position, record in enumerate(data['records']):
        out = {'representative_index': record['representative_index'],
               'status': record['status']}
        if record['status'] != 'NOT_RUN':
            rp = Path(record['result_file'])
            result = json.loads(rp.read_text())
            assert sha(rp) == record['result_sha256']
            assert result['status'] == record['status']
            assert result['workers'] == 1 and result['limit_seconds'] == 20
            assert result['random_seed'] == 1 and result['stats']['target'] == 4
            assert result['stats']['complement_pair_variables'] == 35
            assert result['stats']['blocks'] == 6720 and result['stats']['singles'] == 6720
            assert record['fixed'] == {'mandatory_blocks': 5, 'mandatory_extras': 1}
            log = Path(str(PREFIX) + f'_core{position:03d}.log.txt')
            out.update(solve_seconds=result['solve_seconds'], result_file=str(rp.resolve()),
                       result_sha256=sha(rp), log_file=str(log), log_sha256=sha(log),
                       response_stats=result['response_stats'])
        rows.append(out)
    audit_path = H/'global_orientation_independent_static_review_20261018.json'
    reviewed = json.loads(audit_path.read_text())
    assert reviewed['source_sha256'] == sha(H/'global_orientation_witness_completion.py')
    core_audit = H/'canonical_six_witness_independent_review_20261018.json'
    out = {'scope': 'All complementary support orientations; 52 blocks + <=2 singletons; R6=0; R7>=4; canonical six correct; fixed actual one-singleton witness core only.',
           'additional_cuts': [], 'workers': 1, 'seconds_per_core': 20,
           'selected_core_ids': list(range(4,25)),
           'source_hashes': {name: sha(H/name) for name in
                             ('global_orientation_witness_completion.py',
                              'global_orientation_core_runner.py',
                              'canonical_six_witness_preparation.json',
                              'global_orientation_controls.json')},
           'model_review': str(audit_path), 'model_review_sha256': sha(audit_path),
           'core_review': str(core_audit), 'core_review_sha256': sha(core_audit),
           'checkpoint': str(checkpoint_path), 'checkpoint_sha256': sha(checkpoint_path),
           'summary': data['summary'], 'records': rows,
           'total_solver_seconds': sum(r.get('solve_seconds', 0) for r in rows),
           'interpretation': 'UNKNOWN means unresolved; no impossibility claim follows from a bounded attempt.'}
    path = H/'global_orientation_oneextra_20261018.manifest.json'
    path.write_text(json.dumps(out, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k,v in out.items() if k != 'records'}, indent=2))

if __name__ == '__main__':
    main()
