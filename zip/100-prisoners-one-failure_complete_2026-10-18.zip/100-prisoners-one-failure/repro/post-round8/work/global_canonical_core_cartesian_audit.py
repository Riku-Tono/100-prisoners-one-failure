"""Independent Cartesian regeneration of all canonical-six supplier cores.

Uses the lossword+target five-cycle-group generator, not the submitted DFS
or its2520-block catalogue. Enumerates all5^6 supplier choices before the
<=2 single and word collision filters. No completion solver is called.
"""
from itertools import product
from collections import Counter
from pathlib import Path
import hashlib,json,time
from sevenflip9_witness_rulepair_lemma import regenerate,word,rules
H=Path(__file__).resolve().parent
REQUIRED=((1,2,3,4,7),(2,3,4,5,1),(3,4,5,6,2),(4,5,6,7,3),(5,6,7,1,4),(6,7,1,2,5))

def key(blocks,extras):
    return (tuple(sorted(tuple(sorted(b)) for b in blocks)),tuple(sorted(extras)))

def main():
    started=time.monotonic();_,blocks=regenerate(labels=frozenset(range(1,8)))
    assert len(blocks)==2520
    opts=[]
    for r in REQUIRED:
        suppliers=[b for b in blocks if r in b]
        assert len(suppliers)==4 and all(len(set(REQUIRED)&b)==1 for b in suppliers)
        opts.append([(b,None) for b in suppliers]+[(None,r)])
    cartesian=allowed=0;found=set();hist=Counter()
    for selection in product(*opts):
        cartesian+=1
        extras=tuple(r for b,r in selection if r is not None)
        if len(extras)>2:continue
        allowed+=1;chosen=tuple(b for b,r in selection if b is not None)
        rs=[r for b in chosen for r in b]+list(extras)
        occupied=[word(r[:4]) for r in rs]
        if len(occupied)!=len(set(occupied)):continue
        assert set(REQUIRED)<=set(rs)
        found.add(key(chosen,extras));hist[len(extras)]+=1
    src=H/'canonical_six_witness_preparation.json';raw=src.read_bytes();doc=json.loads(raw)
    submitted={key([frozenset(map(tuple,b)) for b in rec['actual_blocks']],map(tuple,rec['extras'])) for rec in doc['records']}
    assert found==submitted and len(found)==len(doc['records'])==70
    assert dict(hist)=={0:4,1:21,2:45}
    out=dict(status='PASS_EXACT_ACTUAL_RULE_SET_EQUALITY',method=__doc__,submitted_sha256=hashlib.sha256(raw).hexdigest(),
             all2520_blocks_independently_regenerated=True,total_cartesian_choices=cartesian,
             choices_with_at_most2_extras=allowed,unique_legal_cores=len(found),extra_count_histogram=dict(hist),
             missing_from_submission=0,extra_in_submission=0,Solve_called=False,seconds=time.monotonic()-started)
    (H/'global_canonical_core_cartesian_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2),flush=True)

if __name__=='__main__':main()
