"""Actual18-block seed -> exhaustive critical-fourth witnesses -> non-CP cover.

Only full-star,52 four-rule blocks,<=2 extra rules and R6=0 are handled.
The fixed seed must already rescue at least3 sevens with>=6 correct rules;
7/7 correctness is never required. A seed with fewer rescues is rejected,
since enumerating one additional cycle would not cover target4.
UNKNOWN is retained. Previously closed18-core supersets reuse that proof.
Actual mandatory sets are stored as fixed_actual_blocks plus each record's
additional_actual_blocks; IDs are convenience only, tied to a catalogue SHA.
"""
from pathlib import Path
from itertools import permutations,combinations
from collections import defaultdict,Counter
import argparse,hashlib,json,time
from fullstar_finite_core_finish import HighEngine
from fullstar_finite_core_completion import H,RULES,ROWS,WORDS,SIX,R6INC,DELTA,CATALOGUE_SHA,canon,correct,export_and_audit

LOOKUP={b:i for i,b in enumerate(RULES)}
SEVENS=tuple(((1,)+tail,frozenset(correct((1,)+tail))) for tail in permutations(range(2,8)))

def save(path,data):Path(path).write_text(json.dumps(data,separators=(',',':')),encoding='utf-8')

def closed_proof():
    p=H/'fullstar_fixed18_complete_summary.json';raw=p.read_bytes();doc=json.loads(raw)
    catalogue=json.loads((H/'fullstar_fixed_core_enumeration.json').read_text())
    assert catalogue['block_catalogue_sha256']==CATALOGUE_SHA
    assert doc['status']=='EXHAUSTED_NO_TARGET4_WITH_FIXED_18_CORE' and doc['all3735_verified_by_non_CP_cover']
    assert doc['unknown']==doc['unprocessed']==doc['found']==0
    assert set(doc['fixed_core'])==set(catalogue['fixed_core'])
    return frozenset(doc['fixed_core']),dict(source=str(p),sha256=hashlib.sha256(raw).hexdigest())

def seed_facts(seed):
    seed=frozenset(seed)
    if len(seed)!=18:raise ValueError('Expected exactly18 distinct mandatory blocks.')
    used=[w for b in seed for w in ROWS[b]]
    if len(used)!=len(set(used)):raise ValueError('Mandatory seed has colliding words.')
    fixed=set().union(*(RULES[b] for b in seed))
    counts=[len(set(rr)&fixed) for rr in SIX]
    if max(counts)>4:raise ValueError('Mandatory seed already violates R6=0.')
    rescues=[c for c,rr in SEVENS if len(rr&fixed)>=6]
    if len(rescues)<3:raise ValueError('One-additional-cycle target4 coverage requires at least3 seed rescues.')
    return dict(blocks=18,words=72,base_R6=0,base_R7=len(rescues),rescued_cycles=rescues,
                correct_counts=[len(rr&fixed) for c,rr in SEVENS if len(rr&fixed)>=6])

def load_manifest(path):
    p=Path(path);raw=p.read_bytes();doc=json.loads(raw);closed,proof=closed_proof();seeds=[]
    for position,record in enumerate(doc['seeds']):
        actual=record.get('actual_blocks',record.get('actual_rules'))
        if actual is None:raise ValueError('Manifest seed is missing actual blocks.')
        keys=[frozenset(map(tuple,b)) for b in actual]
        if len(keys)!=18 or len(set(keys))!=18 or any(b not in LOOKUP for b in keys):raise ValueError('Invalid actual18-block seed.')
        seed=frozenset(LOOKUP[b] for b in keys)
        if seed==closed:raise ValueError('Closed18 branch must not be rescanned.')
        if record.get('extras'):raise ValueError('This mandatory18 interface expects no pre-fixed extras.')
        facts=seed_facts(seed)
        declared=record.get('cycles',())
        fixed=set().union(*(RULES[b] for b in seed))
        if any(len(set(correct(tuple(c)))&fixed)<6 for c in declared):raise ValueError('Declared seed cycle is not rescued.')
        seeds.append(dict(core_index=record.get('core_index',position),seed=seed,facts=facts,
                          distance_from_closed=len(seed^closed),manifest_position=position,
                          expansion_representative_index=record.get('expansion_representative_index')))
    return sorted(seeds,key=lambda r:(r['distance_from_closed'],r['core_index'])),dict(source=str(p),sha256=hashlib.sha256(raw).hexdigest(),seeds=len(seeds),closed_proof=proof)

def enumerate_critical(seed):
    started=time.monotonic();seed=frozenset(seed);facts=seed_facts(seed)
    fixed=set().union(*(RULES[b] for b in seed));initial_slots=frozenset(w for b in seed for w in ROWS[b]);inc=defaultdict(list)
    for b,rs in enumerate(RULES):
        if not set(ROWS[b])&initial_slots:
            for r in rs:inc[r].append(b)
    counts=[len(set(rr)&fixed) for rr in SIX];nodes=leaves=0;found={};cycle_stats=[]
    if facts['base_R7']>=4:
        found[(tuple(sorted(seed)),())]={'cycles':set()}
    else:
        for cycle,rr in SEVENS:
            if len(rr&fixed)>=6:continue
            before=len(found);local_leaves=0
            for ignored in sorted(rr):
                needed=rr-{ignored}-fixed
                if any(canon(r[:4]) in initial_slots for r in needed):continue
                def dfs(todo,used,chosen,extras):
                    nonlocal nodes,leaves,local_leaves
                    nodes+=1
                    if not todo:
                        leaves+=1;local_leaves+=1;key=(tuple(sorted(seed|chosen)),tuple(sorted(extras)))
                        found.setdefault(key,{'cycles':set()})['cycles'].add(cycle);return
                    opts=[]
                    for r in todo:
                        bs=[b for b in inc[r] if not set(ROWS[b])&used and all(counts[k]<4 for k in DELTA[b])]
                        single=len(extras)<2 and canon(r[:4]) not in used and all(counts[k]<4 for k in R6INC[r])
                        if not bs and not single:return
                        opts.append((len(bs)+int(single),r,bs,single))
                    _,r,bs,single=min(opts)
                    for b in bs:
                        for k in DELTA[b]:counts[k]+=1
                        dfs(todo-RULES[b],used|set(ROWS[b]),chosen|{b},extras)
                        for k in DELTA[b]:counts[k]-=1
                    if single:
                        for k in R6INC[r]:counts[k]+=1
                        dfs(todo-{r},used|{canon(r[:4])},chosen,extras|{r})
                        for k in R6INC[r]:counts[k]-=1
                dfs(needed,initial_slots,frozenset(),frozenset())
            if local_leaves:cycle_stats.append(dict(cycle=cycle,leaves=local_leaves,new_unique_cores=len(found)-before))
    records=[]
    for index,(key,data) in enumerate(sorted(found.items())):
        blocks,extras=key;additional=set(blocks)-seed;allrules=set().union(*(RULES[b] for b in blocks))|set(extras)
        occupied=[canon(r[:4]) for r in allrules]
        assert len(allrules)==4*len(blocks)+len(extras) and len(occupied)==len(set(occupied))
        assert all(len(set(rr)&allrules)<=4 for rr in SIX)
        assert sum(len(rr&allrules)>=6 for c,rr in SEVENS)>=4
        records.append(dict(index=index,core_blocks=blocks,critical_extra_rules=extras,
                            additional_actual_blocks=[sorted(RULES[b]) for b in sorted(additional)],fourth_cycles=sorted(data['cycles'])))
    minimal=[];subsumed={};accepted=defaultdict(list)
    for rec in sorted(records,key=lambda r:(len(r['core_blocks'])-18+len(r['critical_extra_rules']),len(r['critical_extra_rules']),r['core_blocks'],r['critical_extra_rules'])):
        mask=sum(1<<b for b in rec['core_blocks']);extras=rec['critical_extra_rules'];small=None
        for n in range(len(extras)+1):
            for subset in combinations(extras,n):
                for bm,idx in accepted[tuple(subset)]:
                    if mask&bm==bm:small=idx;break
                if small is not None:break
            if small is not None:break
        if small is not None:subsumed[str(rec['index'])]=small
        else:
            minimal.append(rec['index']);accepted[tuple(extras)].append((mask,rec['index']))
    return dict(status='EXHAUSTED_CRITICAL_ENUMERATION_NO_COMPLETION',scope=__doc__,fixed_core=sorted(seed),
                fixed_actual_blocks=[sorted(RULES[b]) for b in sorted(seed)],actual_set_encoding='fixed_actual_blocks union record.additional_actual_blocks; critical extras are actual5tuples',
                block_catalogue_sha256=CATALOGUE_SHA,seed_facts=facts,dfs_nodes=nodes,dfs_leaves=leaves,
                records=records,minimal_record_indices=minimal,subsumed_by_minimal_record=subsumed,
                unique_critical_cores=len(records),minimal_critical_cores=len(minimal),fourth_cycle_count=len(cycle_stats),
                extra_count_histogram=dict(Counter(len(r['critical_extra_rules']) for r in records)),cycle_stats=cycle_stats,seconds=time.monotonic()-started)

def positive_control(prefix):
    prefix=Path(prefix);closed,proof=closed_proof();src=H/'inputs/baseline15051.rules.json';d=json.loads(src.read_text());rules={(a,*h,t) for a,h,t in d['rules']}
    known=frozenset(i for i,b in enumerate(RULES) if b<=rules);assert len(known)==52 and closed<=known
    engine=HighEngine();status,nodes,additional,holes=engine.run(closed,[],5,2000000,known,True)
    assert status=='FOUND' and closed|set(additional)==known and len(additional)==34
    audited=export_and_audit(prefix.with_suffix('.positive.rules.json'),closed,[],additional,holes,15051)
    assert audited['rescued_cycles']['7']==3
    result=dict(status='PASS_KNOWN_18_TO_52_RESTORED',retained=18,recovered=34,nodes=nodes,
                hint_only=True,found_blocks_exactly_known=True,direct_audit=audited,closed_proof=proof)
    save(prefix.with_suffix('.positive.json'),result);return result

def run_seed(seed_record,provenance,prefix,wall_seconds=300,pure_seconds=1,r6_seconds=3,node_limit=2000000,resume_from=None,prepared_critical=None,packing_hint_path=None):
    prefix=Path(prefix);seed=frozenset(seed_record['seed']);closed,proof=closed_proof();assert seed!=closed
    facts=seed_facts(seed);start=time.monotonic();deadline=start+wall_seconds;engine=HighEngine()
    out=dict(scope=__doc__,provenance=provenance,core_index=seed_record['core_index'],fixed_core=sorted(seed),seed_facts=facts,
             records=[],status='RUNNING',node_limit=node_limit,pure_seconds=pure_seconds,r6_seconds=r6_seconds,wall_seconds=wall_seconds)
    target=prefix.with_suffix('.result.json')
    prior=None
    if resume_from is not None:
        prior_path=Path(resume_from);prior_raw=prior_path.read_bytes();prior=json.loads(prior_raw)
        assert prior['core_index']==out['core_index'] and prior['fixed_core']==out['fixed_core']
        assert prior['provenance']['sha256']==provenance['sha256']
        if prior['status'].startswith('FOUND'):raise ValueError('Previous result already contains an independently audited candidate.')
        out['resume_history']=dict(source=str(prior_path),sha256=hashlib.sha256(prior_raw).hexdigest(),status=prior['status'],
                                   prior_unknown_indices=prior.get('unknown_indices',[]),prior_unprocessed_indices=prior.get('unprocessed_indices',[]))
        for rec in prior['records']:
            if rec['status'] in ('EXHAUSTED_NO_COMPLETION','REUSED_CLOSED18_SUPERSET','REUSED_EXHAUSTED_FROM_PREVIOUS'):
                out['records'].append(dict(index=rec['index'],status='REUSED_EXHAUSTED_FROM_PREVIOUS',nodes=0,
                                           source=str(prior_path),source_status=rec['status'],source_nodes=rec.get('nodes',0),source_r6_nodes=rec.get('r6_nodes',0)))
    # Necessary52-block precheck: excluding it also excludes any extra rules.
    initial_hint=frozenset()
    if packing_hint_path is not None:
        hint_path=Path(packing_hint_path);hint_raw=hint_path.read_bytes();hd=json.loads(hint_raw)
        hrules={(a,*hist,t) for a,hist,t in hd['rules']};hextras=set(map(tuple,hd['extra_rules']));pure=hrules-hextras
        initial_hint=frozenset(i for i,b in enumerate(RULES) if b<=pure)
        assert len(initial_hint)==52 and seed<=initial_hint and len(pure)==208
        assert set().union(*(RULES[b] for b in initial_hint))==pure
        assert len({canon(r[:4]) for r in pure})==208
        assert set(hd['selected_block_ids'])==set(initial_hint)
        assert all(len(set(rr)&pure)<=4 for rr in SIX)
        out['packing_hint_source']=dict(path=str(hint_path),sha256=hashlib.sha256(hint_raw).hexdigest(),block_count=52,hint_not_a_constraint=True)
    if prior is None:
        if initial_hint:
            status='FOUND';nodes=0;more=sorted(initial_hint-seed);holes=sorted(set(WORDS)-{w for b in initial_hint for w in ROWS[b]})
            assert len(holes)==2
        else:status,nodes,more,holes=engine.run(seed,[],min(2,wall_seconds),node_limit,use_r6=True)
        out['initial_R6zero_52packing']=dict(status=status,nodes=nodes,extras=0,holes=2)
    else:
        status=prior['initial_R6zero_52packing']['status'];nodes=0;more=holes=None
        out['initial_R6zero_52packing']=dict(prior['initial_R6zero_52packing'],reused_from=str(resume_from))
    hint=initial_hint
    if status=='EXHAUSTED_NO_COMPLETION':
        out.update(status='EXHAUSTED_NO_52BLOCK_PACKING_WITH_MANDATORY18',unknown_indices=[],unprocessed_indices=[],seconds=time.monotonic()-start)
        save(target,out);return out
    if status=='FOUND' and prior is None:
        hint=seed|set(more);audit=export_and_audit(prefix.with_suffix('.initial52.rules.json'),seed,[],more,holes,15051)
        out['initial_R6zero_52packing']['direct_audit']=audit
        if audit['wins']>=15052:
            out.update(status='FOUND_INDEPENDENTLY_VERIFIED_IN_INITIAL52',seconds=time.monotonic()-start);save(target,out);return out
    enum_path=prefix.with_suffix('.critical.json')
    if prior is None:
        if prepared_critical is None:enum=enumerate_critical(seed);save(enum_path,enum)
        else:
            enum_raw=Path(prepared_critical).read_bytes();enum=json.loads(enum_raw)
            assert enum['fixed_core']==sorted(seed) and enum['block_catalogue_sha256']==CATALOGUE_SHA
            for rec in enum['records']:
                assert {LOOKUP[frozenset(map(tuple,b))] for b in rec['additional_actual_blocks']}==set(rec['core_blocks'])-seed
            enum_path.write_bytes(enum_raw);out['prepared_critical_source']=dict(path=str(prepared_critical),sha256=hashlib.sha256(enum_raw).hexdigest())
    else:
        enum_raw=Path(prior['critical_file']).read_bytes();assert hashlib.sha256(enum_raw).hexdigest()==prior['critical_sha256']
        enum=json.loads(enum_raw);assert enum['fixed_core']==sorted(seed) and enum['block_catalogue_sha256']==CATALOGUE_SHA
        for rec in enum['records']:
            actual={LOOKUP[frozenset(map(tuple,b))] for b in rec['additional_actual_blocks']}
            assert actual==set(rec['core_blocks'])-seed
        enum_path.write_bytes(enum_raw)
    out.update(critical_file=str(enum_path),critical_sha256=hashlib.sha256(enum_path.read_bytes()).hexdigest(),
               total_critical=len(enum['records']),minimal_critical=len(enum['minimal_record_indices']),
               enumeration_seconds=enum['seconds'],previous_closed_proof=proof)
    for idx in enum['minimal_record_indices']:
        if any(r['index']==idx for r in out['records']):continue
        critical=enum['records'][idx];blocks=frozenset(critical['core_blocks']);extras=critical['critical_extra_rules']
        if closed<=blocks:
            out['records'].append(dict(index=idx,status='REUSED_CLOSED18_SUPERSET',nodes=0,source=proof));continue
        remaining=deadline-time.monotonic()
        if remaining<=0:break
        st,n,more,holes=engine.run(blocks,extras,min(pure_seconds,remaining),node_limit,hint,use_r6=False)
        rec=dict(index=idx,status=st,engine='PURE_HIGH_BITSET',nodes=n)
        if st=='FOUND':
            rr=set().union(*(RULES[b] for b in blocks|set(more)))|set(map(tuple,extras))
            if any(len(set(c)&rr)>=5 for c in SIX):st='NEEDS_R6_SEARCH'
        if st=='NEEDS_R6_SEARCH' or st.startswith('UNKNOWN'):
            remaining=deadline-time.monotonic()
            if remaining<=0:rec['status']='UNKNOWN_WALL_LIMIT';st=rec['status']
            else:
                st,n6,more,holes=engine.run(blocks,extras,min(r6_seconds,remaining),node_limit,hint,use_r6=True)
                rec.update(status=st,engine='R6_HIGH_BITSET',r6_nodes=n6)
        if st=='FOUND':
            path=Path(str(prefix)+f'.found_{idx}.rules.json');rec.update(certificate=str(path),direct_audit=export_and_audit(path,blocks,extras,more,holes,15052))
            out['status']='FOUND_INDEPENDENTLY_VERIFIED'
        out['records'].append(rec)
        if len(out['records'])%25==0 or st=='FOUND':
            out.update(seconds=time.monotonic()-start,counts=dict(Counter(r['status'] for r in out['records'])));save(target,out)
        if len(out['records'])%250==0 or st=='FOUND':print('CORE',out['core_index'],'attempted',len(out['records']),out.get('counts'),flush=True)
        if st=='FOUND':break
    covered={r['index'] for r in out['records']};out['unprocessed_indices']=sorted(set(enum['minimal_record_indices'])-covered)
    out['unknown_indices']=[r['index'] for r in out['records'] if r['status'].startswith('UNKNOWN')]
    out.update(seconds=time.monotonic()-start,counts=dict(Counter(r['status'] for r in out['records'])))
    if out['status']=='RUNNING':
        out['status']='EXHAUSTED_NO_TARGET4_WITH_THIS_MANDATORY18' if not out['unprocessed_indices'] and not out['unknown_indices'] else 'INCOMPLETE_UNRESOLVED'
    save(target,out);return out

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=('controls','prepare','search'))
    p.add_argument('--manifest');p.add_argument('--prefix',required=True);p.add_argument('--core-index',type=int)
    p.add_argument('--wall-seconds',type=float,default=300);p.add_argument('--pure-seconds',type=float,default=1)
    p.add_argument('--r6-seconds',type=float,default=3);p.add_argument('--node-limit',type=int,default=2000000);p.add_argument('--resume-from')
    p.add_argument('--prepared-critical');p.add_argument('--packing-hint');a=p.parse_args()
    if a.command=='controls':positive_control(a.prefix);return
    if not a.manifest:raise ValueError('Manifest required.')
    seeds,provenance=load_manifest(a.manifest)
    if a.core_index is not None:seeds=[s for s in seeds if s['core_index']==a.core_index]
    if not seeds:raise ValueError('No selected seed.')
    selected=seeds[0];metadata=dict(provenance=provenance,selected_core_index=selected['core_index'],distance_from_closed=selected['distance_from_closed'],facts=selected['facts'],Solve_called=False)
    save(Path(a.prefix).with_suffix('.preparation.json'),metadata)
    if a.command=='prepare':print(metadata,flush=True);return
    if Path(a.prefix).with_suffix('.result.json').exists():raise ValueError('Result prefix exists; use a new prefix to preserve raw history.')
    positive_control(a.prefix)
    result=run_seed(selected,provenance,a.prefix,a.wall_seconds,a.pure_seconds,a.r6_seconds,a.node_limit,a.resume_from,a.prepared_critical,a.packing_hint)
    print('FINAL',result['core_index'],result['status'],result.get('counts'),result.get('seconds'),flush=True)

if __name__=='__main__':main()
