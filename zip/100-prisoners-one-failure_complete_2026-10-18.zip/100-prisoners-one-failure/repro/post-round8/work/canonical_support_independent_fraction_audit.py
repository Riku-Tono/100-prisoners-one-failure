"""Claude-actual-block independent support-capacity audit.

Does not import the submitted support relaxation or orientation builders.
Regenerates all6720 four-rule blocks using Claude c3's cycle/rule functions.
For each supplied orientation, actual block support rows are the relaxation
patterns. GLOP only proposes fractional dual weights; every exclusion from
weights is rechecked exactly with Fraction. CBC, a different integer engine
from the submitted CP-SAT model, checks cases not excluded by an exact dual.
The1378-orbit input coverage is an external dependency, not proved here.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
from fractions import Fraction
import sys,json,hashlib,time

H=Path(__file__).resolve().parent
RUNTIME=Path(r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
sys.path.insert(0,str(RUNTIME));sys.path.insert(0,str(H/'claude_desktop_continuation3'))
from ortools.linear_solver import pywraplp
from c3_model import cyc_rules,directed_cycles,word

ALL=frozenset(range(1,9))
SUPPORTS=tuple(map(frozenset,combinations(range(1,9),4)))
SI={s:i for i,s in enumerate(SUPPORTS)}

def actual_universe():
    blocks=set()
    for five in combinations(range(1,9),5):
        for cycle in directed_cycles(five):
            rs=cyc_rules(cycle)
            for omitted in range(5):
                block=frozenset(rs[:omitted]+rs[omitted+1:])
                assert len({word(r) for r in block})==4
                blocks.add(block)
    blocks=tuple(sorted(blocks,key=lambda b:tuple(sorted(b))))
    patterns=Counter(tuple(sorted(SI[frozenset(r[:4])] for r in b)) for b in blocks)
    assert len(blocks)==6720 and len(patterns)==280 and set(patterns.values())=={24}
    assert len(set().union(*blocks))==6720
    assert all(len(set(p))==4 for p in patterns)
    # This equality connects actual rules to the submitted support relaxation's
    # mathematical definition without importing or executing its builder.
    definition=set()
    for five in combinations(range(1,9),5):
        available=[SI[frozenset(s)] for s in combinations(five,4)]
        definition.update(tuple(sorted(p)) for p in combinations(available,4))
    assert set(patterns)==definition
    return blocks,tuple(sorted(patterns))

def active_from_flips(flips):
    active={frozenset(s) for s in combinations(range(1,8),4)}
    for fs in flips:
        s=frozenset(fs);active.remove(s);active.add(ALL-s)
    assert len(active)==35 and all(ALL-s not in active for s in active)
    return frozenset(SI[s] for s in active)

def exact_dual_check(active,patterns,weights):
    weights={i:Fraction(q) for i,q in weights.items() if q}
    if not set(weights)<=set(active) or any(q<0 for q in weights.values()):return None
    slacks=[sum((weights.get(i,Fraction()) for i in p),Fraction()) for p in patterns]
    if any(q<1 for q in slacks):return None
    bound=6*sum(weights.values(),Fraction())
    return dict(bound=bound,minimum_pattern_cover=min(slacks) if slacks else None,
                strictly_below52=bound<52,weights=weights)

def dual_candidate(active,patterns):
    lp=pywraplp.Solver.CreateSolver('GLOP')
    if lp is None:raise RuntimeError('GLOP unavailable.')
    y={i:lp.NumVar(0,lp.infinity(),f'y{i}') for i in sorted(active)}
    for p in patterns:lp.Add(sum(y[i] for i in p)>=1)
    lp.Minimize(6*sum(y.values()))
    status=lp.Solve()
    if status!=pywraplp.Solver.OPTIMAL:raise RuntimeError(f'Unexpected dual LP status{status}.')
    proposed={i:y[i].solution_value() for i in y}
    for denominator in (1000,1000000,1000000000):
        weights={i:Fraction(max(0.0,v)).limit_denominator(denominator) for i,v in proposed.items()}
        covers=[sum((weights[i] for i in p),Fraction()) for p in patterns]
        if covers and min(covers)<=0:continue
        if covers and min(covers)<1:
            scale=min(covers);weights={i:q/scale for i,q in weights.items()}
        checked=exact_dual_check(active,patterns,weights)
        if checked and checked['strictly_below52']:
            return lp.Objective().Value(),checked
    return lp.Objective().Value(),None

def integer_check(active,patterns,limit_ms=5000,fixed=None):
    solver=pywraplp.Solver.CreateSolver('CBC')
    if solver is None:raise RuntimeError('CBC unavailable.')
    solver.SetNumThreads(1);solver.SetTimeLimit(limit_ms)
    xs=[solver.IntVar(0,6,f'n{j}') for j in range(len(patterns))]
    solver.Add(sum(xs)==52)
    for i in active:solver.Add(sum(xs[j] for j,p in enumerate(patterns) if i in p)<=6)
    if fixed is not None:
        for j,p in enumerate(patterns):solver.Add(xs[j]==fixed.get(p,0))
    solver.Minimize(0)
    started=time.monotonic();status=solver.Solve()
    names={pywraplp.Solver.OPTIMAL:'OPTIMAL',pywraplp.Solver.FEASIBLE:'FEASIBLE',pywraplp.Solver.INFEASIBLE:'INFEASIBLE',
           pywraplp.Solver.UNBOUNDED:'UNBOUNDED',pywraplp.Solver.ABNORMAL:'ABNORMAL',pywraplp.Solver.NOT_SOLVED:'NOT_SOLVED'}
    out=dict(engine='CBC',status=names.get(status,str(status)),seconds=time.monotonic()-started,
             nodes=solver.nodes(),limit_ms=limit_ms,workers=1)
    if status in (pywraplp.Solver.OPTIMAL,pywraplp.Solver.FEASIBLE):
        values=[int(round(x.solution_value())) for x in xs]
        assert sum(values)==52 and all(0<=x<=6 for x in values)
        assert all(sum(values[j] for j,p in enumerate(patterns) if i in p)<=6 for i in active)
        out['positive_pattern_counts']=[dict(pattern=list(p),count=n) for p,n in zip(patterns,values) if n]
    return out

def qjson(q):return [q.numerator,q.denominator]

def main():
    start=time.monotonic();classification_path=H/'canonical_orientation_S8_classification.json';root_path=H/'canonical_orientation_support_relaxation.json'
    craw=classification_path.read_bytes();rraw=root_path.read_bytes();classification=json.loads(craw);submitted=json.loads(rraw)
    assert submitted['complete'] and len(classification['orbits'])==len(submitted['records'])==1378
    assert submitted['source_sha256']==hashlib.sha256(craw).hexdigest()
    previous={r['index']:r for r in submitted['records']}
    blocks,catalogue=actual_universe();pattern_ids={p:j for j,p in enumerate(catalogue)}
    bitpatterns=[sum(1<<i for i in p) for p in catalogue]
    # Independent positive control uses actual fixed baseline blocks and an
    # independently checked integral support count assignment.
    source=H/'inputs/baseline15051.rules.json';source_doc=json.loads(source.read_text());rules=frozenset((a,*hist,t) for a,hist,t in source_doc['rules'])
    selected=[b for b in blocks if b<=rules];assert len(selected)==52
    active=active_from_flips(());patterns=[p for p in catalogue if set(p)<=active]
    fixed=Counter(tuple(sorted(SI[frozenset(r[:4])] for r in b)) for b in selected)
    positive=integer_check(active,patterns,fixed=fixed)
    assert positive['status']=='OPTIMAL'
    positive.update(actual_blocks=52,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),support_patterns=len(patterns))
    result=dict(status='RUNNING',method=__doc__,input_classification_sha256=hashlib.sha256(craw).hexdigest(),
                submitted_relaxation_sha256=hashlib.sha256(rraw).hexdigest(),
                claude_generator_sha256=hashlib.sha256((H/'claude_desktop_continuation3/c3_model.py').read_bytes()).hexdigest(),
                actual_all_blocks=6720,actual_all_rules=6720,global_support_patterns=280,actual_blocks_per_global_pattern=24,
                actual_patterns_equal_four_of_five_definition=True,
                global_support_catalogue=[sorted(s) for s in SUPPORTS],global_pattern_catalogue=[list(p) for p in catalogue],
                positive_control=positive,records=[])
    output=H/'canonical_support_independent_fraction_audit.json'
    def checkpoint():
        result['counts']=dict(Counter(r['independent_status'] for r in result['records']))
        result['complete']=len(result['records'])==1378;result['seconds']=time.monotonic()-start
        output.write_text(json.dumps(result,indent=2),encoding='utf-8')
    for orientation in classification['orbits']:
        index=orientation['index'];active=active_from_flips(orientation['flips']);mask=sum(1<<i for i in active)
        patterns=[p for p,bits in zip(catalogue,bitpatterns) if bits&mask==bits]
        # The pattern list is also regenerated directly from actual selected
        # blocks, providing a rule-level check of the catalogue filter.
        actual_rows={tuple(sorted(SI[frozenset(r[:4])] for r in b)) for b in blocks if all(SI[frozenset(r[:4])] in active for r in b)}
        assert set(patterns)==actual_rows and len(patterns)==previous[index]['types']
        root_record=previous[index]
        rec=dict(index=index,canonical_S8_key_hex=orientation['canonical_S8_key_hex'],
                 active_support_indices=sorted(active),pattern_catalogue_indices=[pattern_ids[p] for p in patterns],
                 actual_rule_pattern_set_regenerated=True,support_pattern_count=len(patterns),
                 submitted_status=root_record['status'])
        bound,certificate=dual_candidate(active,patterns);rec['floating_dual_optimum']=bound
        if certificate is not None:
            assert root_record['status']=='INFEASIBLE'
            rec.update(independent_status='EXACT_FRACTION_DUAL_EXCLUSION',
                       certificate=dict(upper_bound=qjson(certificate['bound']),
                                        minimum_pattern_cover=qjson(certificate['minimum_pattern_cover']) if certificate['minimum_pattern_cover'] is not None else None,
                                        nonzero_weights=[dict(support_index=i,value=qjson(q)) for i,q in sorted(certificate['weights'].items())],
                                        exact_nonnegative=True,all_pattern_covers_at_least1=True,exact_upper_bound_below52=True))
        else:
            checked=integer_check(active,patterns);rec['independent_integer_check']=checked
            if checked['status']=='INFEASIBLE':
                assert root_record['status']=='INFEASIBLE';rec['independent_status']='CBC_INTEGER_INFEASIBLE'
            elif checked['status'] in ('OPTIMAL','FEASIBLE'):
                assert root_record['status'] in ('OPTIMAL','FEASIBLE'),(index,checked,root_record)
                # Check the submitted positive witness against the full actual
                # pattern set, not just its declared pattern count.
                original_counts={tuple(sorted(SI[frozenset(s)] for s in row['supports'])):row['count'] for row in root_record['support_pattern_counts']}
                assert set(original_counts)<=set(patterns) and sum(original_counts.values())==52
                assert all(isinstance(n,int) and 0<=n<=6 for n in original_counts.values())
                assert all(sum(n for p,n in original_counts.items() if i in p)<=6 for i in active)
                rec.update(independent_status='INTEGER_RELAXATION_SURVIVES',submitted_positive_counts_exactly_valid=True)
            else:rec['independent_status']='UNRESOLVED_'+checked['status']
        result['records'].append(rec)
        if len(result['records'])%50==0:
            checkpoint();print(len(result['records']),result['counts'],flush=True)
    unresolved=[r['index'] for r in result['records'] if r['independent_status'].startswith('UNRESOLVED')]
    survivors=[r['index'] for r in result['records'] if r['independent_status']=='INTEGER_RELAXATION_SURVIVES']
    assert survivors==[1255,1291,1305,1319,1376]
    result.update(status='PASS_COMPLETE' if not unresolved else 'INCOMPLETE_UNRESOLVED',survivors=survivors,unresolved_indices=unresolved,
                  claim_boundary='Only the1378 supplied orientation representatives are audited. Coverage and low-degree family reductions are separate dependencies. Integral support feasibility does not certify an actual rule table, R6=0 or R7>=4.')
    checkpoint();print(result['status'],result['counts'],'seconds',result['seconds'],flush=True)

if __name__=='__main__':main()
