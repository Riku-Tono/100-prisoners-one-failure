"""Generate four-rescue local witnesses, then complete with R6=0 DLX.

Only an exhausted completion permits a core+extras no-good. UNKNOWN ends
the bounded run, so no unresolved witness is ever silently excluded.
"""
from agent_seed_pair_reduced import *
from completion_dlx_recheck import DLX

R6INC=defaultdict(list)
for i,rr in enumerate(CW[6]):
    for r in rr:R6INC[r].append(i)
R6DELTA=[Counter(i for r in rs for i in R6INC[r]) for rs in RULES]

class NoSixDLX(DLX):
    def search_nosix(self,selected):
        self.nodes+=1
        if self.nodes%1000==0 and time.monotonic()>self.deadline:raise TimeoutError
        if self.right[0]==0:self.answer=selected[:];return True
        c=self.right[0];j=self.right[c]
        while j:
            if self.size[j]<self.size[c]:c=j
            if not self.size[c]:return False
            j=self.right[j]
        if not self.size[c]:return False
        self.cover(c);i=self.down[c];found=False
        while i!=c:
            b=self.row[i];d=R6DELTA[b]
            if all(self.rcount[k]+v<=4 for k,v in d.items()):
                self.rcount.update(d)
                j=self.right[i]
                while j!=i:self.cover(self.col[j]);j=self.right[j]
                found=self.search_nosix(selected+[b])
                j=self.left[i]
                while j!=i:self.uncover(self.col[j]);j=self.left[j]
                self.rcount.subtract(d)
                if found:break
            i=self.down[i]
        self.uncover(c);return found
    def run_nosix(self,mandatory,extras,seconds=1):
        self.rcount=Counter(i for b in mandatory for i in R6DELTA[b].elements())
        self.rcount.update(i for r in extras for i in R6INC[r])
        if any(v>=5 for v in self.rcount.values()):return 'EXHAUSTED_R6_CONFLICT',0,None
        holes={rotate_min(r[:4]) for r in extras};assert len(holes)==2
        removed=[]
        for h in sorted(holes):c=self.headers[h];self.cover(c);removed.append(c)
        for b in sorted(mandatory):removed.extend(self.force_row(b))
        self.nodes=0;self.answer=None;self.deadline=time.monotonic()+seconds
        try:found=self.search_nosix([])
        except TimeoutError:return 'UNKNOWN',self.nodes,None
        for c in reversed(removed):self.uncover(c)
        assert len(self.active)==186
        return 'FOUND' if found else 'EXHAUSTED_NO_COMPLETION',self.nodes,self.answer

def main():
    index=int(sys.argv[1]) if len(sys.argv)>1 else 1
    limit=int(sys.argv[2]) if len(sys.argv)>2 else 100
    wall=float(sys.argv[3]) if len(sys.argv)>3 else 80
    seed=json.loads((H/'witness_pair_seeds.json').read_text())['seeds'][index]
    m,bs,ss,stats=build(seed,True);solver=cp_model.CpSolver()
    solver.parameters.num_search_workers=1;solver.parameters.max_time_in_seconds=2
    matrix=NoSixDLX();records=[];t0=time.monotonic();endstatus='WITNESS_LIMIT'
    for iteration in range(limit):
        if time.monotonic()-t0>wall:endstatus='WALL_LIMIT';break
        st=solver.solve(m)
        if st not in (cp_model.FEASIBLE,cp_model.OPTIMAL):endstatus='LOCAL_'+solver.status_name(st);break
        selected=set(seed['blocks'])|{b for b,v in bs.items() if solver.value(v)}
        extras={r for r,v in ss.items() if solver.value(v)}
        supplied=set().union(*(RULES[b] for b in selected))
        newcycles=[rr for rr in CW[7] if sum(r in supplied for r in rr)<=5 and sum(r in supplied|extras for r in rr)>=6]
        assert len(newcycles)==2
        required={r for rr in newcycles for r in rr if r in supplied}
        core=set(seed['blocks'])|{b for b in selected if RULES[b]&required}
        assert len(core)<=22
        crules=set().union(*(RULES[b] for b in core))
        R=Counter(k for k in (6,7) for rr in CW[k] if sum(r in crules|extras for r in rr)>=k-1)
        assert R[6]==0 and R[7]>=4
        status,nodes,additional=matrix.run_nosix(core,extras,1)
        rec={'iteration':iteration,'local_cp_seconds':solver.wall_time,'status':status,'nodes':nodes,'core_blocks':sorted(core),'extras':sorted(extras)}
        if status=='FOUND':
            allblocks=core|set(additional);assert len(allblocks)==46
            # Export through the ordinary exact-completion exporter using fixed
            # assignments, keeping all 24 forced new-side rules unchanged.
            raw=json.loads((H/'inputs/new15051.rules.json').read_text())
            rr={(a,*h,t) for a,h,t in raw['rules']};groups=defaultdict(set)
            for r in rr:groups[rotate_min((r[-1],)+r[:4])].add(r)
            new=set().union(*(g for g in groups.values() if len(g)==4 and any(8 in r for r in g)))
            full=new|set().union(*(RULES[b] for b in allblocks))|extras
            path=H/f'agent_seed_local_completion_found_{index}.rules.json'
            path.write_text(json.dumps({'n':8,'rules':[[r[0],list(r[1:4]),r[4]] for r in sorted(full)]},indent=2),encoding='utf-8')
            rec['certificate']=str(path);endstatus='FOUND'
        records.append(rec)
        out={'scope':__doc__,'seed_index':index,'stats':stats,'records':records,'completion_counts':dict(Counter(r['status'] for r in records)),'seconds':time.monotonic()-t0,'status':endstatus}
        (H/f'agent_seed_local_completion_{index}.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        if iteration%10==0 or status=='FOUND':print(iteration,status,nodes,'elapsed',round(out['seconds'],2),flush=True)
        if status=='FOUND':break
        if status=='UNKNOWN':endstatus='COMPLETION_UNKNOWN';break
        assert status.startswith('EXHAUSTED')
        m.add_bool_or([bs[b].Not() for b in core-set(seed['blocks'])]+[ss[r].Not() for r in extras])
    out={'scope':__doc__,'seed_index':index,'stats':stats,'records':records,'completion_counts':dict(Counter(r['status'] for r in records)),'seconds':time.monotonic()-t0,'status':endstatus}
    (H/f'agent_seed_local_completion_{index}.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('FINAL',endstatus,out['completion_counts'],out['seconds'],flush=True)
if __name__=='__main__':main()
