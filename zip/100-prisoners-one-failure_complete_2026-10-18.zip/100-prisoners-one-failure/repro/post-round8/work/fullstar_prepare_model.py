"""Build, but do not solve, a full-star R5=52,R6=0,R7>=4 model.

No construction search occurs in this preparation entrypoint. No restriction
on the block-only R7 score is transferred from the standard-three-flip proof.
All 16 single-rule choices per free cyclic word remain allowed, including
target8, since a target4 construction may already rescue4 sevens in blocks.
Cycles containing8 have at most k-4 correct windows (their other four
histories contain8 and lie outside all35 active supports), hence cannot be
rescued for k=6,7,8. The old-label cycle constraints are therefore complete.
"""
from fullstar_prepare_basic import *
import sys
sys.path.insert(0,r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\work\python_packages')
from ortools.sat.python import cp_model

def build(seed,target=4,local=False):
    mandatory=set(seed);fixedrules=set().union(*(RULES[b] for b in mandatory)) if mandatory else set()
    used=[w for b in mandatory for w in ROWS[b]];assert len(used)==len(set(used))
    occupied=set(used);remaining=set(WORDS)-occupied
    permitted=[b for b in range(len(RULES)) if not ROWS[b]&occupied]
    m=cp_model.CpModel();bs={b:m.new_bool_var(f'b{b}') for b in permitted}
    terms=defaultdict(list);columns=defaultdict(list)
    for b,v in bs.items():
        for r in RULES[b]:terms[r].append(v)
        for w in ROWS[b]:columns[w].append(v)
    ss={}
    for w in sorted(remaining):
        for offset in range(4):
            h=w[offset:]+w[:offset]
            for t in range(1,9):
                if t in w:continue
                r=h+(t,);v=m.new_bool_var('s'+str(r));ss[r]=v
                terms[r].append(v);columns[w].append(v)
    for w in remaining:
        if local:m.add_at_most_one(columns[w])
        else:m.add_exactly_one(columns[w])
    if local:
        m.add(sum(bs.values())<=52-len(mandatory));m.add(sum(ss.values())<=2)
    else:
        m.add(sum(bs.values())==52-len(mandatory));m.add(sum(ss.values())==2)
    zs={};already=0;constraint6=0
    for k in (6,7):
        for s in combinations(range(1,8),k):
            for tail in permutations(s[1:]):
                c=(s[0],)+tail;rr=correct(c);constant=len(rr&fixedrules)
                possible=constant+sum(bool(terms[r]) for r in rr-fixedrules)
                if k==6:
                    if possible>=5:
                        m.add(constant+sum(v for r in rr for v in terms[r])<=4);constraint6+=1
                elif constant>=6:already+=1
                elif possible>=6:
                    z=m.new_bool_var('z'+str(c));n=constant+sum(v for r in rr for v in terms[r])
                    m.add(n>=6).only_enforce_if(z);m.add(n<=5).only_enforce_if(z.Not());zs[c]=z
    m.add(already+sum(zs.values())>=target)
    stats={'mandatory_blocks':len(mandatory),'free_slots':len(remaining),'compatible_block_variables':len(bs),'single_rule_variables':len(ss),'fixed_rescued_sevens':already,'potential_additional_seven_flags':len(zs),'six_nonrescue_constraints':constraint6,'variables':len(m.proto.variables),'constraints':len(m.proto.constraints),'validation_error':m.validate(),'local_relaxation':local,'target_R7':target}
    return m,bs,ss,zs,stats

def main():
    d=json.loads((H/'fullstar_prepare_baseline.json').read_text())
    seed=d['mandatory_three_witness_union'];m,bs,ss,zs,stats=build(seed)
    assert stats['validation_error']==''
    out={'status':'MODEL_PREPARED_NOT_SOLVED','scope':__doc__,'baseline_three_witness_seed':seed,'stats':stats}
    (H/'fullstar_prepare_model.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(out['status'],stats,flush=True)
if __name__=='__main__':main()
