"""Post-AUDIT_PASS generic six-flip search, full eight-label model.
Runs only the two assigned orientations. Finite-timeUNKNOWNisnotanexclusion.
"""
from pathlib import Path
import sys,json,time,datetime,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));import general_orientation_model as G
PREFIX='post_audit_sixflip_20261018';source=(H/'support_orientation_six_flip_screen.json').read_bytes();screen=json.loads(source);byid={r['index']:r for r in screen['orbits']};batch={'scope':__doc__,'model_scope':G.__doc__,'source_screen_sha256':hashlib.sha256(source).hexdigest(),'general_model_sha256':hashlib.sha256((H/'general_orientation_model.py').read_bytes()).hexdigest(),'assigned_orbits':[2,3],'workers':1,'seconds_per_solve':120,'records':[],'status':'RUNNING'};start=time.monotonic()
def save():
 batch['seconds']=time.monotonic()-start;(H/(PREFIX+'_summary.json')).write_text(json.dumps(batch,indent=2),encoding='utf-8')
def run(index,target):
 label=f'{PREFIX}_orbit{index}_target{target}';tbuild=time.monotonic();model=G.build(byid[index]['removed_supports'],target=target);validation=model.model.validate();assert validation==''
 record={'orbit_index':index,'target':target,'scope':G.__doc__,'flips':model.data.flips,'stats':model.stats,'validation_passed':True,'build_seconds':time.monotonic()-tbuild,'status':'RUNNING','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workers':1,'random_seed':20261018+10*index+target}
 path=H/(label+'.result.json');path.write_text(json.dumps(record,indent=2),encoding='utf-8');batch['current']={'orbit_index':index,'target':target,'result':str(path)};save();print('START',index,target,flush=True)
 solver=G.cp_model.CpSolver();solver.parameters.max_time_in_seconds=120;solver.parameters.num_search_workers=1;solver.parameters.random_seed=record['random_seed'];status=solver.solve(model.model)
 record.update(status=solver.status_name(status),solve_seconds=solver.wall_time,response_stats=solver.response_stats(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 if status in(G.cp_model.FEASIBLE,G.cp_model.OPTIMAL):record.update(model.export_and_audit(solver,H/(label+'.rules.json'),H/(label+'.audit.json')))
 path.write_text(json.dumps(record,indent=2),encoding='utf-8');batch['records'].append(record);batch.pop('current',None);save();print('END',index,target,record['status'],record['solve_seconds'],record.get('audit',{}).get('wins'),flush=True);return record
save()
for index in (2,3):
 result=run(index,4)
 if result['status']in('FEASIBLE','OPTIMAL'):
  batch['status']='TARGET4_FOUND';batch['found_orbit']=index;save();break
 if result['status']=='UNKNOWN':
  result0=run(index,0)
  if result0.get('audit',{}).get('wins',0)>=15052:batch['status']='TARGET4_FOUND_DURING_CONTROL';batch['found_orbit']=index;save();break
else:batch['status']='ASSIGNED_BOUNDED_SEARCHES_FINISHED';save()
print('FINAL',batch['status'],batch['seconds'],flush=True)
