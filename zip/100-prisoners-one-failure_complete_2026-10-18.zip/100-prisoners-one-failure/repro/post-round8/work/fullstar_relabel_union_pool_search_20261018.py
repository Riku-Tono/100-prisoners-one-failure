"""Heuristic unions of S7-relabeled incumbent52-block fullstar tables.

Keep8 fixed. Apply4 reproducible permutations to each of baseline+FOUND5,
including the original142-block union. If that pool is strictly INFEASIBLE,
expand to the first12 permutations. All3360 singles remain unrestricted,
<=2 extras,52 blocks,R6zero and arbitraryR7>=4. Baseline is only a hint in
target4 runs. A bounded UNKNOWN never excludes a family. An INFEASIBLE is
limited to that recorded actual-block union, not the whole fullstar model.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,time,random
from general_orientation_model import H,build,orientation_data,read_rules,cp_model,canon
from independent_audit import audit

PREFIX='fullstar_relabel_union_pool_20261018'
RANDOM_SEED=2026101807
LIMIT=90


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,indent=2),encoding='utf-8')
def digest_blocks(blocks):return hashlib.sha256(json.dumps([sorted(b) for b in blocks],separators=(',',':')).encode()).hexdigest()


def main():
    started=time.monotonic();data=orientation_data(())
    lookup={b:i for i,b in enumerate(data.blocks)};checker=build((),3)
    source_meta=H/'fullstar_six_table_union_pool_20261018.preparation.json'
    source_results=H/'fullstar_six_table_union_pool_20261018.result.json'
    old=json.loads(source_meta.read_text());original_result_sha=sha(source_results)
    assert json.loads(source_results.read_text())['status']=='INFEASIBLE'
    sources=[];rules=[];selected=[];singletons=[]
    for r in old['source_tables']:
        assert sha(r['path'])==r['sha256']
        table=read_rules(r['path']);bs,extras=checker.certificate_assignment(table)
        assert sorted(bs)==r['selected_block_ids']
        sources.append(dict(r));rules.append(table);selected.append(bs);singletons.append(extras)
    assert len(sources)==6
    original_pool=set().union(*selected)
    assert len(original_pool)==142 and original_pool==set(old['pool_block_ids'])
    rng=random.Random(RANDOM_SEED);perms=[];seen={tuple(range(1,8))}
    while len(perms)<12:
        p=tuple(rng.sample(range(1,8),7))
        if p not in seen:seen.add(p);perms.append(p)
    perm_records=[];new_pools=[]
    for index,p in enumerate(perms):
        mp={i+1:p[i] for i in range(7)}|{8:8}
        relabeled_union=set();records=[]
        for src,table,bs,extras in zip(sources,rules,selected,singletons):
            moved=frozenset(tuple(mp[v] for v in r) for r in table)
            moved_actual=[frozenset(tuple(mp[v] for v in r) for r in data.blocks[b]) for b in sorted(bs)]
            mapped={lookup[b] for b in moved_actual}
            mbs,mextras=checker.certificate_assignment(moved)
            assert len(mapped)==52 and mapped==mbs
            assert mextras=={tuple(mp[v] for v in r) for r in extras}
            assert len({canon(r[:4]) for r in moved})==len(moved)
            assert all(set(r[:4])<=set(range(1,8)) and r in data.singles for r in moved)
            relabeled_union.update(mapped)
            records.append(dict(source_label=src['label'],source_sha256=src['sha256'],
                                selected_block_ids=sorted(mapped),actual_selected_block_sha256=digest_blocks(sorted(moved_actual,key=lambda b:tuple(sorted(b)))),
                                extras=sorted(mextras),rules=len(moved)))
            if index==0 and src['label']=='baseline':
                control_path=H/f'{PREFIX}.first_relabel_control.rules.json'
                save(control_path,dict(n=8,rules=[[r[0],list(r[1:4]),r[4]] for r in sorted(moved)],
                                       selected_block_ids=sorted(mapped),extra_rules=sorted(mextras),
                                       source=src['path'],source_sha256=src['sha256'],permutation1_to7=p,fixed8=True))
                checked=audit(control_path)
                assert checked['placements']==40320 and checked['lost_cf']==0 and checked['wins']==15051
                assert checked['rescued_cycles']=={'5':52,'6':0,'7':3,'8':0}
                save(H/f'{PREFIX}.first_relabel_control.audit.json',checked)
                relabel_control=dict(certificate=str(control_path),source_permutation=p,audit=checked)
        assert len(relabeled_union)==142
        perm_records.append(dict(permutation_index=index,permutation1_to7=p,fixed8=True,source_tables=records))
        new_pools.append(relabeled_union)
    summary=dict(status='PREPARED',scope=__doc__,random_seed=RANDOM_SEED,workers=1,seconds_per_stage=LIMIT,
                 permutation_count_plan=[4,12],permutations=perm_records,
                 original142pool_preparation_sha256=sha(source_meta),original142result_sha256=original_result_sha,
                 original_source_tables=sources,first_relabel_direct40320_control=relabel_control,
                 all_singleton_options=3360,known_cycles_fixed=0,baseline_hint_is_constraint=False,
                 stages=[],block_catalogue_sha256=digest_blocks(data.blocks))
    save(H/f'{PREFIX}.preparation.json',summary)
    for count in (4,12):
        pool=original_pool|set().union(*new_pools[:count])
        outside=set(range(2520))-pool
        assert original_pool<=pool and all(bs<=pool for bs in selected)
        suffix=f'{PREFIX}.stage{count:02}'
        meta=dict(scope=__doc__,permutations_per_source=count,relabeled_source_tables=6*count,
                  original_source_tables=6,pool_size=len(pool),pool_block_ids=sorted(pool),
                  pool_actual_blocks=[sorted(data.blocks[b]) for b in sorted(pool)],
                  pool_actual_blocks_sha256=digest_blocks([data.blocks[b] for b in sorted(pool)]),
                  random_seed=RANDOM_SEED,source_permutations=perms[:count],fixed8=True,
                  source_metadata_sha256=sha(H/f'{PREFIX}.preparation.json'),
                  singleton_options_retained=3360,known_cycle_mandatory_constraints=0,
                  R5=52,R6=0,R7_target=4,extra_rules_max=2,
                  outside_pool_zero_constraints=len(outside),workers=1,limit_seconds=LIMIT,
                  baseline_hint_is_constraint=False)
        save(H/f'{suffix}.pool.json',meta)
        # Fully fixed existing baseline control, separate from target4 model.
        positive=build((),3)
        for b in outside:positive.model.add(positive.blocks[b]==0)
        fixed=positive.fix_certificate(rules[0])
        cs=cp_model.CpSolver();cs.parameters.num_search_workers=1;cs.parameters.max_time_in_seconds=10
        cst=cs.solve(positive.model);assert cst==cp_model.OPTIMAL
        positive_info=dict(status=cs.status_name(cst),fixed=fixed,seconds=cs.wall_time,
                           justification='All variables fixed to previously40320-audited baseline; original142pool is included.')
        model=build((),4)
        for b in outside:model.model.add(model.blocks[b]==0)
        for b,var in enumerate(model.blocks):model.model.add_hint(var,int(b in selected[0]))
        for r,var in model.singles.items():model.model.add_hint(var,int(r in singletons[0]))
        assert len(model.singles)==3360 and model.stats['seven_variable_flags']==720 and model.stats['eight_variable_flags']==0
        assert not model.model.validate()
        model_path=H/f'{suffix}.model.pbtxt';model.model.export_to_file(str(model_path))
        result=dict(scope=__doc__,status='RUNNING',permutations_per_source=count,pool_size=len(pool),
                    pool_metadata=str(H/f'{suffix}.pool.json'),pool_metadata_sha256=sha(H/f'{suffix}.pool.json'),
                    positive_control=positive_info,model_stats=model.stats,workers=1,limit_seconds=LIMIT,
                    baseline_hint_constraints=0,baseline_hint_variables=len(model.blocks)+len(model.singles),
                    all3360_singletons_retained=True,known_cycle_mandatory_constraints=0,
                    model_proto=str(model_path),model_proto_sha256=sha(model_path),
                    claim_boundary='Only52-block selections wholly inside this recorded relabeled-incumbent union pool, with arbitrary<=2 admissible singles.')
        save(H/f'{suffix}.result.json',result)
        print('READY stage',count,'pool',len(pool),'outsidezero',len(outside),'positive',positive_info['status'],flush=True)
        solver=cp_model.CpSolver();solver.parameters.num_search_workers=1
        solver.parameters.max_time_in_seconds=LIMIT;solver.parameters.random_seed=1
        solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
        with (H/f'{suffix}.log.txt').open('w',encoding='utf-8') as log:
            solver.log_callback=lambda line:log.write(line+'\n')
            st=solver.solve(model.model)
        result.update(status=solver.status_name(st),solve_seconds=solver.wall_time,response_stats=solver.response_stats())
        if st in (cp_model.FEASIBLE,cp_model.OPTIMAL):
            result.update(model.export_and_audit(solver,H/f'{suffix}.found.rules.json'))
            assert result['audit']['wins']>=15052
        save(H/f'{suffix}.result.json',result)
        summary['stages'].append(dict(permutations_per_source=count,pool_size=len(pool),status=result['status'],
                                      seconds=solver.wall_time,result=str(H/f'{suffix}.result.json'),
                                      result_sha256=sha(H/f'{suffix}.result.json')))
        print('FINAL stage',count,result['status'],'seconds',solver.wall_time,'pool',len(pool),flush=True)
        if st!=cp_model.INFEASIBLE:
            summary['status']='FOUND_VERIFIED' if st in (cp_model.FEASIBLE,cp_model.OPTIMAL) else 'BOUNDED_UNKNOWN_RETAINED'
            break
    else:summary['status']='BOTH_RECORDED_UNION_POOLS_INFEASIBLE'
    summary['seconds']=time.monotonic()-started
    summary['not_run_stages']=[n for n in (4,12) if n not in {r['permutations_per_source'] for r in summary['stages']}]
    assert sha(source_results)==original_result_sha
    for r in sources:assert sha(r['path'])==r['sha256']
    save(H/f'{PREFIX}.summary.json',summary)
    print('SUMMARY',summary['status'],'seconds',summary['seconds'],'notrun',summary['not_run_stages'],flush=True)


if __name__=='__main__':main()
