"""Bitset exact-cover with immediate removal of rows forbidden by R6=0.

Reads the independent2520-row regeneration from the tuple-DLX module, but
uses immutable integer row/column masks. Whenever a6-cycle reaches4 correct
rules, all rows contributing to that cycle are removed from availability.
UNKNOWN limits are retained explicitly. All3735 finite cores are rechecked.
"""
from fullstar_finite_core_completion import H,WORDS,RULES,ROWS,SIX,R6INC,DELTA,CATALOGUE_SHA,canon,correct,export_and_audit,save
from pathlib import Path
from collections import Counter
import argparse,json,time,hashlib
WI={w:i for i,w in enumerate(WORDS)}
RM=[sum(1<<WI[w] for w in row) for row in ROWS]
COL=[0]*210;SAT=[0]*840
for b,row in enumerate(ROWS):
    bit=1<<b
    for w in row:COL[WI[w]]|=bit
    for k in DELTA[b]:SAT[k]|=bit
CONFLICT=[]
for row in ROWS:
    bad=0
    for w in row:bad|=COL[WI[w]]
    CONFLICT.append(bad)
ALL_WORDS=(1<<210)-1;ALL_ROWS=(1<<2520)-1

class Limited(Exception):pass
class Engine:
    def dfs(self,remaining,available,selected,holes,budget):
        self.nodes+=1
        if self.nodes>self.node_limit:raise Limited('NODE_LIMIT')
        if self.nodes%256==0 and time.monotonic()>self.deadline:raise Limited('TIME_LIMIT')
        if not remaining:
            if budget:return False
            self.answer=selected[:];self.answer_holes=holes[:];return True
        x=remaining;best=0;bestn=10**9;chosen_word_bit=0
        while x:
            bit=x&-x;x-=bit;options=COL[bit.bit_length()-1]&available;n=options.bit_count()
            if n<bestn:best,bestn,chosen_word_bit=options,n,bit
            if n==0:break
        if not bestn:
            if not budget:return False
            return self.dfs(remaining^chosen_word_bit,available,selected,holes+[chosen_word_bit.bit_length()-1],budget-1)
        while best:
            preferred=best&self.hint
            bit=(preferred&-preferred) if preferred else (best&-best)
            best-=bit;b=bit.bit_length()-1;bad=CONFLICT[b]
            delta=DELTA[b]
            for k in delta:
                self.counts[k]+=1
                if self.counts[k]==4:bad|=SAT[k]
                assert self.counts[k]<=4
            found=self.dfs(remaining^RM[b],available&~bad,selected+[b],holes,budget)
            for k in delta:self.counts[k]-=1
            if found:return True
        if budget:
            w=chosen_word_bit.bit_length()-1
            return self.dfs(remaining^chosen_word_bit,available&~COL[w],selected,holes+[w],budget-1)
        return False
    def run(self,core,extras,seconds,node_limit,hint=frozenset()):
        core=set(core);extras=set(map(tuple,extras));assert len(extras)<=2
        rem=ALL_WORDS;avail=ALL_ROWS;self.counts=[0]*840;self.hint=sum(1<<b for b in hint)
        for b in core:
            assert rem&RM[b]==RM[b];rem^=RM[b];avail&=~CONFLICT[b]
            for k in DELTA[b]:self.counts[k]+=1
        for r in extras:
            w=WI[canon(r[:4])];bit=1<<w;assert rem&bit;rem^=bit;avail&=~COL[w]
            for k in R6INC[r]:self.counts[k]+=1
        assert max(self.counts)<=4
        for k,n in enumerate(self.counts):
            if n==4:avail&=~SAT[k]
        self.nodes=0;self.answer=None;self.answer_holes=None
        self.node_limit=node_limit;self.deadline=time.monotonic()+seconds
        try:found=self.dfs(rem,avail,[],[],2-len(extras))
        except Limited as e:return 'UNKNOWN_'+str(e),self.nodes,None,None
        return ('FOUND',self.nodes,self.answer,[WORDS[w] for w in self.answer_holes]) if found else ('EXHAUSTED_NO_COMPLETION',self.nodes,None,None)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--wall-seconds',type=float,default=200)
    p.add_argument('--per-core-seconds',type=float,default=2);p.add_argument('--node-limit',type=int,default=2000000)
    p.add_argument('--prefix',default='fullstar_finite_core_bitset');a=p.parse_args()
    path=H/'fullstar_fixed_core_enumeration.json';raw=path.read_bytes();data=json.loads(raw)
    assert data['block_catalogue_sha256']==CATALOGUE_SHA and len(data['minimal_records'])==3735
    cores=data['minimal_records'];engine=Engine();start=time.monotonic();deadline=start+a.wall_seconds
    baseline=json.loads((H/'inputs/baseline15051.rules.json').read_text());brules={(x,*h,t) for x,h,t in baseline['rules']}
    chosen={i for i,b in enumerate(RULES) if b<=brules};assert len(chosen)==52
    fixed=set(data['fixed_core']);fixed.update(sorted(chosen-fixed)[:39-len(fixed)]);assert len(fixed)==39
    holes=set(WORDS)-set().union(*(set(ROWS[b]) for b in chosen));extras={w+(8,) for w in holes}
    st,nodes,more,h=engine.run(fixed,extras,min(5,deadline-time.monotonic()),a.node_limit,chosen)
    assert st=='FOUND' and len(more)==13
    positive=export_and_audit(H/f'{a.prefix}_positive.rules.json',fixed,extras,more,h,15051)
    out={'scope':__doc__,'source':str(path),'source_sha256':hashlib.sha256(raw).hexdigest(),'block_catalogue_sha256':CATALOGUE_SHA,'fixed_core':data['fixed_core'],'total_cores':len(cores),'positive_control':{'retained':39,'recovered':13,'status':st,'nodes':nodes,'direct_audit':positive},'records':[],'status':'RUNNING'}
    result=H/f'{a.prefix}_result.json'
    if positive['wins']>=15052:out['status']='FOUND_IN_POSITIVE_CONTROL';save(result,out);print(out['status']);return
    for index,core in enumerate(cores):
        remaining=deadline-time.monotonic()
        if remaining<=0:out['status']='WALL_LIMIT';break
        st,nodes,more,holes=engine.run(core['core_blocks'],core['critical_extra_rules'],min(a.per_core_seconds,remaining),a.node_limit)
        rec={'index':index,'status':st,'nodes':nodes,'core_blocks':len(core['core_blocks']),'critical_extras':len(core['critical_extra_rules'])}
        if st=='FOUND':
            cert=H/f'{a.prefix}_found_{index}.rules.json';rec['certificate']=str(cert)
            rec['direct_audit']=export_and_audit(cert,core['core_blocks'],core['critical_extra_rules'],more,holes,15052)
            out['status']='FOUND_INDEPENDENTLY_VERIFIED'
        out['records'].append(rec);out['seconds']=time.monotonic()-start
        out['counts']=dict(Counter(r['status'] for r in out['records']))
        out['unprocessed_indices']=list(range(index+1,len(cores)));out['unknown_indices']=[r['index'] for r in out['records'] if r['status'].startswith('UNKNOWN')]
        if index%50==0 or st=='FOUND':save(result,out)
        if index%250==0 or st=='FOUND':print(index,st,nodes,'elapsed',round(out['seconds'],3),out['counts'],flush=True)
        if st=='FOUND':break
    else:out['status']='ALL_CORES_PROCESSED'
    out['seconds']=time.monotonic()-start;out['counts']=dict(Counter(r['status'] for r in out['records']))
    out['unprocessed_indices']=list(range(len(out['records']),len(cores)));out['unknown_indices']=[r['index'] for r in out['records'] if r['status'].startswith('UNKNOWN')]
    out['all_core_coverage']=len(out['records'])==len(cores)
    out['exhausted_fixed_core_branch']=out['all_core_coverage'] and not out['unknown_indices'] and out['counts'].get('EXHAUSTED_NO_COMPLETION')==len(cores)
    if out['exhausted_fixed_core_branch']:out['status']='EXHAUSTED_NO_TARGET4_WITH_FIXED_18_CORE'
    save(result,out);print('FINAL',out['status'],out['counts'],out['seconds'],'unprocessed',len(out['unprocessed_indices']),'unknown',len(out['unknown_indices']),flush=True)
if __name__=='__main__':main()
