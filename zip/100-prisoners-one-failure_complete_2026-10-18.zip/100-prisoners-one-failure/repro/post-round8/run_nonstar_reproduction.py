"""Portable advanced reproduction of the bounded nonstar computation.

Install beside the preserved `work/` directory. Python 3.10+ is required.
Examples (from the release root):
  python -X utf8 repro/post-round8/run_nonstar_reproduction.py --list
  python -X utf8 repro/post-round8/run_nonstar_reproduction.py --stage screen
  python -X utf8 repro/post-round8/run_nonstar_reproduction.py --stage capacity
  python -X utf8 repro/post-round8/run_nonstar_reproduction.py --stage survivors
  python -X utf8 repro/post-round8/run_nonstar_reproduction.py --stage all --with-solvers

Only the optional cbc1267, survivors and low-degree-solvers stages import
OR-Tools. Install ortools==9.15.6755 in the active Python environment to
match the recorded solver release; CBC must be available through pywraplp.
No package is installed or downloaded by this runner. A different version
or machine may return UNKNOWN; UNKNOWN never counts as an exclusion.

Each stage starts from its own temporary copy of preserved work/. Original
bytes are never rewritten. Logs and generated evidence remain in --output.
Screen: fresh 5**6 core generation, all 6,250,496 support assignments and
independent S8 membership. Capacity: exact checks of saved dual/integer
certificates, rather than another optimizer search. cbc1267: fresh integer
model. Survivors: fresh independent actual-rule models and fixed controls.
Low-degree: fresh necessary screens and the 9/15 seven-flip combinatorial
checks. Standard3/fourflip: fresh witness/core generation and exact-cover
exhaustion, using archived base representatives whose coverage is rechecked.
Low-degree-solvers: rebuild and solve the eight six-flip and twelve seven-
flip models; the two archived UNKNOWN cases are handled by the separate
combinatorial check, not relabelled as INFEASIBLE.

The written model/structural reductions and extra-rule lemmas remain proof
dependencies. This is not a formal proof checker, a new construction search,
a proof about full-star orientations, or a global optimality certificate.
Some exploratory files in work/ have other dependencies; this runner calls
only the named, inspected entrypoints below.
"""
from __future__ import annotations

import argparse
from collections import Counter
from itertools import combinations, permutations, product
import importlib.util
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import tempfile
import time

STAGES = {
    'screen': ('standard library', 'Regenerate 70 cores, all support assignments, and independent S8 partition (~1 minute).'),
    'capacity': ('standard library', 'Verify 1,372 rational dual certificates and five integer positive witnesses (~2 seconds).'),
    'cbc1267': ('OR-Tools CBC', 'Rebuild and solve the one remaining integer-capacity exclusion.'),
    'survivors': ('OR-Tools CP-SAT', 'Rebuild five full presence/iff rule models plus fixed positive and negative controls (~1 minute).'),
    'low-degree': ('standard library', 'Regenerate three through seven-flip screens and seven-flip 9/15 combinatorial checks (~30 seconds).'),
    'standard3': ('standard library', 'Regenerate witness orbits, exhaust 248 triangle and 2,938 compound-core completions (~20 seconds).'),
    'fourflip': ('standard library', 'Recheck 48 triangles; regenerate and exhaust all 21,097 compound cores (~25 seconds).'),
    'low-degree-solvers': ('OR-Tools CP-SAT', 'Rebuild eight six-flip and twelve seven-flip independent models; may take several minutes.'),
}
SOLVER_STAGES = {'cbc1267', 'survivors', 'low-degree-solvers'}
ORDER = ['screen', 'low-degree', 'standard3', 'fourflip', 'capacity', 'cbc1267', 'survivors', 'low-degree-solvers']


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run_original(work, output, script, outputs, args=()):
    """Run one original entrypoint; save outputs and restore its input records."""
    backups = {name: (work/name).read_bytes() if (work/name).is_file() else None for name in outputs}
    old_argv = sys.argv[:]
    old_cwd = Path.cwd()
    started = time.monotonic()
    print('RUN', script, *args, flush=True)
    try:
        sys.argv = [str(work/script), *map(str, args)]
        os.chdir((work/script).parent)
        runpy.run_path(str(work/script), run_name='__main__')
        result = {}
        for name in outputs:
            source = work/name
            if source.is_file():
                target = output/name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, target)
                if source.suffix == '.json': result[name] = read(source)
        print('DONE', script, round(time.monotonic()-started, 3), 'seconds', flush=True)
        return result
    finally:
        sys.argv = old_argv
        os.chdir(old_cwd)
        for name, original in backups.items():
            target = work/name
            if original is not None: target.write_bytes(original)
            elif target.is_file(): target.unlink()


def check_cores(work, output):
    """Regenerate actual blocks over all eight labels; compare actual rules."""
    c3 = load_module('c3_model', work/'claude_desktop_continuation3/c3_model.py')
    blocks = set()
    for labels in combinations(range(1, 9), 5):
        for cycle in c3.directed_cycles(labels):
            rules = tuple(c3.cyc_rules(cycle))
            blocks.update(frozenset(rules[:j]+rules[j+1:]) for j in range(5))
    assert len(blocks) == 6720
    required = tuple(c3.cyc_rules((1,2,3,4,5,6,7)))[:6]
    options = [tuple(b for b in blocks if r in b)+(frozenset((r,)),) for r in required]
    assert all(len(o) == 5 for o in options)
    found = set()
    for chosen in product(*options):
        extras = tuple(sorted(next(iter(b)) for b in chosen if len(b) == 1))
        if len(extras) > 2: continue
        actual_blocks = frozenset(b for b in chosen if len(b) == 4)
        actual_rules = [r for b in actual_blocks for r in b]+list(extras)
        words = [c3.word(r) for r in actual_rules]
        if len(words) != len(set(words)): continue
        found.add((actual_blocks, extras))
    expected = set()
    for index in range(70):
        d = read(work/f'canonical_six_witness_cores/core_{index:03d}.json')
        expected.add((frozenset(frozenset(map(tuple,b)) for b in d['actual_blocks']), tuple(sorted(map(tuple,d['extras'])))))
    assert found == expected and len(found) == 70
    histogram = Counter(len(extras) for b,extras in found)
    assert histogram == {0:4,1:21,2:45}
    result = dict(status='PASS', actual_blocks=6720, supplier_assignments=15625,
                  unique_cores=70, extras_histogram=dict(histogram), exact_actual_rule_sets_equal=True)
    write(output/'portable_core_regeneration.json', result)
    return result


def worker(stage, work, output, seconds):
    sys.path.insert(0, str(work))
    sys.path.insert(0, str(work/'claude_desktop_continuation3'))
    if stage in SOLVER_STAGES:
        # Import the caller's installed package before historical scripts add
        # now-obsolete sys.path hints. No original-machine path is used here.
        import ortools
        print('OR-Tools', ortools.__version__, ortools.__file__, flush=True)
    if stage == 'screen':
        result = check_cores(work, output)
        accepted = set(); total = count = 0
        for first,last in ((0,4),(4,25),(25,70)):
            name = f'canonical_orientation_capacity_{first}_{last}.json'
            old = read(work/name)
            d = run_original(work,output,'canonical_orientation_capacity_screen.py',[name],['--start',first,'--stop',last])[name]
            assert d['complete']
            assert [r['accepted_masks_hex'] for r in d['records']] == [r['accepted_masks_hex'] for r in old['records']]
            for row in d['records']:
                total += row['tested']; count += row['capacity_accepted']; accepted.update(row['accepted_masks_hex'])
        assert (total,count,len(accepted)) == (6250496,53392,27423)
        # The separate decreasing-degree/max-encoding implementation checks
        # every orbit's member set against the preserved classification.
        name = 'independent_orientation_S8_partition_20261018.json'
        d = run_original(work,output,'independent_orientation_S8_partition_20261018.py',[name])[name]
        assert d['status'] == 'PASS'
        result.update(assignments=total, accepted_core_orientation_pairs=count, distinct_orientations=len(accepted), orbit_partition_status='PASS')
        return result
    if stage == 'capacity':
        name = 'canonical_support_fraction_certificate_verify.json'
        d = run_original(work,output,'canonical_support_fraction_certificate_verify.py',[name])[name]
        assert d['status'] == 'PASS_OPTIMIZER_FREE_CERTIFICATES'
        assert d['counts'] == {'EXACT_FRACTION_DUAL_EXCLUSION':1372,'INTEGER_RELAXATION_SURVIVES':5,'CBC_INTEGER_INFEASIBLE':1}
        return dict(status='PASS', exact_fraction_exclusions=1372, integer_positive_witnesses=5,
                    cbc1267_reexecuted=False, note='The CBC-only record is identified, not proved by this stage.')
    if stage == 'cbc1267':
        m = load_module('portable_capacity_builder', work/'canonical_support_independent_fraction_audit.py')
        blocks,catalogue = m.actual_universe()
        row = next(r for r in read(work/'canonical_orientation_S8_classification.json')['orbits'] if r['index']==1267)
        active = m.active_from_flips(row['flips']); patterns = [p for p in catalogue if set(p)<=active]
        result = m.integer_check(active,patterns,limit_ms=int(seconds*1000))
        write(output/'cbc1267_fresh.json', result)
        assert result['status'] == 'INFEASIBLE', result
        return dict(status='PASS', engine='CBC', orbit=1267, fresh_result=result)
    if stage == 'survivors':
        name = 'five_survivors_c3_presence_iff_independent_20261018.json'
        d = run_original(work,output,'five_survivors_c3_presence_iff_independent_20261018.py',[name])[name]
        for source in work.glob('five_survivors_c3_presence_iff_*_20261018.*'):
            if source.name != name and source.suffix in ('.pbtxt','.txt','.json'): shutil.copyfile(source,output/source.name)
        assert d['status'] == 'ALL_FIVE_INFEASIBLE_CONFIRMED', d['status']
        assert len(d['survivors']) == 5 and all(r['status']=='INFEASIBLE' for r in d['survivors'])
        return dict(status='PASS', fresh_model_exclusions=5, controls=[r['status'] for r in d['controls']])
    if stage == 'standard3':
        lemma_outputs=['claude_desktop_continuation3/c3_lemmas.json','claude_desktop_continuation3/c3_lemmas_sanity.json']
        lemma=run_original(work,output,'claude_desktop_continuation3/c3_lemmas_sanity.py',lemma_outputs)
        local=lemma[lemma_outputs[0]];sanity=lemma[lemma_outputs[1]]
        assert local['L2_feasible_local_witnesses']==local['L3_feasible_local_witnesses']==0
        assert local['L4_max_shared_correct_rules_[7]_seven_pairs']==1
        assert sanity['cycles_with_6rule_local_witness']==sanity['expected']==144
        a = run_original(work,output,'agent_witness_orbit_independent.py',['agent_witness_orbit_independent.json'])['agent_witness_orbit_independent.json']
        assert a['pair_orbits']==913 and a['triangle_orbits']==248
        d = run_original(work,output,'agent_seed_triangle_completion.py',['agent_seed_triangle_completion.json'],[seconds])['agent_seed_triangle_completion.json']
        assert d['counts']=={'EXHAUSTED_NO_COMPLETION':248}
        outputs=['chatgpt_compound_audit_compound_seeds.json','chatgpt_compound_audit_summary.json']
        d = run_original(work,output,'chatgpt_compound_audit_regenerate.py',outputs)['chatgpt_compound_audit_summary.json']
        assert d['compound_unique_core_extra_keys']==2938 and d['matches_chatgpt_counts']
        name='chatgpt_compound_audit_completion.json'
        d=run_original(work,output,'chatgpt_compound_audit_completion.py',[name])[name]
        assert d['total']==d['exhausted']==2938 and d['found']==d['unknown']==0
        return dict(status='PASS', pair_orbits=913, triangle_exhaustions=248, compound_core_exhaustions=2938,
                    written_lemmas_are_separate_dependencies=True)
    if stage == 'fourflip':
        tri_outputs=['fourflip_triangle_pure_seeds.json','fourflip_triangle_pure_completion.json']
        old_seeds=read(work/tri_outputs[0])
        fresh=run_original(work,output,'fourflip_triangle_pure_completion.py',tri_outputs,[seconds,10000000,max(120,seconds*2)])
        assert fresh[tri_outputs[0]]['triangle_orbits']==48
        assert fresh[tri_outputs[0]]['seeds']==old_seeds['seeds']
        assert fresh[tri_outputs[1]]['counts']=={'EXHAUSTED_NO_COMPLETION':48}
        assert fresh[tri_outputs[1]]['not_run']==0
        a='fourflip_triangle_bitset_recheck.json'
        d=run_original(work,output,'fourflip_triangle_bitset_recheck.py',[a])[a]
        assert d['counts']=={'EXHAUSTED_NO_COMPLETION':48}
        b='fourflip_independent_regenerate_cover.json'
        e=run_original(work,output,'fourflip_independent_regenerate_cover.py',[b])[b]
        assert e['total']==e['exhausted']==21097 and e['found']==e['unknown']==0
        return dict(status='PASS', triangle_orbits_regenerated=48,triangle_exhaustions=48,
                    independent_triangle_exhaustions=48,compound_core_exhaustions=21097,R6_used=False)
    if stage == 'low-degree':
        names=['support_orientation_three_flip_classification','support_orientation_four_flip_classification',
               'support_orientation_five_flip_screen','support_orientation_six_flip_screen',
               'post_audit_sevenflip_20261018_screen','sevenflip_independent_rulepair_bound']
        for stem in names:
            original=read(work/(stem+'.json'))
            d=run_original(work,output,stem+'.py',[stem+'.json'])[stem+'.json']
            # Timings are variable. Mathematical data and completion flags
            # must agree; a time-limited partial six-flip screen fails here.
            if stem=='support_orientation_six_flip_screen':
                assert d['enumeration_complete'] and d['orbit_classification_complete']
            for key in ('orbits','orientations','slot_eligible_orbit_indices','accepted_masks_sha256','brute_accepted_masks_sha256'):
                if key in original: assert d[key]==original[key], (stem,key)
        return dict(status='PASS', fresh_screens=6, solver_exclusions_reexecuted=False,
                    one_two_flip_capacity_argument='written proof dependency')
    if stage == 'low-degree-solvers':
        m=load_module('portable_independent_orientation_builder',work/'post_audit_independent_orientation_cp.py')
        std3=((1,2,3,4),(1,2,3,5),(1,2,3,6))
        controls=[]
        for label,flips,target,path,expected in (
            ('control_fullstar',(),3,work/'inputs/baseline15051.rules.json','OPTIMAL'),
            ('control_standard3_15050',std3,2,work/'chatgpt_15050_received.rules.json','OPTIMAL'),
            ('control_r6one_rejected',std3,1,work/'inputs/new15051.rules.json','INFEASIBLE')):
            result=m.solve(label,flips,target,seconds,path)
            assert result['status']==expected, result
            controls.append(result)
            for source in work.glob('post_audit_independent_'+label+'.*'): shutil.copyfile(source,output/source.name)
        write(output/'low_degree_fresh_controls.json',controls)
        cases=[]
        for item in read(work/'sixflip_model_preparation_inputs.json'):
            cases.append(('sixflip_orbit'+str(item['orbit_index']),item['flips']))
        for item in read(work/'post_audit_sevenflip_independent_cp_summary.json')['records']:
            cases.append((item['label'],item['flips']))
        assert len(cases)==20
        records=[]
        for label,flips in cases:
            result=m.solve(label,flips,4,seconds)
            records.append(result); write(output/'low_degree_fresh_solver_results.json',records)
            for source in work.glob('post_audit_independent_'+label+'.*'): shutil.copyfile(source,output/source.name)
        assert all(r['status']=='INFEASIBLE' for r in records), 'Fresh solver run has unresolved or differing result.'
        return dict(status='PASS', fresh_six_flip_exclusions=8, fresh_seven_flip_exclusions=12,controls=[r['status'] for r in controls],
                    cases9_15='Separate combinatorial low-degree stage; archived UNKNOWN is unchanged.')
    raise ValueError(stage)


def main():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--list',action='store_true');p.add_argument('--stage',action='append',choices=[*STAGES,'all'])
    p.add_argument('--screen',action='store_true');p.add_argument('--capacity',action='store_true');p.add_argument('--survivors',action='store_true')
    p.add_argument('--with-solvers',action='store_true',help='Include optional solver stages when selecting all/capacity.')
    p.add_argument('--work',type=Path,default=Path(__file__).resolve().parent/'work')
    p.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[2]/'verification'/'post-round8-advanced')
    p.add_argument('--seconds',type=float,default=120,help='Per-case solver/triangle limit; UNKNOWN fails the stage.')
    a=p.parse_args()
    if a.list:
        for stage,(dependency,description) in STAGES.items(): print(f'{stage}: {dependency}; {description}')
        return 0
    requested=a.stage or []
    requested += [name for name in ('screen','capacity','survivors') if getattr(a,name)]
    requested=requested or ['capacity']
    if 'all' in requested: selected=[s for s in ORDER if a.with_solvers or s not in SOLVER_STAGES]
    else: selected=list(dict.fromkeys(requested))
    if a.with_solvers and 'capacity' in selected and 'cbc1267' not in selected: selected.insert(selected.index('capacity')+1,'cbc1267')
    work=a.work.resolve();output=a.output.resolve()
    if not (work/'NONSTAR_SUPPORT_EXCLUSION_2026-10-18.txt').is_file(): p.error('--work must name the preserved post-Round8 work directory.')
    if output==work or work in output.parents: p.error('--output must be outside preserved work/.')
    if a.seconds<=0:p.error('--seconds must be positive.')
    output.mkdir(parents=True,exist_ok=True)
    summary={'status':'RUNNING','selected_stages':selected,'scope':'52 four-rule blocks + <=2 extras, CF-preserving final-box-only, R6=0; non-full-star only.',
             'fullstar_or_global_optimality_claimed':False,'results':[],
             'written_structural_lemmas_reproved':False,'unselected_stages':[s for s in ORDER if s not in selected]}
    write(output/'summary.json',summary)
    for stage in selected:
        stageout=output/stage;stageout.mkdir(exist_ok=True)
        print('START',stage,flush=True);started=time.monotonic()
        with tempfile.TemporaryDirectory(prefix='nonstar-scratch-',dir=output) as temporary:
            scratch=Path(temporary)/'work'
            shutil.copytree(work,scratch,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
            cmd=[sys.executable,'-X','utf8',str(Path(__file__).resolve()),'_worker',stage,str(scratch),str(stageout),str(a.seconds)]
            with (stageout/'transcript.txt').open('w',encoding='utf-8') as log:
                completed=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=False)
        result=(read(stageout/'stage-result.json') if not completed.returncode and (stageout/'stage-result.json').is_file()
                else {'status':'FAILED_OR_UNRESOLVED','returncode':completed.returncode})
        result.update(stage=stage,elapsed_seconds=time.monotonic()-started)
        summary['results'].append(result);write(output/'summary.json',summary)
        print(stage,result['status'],round(result['elapsed_seconds'],2),'seconds',flush=True)
        if completed.returncode or result['status']!='PASS':
            summary['status']='FAILED_OR_UNRESOLVED';write(output/'summary.json',summary);return 1
    summary['status']='PASSED_SELECTED_STAGES'
    summary['all_named_computational_stages_rerun']=set(selected)==set(STAGES)
    summary['note']='Written reductions remain proof dependencies. Passing selected stages does not certify unselected stages or global optimality.'
    write(output/'summary.json',summary);print(summary['status'],output/'summary.json',flush=True)
    return 0


if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='_worker':
        _,_,stage,work,output,seconds=sys.argv
        result=worker(stage,Path(work),Path(output),float(seconds))
        write(Path(output)/'stage-result.json',result)
    else: raise SystemExit(main())
