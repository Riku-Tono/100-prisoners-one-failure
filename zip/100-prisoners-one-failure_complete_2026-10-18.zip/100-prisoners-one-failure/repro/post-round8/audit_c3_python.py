"""Portable, solver-free recheck of continuation3 completion cases.

The generator is the archived Claude c3_pairs/c3_old code. This file supplies
an independently implemented Python bitset exact-cover engine, replacing the
archived Linux C executable. It never writes into the archived source tree.
Use: python audit_c3_python.py --source PATH [--lo 0 --hi 913] [--triangles]
"""
import argparse
from collections import Counter
import importlib
import json
from pathlib import Path
import sys
import time


def bit_indices(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def completion_engine(model):
    masks = [sum(1 << w for w in ws) for ws in model.BWS]
    col_rows = [sum(1 << b for b, ws in enumerate(model.BWS) if w in ws)
                for w in range(len(model.OLDW))]
    conflicts = []
    for ws in model.BWS:
        conflict = 0
        for w in ws:
            conflict |= col_rows[w]
        conflicts.append(conflict)
    ds = [tuple(sorted(s for r in rules for s in model.six_with_rule[r]))
          for rules in model.BRULES]
    assert all(len(x) == len(set(x)) for x in ds)
    all_words = (1 << len(model.OLDW)) - 1
    all_rows = (1 << len(masks)) - 1

    def run_cases(cases, **unused):
        output = {}
        for case in cases:
            fixed = case['fixed']
            holes = case['holes']
            used = sum(1 << w for w in holes)
            available = all_rows
            counts = Counter(case.get('init', []))
            limit = case.get('sixlimit', 4)
            bad = False
            for b in fixed:
                if used & masks[b]:
                    bad = True
                used |= masks[b]
                available &= ~conflicts[b]
                counts.update(ds[b])
            for w in holes:
                available &= ~col_rows[w]
            if any(value > limit for value in counts.values()):
                bad = True
            nodes = 0
            solution = None

            def search(remaining, avail, budget, chosen, free_holes):
                nonlocal nodes, solution
                nodes += 1
                if not remaining:
                    if budget == 0:
                        solution = (chosen, free_holes)
                        return True
                    return False
                if remaining.bit_count() < budget or (remaining.bit_count() - budget) % 4:
                    return False
                candidates = None
                chosen_word = None
                best = 10**9
                for w in bit_indices(remaining):
                    opts = col_rows[w] & avail
                    n = opts.bit_count()
                    if n < best:
                        chosen_word, candidates, best = w, opts, n
                        if n == 0:
                            break
                for b in bit_indices(candidates):
                    if any(counts[s] >= limit for s in ds[b]):
                        continue
                    counts.update(ds[b])
                    if search(remaining & ~masks[b], avail & ~conflicts[b], budget,
                              chosen + [b], free_holes):
                        return True
                    counts.subtract(ds[b])
                if budget:
                    if search(remaining & ~(1 << chosen_word), avail & ~col_rows[chosen_word],
                              budget - 1, chosen, free_holes + [chosen_word]):
                        return True
                return False

            if not bad:
                search(all_words & ~used, available, case.get('budget', 0), [], [])
            status = 'FOUND' if solution is not None else 'EXHAUSTED'
            output[case['id']] = (status, nodes, *(solution or ([], [])))
        return output
    return run_cases


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--lo', type=int, default=0)
    parser.add_argument('--hi', type=int, default=913)
    parser.add_argument('--triangles', action='store_true')
    parser.add_argument('--control', type=Path)
    args = parser.parse_args()
    source = args.source.resolve()
    sys.path.insert(0, str(source))
    model = importlib.import_module('c3_old')
    engine = completion_engine(model)
    seeds = json.loads((source / 'c3_seeds.json').read_text())
    start = time.monotonic()
    if args.control:
        supplied = json.loads(args.control.read_text(encoding='utf-8-sig'))
        rules = {(a, *history, t) for a, history, t in supplied['rules']}
        old = {b for b, rs in enumerate(model.BRULES) if rs <= rules}
        assert len(old) == 46
        words = set().union(*(model.BWS[b] for b in old))
        holes = sorted(set(range(len(model.OLDW))) - words)
        assert len(holes) == 2
        fixed = sorted(old)[:33]
        result = engine([dict(id=0, fixed=fixed, holes=holes, budget=0, sixlimit=4)])[0]
        assert result[0] == 'FOUND'
        completed = set(fixed) | set(result[2])
        assert len(completed) == 46 and len(result[2]) == 13
        counts = Counter(w for b in completed for w in model.BWS[b])
        assert all(n == 1 for n in counts.values())
        assert set(counts) | set(holes) == set(range(len(model.OLDW)))
        six_counts = Counter(s for b in completed for r in model.BRULES[b] for s in model.six_with_rule[r])
        assert max(six_counts.values()) <= 4
        out = dict(status='PASS_FOUND_VALID_COVER', fixed_blocks=33, recovered_blocks=13,
                   six_limit=4, nodes=result[1], seconds=time.monotonic()-start)
        Path('c3_python_control.json').write_text(json.dumps(out, indent=2))
        print(json.dumps(out))
    elif args.triangles:
        cases = []
        for i, seed in enumerate(seeds['triangle_seeds']):
            fixed = [model.BIDX[tuple(sorted(map(tuple, block)))] for block in seed]
            cases.append(dict(id=i, fixed=fixed, holes=[], budget=2, sixlimit=99))
        result = engine(cases)
        out = dict(status_counts=dict(Counter(x[0] for x in result.values())),
                   cases=len(cases), nodes=sum(x[1] for x in result.values()),
                   seconds=time.monotonic()-start)
        assert out['status_counts'] == {'EXHAUSTED': 248}
        Path('c3_python_triangles.json').write_text(json.dumps(out, indent=2))
        print(json.dumps(out))
    else:
        pairs = importlib.import_module('c3_pairs')
        records = {}
        for i in range(args.lo, args.hi):
            seed = pairs.seed_ids(seeds['pair_seeds'][i])
            base, opts_a, opts_b = pairs.enum_options(seed)
            cores = pairs.make_cores(seed, opts_a, opts_b, base)
            cases = []
            for ci, key in enumerate(cores):
                fixed, extras, budget = key
                cases.append(dict(id=ci, fixed=sorted(fixed), holes=sorted(cores[key]['holes']),
                                  budget=budget, sixlimit=4, init=pairs.six_init(extras)))
            result = engine(cases)
            record = dict(base=len(base), optsA=len(opts_a), optsB=len(opts_b), cores=len(cores),
                          statuses=dict(Counter(x[0] for x in result.values())),
                          nodes=sum(x[1] for x in result.values()))
            assert not any(x[0] != 'EXHAUSTED' for x in result.values())
            records[i] = record
            if i % 100 == 0:
                print(i, record, round(time.monotonic()-start, 2), flush=True)
        out = dict(range=[args.lo,args.hi], records=records, seconds=time.monotonic()-start,
                   total_cores=sum(x['cores'] for x in records.values()),
                   total_nodes=sum(x['nodes'] for x in records.values()))
        Path(f'c3_python_pairs_{args.lo}_{args.hi}.json').write_text(json.dumps(out, indent=2))
        print({k:v for k,v in out.items() if k != 'records'})


if __name__ == '__main__':
    main()
