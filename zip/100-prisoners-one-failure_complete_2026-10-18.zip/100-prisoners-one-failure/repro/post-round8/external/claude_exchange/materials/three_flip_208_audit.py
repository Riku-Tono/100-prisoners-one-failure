"""Independent local C7 witness audit for the canonical three-support-flip208 branch.

Old seven-label blocks forbid1234,1235,1236,4567. No extra independent rules.
Does not test completion to46old blocks. No statement about210rules is made.
"""
from itertools import combinations,permutations
from collections import defaultdict,Counter
from pathlib import Path
import json,time
H=Path(__file__).resolve().parent
L=tuple(range(1,8));FORBIDDEN={frozenset(x) for x in [(1,2,3,4),(1,2,3,5),(1,2,3,6),(4,5,6,7)]}

def cyclic(k):
    for s in combinations(L,k):
        for p in permutations(s[1:]):yield (s[0],)+p
def canon(c):
    c=tuple(c);i=c.index(min(c));return c[i:]+c[:i]
def windows(c):return [tuple(c[(i+j)%len(c)] for j in range(5)) for i in range(len(c))]
def bits(x):
    while x:
        b=x&-x;yield b.bit_length()-1;x^=b

def graph_counts(adj):
    triangles=0;k4=0;triangle_example=None
    for i in range(len(adj)):
        for j in bits(adj[i]&~((1<<(i+1))-1)):
            common=adj[i]&adj[j]&~((1<<(j+1))-1);triangles+=common.bit_count()
            for k in bits(common):
                if triangle_example is None:triangle_example=[i,j,k]
                k4+=(common&adj[k]&~((1<<(k+1))-1)).bit_count()
    return {'edges':sum(a.bit_count() for a in adj)//2,'triangles':triangles,'four_cliques':k4,'maximum_clique_if_no_four':3 if triangles and not k4 else None,'triangle_example_pattern_ids':triangle_example}

def main():
    start=time.perf_counter();words={c:i for i,c in enumerate(cyclic(4))};blocks=[];providers=defaultdict(list)
    for c in cyclic(5):
        for omit in c:
            rr=tuple(r for r in windows(c) if r[0]!=omit)
            if any(frozenset(r[1:]) in FORBIDDEN for r in rr):continue
            losses=tuple(words[canon(r[1:])] for r in rr);wm=sum(1<<w for w in losses);bi=len(blocks);blocks.append((c,omit,rr,losses,wm))
            for r in rr:providers[r].append(bi)
    cycles=[];patterns=[];parents=[];bycycle=[];window_hist=Counter();pattern_hist=Counter();examined=0
    for c in cyclic(7):
        examined+=1;ww=windows(c);forbidden=sum(frozenset(r[1:]) in FORBIDDEN for r in ww);window_hist[forbidden]+=1
        if forbidden>1:continue
        found=set()
        for miss in range(7):
            req=[r for i,r in enumerate(ww) if i!=miss]
            if any(not providers[r] for r in req):continue
            req.sort(key=lambda r:len(providers[r]))
            def dfs(position,occupied,selected):
                if position==6:found.add(tuple(sorted(selected)));return
                for bi in providers[req[position]]:
                    mask=blocks[bi][4]
                    if mask&occupied:continue
                    dfs(position+1,occupied|mask,selected+[bi])
            dfs(0,0,[])
        if not found:continue
        ci=len(cycles);cycles.append(c);pids=[];pattern_hist[len(found)]+=1
        for pat in sorted(found):pids.append(len(patterns));patterns.append(pat);parents.append(ci)
        bycycle.append(pids)
    assert examined==720
    cp=[sum(1<<p for p in pp) for pp in bycycle];allp=(1<<len(patterns))-1
    bpat=defaultdict(int);wpat=defaultdict(int);rpat=defaultdict(int)
    for pi,pat in enumerate(patterns):
        for bi in pat:
            bpat[bi]|=1<<pi
            for r,w in zip(blocks[bi][2],blocks[bi][3]):wpat[w]|=1<<pi;rpat[r]|=1<<pi
    bad_a={};bad_b={}
    for bi,containing in bpat.items():
        aa=0;bb=0
        for r,w in zip(blocks[bi][2],blocks[bi][3]):aa|=wpat[w];bb|=wpat[w]&~rpat[r]
        bad_a[bi]=aa&~containing;bad_b[bi]=bb
    adj_a=[];adj_b=[]
    for pi,pat in enumerate(patterns):
        aa=cp[parents[pi]];bb=aa
        for bi in pat:aa|=bad_a[bi];bb|=bad_b[bi]
        adj_a.append(allp&~aa);adj_b.append(allp&~bb)
    assert all(((adj_b[i]>>j)&1)==((adj_b[j]>>i)&1) for i in range(len(patterns)) for j in range(i))
    a=graph_counts(adj_a);b=graph_counts(adj_b)
    result={'scope':__doc__,'forbidden_supports':[sorted(s) for s in sorted(FORBIDDEN,key=lambda s:sorted(s))],'old_allowed_blocks':len(blocks),'cycles_examined':examined,'forbidden_window_histogram':dict(window_hist),'cycles_with_at_most_one_forbidden_window':sum(v for k,v in window_hist.items() if k<=1),'cycles_with_witnesses':len(cycles),'minimal_six_block_witnesses':len(patterns),'pattern_count_histogram':dict(pattern_hist),'strict_block_compatibility':a,'rule_table_compatibility':b,'expected_ChatGPT_counts_match':len(cycles)==144 and len(patterns)==648 and b['edges']==32076 and b['triangles']==8736 and b['four_cliques']==0,'seconds':time.perf_counter()-start}
    details={'cycles':cycles,'patterns':[[[blocks[bi][0],blocks[bi][1]] for bi in pat] for pat in patterns],'pattern_parent_cycle_indices':parents,'rule_table_adjacency_indices':[list(bits(mask)) for mask in adj_b]}
    (H/'canonical_three_flip_audit.json').write_text(json.dumps(result,indent=2)+'\n');(H/'canonical_three_flip_witnesses.json').write_text(json.dumps(details,separators=(',',':'))+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
