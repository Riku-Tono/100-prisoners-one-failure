"""Claude Desktop: relaxation bound per (6-cycle, failing prisoner) orbit in the standard 3-flip 210-rule branch.

Relaxation of the 210-rule exact cover: slots inside [7] other than 4567 are 'at most once' (packing);
slots containing 8 and the 4567 slots stay 'exactly once'; total single rules <= 2; the chosen 6-cycle is rescued
with the chosen prisoner failing.  Maximise R7.  An OPTIMAL value v proves R7 <= v for that case in the full problem.
Usage: python3 flip3_relax.py OUTFILE PER_CASE_SECONDS SLICE NSLICES [WORKERS]
"""
import itertools, json, sys, time
from collections import defaultdict
from ortools.sat.python import cp_model
import flip3_model as F, flip3_cases as K

def build_relax(C6, f):
    m = cp_model.CpModel()
    terms = defaultdict(list); slot_terms = defaultdict(list); blocks = {}; singles = {}
    for C in F.dcycles(5):
        for w in C:
            rules = [F.member_rule(C, i) for i in range(5) if C[(i-1) % 5] != w]
            if all(F.active_rule(r) for r in rules):
                v = m.NewBoolVar(""); blocks[(C, w)] = (v, rules)
                for r in rules: terms[r].append(v); slot_terms[F.slot_of(r)].append(v)
    active_slots = sorted({F.canon((S[0],) + p) for S in F.ACTIVE for p in itertools.permutations(S[1:])})
    for D in active_slots:
        for rot in range(4):
            key = D[rot:] + D[:rot]
            for t in F.L:
                if t in D: continue
                r = key + (t,); v = m.NewBoolVar(""); singles[r] = v
                terms[r].append(v); slot_terms[D].append(v)
    for D in active_slots:
        S = set(D)
        if 8 in S or S == {4, 5, 6, 7}: m.AddExactlyOne(slot_terms[D])
        else: m.AddAtMostOne(slot_terms[D])
    m.Add(sum(singles.values()) <= 2)
    x = {}
    for r, ts in terms.items():
        xv = m.NewBoolVar(""); m.Add(xv == sum(ts)); x[r] = xv
    i = C6.index(f)
    for j in range(6):
        if j != i: m.Add(x[F.member_rule(C6, j)] == 1)
    z7 = {}
    for C in F.dcycles(7):
        avail = [x[r] for r in (F.member_rule(C, j) for j in range(7)) if r in x]
        if len(avail) < 6: continue
        z = m.NewBoolVar(""); z7[C] = z
        if len(avail) == 6:
            for a in avail: m.AddImplication(z, a)
        else:
            for a, b in itertools.combinations(avail, 2): m.AddBoolOr([a, b]).OnlyEnforceIf(z)
    m.Maximize(sum(z7.values()))
    return m, blocks, singles, z7

if __name__ == "__main__":
    out, per, sl, ns = sys.argv[1], float(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
    workers = int(sys.argv[5]) if len(sys.argv) > 5 else 2
    reps = sorted(K.cases().items())
    mine = [rc for k, rc in enumerate(reps) if k % ns == sl]
    results = []; t00 = time.time()
    for (C6, f), cnt in mine:
        t0 = time.time()
        m, blocks, singles, z7 = build_relax(C6, f)
        s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = per; s.parameters.num_workers = workers
        st = s.Solve(m)
        rec = {"six_cycle": list(C6), "failing": f, "orbit_size": cnt, "status": s.StatusName(st),
               "relax_R7_best": s.ObjectiveValue() if st in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None,
               "relax_R7_bound": s.BestObjectiveBound() if st != cp_model.INFEASIBLE else None,
               "sec": round(time.time() - t0, 2)}
        if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            rec["seven_cycles"] = [list(C) for C, v in z7.items() if s.Value(v)]
        results.append(rec); print(json.dumps(rec), flush=True)
        json.dump({"results": results, "elapsed": round(time.time() - t00, 1)}, open(out, "w", encoding="utf-8"), indent=1)
