"""Claude Desktop: independent CP-SAT check of the reduced old-side exact cover (standard 3-flip, 210 rules, R5=52, R6=1).

Old side = 31 allowed 4-subsets of [7] (all except 1234,1235,1236,4567) = 186 slots.  The 6-cycle case fixes the two
single rules P,Q (members c_{j-1}, c_{j-2} of the 6-cycle, j = index of the failing prisoner); the other 184 slots are
covered exactly once by 4-rule blocks on 5-subsets of [7].  The other 3 required 6-cycle rules must be block rules.
Ask: R7 >= R7MIN over the 720 directed 7-cycles on [7]?
Usage: python3 flip3_oldside.py OUT.json R7MIN SECONDS [case_index ...]
"""
import itertools, json, sys, time
from collections import defaultdict
from ortools.sat.python import cp_model
import flip3_model as F
SEVEN = tuple(range(1, 8))
FORB = {(1,2,3,4), (1,2,3,5), (1,2,3,6), (4,5,6,7)}
ALLOWED = {S for S in itertools.combinations(SEVEN, 4) if S not in FORB}
assert len(ALLOWED) == 31
CASES = [((1,4,2,5,6,7),6), ((1,4,2,5,7,6),7), ((1,4,2,7,5,6),5), ((1,4,5,6,2,7),5)]
def allowed(r): return tuple(sorted(r[:4])) in ALLOWED
def old_blocks(excluded_slots=()):
    out = []
    for S in itertools.combinations(SEVEN, 5):
        for tail in itertools.permutations(S[1:]):
            C = (S[0],) + tail
            for w in C:
                rules = [F.member_rule(C, i) for i in range(5) if C[(i-1) % 5] != w]
                if all(allowed(r) for r in rules) and not any(F.slot_of(r) in excluded_slots for r in rules):
                    out.append(((C, w), rules))
    return out
OLD_SLOTS = sorted({F.canon((S[0],) + p) for S in ALLOWED for p in itertools.permutations(S[1:])})
assert len(OLD_SLOTS) == 186

def build(C6, f, r7min):
    j = C6.index(f)
    P = F.member_rule(C6, (j - 1) % 6); Q = F.member_rule(C6, (j - 2) % 6)
    singles = {P, Q}
    req_block = [F.member_rule(C6, k) for k in range(6) if k not in (j, (j-1) % 6, (j-2) % 6)]
    m = cp_model.CpModel()
    B = old_blocks(excluded_slots={F.slot_of(P), F.slot_of(Q)})
    bv = []; slot_terms = defaultdict(list); terms = defaultdict(list)
    for key, rules in B:
        v = m.NewBoolVar(""); bv.append((key, v, rules))
        for r in rules: slot_terms[F.slot_of(r)].append(v); terms[r].append(v)
    for D in OLD_SLOTS:
        if D in (F.slot_of(P), F.slot_of(Q)): continue
        m.AddExactlyOne(slot_terms[D])
    for r in req_block: m.Add(sum(terms[r]) == 1)
    def present(r):
        return 1 if r in singles else (sum(terms[r]) if terms[r] else 0)
    z = {}
    for tail in itertools.permutations(SEVEN[1:]):
        C = (1,) + tail
        rs = [F.member_rule(C, i) for i in range(7)]
        ex = [present(r) for r in rs]
        if sum(1 for e in ex if not (isinstance(e, int) and e == 0)) < 6: continue
        zz = m.NewBoolVar(""); z[C] = zz
        xs = []
        for e in ex:
            if isinstance(e, int): xs.append(e)
            else:
                b = m.NewBoolVar(""); m.Add(b == e); xs.append(b)
        consts_missing = sum(1 for e in xs if isinstance(e, int) and e == 0)
        if consts_missing == 1:
            for e in xs:
                if not isinstance(e, int): m.AddImplication(zz, e)
        else:
            var = [e for e in xs if not isinstance(e, int)]
            for a, b in itertools.combinations(var, 2): m.AddBoolOr([a, b]).OnlyEnforceIf(zz)
    m.Add(sum(z.values()) >= r7min)
    return m, bv, z, (P, Q)

if __name__ == "__main__":
    out, r7min, secs = sys.argv[1], int(sys.argv[2]), float(sys.argv[3])
    idx = [int(a) for a in sys.argv[4:]] or [0, 1, 2, 3]
    res = []
    for k in idx:
        C6, f = CASES[k]; t0 = time.time()
        m, bv, z, PQ = build(C6, f, r7min)
        s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = secs; s.parameters.num_workers = 2
        st = s.Solve(m)
        rec = {"case": [list(C6), f], "P_Q": [list(PQ[0]), list(PQ[1])], "R7min": r7min, "status": s.StatusName(st),
               "n_blocks_vars": len(bv), "n_7cycles": len(z), "sec": round(time.time() - t0, 1)}
        if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            rec["seven_cycles"] = [list(C) for C, v in z.items() if s.Value(v)]
            rec["blocks"] = [[list(key[0]), key[1]] for key, v, _ in bv if s.Value(v)]
        res.append(rec); print(json.dumps({k2: v for k2, v in rec.items() if k2 != "blocks"}), flush=True)
        json.dump(res, open(out, "w"), indent=1)
