"""Claude Desktop review checks for the 4 representative cases (standard 3-flip, 210 rules, R5=52, R6>=1).
A: relaxation max of 2*(R6-1)+R7+R8  (makes 'wins <= 15052' self-contained in this branch)
B: for each of the 5 required 6-cycle rules: can it be a block rule? a single rule?
C: number of ways to cover the 24 slots on 5678/4678/4578/4567 by 6 blocks on 45678 with skipped target 7
"""
import itertools, json, time
from ortools.sat.python import cp_model
import flip3_model as F, flip3_relax as X
CASES = [((1,4,2,5,6,7),6), ((1,4,2,5,7,6),7), ((1,4,2,7,5,6),5), ((1,4,5,6,2,7),5)]
def solve(m, t=30):
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = t; s.parameters.num_workers = 2
    st = s.Solve(m); return s, s.StatusName(st)
out = {"A": [], "B": [], "C": None}
for C6, f in CASES:
    # A
    m, blocks, singles, z7 = X.build_relax(C6, f)
    xs = {}
    # rebuild x lookup: rule -> Bool via fresh expression of block/single vars
    terms = {}
    for (C, w), (v, rs) in blocks.items():
        for r in rs: terms.setdefault(r, []).append(v)
    for r, v in singles.items(): terms.setdefault(r, []).append(v)
    extra = []
    for k in (6, 8):
        for C in F.dcycles(k):
            if k == 6 and F.canon(C) == F.canon(C6): continue
            avail = [r for r in (F.member_rule(C, j) for j in range(k)) if r in terms]
            if len(avail) < k - 1: continue
            z = m.NewBoolVar(""); m.Add(sum(sum(terms[r]) for r in avail) >= (k - 1) * z)
            extra.append((k, z))
    m.Maximize(sum(z7.values()) + sum((2 if k == 6 else 1) * z for k, z in extra))
    s, st = solve(m)
    rec = {"case": [list(C6), f], "status": st, "max_2(R6-1)+R7+R8": s.ObjectiveValue(), "bound": s.BestObjectiveBound(),
           "other6": sum(1 for k, z in extra if k == 6 and s.Value(z)), "R8": sum(1 for k, z in extra if k == 8 and s.Value(z))}
    out["A"].append(rec); print("A", rec, flush=True)
    # B
    i = C6.index(f)
    for j in range(6):
        if j == i: continue
        r = F.member_rule(C6, j)
        row = {"case": [list(C6), f], "prisoner": C6[j], "rule[t,i,o1,o2,o3]": [r[4], r[0], r[1], r[2], r[3]]}
        for how in ("block", "single"):
            m, blocks, singles, z7 = X.build_relax(C6, f)
            if how == "single": m.Add(singles[r] == 1)
            else: m.Add(singles[r] == 0)
            s, st = solve(m, 20); row[how] = st
        out["B"].append(row); print("B", row, flush=True)
# C
V = (4, 5, 6, 7, 8)
cands = []
for C in F.dcycles(5):
    if set(C) != set(V): continue
    rules = [F.member_rule(C, i) for i in range(5) if C[(i-1) % 5] != 7]
    if all(F.active_rule(r) for r in rules): cands.append((C, [F.slot_of(r) for r in rules]))
slots = sorted({s for _, ss in cands for s in ss})
cnt = 0
for combo in itertools.combinations(range(len(cands)), 6):
    used = [s for k in combo for s in cands[k][1]]
    if len(set(used)) == 24: cnt += 1
out["C"] = {"skip7_blocks_on_45678": len(cands), "slots": len(slots), "exact_covers_by_6": cnt}
print("C", out["C"])
json.dump(out, open("runs/review_checks.json", "w"), indent=1)
