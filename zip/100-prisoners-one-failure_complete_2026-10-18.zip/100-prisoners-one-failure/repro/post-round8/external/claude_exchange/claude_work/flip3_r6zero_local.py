"""Claude Desktop: R6=0 local question (standard 3-flip old side, local relaxation, no completion to 52 blocks).

Extra rule r=(a,b,c,d,t): prisoner a, observes b,c,d, opens t; {a,b,c,d} must be one of the 31 allowed old supports.
With {x,y} = [7] minus {a,b,c,d,t}, r is the correct rule of a in C1=(a,b,c,d,x,y,t) and C2=(a,b,c,d,y,x,t).
Question: do pairwise slot-disjoint old-side 4-rule blocks (never using r's slot) exist so that C1 and C2 are BOTH
rescued (>=6 of 7 correct, r counted)?  Only r is an extra rule here.  Orbits under G=Sym{1,2,3}xSym{4,5,6}.
"""
import itertools, json, time
from collections import defaultdict
from ortools.sat.python import cp_model
import flip3_model as F, flip3_oldside as O, flip3_cases as K
SEVEN = O.SEVEN
def rep(r):
    return min(tuple(g[v] for v in r) for g in K.G)
reps = {}
for a, b, c, d, t in itertools.permutations(SEVEN, 5):
    r = (a, b, c, d, t)
    if tuple(sorted(r[:4])) not in O.ALLOWED: continue
    reps.setdefault(rep(r), 0); reps[rep(r)] += 1
res = []; t00 = time.time()
for r, cnt in sorted(reps.items()):
    a, b, c, d, t = r
    x, y = [v for v in SEVEN if v not in r]
    cyc = [(a, b, c, d, x, y, t), (a, b, c, d, y, x, t)]
    m = cp_model.CpModel()
    B = O.old_blocks(excluded_slots={F.slot_of(r)})
    slot_terms = defaultdict(list); terms = defaultdict(list); bv = []
    for key, rules in B:
        v = m.NewBoolVar(""); bv.append((key, v))
        for q in rules: slot_terms[F.slot_of(q)].append(v); terms[q].append(v)
    for D, ts in slot_terms.items(): m.AddAtMostOne(ts)
    detail = []
    for C in cyc:
        rs = [F.member_rule(C, i) for i in range(7)]
        assert rs[0] == r
        xs = []
        for q in rs[1:]:
            if terms[q]:
                bq = m.NewBoolVar(""); m.Add(bq == sum(terms[q])); xs.append(bq)
        detail.append(len(xs))
        if len(xs) < 5: m.Add(0 == 1)
        else: m.Add(sum(xs) >= 5)
    m.Minimize(sum(v for _, v in bv))
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = 20; s.parameters.num_workers = 2
    st = s.Solve(m)
    rec = {"r_(a,b,c,d,t)": list(r), "orbit_size": cnt, "C1": list(cyc[0]), "C2": list(cyc[1]),
           "window_rules_available": detail, "status": s.StatusName(st)}
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        rec["min_blocks"] = int(s.ObjectiveValue())
        rec["blocks_(5cycle,skipped_target)"] = [[list(k[0]), k[1]] for k, v in bv if s.Value(v)]
    res.append(rec)
json.dump({"orbits": len(res), "rules_total": sum(reps.values()), "results": res, "elapsed": round(time.time()-t00,1)},
          open("runs/r6zero_local.json", "w"), indent=1)
from collections import Counter
print("orbits", len(res), "rules", sum(reps.values()), "elapsed", round(time.time()-t00,1))
print(Counter(x["status"] for x in res))
for x in res:
    if x["status"] != "INFEASIBLE": print(json.dumps({k: x[k] for k in x if k != "blocks_(5cycle,skipped_target)"}), x.get("blocks_(5cycle,skipped_target)"))
