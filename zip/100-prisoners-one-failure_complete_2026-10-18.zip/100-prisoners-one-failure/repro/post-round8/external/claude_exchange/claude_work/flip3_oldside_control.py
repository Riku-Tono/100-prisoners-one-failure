"""Control: the known new15051 (6-cycle (1,5,2,6,7,4), failing 7) must be accepted by flip3_oldside.build with R7>=1."""
import json
from ortools.sat.python import cp_model
import flip3_model as F, flip3_oldside as O
raw = json.load(open("../materials/new15051.rules.json", encoding="utf-8-sig"))
hb, hs = F.decompose(raw["rules"])
m, bv, z, PQ = O.build((1,5,2,6,7,4), 7, 1)
print("P,Q from formula:", PQ, " singles in new15051:", sorted(hs), " match:", set(PQ) == hs)
old = {b for b in hb if set(b[0]) <= set(O.SEVEN)}
keys = {key for key, v, _ in bv}
print("old-side blocks in new15051:", len(old), "all present as model vars:", old <= keys)
for key, v, _ in bv: m.Add(v == (1 if key in old else 0))
s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = 30; st = s.Solve(m)
print("control status:", s.StatusName(st), "rescued 7-cycles:", [C for C, v in z.items() if st in (2, 4) and s.Value(v)])
print("old_blocks() unrestricted count:", len(O.old_blocks()))
