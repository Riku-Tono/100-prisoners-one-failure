"""Claude Desktop: CP-SAT model for the standard 3-flip, 210-rule branch (n=8, 4 boxes, >=7 to win).

Conventions (same as verify_rules.py): rule [a,[h1,h2,h3],t] = prisoner a, after seeing h1,h2,h3, opens t.
Cycle (c0..c_{k-1}) means box c_i contains c_{i+1}. Member c_i is rescued by rule (c_i; c_{i+1},c_{i+2},c_{i+3} -> c_{i-1}).
Slot of a rule = directed 4-cycle (a,h1,h2,h3). Active family A = 4-subsets of [7] with 1234,1235,1236 replaced by complements.
Every active slot holds exactly one rule (M=210); 52 five-cycle blocks of 4 rules + 2 single rules.
Maximise 2*R6 + R7 + R8 (R5=52 fixed => wins = 14736 + 312 + 2R6 + R7 + R8).
Usage: python3 flip3_model.py OUTDIR TIME_LIMIT SEED MODE   (MODE: max | feas_r6r7 | feas4)
"""
import itertools, json, sys, time, os
from collections import defaultdict
from ortools.sat.python import cp_model

L = tuple(range(1, 9))
def canon(c):
    c = tuple(c); i = c.index(min(c)); return c[i:] + c[:i]
def dcycles(k):
    for S in itertools.combinations(L, k):
        for t in itertools.permutations(S[1:]):
            yield (S[0],) + t
FLIPS = [(1,2,3,4), (1,2,3,5), (1,2,3,6)]
ACTIVE = set()
for S in itertools.combinations(range(1, 8), 4):
    ACTIVE.add(tuple(sorted(set(L) - set(S))) if S in FLIPS else S)
assert len(ACTIVE) == 35
def slot_of(rule):            # rule = (a,h1,h2,h3,t)
    return canon(rule[:4])
def active_rule(rule):
    return tuple(sorted(rule[:4])) in ACTIVE
def member_rule(cyc, i):
    k = len(cyc)
    return (cyc[i], cyc[(i+1) % k], cyc[(i+2) % k], cyc[(i+3) % k], cyc[(i-1) % k])

def build(mode, hint=None):
    m = cp_model.CpModel()
    rule_terms = defaultdict(list)     # rule -> vars that place it
    slot_terms = defaultdict(list)
    blocks = {}
    for C in dcycles(5):
        for w in C:
            rules = [member_rule(C, i) for i in range(5) if C[(i-1) % 5] != w]
            if all(active_rule(r) for r in rules):
                v = m.NewBoolVar(f"b{C}{w}")
                blocks[(C, w)] = (v, rules)
                for r in rules:
                    rule_terms[r].append(v); slot_terms[slot_of(r)].append(v)
    singles = {}
    active_slots = sorted({canon((S[0],) + p) for S in ACTIVE for p in itertools.permutations(S[1:])})
    assert len(active_slots) == 210
    for D in active_slots:
        for rot in range(4):
            key = D[rot:] + D[:rot]
            for t in L:
                if t in D: continue
                r = key + (t,)
                v = m.NewBoolVar(f"s{r}")
                singles[r] = v
                rule_terms[r].append(v); slot_terms[D].append(v)
    for D in active_slots:
        m.AddExactlyOne(slot_terms[D])
    m.Add(sum(v for v, _ in blocks.values()) == 52)
    z = {}
    for k in (6, 7, 8):
        for C in dcycles(k):
            rs = [member_rule(C, i) for i in range(k)]
            avail = [r for r in rs if r in rule_terms]
            if len(avail) < k - 1: continue
            v = m.NewBoolVar(f"z{C}")
            z[C] = v
            m.Add(sum(sum(rule_terms[r]) for r in avail) >= (k - 1) * v)
    R6 = sum(v for C, v in z.items() if len(C) == 6)
    R7 = sum(v for C, v in z.items() if len(C) == 7)
    R8 = sum(v for C, v in z.items() if len(C) == 8)
    obj = 2 * R6 + R7 + R8
    if mode == "max":
        m.Maximize(obj)
    elif mode == "feas_r6r7":
        m.Add(R6 >= 1); m.Add(R7 >= 2)
    elif mode == "feas4":
        m.Add(obj >= 4)
    if hint:
        hb, hs = hint
        for key, (v, _) in blocks.items(): m.AddHint(v, key in hb)
        for r, v in singles.items(): m.AddHint(v, r in hs)
    return m, blocks, singles, z

def decompose(rules):
    """Split a 210-rule table into blocks (C5, skipped target) and single rules."""
    groups = defaultdict(list)
    for a, h, t in rules:
        r = (a, h[0], h[1], h[2], t); groups[canon((t, a) + tuple(h))].append(r)
    hb, hs = set(), set()
    for C, rs in groups.items():
        if len(rs) == 4:
            targets = {r[4] for r in rs}; w = [x for x in C if x not in targets][0]; hb.add((C, w))
        else:
            hs.update(rs)
    return hb, hs

if __name__ == "__main__":
    outdir, tl, seed, mode = sys.argv[1], float(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
    hint_path = sys.argv[5] if len(sys.argv) > 5 else None
    t0 = time.time()
    hint = None
    if hint_path:
        raw = json.load(open(hint_path, encoding="utf-8-sig"))
        hint = decompose(raw["rules"])
    m, blocks, singles, z = build(mode, hint)
    s = cp_model.CpSolver()
    s.parameters.max_time_in_seconds = tl
    s.parameters.num_workers = int(os.environ.get("WORKERS", "2"))
    s.parameters.random_seed = seed
    st = s.Solve(m)
    res = {"mode": mode, "seed": seed, "time_limit": tl, "status": s.StatusName(st),
           "num_block_vars": len(blocks), "num_single_vars": len(singles), "num_cycle_vars": len(z),
           "wall": round(time.time() - t0, 1), "hint": bool(hint_path)}
    if mode == "max" and st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        res["objective_2R6_R7_R8"] = s.ObjectiveValue(); res["bound"] = s.BestObjectiveBound()
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        rules = []
        for (C, w), (v, rs) in blocks.items():
            if s.Value(v): rules += rs
        for r, v in singles.items():
            if s.Value(v): rules.append(r)
        rules = sorted(rules)
        res["R"] = {str(k): sum(1 for C, v in z.items() if len(C) == k and s.Value(v)) for k in (6, 7, 8)}
        res["rescued_long"] = [list(C) for C, v in z.items() if s.Value(v)]
        out = {"schema": "mixed-n8-v1", "rules": [[r[0], list(r[1:4]), r[4]] for r in rules]}
        name = f"{outdir}/flip3_{mode}_seed{seed}.rules.json"
        json.dump(out, open(name, "w", encoding="utf-8"), indent=1); res["rules_file"] = name
    json.dump(res, open(f"{outdir}/flip3_{mode}_seed{seed}.result.json", "w", encoding="utf-8"), indent=2)
    print(json.dumps(res))
