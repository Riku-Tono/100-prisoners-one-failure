"""Claude Desktop: enumerate all 7-cycle pairs allowed by the relaxation (flip3_relax.build_relax) for given cases.
Usage: python3 flip3_pairs.py OUTFILE TIME_BUDGET"""
import json, sys, time
from ortools.sat.python import cp_model
import flip3_relax as X
CASES = [((1,4,2,5,6,7),6), ((1,4,2,5,7,6),7), ((1,4,2,7,5,6),5), ((1,4,5,6,2,7),5)]
out, budget = sys.argv[1], float(sys.argv[2]); t00 = time.time(); res = []
for C6, f in CASES:
    m, blocks, singles, z7 = X.build_relax(C6, f)
    m.ClearObjective(); m.Add(sum(z7.values()) >= 2)
    pairs = []; status = None
    while time.time() - t00 < budget:
        s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = 20; s.parameters.num_workers = 2
        st = s.Solve(m); status = s.StatusName(st)
        if st not in (cp_model.OPTIMAL, cp_model.FEASIBLE): break
        on = [C for C, v in z7.items() if s.Value(v)]
        pairs.append([list(c) for c in on])
        m.AddBoolOr([z7[c].Not() for c in on])
    res.append({"six_cycle": list(C6), "failing": f, "pairs": pairs, "n_pairs": len(pairs), "final_status": status,
                "complete": status == "INFEASIBLE"})
    print(C6, f, len(pairs), status, round(time.time()-t00,1), flush=True)
    json.dump(res, open(out, "w"), indent=1)
