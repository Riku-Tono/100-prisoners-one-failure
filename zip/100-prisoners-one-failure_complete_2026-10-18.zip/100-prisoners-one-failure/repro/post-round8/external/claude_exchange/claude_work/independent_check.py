"""Claude Desktop's independent re-implementation (written without reusing verify_rules.py code).

Model: n=8 prisoners/boxes, each prisoner opens 4 boxes, team wins iff >=7 prisoners succeed.
Strategy: prisoner p opens box p, then box = number seen, for the first 3 boxes (cycle following).
After seeing numbers h1,h2,h3 (none equal to p), the 4th box is h3 unless a rule
[p,[h1,h2,h3],t] exists, in which case box t is opened instead.
Usage: python3 independent_check.py RULES.json OUTPUT.json
"""
import sys, json, itertools, collections, hashlib, time

def load(path):
    raw = json.loads(open(path, encoding="utf-8-sig").read())
    rules = raw["rules"] if isinstance(raw, dict) else raw
    table = {}
    for p, h, t in rules:
        k = (p, h[0], h[1], h[2])
        if k in table:
            raise SystemExit(f"duplicate rule key {k}")
        table[k] = t
    return rules, table

def run(path, out):
    t0 = time.time()
    rules, table = load(path)
    nums = range(1, 9)
    wins = cf_wins = cf_lost = new_wins = 0
    by_long = collections.Counter()          # winning placements keyed by (length, canonical long cycle)
    hist = collections.Counter()
    for perm in itertools.permutations(nums):
        box = {i + 1: perm[i] for i in range(8)}   # box -> number inside
        # cycle structure by following box -> number
        seen, lens, longest_cycles = set(), [], []
        for s in nums:
            if s in seen:
                continue
            c, x = [], s
            while x not in seen:
                seen.add(x); c.append(x); x = box[x]
            lens.append(len(c))
            if len(c) >= 5:
                m = c.index(min(c)); longest_cycles.append(tuple(c[m:] + c[:m]))
        cf_ok = sum(l for l in lens if l <= 4) >= 7
        ok = 0
        for p in nums:
            opened = p; seen_nums = []; success = False
            for step in range(4):
                v = box[opened]
                if v == p:
                    success = True; break
                seen_nums.append(v)
                if step < 2:
                    opened = v
                elif step == 2:
                    opened = table.get((p, seen_nums[0], seen_nums[1], seen_nums[2]), v)
            ok += success
        hist[ok] += 1
        win = ok >= 7
        wins += win; cf_wins += cf_ok
        if cf_ok and not win: cf_lost += 1
        if win and not cf_ok:
            new_wins += 1
            assert len(longest_cycles) == 1
            c = longest_cycles[0]
            by_long[(len(c), c)] += 1
    R = collections.Counter(k[0] for k in by_long)
    per_cycle_mult = collections.Counter((k[0], v) for k, v in by_long.items())
    res = {
        "checker": "claude-desktop-independent-simulation-v1",
        "input_sha256": hashlib.sha256(open(path, "rb").read()).hexdigest(),
        "rules_count": len(rules),
        "placements": 40320,
        "wins": wins,
        "cf_wins": cf_wins,
        "cf_old_wins_lost": cf_lost,
        "new_wins_beyond_cf": new_wins,
        "rescued_long_cycles_by_length": {str(k): R[k] for k in sorted(R)},
        "wins_per_rescued_cycle": {f"len{k}_x{v}": n for (k, v), n in sorted(per_cycle_mult.items())},
        "formula_14736_6R5_2R6_R7": 14736 + 6*R[5] + 2*R[6] + R[7],
        "success_histogram": {str(k): hist[k] for k in sorted(hist)},
        "rescued_6_7_8_cycles": [list(k[1]) for k in sorted(by_long) if k[0] >= 6],
        "elapsed_seconds": round(time.time() - t0, 2),
    }
    open(out, "w", encoding="utf-8").write(json.dumps(res, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({k: res[k] for k in ("rules_count","wins","cf_wins","cf_old_wins_lost","rescued_long_cycles_by_length","formula_14736_6R5_2R6_R7","wins_per_rescued_cycle","rescued_6_7_8_cycles","elapsed_seconds")}, ensure_ascii=False))

if __name__ == "__main__":
    run(sys.argv[1], sys.argv[2])
