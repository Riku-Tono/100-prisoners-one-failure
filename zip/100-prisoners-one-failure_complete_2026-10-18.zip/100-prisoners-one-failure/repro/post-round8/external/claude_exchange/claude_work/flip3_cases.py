"""Claude Desktop: case split of the standard 3-flip 210-rule branch by (rescued 6-cycle, failing prisoner).

For each orbit representative under G = Sym{1,2,3} x Sym{4,5,6} (A is G-invariant), fix that 6-cycle as
rescued with that prisoner failing, keep exact cover (210 active slots, 52 blocks, 2 singles), and ask CP-SAT
whether R7 >= 2 is possible.  INFEASIBLE = proven impossible for that case, UNKNOWN = time limit.
Usage: python3 flip3_cases.py OUTFILE PER_CASE_SECONDS SLICE NSLICES [WORKERS]
"""
import itertools, json, sys, time
from collections import defaultdict
from ortools.sat.python import cp_model
import flip3_model as F

L = F.L
G = []
for p in itertools.permutations((1, 2, 3)):
    for q in itertools.permutations((4, 5, 6)):
        mp = {1: p[0], 2: p[1], 3: p[2], 4: q[0], 5: q[1], 6: q[2], 7: 7, 8: 8}
        G.append(mp)
assert all(F.ACTIVE == {tuple(sorted(g[x] for x in S)) for S in F.ACTIVE} for g in G)

def case_key(C, f):
    return (F.canon(C), f)
def orbit_rep(C, f):
    return min(case_key(tuple(g[x] for x in C), g[f]) for g in G)

def cases():
    reps = {}
    for C in F.dcycles(6):
        for f in C:
            i = C.index(f)
            need = [F.member_rule(C, j) for j in range(6) if j != i]
            if not all(F.active_rule(r) for r in need):
                continue
            rep = orbit_rep(C, f)
            reps.setdefault(rep, 0); reps[rep] += 1
    return reps

def build_case(C6, f, r7_min=2, extra_obj=False):
    m = cp_model.CpModel()
    terms = defaultdict(list); slot_terms = defaultdict(list); blocks = {}; singles = {}
    for C in F.dcycles(5):
        for w in C:
            rules = [F.member_rule(C, i) for i in range(5) if C[(i-1) % 5] != w]
            if all(F.active_rule(r) for r in rules):
                v = m.NewBoolVar(""); blocks[(C, w)] = (v, rules)
                for r in rules: terms[r].append(v); slot_terms[F.slot_of(r)].append(v)
    active_slots = sorted({F.canon((S[0],) + p) for S in F.ACTIVE for p in itertools.permutations(S[1:])})
    for D in active_slots:
        for rot in range(4):
            key = D[rot:] + D[:rot]
            for t in L:
                if t in D: continue
                r = key + (t,); v = m.NewBoolVar(""); singles[r] = v
                terms[r].append(v); slot_terms[D].append(v)
    for D in active_slots: m.AddExactlyOne(slot_terms[D])
    m.Add(sum(v for v, _ in blocks.values()) == 52)
    x = {}
    for r, ts in terms.items():
        xv = m.NewBoolVar(""); m.Add(xv == sum(ts)); x[r] = xv
    # fixed rescued 6-cycle
    i = C6.index(f)
    for j in range(6):
        if j != i: m.Add(x[F.member_rule(C6, j)] == 1)
    z7 = {}
    for C in F.dcycles(7):
        rs = [F.member_rule(C, j) for j in range(7)]
        avail = [x[r] for r in rs if r in x]
        if len(avail) < 6: continue
        z = m.NewBoolVar(""); z7[C] = z
        if len(avail) == 6:
            for a in avail: m.AddImplication(z, a)
        else:
            for a, b in itertools.combinations(avail, 2): m.AddBoolOr([a, b]).OnlyEnforceIf(z)
            m.Add(sum(avail) >= 6).OnlyEnforceIf(z)
    m.Add(sum(z7.values()) >= r7_min)
    return m, blocks, singles, z7

if __name__ == "__main__":
    out, per, sl, ns = sys.argv[1], float(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
    workers = int(sys.argv[5]) if len(sys.argv) > 5 else 2
    reps = sorted(cases().items())
    mine = [rc for k, rc in enumerate(reps) if k % ns == sl]
    print(json.dumps({"total_orbits": len(reps), "total_cases": sum(c for _, c in reps), "this_slice": len(mine)}), flush=True)
    results = []
    t00 = time.time()
    for (C6, f), cnt in mine:
        t0 = time.time()
        m, blocks, singles, z7 = build_case(C6, f)
        s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = per; s.parameters.num_workers = workers
        st = s.Solve(m)
        rec = {"six_cycle": list(C6), "failing": f, "orbit_size": cnt, "status": s.StatusName(st), "sec": round(time.time() - t0, 2)}
        if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            rules = sorted([r for (C, w), (v, rs) in blocks.items() if s.Value(v) for r in rs] + [r for r, v in singles.items() if s.Value(v)])
            rec["rules"] = [[r[0], list(r[1:4]), r[4]] for r in rules]
            rec["seven_cycles"] = [list(C) for C, v in z7.items() if s.Value(v)]
        results.append(rec)
        print(json.dumps({k: v for k, v in rec.items() if k != "rules"}), flush=True)
        json.dump({"results": results, "elapsed": round(time.time() - t00, 1)}, open(out, "w", encoding="utf-8"), indent=1)
        if rec["status"] in ("FEASIBLE", "OPTIMAL"):
            json.dump({"schema": "mixed-n8-v1", "rules": rec["rules"]}, open(out.replace(".json", "_FOUND.rules.json"), "w"), indent=1)
            break
