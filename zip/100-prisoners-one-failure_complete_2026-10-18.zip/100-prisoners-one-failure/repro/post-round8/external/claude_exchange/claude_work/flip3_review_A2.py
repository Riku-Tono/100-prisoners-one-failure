"""Re-check A for cases 2,3 with pairwise (at-most-one-missing) clauses for the extra 6-/8-cycles."""
import itertools, json
from ortools.sat.python import cp_model
import flip3_model as F, flip3_relax as X
res = []
for C6, f in [((1,4,2,5,7,6),7), ((1,4,2,7,5,6),5), ((1,4,2,5,6,7),6), ((1,4,5,6,2,7),5)]:
    m, blocks, singles, z7 = X.build_relax(C6, f)
    terms = {}
    for (C, w), (v, rs) in blocks.items():
        for r in rs: terms.setdefault(r, []).append(v)
    for r, v in singles.items(): terms.setdefault(r, []).append(v)
    x = {}
    for r, ts in terms.items():
        b = m.NewBoolVar(""); m.Add(b == sum(ts)); x[r] = b
    extra = []
    for k in (6, 8):
        for C in F.dcycles(k):
            if k == 6 and F.canon(C) == F.canon(C6): continue
            avail = [x[r] for r in (F.member_rule(C, j) for j in range(k)) if r in x]
            if len(avail) < k - 1: continue
            z = m.NewBoolVar("")
            if len(avail) == k - 1:
                for a in avail: m.AddImplication(z, a)
            else:
                for a, b in itertools.combinations(avail, 2): m.AddBoolOr([a, b]).OnlyEnforceIf(z)
            extra.append((k, z))
    m.Maximize(sum(z7.values()) + sum((2 if k == 6 else 1) * z for k, z in extra))
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = 60; s.parameters.num_workers = 2
    st = s.Solve(m)
    rec = {"case": [list(C6), f], "status": s.StatusName(st), "max_2(R6-1)+R7+R8": s.ObjectiveValue(), "bound": s.BestObjectiveBound()}
    res.append(rec); print(rec, flush=True)
json.dump(res, open("runs/review_checks_A2.json", "w"), indent=1)
