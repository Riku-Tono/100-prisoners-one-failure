"""Portable implementation checks for the general one-failure proof supplement.

Python 3 standard library only; no external files, solver, or construction search.
The all-m statements are proved in general-one-failure.en.md. The finite checks
here independently check implementation, the partial-map completion lemma, and
the exact incidence counts used in the final-box upper bound.
"""

import argparse
from collections import Counter, defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction
from itertools import combinations, permutations, product
import json
from math import comb, factorial
from pathlib import Path
import time


def major(word):
    return sum(j for j in range(1, len(word)) if word[j - 1] > word[j])


def cycles_of(placement):
    unseen = set(range(len(placement)))
    cycles = []
    while unseen:
        start = min(unseen)
        cycle, v = [], start
        while v in unseen:
            unseen.remove(v)
            cycle.append(v)
            v = placement[v]
        assert v == start
        cycles.append(tuple(cycle))
    return cycles


def complete_to_short_cycles(edges, n, m):
    """Decide completion by graph components, without enumerating completions."""
    if len(set(edges.values())) != len(edges):
        return False
    incident = defaultdict(set)
    for a, b in edges.items():
        incident[a].add(b)
        incident[b].add(a)
    remaining = set(range(n))
    while remaining:
        stack = [min(remaining)]
        component = set()
        while stack:
            v = stack.pop()
            if v in component:
                continue
            component.add(v)
            stack.extend(incident[v] - component)
        remaining -= component
        # A partial injection's connected components are directed paths or
        # directed cycles; an isolated vertex is a path of one vertex.
        if len(component) > m:
            return False
    return True


def check_completion_lemma(n):
    m = n // 2
    completable = set()
    for p in permutations(range(n)):
        if max(map(len, cycles_of(p))) <= m:
            for mask in range(1 << n):
                completable.add(tuple((a, p[a]) for a in range(n) if mask >> a & 1))
    checked = 0
    for k in range(n + 1):
        for domain in combinations(range(n), k):
            for images in permutations(range(n), k):
                edges = tuple(zip(domain, images))
                assert complete_to_short_cycles(dict(edges), n, m) == (edges in completable)
                checked += 1
    return {"n": n, "partial_injections": checked, "CF_completable": len(completable)}


def word_classes(m):
    labels = 2 * m - 1
    classes = defaultdict(list)
    for word in permutations(range(labels), m):
        classes[(sum(word) % labels, major(word) % m)].append(word)
    assert len(classes) == labels * m
    assert {len(words) for words in classes.values()} == {factorial(2 * m - 2) // factorial(m)}
    for words in classes.values():
        deletion_owner = {}
        for word in words:
            for j in range(m):
                deleted = word[:j] + word[j + 1:]
                assert deleted not in deletion_owner or deletion_owner[deleted] == word
                deletion_owner[deleted] = word
    return classes


def rules_from_cycles(selected_cycles, m):
    rules = {}
    for cycle in selected_cycles:
        # Omit the anchor's successor; every loss support retains the anchor.
        for j, prisoner in enumerate(cycle):
            if j == 1:
                continue
            history = tuple(cycle[(j + step) % (m + 1)] for step in range(m))
            target = cycle[(j - 1) % (m + 1)]
            assert history not in rules
            rules[history] = target
    return rules


def decode_zero_class(history, m):
    anchor, labels = 2 * m - 1, 2 * m - 1
    if anchor not in history:
        return history[-1]
    start = history.index(anchor)
    cyclic = history[start:] + history[:start]
    shorter = cyclic[1:]
    missing = (-sum(shorter)) % labels
    if missing in shorter:
        return history[-1]
    candidates = []
    for position in range(m):
        word = shorter[:position] + (missing,) + shorter[position:]
        if major(word) % m == 0:
            candidates.append(word)
    assert len(candidates) <= 1
    if not candidates:
        return history[-1]
    cycle = (anchor,) + candidates[0]
    after_missing = cycle[(cycle.index(missing) + 1) % (m + 1)]
    return missing if after_missing == history[0] else history[-1]


def successes_by_opening(p, m, rules):
    """Physically open boxes, stop on success; independent of cycle formulas."""
    successes = []
    for prisoner in range(len(p)):
        box, history, opened = prisoner, [prisoner], set()
        for step in range(m):
            if step == m - 1:
                box = rules.get(tuple(history), box)
            assert box not in opened
            opened.add(box)
            seen = p[box]
            if seen == prisoner:
                successes.append(prisoner)
                break
            history.append(seen)
            box = seen
    return successes


def simulate(m, rules):
    n = 2 * m
    cf_wins = wins = lost = 0
    individual_successes = Counter()
    failure_histogram = Counter()
    long_incidences = Counter()
    for p in permutations(range(n)):
        cycles = cycles_of(p)
        old = max(map(len, cycles)) <= m
        found = successes_by_opening(p, m, rules)
        individual_successes.update(found)
        failure_histogram[n - len(found)] += 1
        new = len(found) >= n - 1
        cf_wins += old
        wins += new
        lost += old and not new
        for cycle in cycles:
            if len(cycle) > m:
                k = len(cycle)
                for j in range(k):
                    history = tuple(cycle[(j + step) % k] for step in range(m))
                    target = cycle[(j - 1) % k]
                    long_incidences[(history, target, k)] += 1
                if k == n:
                    # Opposite windows have complementary supports, which a
                    # preserving rule table cannot activate simultaneously.
                    assert len(found) <= m
    assert lost == 0
    assert set(individual_successes.values()) == {factorial(n) // 2}
    assert len(individual_successes) == n
    # Every possible proper exception occurs exactly (m-1)! times at each k.
    expected_keys = factorial(n) // factorial(n - m) * (n - m) * m
    assert len(long_incidences) == expected_keys
    assert set(long_incidences.values()) == {factorial(m - 1)}
    return {"n": n, "placements": factorial(n), "CF_wins": cf_wins,
            "modified_wins": wins, "lost_CF_wins": lost,
            "individual_success_count": factorial(n) // 2,
            "failure_histogram": dict(sorted(failure_histogram.items())),
            "incidence_keys_checked": len(long_incidences),
            "each_fixed_rule_length_incidence_count": factorial(m - 1)}


def check_binary_vt():
    cases = 0
    for length in range(1, 11):
        owners = {}
        for bits in product((0, 1), repeat=length):
            syndrome = sum(j * b for j, b in enumerate(bits, 1)) % (length + 1)
            for position in range(length):
                key = (syndrome, bits[:position] + bits[position + 1:])
                assert key not in owners or owners[key] == bits
                owners[key] = bits
                cases += 1
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("general_audit.json"))
    args = parser.parse_args()
    started = time.monotonic()
    completion = [check_completion_lemma(n) for n in (4, 6)]
    checksum, direct = [], []
    for m in range(2, 6):
        classes = word_classes(m)
        checksum.append({"m": m, "classes": len(classes),
                         "words_per_class": len(classes[(0, 0)]), "deletion_collisions": 0})
        if m <= 4:
            anchor = 2 * m - 1
            cycles = [(anchor,) + word for word in classes[(0, 0)]]
            rules = rules_from_cycles(cycles, m)
            for history in permutations(range(2 * m), m):
                assert rules.get(history, history[-1]) == decode_zero_class(history, m)
            result = simulate(m, rules)
            assert result["modified_wins"] - result["CF_wins"] == len(cycles) * factorial(m - 1)
            result["strategy"] = "fixed_checksum_class_0_0"
            direct.append(result)
            single = simulate(m, rules_from_cycles([tuple(range(m + 1))], m))
            assert single["modified_wins"] - single["CF_wins"] == factorial(m - 1)
            single["strategy"] = "one_fixed_cycle_block"
            direct.append(single)
    m = 50
    cf = 1 - sum((Fraction(1, k) for k in range(m + 1, 2 * m + 1)), Fraction())
    lower = Fraction(1, 2 * m * m * (2 * m - 1))
    shortest_upper = Fraction(1, 2 * m ** 3)
    upper = sum((Fraction(1, k) for k in range(m, 2 * m - 1)), Fraction()) / (2 * m * m)
    numerics = {}
    with localcontext() as ctx:
        ctx.prec = 60
        for name, value in (("CF", cf), ("checksum_gain", lower),
                            ("checksum_total", cf + lower),
                            ("all_long_cycle_gain_upper", upper),
                            ("restricted_total_upper", cf + upper),
                            ("m_plus_1_cycle_contribution_upper", shortest_upper),
                            ("general_expectation_upper", Fraction(m, 2 * m - 1))):
            decimal = Decimal(value.numerator) / Decimal(value.denominator)
            numerics[name] = {"fraction": str(value), "probability": str(decimal),
                              "percent_or_percentage_points": str(decimal * 100)}
    out = {"status": "PASS", "date": "2026-10-18",
           "scope": "Implementation checks of supplied constructions and proof lemmas; no optimizer or solver.",
           "finite_checks_do_not_replace_general_proofs": True,
           "completion_lemma": completion, "checksum_classes": checksum,
           "binary_VT_deletion_cases": check_binary_vt(), "direct_simulations": direct,
           "n100_exact_arithmetic": numerics, "seconds": round(time.monotonic() - started, 3)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": out["status"], "output": str(args.output),
                      "direct_simulations": [{k: r[k] for k in ("n", "strategy", "modified_wins", "lost_CF_wins")} for r in direct],
                      "seconds": out["seconds"]}, indent=2))


if __name__ == "__main__":
    main()
