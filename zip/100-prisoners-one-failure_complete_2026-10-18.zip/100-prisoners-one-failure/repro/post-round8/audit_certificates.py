"""Direct n=8 all-placement audit, independent of submitted generators/solvers."""
import argparse
from collections import Counter
import hashlib
from itertools import permutations
import json
from pathlib import Path
import time

def canon(c):
    c=tuple(c)
    return min(c[j:]+c[:j] for j in range(len(c)))

def read_rules(path):
    doc=json.loads(path.read_text(encoding="utf-8-sig"))
    rules={}
    words={}
    supports=set()
    for player,history,target in doc["rules"]:
        history=tuple(history)
        assert len(history)==3
        h=(player,)+history
        assert len(set(h))==4 and target not in h and set(h+(target,))<=set(range(1,9))
        key=(player,history)
        assert key not in rules
        rules[key]=target
        w=canon(h)
        assert w not in words
        words[w]=(player,history,target)
        supports.add(frozenset(h))
    assert all(frozenset(range(1,9))-s not in supports for s in supports)
    return rules

def audit(path):
    began=time.monotonic()
    rules=read_rules(path)
    histogram=Counter()
    long_success=Counter()
    rescued={k:set() for k in range(5,9)}
    lost=0
    wins=0
    individual=[0]*8
    cf_wins=0
    six_example=None
    for p in permutations(range(1,9)):
        unseen=set(range(1,9))
        cycles=[]
        while unseen:
            a=min(unseen);c=[];x=a
            while x not in c:
                c.append(x);unseen.remove(x);x=p[x-1]
            assert x==a
            cycles.append(tuple(c))
        old=all(len(c)<=4 for c in cycles)
        cf_wins+=old
        successes=[]
        for player in range(1,9):
            history=[];box=player
            for opening in range(4):
                if opening==3:
                    box=rules.get((player,tuple(history)),box)
                value=p[box-1]
                history.append(value)
                if value==player:
                    successes.append(player);individual[player-1]+=1;break
                box=value
        n=len(successes);histogram[n]+=1
        won=n>=7;wins+=won
        lost+=old and not won
        if won and not old:
            long=next(c for c in cycles if len(c)>4)
            rescued[len(long)].add(canon(long))
            correct=sum(a in successes for a in long)
            long_success[(len(long),correct)]+=1
            if len(long)==7 and correct==6 and six_example is None:
                six_example=dict(permutation=p,cycle=canon(long),successful_prisoners=successes)
    counts={str(k):len(v) for k,v in rescued.items()}
    assert cf_wins==14736 and sum(histogram.values())==40320
    assert lost==0 and counts["8"]==0
    assert wins==14736+6*counts["5"]+2*counts["6"]+counts["7"]
    assert individual==[20160]*8
    return dict(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),rules=len(rules),
                permutations=40320,wins=wins,CF_wins=cf_wins,CF_old_wins_lost=lost,
                rescued_cycles=counts,success_histogram=dict(sorted(histogram.items())),
                individual_successes=individual,
                long_cycle_success_histogram={f"{k}/{n}":v for (k,n),v in sorted(long_success.items())},
                six_of_seven_example=six_example,seconds=round(time.monotonic()-began,3))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--work",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    args=p.parse_args()
    specs=[
      ("inputs/baseline15051.rules.json",15051,(52,0,3),208),
      ("inputs/neutral15051.rules.json",15051,(52,0,3),210),
      ("inputs/new15051.rules.json",15051,(52,1,1),210),
      ("chatgpt_15050_received.rules.json",15050,(52,0,2),208),
      ("fullstar_six_witness_pure_completion_20261018_found_1.rules.json",15050,(52,0,2),208)]
    results=[]
    for relative,wins,counts,number in specs:
        r=audit(args.work/relative)
        assert r["wins"]==wins and r["rules"]==number,(relative,r)
        assert tuple(r["rescued_cycles"][str(k)] for k in (5,6,7))==counts
        r["relative_source"]=relative
        results.append(r)
        print(relative,r["wins"],r["rescued_cycles"],flush=True)
    assert results[-1]["six_of_seven_example"] is not None
    out=dict(status="PASS",method=__doc__,certificates=results,total_permutation_runs=40320*len(results),
             total_win_optimality_proved=False)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
if __name__=="__main__":
    main()

