"""Independently recheck the all-[7] two-extra marginal rule lemma.

All 2520 four-rule blocks on seven labels are generated from permutations.
One extra r can be normalized to (1,2,3,4,5); exactly two directed seven
cycles have r as a correct rule. Test all useful second extras s and all
omitted windows. Only a local compatible block packing is required, making
the check a relaxation of any completed table. No completion solver/import.
"""
from collections import defaultdict, Counter
from itertools import combinations, permutations
from pathlib import Path
import json
import time


def rules(c):
    return frozenset((c[i],c[(i+1)%len(c)],c[(i+2)%len(c)],c[(i+3)%len(c)],c[(i-1)%len(c)])
                     for i in range(len(c)))


def word(r):
    t = r[:4]
    return min(t[k:]+t[:k] for k in range(4))


def main():
    start = time.monotonic()
    blocks = sorted({tuple(sorted(rules(c)-{omit}))
                     for labels in combinations(range(1,8),5)
                     for p in permutations(labels[1:])
                     for c in [(labels[0],)+p]
                     for omit in rules(c)})
    assert len(blocks) == 2520
    slots = [frozenset(word(r) for r in b) for b in blocks]
    incidence = defaultdict(list)
    for i,b in enumerate(blocks):
        for r in b:
            incidence[r].append(i)
    first = (1,2,3,4,5)
    cycles = [c for p in permutations(range(2,8)) for c in [(1,)+p] if first in rules(c)]
    assert len(cycles) == 2
    rule_sets = list(map(rules,cycles))
    extras = sorted(set.union(*map(set,rule_sets))-{first})
    assert len(extras) == 12
    cases = []
    total_nodes = 0

    def feasible(required, forbidden):
        nonlocal total_nodes
        candidates = {r:[b for b in incidence[r] if not slots[b]&forbidden] for r in required}
        def search(left,used):
            nonlocal total_nodes
            total_nodes += 1
            if not left:
                return True
            options = [(len(legal),r,legal) for r in left
                       for legal in [[b for b in candidates[r] if not slots[b]&used]]]
            n,r,legal = min(options)
            if not n:
                return False
            for b in legal:
                if search(left-set(blocks[b]),used|slots[b]):
                    return True
            return False
        return search(set(required),frozenset())

    controls = []
    for rs in rule_sets:
        possible = sum(feasible(rs-{first,omit},{word(first)}) for omit in rs-{first})
        assert possible > 0
        controls.append(possible)
    nodes_controls = total_nodes
    for second in extras:
        forbidden = {word(first),word(second)}
        assert len(forbidden) == 2
        tests = 0
        found = 0
        for omit_a in rule_sets[0]-{first}:
            for omit_b in rule_sets[1]-{first}:
                required = (rule_sets[0]-{first,omit_a,second}) | (rule_sets[1]-{first,omit_b,second})
                tests += 1
                found += feasible(required,forbidden)
        assert not found
        cases.append(dict(second_rule=second,omission_pairs=tests,feasible_local_packings=found))
    out = dict(status='PASS',method=__doc__,blocks=len(blocks),first_rule=first,
               cycles=cycles,second_rules=len(extras),omission_pairs=sum(x['omission_pairs'] for x in cases),
               feasible_joint_packings=0,positive_single_cycle_controls=controls,
               nodes=total_nodes,nodes_positive_controls=nodes_controls,cases=cases,
               seconds=time.monotonic()-start)
    Path('unrestricted_two_extra_audit.json').write_text(json.dumps(out,indent=2))
    print({k:v for k,v in out.items() if k not in ('method','cases')})


if __name__ == '__main__':
    main()
