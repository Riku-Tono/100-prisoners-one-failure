﻿# 第8ラウンド差分パッケージ / Round 8 incremental package

作成日：2026-10-13。対象は `100-prisoners-one-failure_round7_2026-10-12.zip` の展開内容。

## 適用方法

1. 元のRound 7 ZIPを展開する。
2. 差分ZIPを同じ場所へ展開し、同名の `100-prisoners-one-failure` フォルダーを統合して上書きする。差分ZIPだけでは第7ラウンド以前のコードはそろわない。
3. `100-prisoners-one-failure` フォルダー内で、次を実行する。

```powershell
python -X utf8 repro/check_integrity.py
python -X utf8 repro/run_round8_verification.py
```

元ZIPと差分ZIPは同じ最上位フォルダー名を使う。GitHubへ反映するときは、そのフォルダーの中身をリポジトリのルートへ上書き・追加する。削除が必要なファイルはない。今回のZIPには元ZIPと同一のファイルを再収録しない。

## 更新内容

- 更新済みの英語・日本語READMEと再現案内。ログの相対リンクも修正。
- 第8ラウンドの4構成の原本ZIP、JSON、CSVと独立検算器。
- Astraの局所解析・位数5対称性のコード、入力、保存結果、探索ログ。`repro/round8/astra/` に元の63ファイル用ハッシュ一覧を含め、原本のバイト列を保存。
- Codexの独立監査コードと過去の記録を `repro/round8/codex/` に保存。
- 8検査の一括実行器と今回の結果を `verification/round8/` に追加。
- 更新されたlog12、新規log13・log14。元ZIPにはハッシュ一覧に載ったlog1〜log12の12本が実際には収録されていなかったため、その欠落も補完。
- 統合後の一覧 `docs/package-manifest.json` とハッシュ `SHA256SUMS.txt`、差分だけの一覧 `docs/update-manifest.json`。

## 8検査と主な結果

| 検査 | 対象・結果 |
| --- | --- |
| Claudeの4構成 | 各40,320配置、15,049 / 15,050 / 15,050 / 15,051勝、CF喪失0、ZIP内ハッシュと規則・CSVの一致 |
| Astraの証明書と原本ハッシュ | 位数5構成15,048勝と既知15,050・15,051勝、CF喪失0、63ファイル照合。一般探索6実行の保存済みUNKNOWN記録も照合 |
| 6巡回局所表 | 255,879表を再列挙し、局所上限・一意性を確認 |
| 部分スター分類 | 279,936割当から6窓型28種と7窓型1種 |
| 7巡回候補 | 全候補936、片側468、片側証人7,638、保存結果との一致 |
| 両立グラフとクリーク | 競合60,481組、11クリークを確認、12クリークの不存在を完全探索 |
| 位数5対称性の全枝 | 基本384枝＋7巡回6,048枝、UNKNOWN 0 |
| 位数5の枝別照合 | 6,432枝の終了状態が保存結果と一致 |

今回の結果は [current_checks.json](../verification/round8/current_checks.json) と同フォルダーのログ・JSONに保存。過去の独立監査レポートとJSONは原本のまま別に保存する。監査スクリプト内に固定された2026-10-12の日付は元コードの記録日であり、今回の実行日は新しい記録JSONを参照する。

`run_round8_verification.py` は自分の位置からリポジトリを探し、必要な入力パスを明示するため、展開先を移しても実行できる。自分の隣へ結果を書く旧スクリプトは一時コピーで実行し、原本を上書きしない。Python 3.10以上の標準ライブラリだけで8検査を実行できる。

第7ラウンドの `repro/run_verification.py` と過去の13検査記録はそのまま利用可能で、今回の8検査とは別。一般CP-SAT探索は今回再実行していない。15,051は達成値であり、総勝数の最適性は未証明。最大クリーク11は局所的な必要条件の緩和についての値であり、11巡回救済戦略の存在を意味しない。

## 任意の探索

Astraの一般探索を再実行する場合のみ、`repro/round8/astra/requirements.txt` に記載された `ortools==9.15.6755` が必要。保存ログ内の絶対パスは当時の記録として残している。再実行例は、同フォルダーを作業場所として次のようにヒントを相対指定する。

```powershell
python -X utf8 search_mixed.py --mode six --k7 2 --seconds 120 --workers 4 --hint search/six_calibration.rules.json --local-patterns local_coexistence/local_patterns.json --pair-compatibility local_coexistence/pair_compatibility.json --same-seven-set --out search/repeat_six.json
python -X utf8 search_mixed.py --mode seven --k7 4 --budget 210 --supports free --seconds 60 --workers 2 --hint search/seven_calibration.rules.json --out search/repeat_free210.json
```

これらの探索は任意で、8検査には含まれない。時間制限・スレッドスケジュールにより保存結果と同じ探索経路・終了状態になるとは限らない。

## Integrity and applying the overlay

Extract the supplied Round 7 ZIP first. Extract this update into the same parent directory and merge/overwrite the identically named `100-prisoners-one-failure` folder. The update contains additions and changed files only; no deletion is required. Run the two commands above from the merged repository root. `check_integrity.py` verifies the entire merged release, while the eight Round 8 checks use only Python's standard library. The historical 13-task Round 7 record remains separate. General CP-SAT searches are not rerun; optimal total winning probability remains open.

Run the integrity check before other verifiers. Fresh verification outputs contain timings and may differ from the distributed hashes after rerunning. Preserve the distributed ZIPs as the original release records.
