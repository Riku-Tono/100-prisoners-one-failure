"""Independent finite audit of the seven-cycle block lemma.

No supplied Round 8 modules are imported.  A rule is encoded directly from
the box experiment as (target, prisoner, first observation, second, third).
The only standard-library dependencies are itertools, collections and json.
"""
from itertools import product, combinations
from collections import Counter
from pathlib import Path
import json

OUT = Path(__file__).resolve().parent
C = tuple(range(1, 8))

def rotate_min(sequence):
    pos = sequence.index(min(sequence))
    return sequence[pos:] + sequence[:pos]

def rule_for_prisoner(cycle, prisoner):
    pos = cycle.index(prisoner)
    # First three boxes follow the cycle; the fourth target is predecessor.
    return tuple(cycle[(pos + d) % len(cycle)] for d in (-1, 0, 1, 2, 3))

def rule_at_target(cycle, target):
    return rule_for_prisoner(cycle, cycle[(cycle.index(target) + 1) % len(cycle)])

def word(rule):
    return rotate_min(rule[1:])

WINDOWS = tuple(rule_for_prisoner(C, p) for p in C)
WINDOW_ID = {r: i for i, r in enumerate(WINDOWS)}
Qs = tuple(tuple(p for p in C if p not in {C[i], C[(i + 1) % 7]}) for i in range(7))

# Each Q has no block, or a four-rule block omitting one possible target.
OPTIONS = []
for Q in Qs:
    options = [(None, {}, 0)]
    for omitted_target in Q:
        rules = [rule_at_target(Q, t) for t in Q if t != omitted_target]
        byword = {word(r): r for r in rules}
        assert len(byword) == 4
        mask = sum(1 << WINDOW_ID[r] for r in rules if r in WINDOW_ID)
        options.append((omitted_target, byword, mask))
    OPTIONS.append(options)

# Derive full/partial patterns geometrically, independently of source code.
# A full star omits predecessor of the two removed vertices in each block.
full_assignment = tuple(1 + Qs[x].index(C[(x - 1) % 7]) for x in range(7))
expected = {full_assignment: ('full', None, None)}
for missing_prisoner in C:
    missing_rule = WINDOWS[C.index(missing_prisoner)]
    missing_Q = rotate_min(missing_rule)
    m = Qs.index(missing_Q)
    # All other windows determine their blocks.  The next Q may omit any
    # target except the target of its own still-required window.
    next_x = (m + 1) % 7
    for omit in Qs[next_x]:
        if omit == C[(m + 3) % 7]:
            continue
        a = list(full_assignment)
        a[m] = 0
        a[next_x] = 1 + Qs[next_x].index(omit)
        expected[tuple(a)] = ('partial', m, omit)
assert len(expected) == 29

hist = Counter()
rescuing = {}
valid = 0
extra_counterexample = None
for choices in product(range(6), repeat=7):
    mapping = {}
    mask = 0
    good = True
    for x, opt in enumerate(choices):
        _, rules, covered = OPTIONS[x][opt]
        for d, r in rules.items():
            if d in mapping and mapping[d] != r:
                good = False
                break
            mapping[d] = r
        if not good:
            break
        mask |= covered
    if not good:
        continue
    valid += 1
    count = mask.bit_count()
    hist[count] += 1
    if count >= 6:
        rescuing[choices] = mask
    # Show why a pure generalized-star constraint cannot replace K2 when
    # independent non-block rules are permitted: use >= 4 block windows
    # and at most two additional windows, while no six-block variant occurs.
    if extra_counterexample is None and count in (4, 5):
        if any(all(opt == choices[x] for x, opt in enumerate(e) if opt) for e in expected):
            continue
        remaining = [r for i, r in enumerate(WINDOWS) if not (mask >> i) & 1]
        for appended in combinations(remaining, 6 - count):
            if all(word(r) not in mapping or mapping[word(r)] == r for r in appended):
                extra_counterexample = {
                    'blocks': [{'cycle': Qs[x], 'omitted_target': OPTIONS[x][opt][0]}
                               for x, opt in enumerate(choices) if opt],
                    'block_derived_windows': count,
                    'extra_rules': appended,
                    'total_rules': len(mapping) + len(appended),
                    'correct_windows': 6,
                    'contains_generalized_star': False,
                    'scope': 'local witness only; not an R5=52 completion',
                }
                break

actual_set = set(rescuing)
expected_set = set(expected)
assert actual_set == expected_set, (actual_set - expected_set, expected_set - actual_set)
assert hist[6] == 28 and hist[7] == 1

# Independently check the L3 loss-word deletion classification.
full_words = {}
for x, opt in enumerate(full_assignment):
    for d, r in OPTIONS[x][opt][1].items():
        assert d not in full_words
        full_words[d] = r
deletion_types = Counter()
for d in full_words:
    removed = set(C) - set(d)
    adj = sum(C[i] in removed and C[(i + 1) % 7] in removed for i in range(7))
    deletion_types[adj] += 1
assert len(full_words) == 28
assert deletion_types == Counter({1: 21, 2: 7})

# Verify precise L4 indexing for each x.  Tau[x-1] is the existing window
# with target c[x+1].  Q[x]'s rule having target c[x-1] has its loss word.
index_checks = []
for x in range(7):
    prior_Q = Qs[(x - 1) % 7]
    tau_previous = rule_at_target(prior_Q, C[(x + 1) % 7])
    conflicting_rule = rule_at_target(Qs[x], C[(x - 1) % 7])
    assert word(tau_previous) == word(conflicting_rule)
    assert tau_previous[0] != conflicting_rule[0]
    index_checks.append({
        'x_zero_based': x,
        'tau_x_minus_1': tau_previous,
        'conflicting_rule': conflicting_rule,
        'forced_omitted_target': C[(x - 1) % 7],
    })

result = {
    'assignments_examined': 6 ** 7,
    'consistent_assignments': valid,
    'correct_window_histogram': dict(sorted(hist.items())),
    'rescuing_patterns': len(rescuing),
    'six_window_patterns': hist[6],
    'seven_window_patterns': hist[7],
    'missing_expected_patterns': len(expected_set - actual_set),
    'unclassified_patterns': len(actual_set - expected_set),
    'L3_full_star_distinct_loss_words': len(full_words),
    'L3_removed_triples_by_number_of_circle_adjacent_pairs': dict(deletion_types),
    'L4_index_checks': index_checks,
    'local_extra_rule_example': extra_counterexample,
    'note': 'The histogram concerns the seven incident five-cycles only. '
            'Any external block family restricts possibilities but cannot add a window of this C.',
}
(OUT / 'results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k not in ('L4_index_checks', 'local_extra_rule_example')}, indent=2))
