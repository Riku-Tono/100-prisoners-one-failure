"""Independent solver-free finite audit of Round 8 L5 and L6.

Uses only Python's standard library.  No supplied module is imported.
Local states enumerate all 0/1 rule tables on the 30 rules belonging to
the six cyclic deletions of C=(1,...,6), subject only to one rule per
directed loss word and the prescribed correct-window pattern.
"""
from collections import Counter, defaultdict
from itertools import combinations, permutations, product
from pathlib import Path
import argparse
import json


def rotation_key(labels):
    labels = tuple(labels)
    return min(labels[j:] + labels[:j] for j in range(len(labels)))


def correct_paths(cycle):
    # (target box, prisoner, first result, second result, third result)
    size = len(cycle)
    return tuple(tuple(cycle[(j + d) % size] for d in (-1, 0, 1, 2, 3))
                 for j in range(size))


def describe_state(state, rules, q_rules, windows):
    selected = {r for j, r in enumerate(rules) if state & (1 << j)}
    rescued = {q for q, rr in q_rules.items() if len(selected.intersection(rr)) >= 4}
    used = set().union(*(selected.intersection(q_rules[q]) for q in rescued)) if rescued else set()
    blocks = []
    for q in sorted(rescued):
        missing = [r[0] for r in q_rules[q] if r not in selected]
        blocks.append({"cycle": list(q), "skipped_target": missing[0] if missing else None,
                       "correct_rules": 5 - len(missing)})
    return {"rescued_5_blocks": blocks, "other_rules": [list(r) for r in sorted(selected - used)],
            "external_correct_6_windows": [list(r) for r in windows if r in selected - used],
            "total_local_rules": len(selected)}


def enumerate_local(missing_owner):
    cycle = tuple(range(1, 7))
    windows = correct_paths(cycle)
    q_rules = {rotation_key(tuple(c for c in cycle if c != removed)):
               correct_paths(rotation_key(tuple(c for c in cycle if c != removed)))
               for removed in cycle}
    rules = sorted(set().union(*map(set, q_rules.values())))
    assert len(rules) == 30
    bits = {r: 1 << i for i, r in enumerate(rules)}
    groups = defaultdict(list)
    for r in rules:
        groups[rotation_key(r[1:])].append(r)
    assert len(groups) == 15 and all(len(rr) == 2 for rr in groups.values())
    required = {r for r in windows if r[1] != missing_owner}
    forbidden = {r for r in windows if r[1] == missing_owner}
    base = 0
    options = []
    for _, rr in sorted(groups.items()):
        fixed = required.intersection(rr)
        if fixed:
            assert len(fixed) == 1
            base |= bits[next(iter(fixed))]
        else:
            options.append([0] + [bits[r] for r in rr if r not in forbidden])
    block_masks = {q: sum(bits[r] for r in rr) for q, rr in q_rules.items()}
    relevant = [(rotation_key(r), bits[r]) for r in windows if r in required]
    histogram = Counter()
    best = -1
    tight_states = []
    count = 0
    for picks in product(*options):
        # Loss groups have disjoint rule indices, so sum is bitwise union.
        state = base + sum(picks)
        rescued = {q for q, mask in block_masks.items() if (state & mask).bit_count() >= 4}
        a = sum(1 for q, rule_bit in relevant if q in rescued and state & rule_bit)
        histogram[a] += 1
        count += 1
        if a > best:
            best = a
            tight_states = [state]
        elif a == best:
            tight_states.append(state)
    return {"missing_prisoner": missing_owner, "enumerated_rule_tables": count,
            "max_block_derived_correct_windows": best,
            "histogram_by_block_derived_windows": dict(sorted(histogram.items())),
            "number_of_tight_full_local_tables": len(tight_states),
            "tight_full_local_tables": [describe_state(s, rules, q_rules, windows) for s in tight_states]}


def independent_certificate(path):
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    rows = [(b, a, *history) for a, history, b in data["rules"]]
    selected = set(rows)
    assert len(rows) == len(selected) == 210
    assert all(len(r) == len(set(r)) == 5 and all(1 <= x <= 8 for x in r) for r in rows)
    words = [rotation_key(r[1:]) for r in rows]
    assert len(set(words)) == len(words)
    supports = {frozenset(r[1:]) for r in rows}
    universe = frozenset(range(1, 9))
    assert all(universe - support not in supports for support in supports)
    rescued = {}
    used = set()
    for size in (5, 6):
        rescued[size] = []
        for subset in combinations(range(1, 9), size):
            for tail in permutations(subset[1:]):
                cycle = (subset[0], *tail)
                paths = correct_paths(cycle)
                present = [r for r in paths if r in selected]
                if len(present) >= size - 1:
                    rescued[size].append({"cycle": list(cycle), "correct_windows": len(present),
                                           "missing_prisoners": [r[1] for r in paths if r not in selected]})
                    if size == 5:
                        used.update(present)
    assert len(rescued[5]) == 52 and len(rescued[6]) == 1
    outside = selected - used
    assert len(used) == 208 and len(outside) == 2
    assert outside == {(5, 6, 1, 2, 3), (6, 1, 2, 3, 4)}
    return {"certificate": str(path.resolve()), "rules": len(rows), "distinct_loss_words": len(set(words)),
            "supports": len(supports), "complementary_support_collisions": 0,
            "rescued_5_cycles": len(rescued[5]), "rules_in_rescued_5_blocks": len(used),
            "rules_outside_rescued_5_blocks": [list(r) for r in sorted(outside)],
            "rescued_6_cycles": rescued[6]}


def shared_six_cycles(pair):
    pair = set(pair)
    result = []
    for subset in combinations(range(1, 9), 6):
        for tail in permutations(subset[1:]):
            cycle = (subset[0], *tail)
            if pair.issubset(correct_paths(cycle)):
                result.append(list(cycle))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()
    local = [enumerate_local(None)] + [enumerate_local(p) for p in range(1, 7)]
    assert local[0]["max_block_derived_correct_windows"] == 2
    for entry in local[1:]:
        assert entry["max_block_derived_correct_windows"] == 3
        unique_block_configs = {json.dumps(s["rescued_5_blocks"], sort_keys=True)
                                for s in entry["tight_full_local_tables"]}
        entry["number_of_tight_rescued_block_configurations"] = len(unique_block_configs)
        assert len(unique_block_configs) == 1
        min_tables = [s for s in entry["tight_full_local_tables"] if len(s["other_rules"]) == 2]
        assert len(min_tables) == 1
        for state in entry["tight_full_local_tables"]:
            pair = state["external_correct_6_windows"]
            assert len(pair) == 2
            containing = shared_six_cycles(map(tuple, pair))
            assert containing == [[1, 2, 3, 4, 5, 6]]
        entry["6_cycles_containing_both_external_rules_n8"] = containing
    certificate = independent_certificate(args.certificate)
    result = {"method": "solver-free exhaustive enumeration; Python standard library only",
              "local_assumptions": ["fixed directed 6-cycle", "at most one rule per directed loss word"],
              "total_enumerated_local_rule_tables": sum(x["enumerated_rule_tables"] for x in local),
              "local_cases": local, "certificate": certificate}
    destination = Path(__file__).with_name("six_cycle_results.json")
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"result": str(destination.resolve()),
                      "enumerated_local_rule_tables": result["total_enumerated_local_rule_tables"],
                      "local_maxima": [(x["missing_prisoner"], x["max_block_derived_correct_windows"],
                                        x["number_of_tight_full_local_tables"]) for x in local],
                      "certificate": certificate}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
