"""Independent Round 8 certificate audit; Python 3 standard library only.

Usage:
  python -X utf8 audit_round8_independent.py ROUND8.zip --output audit.json
  Optional: --round7-zip ROUND7.zip --standalone JSON [JSON ...]

Reads data from archives without executing any supplied script. Directly opens
boxes for every prisoner in every placement, and separately derives cycle
certificates from the final-box rule tables. It does not prove optimality or
rerun CP-SAT searches. Labels are 1 through 8 throughout.
"""

import argparse
import csv
import hashlib
import io
import itertools
import json
import math
import re
import zipfile
from collections import Counter
from pathlib import Path

LABELS = tuple(range(1, 9))
UNIVERSE = frozenset(LABELS)
CERTIFICATES = {
    "best15049_star7_n8.json": (15049, (52, 0, 1, 0), "star7_52.json", "best15049_blocks.csv"),
    "best15050_two_stars_n8.json": (15050, (52, 0, 2, 0), "pair_star_x0_0.json", "best15050_two_stars_blocks.csv"),
    "best15050_six_cycle_n8.json": (15050, (52, 1, 0, 0), "six52_free.json", "best15050_six_blocks.csv"),
    "best15051_three_stars_n8.json": (15051, (52, 0, 3, 0), "clique3_x0_0.json", "best15051_blocks.csv"),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(cycle):
    c = tuple(cycle)
    position = c.index(min(c))
    return c[position:] + c[:position]


def rules_from_json(document):
    assert document["n"] == 8 and document["max_boxes"] == 4
    assert document["required_successes"] == 7
    rules, by_history = set(), {}
    for prisoner, history, target in document["rules"]:
        assert len(history) == 3
        path = (target, prisoner, *history)
        assert len(set(path)) == 5 and set(path) <= UNIVERSE
        key = (prisoner, tuple(history))
        assert key not in by_history, ("duplicate observed history", key)
        assert path not in rules
        rules.add(path)
        by_history[key] = target
    if "rules_count" in document:
        assert document["rules_count"] == len(rules)
    return rules, by_history


def all_directed_cycles(length):
    for support in itertools.combinations(LABELS, length):
        for tail in itertools.permutations(support[1:]):
            yield (support[0], *tail)


def windows(cycle):
    length = len(cycle)
    return [tuple(cycle[(j + delta) % length] for delta in (-1, 0, 1, 2, 3))
            for j in range(length)]


def structural_audit(document):
    rules, _ = rules_from_json(document)
    loss_words = [canonical(path[1:]) for path in rules]
    assert len(set(loss_words)) == len(rules), "multiple rules harm the same directed 4-cycle"
    supports = {frozenset(word) for word in loss_words}
    assert not any(UNIVERSE - support in supports for support in supports)
    counts, rescued, blocks, block_rules = {}, {}, [], set()
    for length in range(5, 9):
        rescued[length] = []
        for cycle in all_directed_cycles(length):
            paths = windows(cycle)
            correct = [path in rules for path in paths]
            if sum(correct) < length - 1:
                continue
            rescued[length].append({
                "cycle": list(cycle), "correct_windows": sum(correct),
                "missing_prisoners": [cycle[j] for j, ok in enumerate(correct) if not ok],
            })
            if length == 5:
                missing = [j for j, ok in enumerate(correct) if not ok]
                assert len(missing) == 1, "this submitted certificate should consist of four-rule 5-cycle blocks"
                j = missing[0]
                blocks.append((canonical(cycle), cycle[(j - 1) % 5]))
                for path, ok in zip(paths, correct):
                    if ok:
                        assert path not in block_rules, "a rule belongs to only one directed 5-cycle"
                        block_rules.add(path)
        counts[str(length)] = len(rescued[length])
    supplied_blocks = [(canonical(cycle), skip) for cycle, skip in document["blocks"]]
    assert len(supplied_blocks) == len(set(supplied_blocks))
    assert set(supplied_blocks) == set(blocks), "block certificate does not match actual rules"
    assert counts == {str(k): v for k, v in document["rescued_cycles"].items()}
    if "longer_cycles" in document:
        assert document["longer_cycles"] == {str(k): rescued[k] for k in (6, 7, 8)}
    else:
        assert canonical(document["seven_cycle"]) == tuple(rescued[7][0]["cycle"])
    predicted_wins = 14736 + 6 * counts["5"] + 2 * counts["6"] + counts["7"] + counts["8"]
    outside = sorted(rules - block_rules)
    return {
        "rules": len(rules), "distinct_loss_words": len(set(loss_words)),
        "supports": len(supports), "complementary_support_pairs": 0,
        "rescued_cycles": counts, "longer_cycles": {str(k): rescued[k] for k in (6, 7, 8)},
        "blocks_checked": len(blocks), "rules_outside_rescued_5cycles": [list(p) for p in outside],
        "supports_containing_8": [sorted(s) for s in sorted(supports, key=lambda s: tuple(sorted(s))) if 8 in s],
        "support_word_counts": {" ".join(map(str, sorted(s))): sum(frozenset(w) == s for w in loss_words)
                                for s in sorted(supports, key=lambda s: tuple(sorted(s)))},
        "predicted_wins": predicted_wins,
    }


def permutation_cycles(placement):
    seen, cycles = set(), []
    for label in LABELS:
        if label in seen:
            continue
        cycle, current = [], label
        while current not in seen:
            seen.add(current)
            cycle.append(current)
            current = placement[current - 1]
        assert current == label
        cycles.append(tuple(cycle))
    return cycles


def direct_simulation(document):
    rules, lookup = rules_from_json(document)
    wins, old_wins, lost = 0, 0, 0
    histogram, winning_success_counts = Counter(), Counter()
    winning_mask = 0
    for number, placement in enumerate(itertools.permutations(LABELS)):
        successful = 0
        for prisoner in LABELS:
            box, history, opened = prisoner, [], set()
            for opening in range(4):
                assert box not in opened
                opened.add(box)
                observed = placement[box - 1]
                history.append(observed)
                if observed == prisoner:
                    successful += 1
                    break
                if opening == 2:
                    box = lookup.get((prisoner, tuple(history)), observed)
                else:
                    box = observed
        cycles = permutation_cycles(placement)
        maximum = max(map(len, cycles))
        cf_win = maximum <= 4
        win = successful >= 7
        # Independent per-placement agreement with the window description.
        long_cycles = [c for c in cycles if len(c) > 4]
        predicted = cf_win or (bool(long_cycles) and
            sum(path in rules for path in windows(long_cycles[0])) >= len(long_cycles[0]) - 1)
        assert win == predicted, ("window semantics differs from actual opened boxes", placement)
        old_wins += cf_win
        lost += cf_win and not win
        if win:
            wins += 1
            histogram[maximum] += 1
            winning_success_counts[successful] += 1
            winning_mask |= 1 << number
    assert number + 1 == math.factorial(8)
    assert old_wins == 14736 and lost == 0
    result = {"placements": number + 1, "wins": wins, "CF_old_wins": old_wins,
              "CF_old_wins_lost": lost,
              "wins_by_max_cycle_length": {str(k): v for k, v in sorted(histogram.items())},
              "winning_placements_by_successful_prisoners": {str(k): v for k, v in sorted(winning_success_counts.items())},
              "per_placement_window_formula_matches": True}
    reported = document.get("evaluation", {})
    for key in ("wins", "CF_old_wins", "CF_old_wins_lost", "wins_by_max_cycle_length"):
        if key in reported:
            assert result[key] == reported[key], ("reported result mismatch", key)
    return result, winning_mask


def audit_csv(csv_bytes, document, rules):
    rows = list(csv.DictReader(io.StringIO(csv_bytes.decode("utf-8-sig"))))
    csv_blocks = set()
    for row in rows:
        cycle = tuple(map(int, re.findall(r"\d+", row["directed_5_cycle"])))
        skip, omitted = int(row["skipped_point_w"]), int(row["omitted_prisoner_o"])
        assert omitted == cycle[(cycle.index(skip) + 1) % 5]
        csv_blocks.add((canonical(cycle), skip))
        actual_words = {canonical(p[1:]) for p in windows(cycle) if p in rules}
        claimed_words = {canonical(map(int, group)) for group in re.findall(r"\((\d{4})\)", row["loss_words_used"])}
        assert actual_words == claimed_words
    assert len(rows) == 52 and csv_blocks == {(canonical(c), w) for c, w in document["blocks"]}
    return len(rows)


def read_package(archive_path):
    with zipfile.ZipFile(archive_path) as archive:
        entries = {entry.filename: archive.read(entry) for entry in archive.infolist() if not entry.is_dir()}
    assert len(entries) > 0
    manifest_names = [name for name in entries if name.endswith("/SHA256SUMS.txt")]
    assert len(manifest_names) == 1
    manifest = manifest_names[0]
    prefix = manifest[:manifest.rfind("/") + 1]
    checked = []
    for line in entries[manifest].decode("utf-8-sig").splitlines():
        if not line.strip():
            continue
        expected, relative = line.split(maxsplit=1)
        relative = relative.lstrip("*")
        if relative.startswith("./"):
            relative = relative[2:]
        name = prefix + relative
        assert name in entries, ("missing file", name)
        assert digest(entries[name]) == expected, ("SHA-256 mismatch", name)
        checked.append(name)
    return entries, prefix, {"manifest_files_checked": len(checked), "hash_mismatches": 0,
                             "archive_sha256": digest(Path(archive_path).read_bytes())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("round8_zip", type=Path)
    parser.add_argument("--output", type=Path, default=Path("round8_certificate_audit.json"))
    parser.add_argument("--round7-zip", type=Path)
    parser.add_argument("--standalone", type=Path, nargs="*", default=[])
    args = parser.parse_args()
    entries, prefix, integrity = read_package(args.round8_zip)
    result = {"audit": "independent direct enumeration and structural certificate audit",
              "date": "2026-10-12", "scope": "n=8, four openings, seven successes, CF-preserving final-box rules",
              "optimality_proved": False, "archive_integrity": integrity, "certificates": {},
              "standalone_files": {}, "pairwise_winning_set_comparisons": []}
    masks = {}
    for name, (expected_wins, expected_cycles, raw_name, csv_name) in CERTIFICATES.items():
        binary = entries[prefix + "certificates/" + name]
        document = json.loads(binary)
        rules, _ = rules_from_json(document)
        raw_binary = entries[prefix + "raw_solver_outputs/" + raw_name]
        raw = json.loads(raw_binary)
        assert rules == {(b, a, *h) for a, h, b in raw["rules"]}
        if "source_rule_table_sha256" in document:
            assert document["source_rule_table_sha256"] == digest(raw_binary)
        structure = structural_audit(document)
        assert tuple(structure["rescued_cycles"][str(k)] for k in range(5, 9)) == expected_cycles
        count, mask = direct_simulation(document)
        assert count["wins"] == structure["predicted_wins"] == expected_wins
        csv_count = audit_csv(entries[prefix + "certificates/" + csv_name], document, rules)
        result["certificates"][name] = {"sha256": digest(binary), "source_rules_match": True,
                                          "csv_rows_checked": csv_count, "structural": structure, "direct": count}
        masks[name] = mask
        print(json.dumps({"certificate": name, "rules": len(rules), "wins": count["wins"],
                          "CF_loss": count["CF_old_wins_lost"], "rescued_cycles": structure["rescued_cycles"]}), flush=True)
    for standalone in args.standalone:
        name = standalone.name
        binary = standalone.read_bytes()
        assert binary == entries[prefix + "certificates/" + name], ("standalone differs from archive", name)
        result["standalone_files"][name] = {"sha256": digest(binary), "identical_to_archive": True}
    if args.round7_zip:
        with zipfile.ZipFile(args.round7_zip) as archive:
            matches = [name for name in archive.namelist() if name.endswith("/repro/round4_baseline_n8.json")]
            assert len(matches) == 1
            baseline = json.loads(archive.read(matches[0]))
        # The archived Round 4 solver certificate predates mixed-n8-v1.
        assert baseline["m"] == 4 and baseline["mode"] == "rescue"
        baseline = dict(baseline, n=8, max_boxes=4, required_successes=7)
        baseline_count, baseline_mask = direct_simulation(baseline)
        assert baseline_count["wins"] == 15042
        result["round4_baseline"] = baseline_count
        for name in CERTIFICATES:
            actual_new = (masks[name] & ~baseline_mask).bit_count()
            actual_lost = (baseline_mask & ~masks[name]).bit_count()
            document = json.loads(entries[prefix + "certificates/" + name])
            assert document["evaluation"]["new_vs_51_cycle_baseline"] == actual_new
            assert document["evaluation"]["lost_vs_51_cycle_baseline"] == actual_lost
            result["certificates"][name]["comparison_with_51_cycle_baseline"] = {
                "new_wins": actual_new, "lost_wins": actual_lost}
    for earlier, later in itertools.combinations(CERTIFICATES, 2):
        result["pairwise_winning_set_comparisons"].append({
            "first": earlier, "second": later,
            "second_only": (masks[later] & ~masks[earlier]).bit_count(),
            "first_only": (masks[earlier] & ~masks[later]).bit_count(),
        })
    result["status"] = "PASS"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("PASS: all package hashes, four exhaustive simulations, raw rules, cycle and CSV certificates.")


if __name__ == "__main__":
    main()
