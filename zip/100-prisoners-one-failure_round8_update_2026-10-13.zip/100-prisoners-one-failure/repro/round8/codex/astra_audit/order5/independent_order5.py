"""Read-only independent finite audit. No source-module imports.

Directed cycles are represented by their sets of directed edges. Rule = five
consecutive labels (target, prisoner, first value, second value, third value).
All masks refer to complete g-orbits of oriented loss words, not supports.
"""
import itertools as I
import argparse
import json
import time
from pathlib import Path
from collections import Counter

OUT = Path(__file__).parent
DEFAULT_SOURCE = Path(r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\outputs\theory_general')
LABELS = tuple(range(1, 9))
ALL_SUPPORT = 255

def g(seq, shift=1):
    return tuple(1 + (x - 1 + shift) % 5 if x < 6 else x for x in seq)

def edge_key(seq):
    return tuple(sorted(zip(seq, seq[1:] + seq[:1])))

def rotation_min(seq):
    return min(seq[i:] + seq[:i] for i in range(len(seq)))

def loss_key(rule):
    return edge_key(rule[1:])

def loss_orbit(rule):
    return min(loss_key(g(rule, k)) for k in range(5))

def support(seq):
    return sum(1 << (x - 1) for x in seq)

def support_orbit(seq):
    return min(support(g(seq, k)) for k in range(5))

def rotated_rules(cycle):
    return [cycle[i:] + cycle[:i] for i in range(5)]

def expand_rules(rules):
    return tuple(g(r, k) for k in range(5) for r in rules)

def exact_cover(masks, universe, limit=1.0):
    """Algorithm X with independent MRV and exhausted-state caching."""
    started = time.monotonic()
    deadline = started + limit
    columns = {}
    for index, row in enumerate(masks):
        assert row and (row | universe) == universe
        rest = row
        while rest:
            low = rest & -rest
            columns.setdefault(low, []).append(index)
            rest -= low
    exhausted = set()
    nodes = 0

    def solve(rem):
        nonlocal nodes
        nodes += 1
        if time.monotonic() > deadline:
            raise TimeoutError
        if rem == 0:
            return ()
        if rem in exhausted:
            return None
        best = None
        bits = rem
        while bits:
            bit = bits & -bits
            bits -= bit
            options = [j for j in columns.get(bit, ()) if masks[j] & rem == masks[j]]
            if not options:
                exhausted.add(rem)
                return None
            if best is None or len(options) < len(best):
                best = options
        for j in best:
            answer = solve(rem & ~masks[j])
            if answer is not None:
                return (j,) + answer
        exhausted.add(rem)
        return None

    try:
        certificate = solve(universe)
        status = 'FEASIBLE' if certificate is not None else 'INFEASIBLE'
    except TimeoutError:
        certificate = None
        status = 'UNKNOWN'
    if certificate is not None:
        used = 0
        for j in certificate:
            assert used & masks[j] == 0
            used |= masks[j]
        assert used == universe
    return {'status': status, 'nodes': nodes, 'seconds': time.monotonic()-started,
            'solution': certificate}

def main(source):
    begun = time.monotonic()
    quotient_words = {}
    for four in I.combinations(LABELS, 4):
        for tail in I.permutations(four[1:]):
            word = (four[0],) + tail
            orbit = min(edge_key(g(word, k)) for k in range(5))
            quotient_words[orbit] = support_orbit(word)
    word_index = {key: j for j, key in enumerate(sorted(quotient_words))}
    support_orbits = sorted(set(quotient_words.values()))
    complements = {}
    for four in I.combinations(LABELS, 4):
        complements[support_orbit(four)] = support_orbit(tuple(x for x in LABELS if x not in four))
    support_pairs = sorted({tuple(sorted((a,b))) for a,b in complements.items()})
    assert len(word_index) == 84 and len(support_orbits) == 14 and len(support_pairs) == 7

    # Exhaustively identify the four cycles fixed under g, rather than assume steps.
    fixed = []
    candidates = []
    discarded = 0
    for five in I.combinations(LABELS, 5):
        for tail in I.permutations(five[1:]):
            cyc = (five[0],) + tail
            orbit = {rotation_min(g(cyc, k)) for k in range(5)}
            if len(orbit) == 1:
                fixed.append(cyc)
                continue
            if cyc != min(orbit):
                continue
            complete = rotated_rules(cyc)
            for omit in range(5):
                rs = expand_rules(complete[:omit] + complete[omit+1:])
                word_set = {loss_key(r) for r in rs}
                supports = {support(r[1:]) for r in rs}
                if len(word_set) != 20 or any((ALL_SUPPORT ^ a) in supports for a in supports):
                    discarded += 1
                    continue
                orbits = {loss_orbit(r) for r in rs}
                assert len(orbits) == 4
                mask = sum(1 << word_index[w] for w in orbits)
                candidates.append((mask, rs))
    assert len(fixed) == 4
    assert len(candidates) == 1148
    fixed.sort()
    fixed_masks = [sum(1 << word_index[w] for w in {loss_orbit(r) for r in rotated_rules(c)}) for c in fixed]
    assert all(m.bit_count() == 1 for m in fixed_masks)

    base_rows = []
    feasible_supports = set()
    for fi,fj in I.combinations(range(4), 2):
        forced_mask = fixed_masks[fi] | fixed_masks[fj]
        assert forced_mask.bit_count() == 2
        for choices in I.product((0,1), repeat=7):
            selected = tuple(sorted(pair[ch] for pair,ch in zip(support_pairs, choices)))
            universe = sum(1 << word_index[w] for w,s in quotient_words.items() if s in selected)
            if universe & forced_mask != forced_mask:
                continue
            assert universe.bit_count() == 42
            remainder = universe & ~forced_mask
            rows = [m for m,_ in candidates if m & remainder == m]
            result = exact_cover(rows, remainder)
            base_rows.append({'pair': [list(fixed[fi]),list(fixed[fj])], 'selected':selected, **result})
            if result['status'] == 'FEASIBLE':
                feasible_supports.add(selected)
    base_counts = Counter(r['status'] for r in base_rows)
    assert len(base_rows) == 384
    expected_supports = {tuple(sorted(support_orbit(s) for s in I.combinations(tuple(x for x in LABELS if x != excluded),4))) for excluded in (6,7,8)}
    expected_supports = {tuple(sorted(set(s))) for s in expected_supports}
    assert feasible_supports == expected_supports
    assert base_counts == {'FEASIBLE':18, 'INFEASIBLE':366}
    print('base', dict(base_counts), flush=True)

    # Saturated feasible supports contain seven labels. Relabel its excluded fixed
    # label as 8; this relabeling commutes with g, so it covers all three families.
    normalized_support = tuple(sorted({support_orbit(s) for s in I.combinations(tuple(range(1,8)),4)}))
    universe = sum(1 << word_index[w] for w,s in quotient_words.items() if s in normalized_support)
    assert universe.bit_count() == 42
    normalized_rows = [(m,rs) for m,rs in candidates if all(8 not in r for r in rs)]
    seven_reps = []
    for tail in I.permutations(tuple(range(2,8))):
        c = (1,) + tail
        if c == min(rotation_min(g(c,k)) for k in range(5)):
            seven_reps.append(c)
    assert len(seven_reps) == 144
    seven_rows = []
    for fi,fj in I.combinations(range(4),2):
        f_rules = rotated_rules(fixed[fi]) + rotated_rules(fixed[fj])
        f_words = {loss_key(r): r for r in f_rules}
        remainder = universe & ~(fixed_masks[fi] | fixed_masks[fj])
        base = [(m,rs) for m,rs in normalized_rows if m & remainder == m]
        for cyc in seven_reps:
            paths = [(cyc+cyc)[j:j+5] for j in range(7)]
            for omit in range(7):
                forced = set(expand_rules(paths[:omit] + paths[omit+1:]))
                forced_by_word = {loss_key(r):r for r in forced}
                if len(forced_by_word) != len(forced):
                    result = {'status':'RULE_CONFLICT'}
                elif any(w in f_words and f_words[w] != r for w,r in forced_by_word.items()):
                    result = {'status':'FIXED_RULE_CONFLICT'}
                else:
                    eligible = [m for m,rs in base if all(loss_key(r) not in forced_by_word or forced_by_word[loss_key(r)] == r for r in rs)]
                    result = exact_cover(eligible, remainder)
                seven_rows.append({'pair':[list(fixed[fi]),list(fixed[fj])], 'cycle':cyc,'omit':omit,**result})
    seven_counts = Counter(r['status'] for r in seven_rows)
    assert len(seven_rows)==6048
    assert seven_counts=={'RULE_CONFLICT':672,'FIXED_RULE_CONFLICT':1152,'INFEASIBLE':4224}
    print('seven',dict(seven_counts),flush=True)

    saved_base = json.loads((source/'order5_quotient.json').read_text(encoding='utf8'))
    saved_seven = json.loads((source/'order5_r7_exhaustive.json').read_text(encoding='utf8'))
    assert Counter(r['status'] for r in saved_base['rows']) == base_counts
    assert saved_seven['counts'] == dict(seven_counts)
    result = {'scope':'all g=(12345)-invariant R5=52 strategies with at most210 admissible rules',
              'quotient_words':len(word_index), 'quotient_blocks':len(candidates),'discarded_blocks':discarded,
              'base_counts':dict(base_counts),'seven_counts':dict(seven_counts),'feasible_support_families':sorted(feasible_supports),
              'saved_count_match':True,'elapsed_seconds':time.monotonic()-begun,
              'max_case_seconds':max(r.get('seconds',0) for r in base_rows+seven_rows),
              'base_rows':base_rows,'seven_rows':seven_rows}
    (OUT/'independent_order5_results.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print('elapsed',result['elapsed_seconds'],flush=True)

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', nargs='?', type=Path, default=DEFAULT_SOURCE,
                        help='Astra theory_general directory containing saved finite-search JSONs')
    main(parser.parse_args().source)
