import json
import argparse
from pathlib import Path
HERE=Path(__file__).parent
parser=argparse.ArgumentParser()
parser.add_argument('source',nargs='?',type=Path,default=Path(r'C:\Users\yauki\Documents\Codex\2026-10-12\8-8-15-051-1-8\outputs\theory_general'))
SOURCE=parser.parse_args().source
ours=json.loads((HERE/'independent_order5_results.json').read_text(encoding='utf8'))
base=json.loads((SOURCE/'order5_quotient.json').read_text(encoding='utf8'))
seven=json.loads((SOURCE/'order5_r7_exhaustive.json').read_text(encoding='utf8'))
fixed=[tuple(1+(i*d)%5 for i in range(5)) for d in range(1,5)]
def pair_from_steps(row):return tuple(fixed[d-1] for d in row['fixed_steps'])
def pair_ours(row):return tuple(tuple(c) for c in row['pair'])
def supportmask(labels):return sum(1<<(x-1) for x in labels)
base_source={(pair_from_steps(row),tuple(sorted(supportmask(s) for s in row['support_orbits']))):row['status'] for row in base['rows']}
base_ours={(pair_ours(row),tuple(row['selected'])):row['status'] for row in ours['base_rows']}
seven_source={(pair_from_steps(row),tuple(row['cycle']),row['missing_window_path_index']):row['status'] for row in seven['results']}
seven_ours={(pair_ours(row),tuple(row['cycle']),row['omit']):row['status'] for row in ours['seven_rows']}
assert base_source==base_ours
assert seven_source==seven_ours
result={'base_branch_match':len(base_ours),'seven_branch_match':len(seven_ours),'all_branch_statuses_identical':True,'independent_elapsed_seconds':ours['elapsed_seconds'],'independent_max_case_seconds':ours['max_case_seconds'],'source_base_unknown':sum(row['status']=='UNKNOWN' for row in base['rows']),'source_seven_unknown':sum(row['status']=='UNKNOWN' for row in seven['results'])}
(HERE/'branch_comparison.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result))
