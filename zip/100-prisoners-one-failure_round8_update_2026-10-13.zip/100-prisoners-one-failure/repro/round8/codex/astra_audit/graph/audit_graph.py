"""Independent compatibility graph reconstruction and exact 12-clique exclusion.

Uses only public witness JSON; never imports Astra's Python files.
"""
import argparse
import itertools
import json
from pathlib import Path
import time

def canonical(c):
    c = tuple(c)
    rotations = [c[k:] + c[:k] for k in range(len(c))]
    return min(rotations)

def bit_indices(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit

def block_properties(key):
    cycle, skip = key
    words = set()
    supports = set()
    paths = set()
    for start in range(5):
        path = tuple(cycle[(start+k) % 5] for k in range(5))
        if path[0] == skip:
            continue
        paths.add(path)
        words.add(canonical(path[1:]))
        supports.add(sum(1 << (x-1) for x in path[1:]))
    assert len(paths) == len(words) == len(supports) == 4
    return words, supports, paths

def build_graph(source, output):
    begin = time.perf_counter()
    raw = json.loads((source / 'local_coexistence/local_patterns_one_side.json').read_text(encoding='utf8'))
    cycles = [tuple(row['cycle']) for row in raw['cycles']]
    assert len(cycles) == 468 and len(set(cycles)) == 468
    blocks = {}
    patterns = []
    parents = []
    own = [0] * len(cycles)
    for ci, row in enumerate(raw['cycles']):
        for witness in row['patterns']:
            keyset = frozenset((canonical(cycle), skip) for cycle, skip in witness)
            assert len(keyset) == 6
            for key in keyset:
                blocks.setdefault(key, block_properties(key))
            own[ci] |= 1 << len(patterns)
            parents.append(ci)
            patterns.append(keyset)
    containing = {block: 0 for block in blocks}
    by_word = {}
    by_support = {}
    for pi, pattern in enumerate(patterns):
        mask = 1 << pi
        seen_words = set()
        seen_supports = set()
        for block in pattern:
            words, supports, paths = blocks[block]
            assert not seen_words.intersection(words)
            assert not any((255 ^ s) in seen_supports for s in supports)
            seen_words.update(words)
            seen_supports.update(supports)
            containing[block] |= mask
            for word in words:
                by_word[word] = by_word.get(word, 0) | mask
            for s in supports:
                by_support[s] = by_support.get(s, 0) | mask
        assert len(seen_words) == 24
    # Pattern p is incompatible with block b if one of p's other blocks has
    # the same loss word or complementary support. A shared b is permissible;
    # internal validity means every p containing b is already compatible with b.
    forbidden = {}
    for block, (words, supports, paths) in blocks.items():
        bad = 0
        for word in words:
            bad |= by_word[word]
        for s in supports:
            bad |= by_support.get(255 ^ s, 0)
        forbidden[block] = bad & ~containing[block]
    universe = (1 << len(patterns)) - 1
    adj = [0] * len(cycles)
    witness_pair_count = 0
    for pi, pattern in enumerate(patterns):
        bad = own[parents[pi]]
        for block in pattern:
            bad |= forbidden[block]
        possible = universe & ~bad
        witness_pair_count += possible.bit_count()
        for cj, mask in enumerate(own):
            if possible & mask:
                adj[parents[pi]] |= 1 << cj
    assert witness_pair_count % 2 == 0
    for i, mask in enumerate(adj):
        assert not (mask >> i) & 1
        for j in bit_indices(mask):
            assert (adj[j] >> i) & 1
    original = json.loads((source / 'local_coexistence/pair_compatibility_one_side.json').read_text(encoding='utf8'))
    original_cycles = [tuple(c) for c in original['cycles']]
    original_map = {c: i for i, c in enumerate(original_cycles)}
    differences = []
    for i, c in enumerate(cycles):
        expected = {original_cycles[j] for j in original['adjacency_indices'][original_map[c]]}
        actual = {cycles[j] for j in bit_indices(adj[i])}
        if actual != expected:
            differences.append({'cycle': c, 'missing': sorted(expected-actual), 'unexpected': sorted(actual-expected)})
    edge_count = sum(a.bit_count() for a in adj) // 2
    conflict_count = len(cycles)*(len(cycles)-1)//2 - edge_count
    summary = {
        'vertices':len(cycles),'witnesses':len(patterns),'different_blocks':len(blocks),
        'compatible_witness_pairs':witness_pair_count//2,
        'compatible_cycle_pairs':edge_count,'incompatible_cycle_pairs':conflict_count,
        'adjacency_difference_rows':len(differences),'reconstruction_seconds':time.perf_counter()-begin,
    }
    (output/'independent_graph.json').write_text(json.dumps({**summary,'cycles':cycles,'adjacency_indices':[list(bit_indices(a)) for a in adj]},indent=2),encoding='utf8')
    assert not differences, differences[:3]
    assert edge_count == 48797 and conflict_count == 60481
    return cycles, adj, summary

def exclude_clique(adj, target):
    # Vertex permutation is chosen only from independent reconstructed graph.
    # Greedy coloring gives a valid upper bound at every node. Searching every
    # reverse-color branch unless pruned excludes all target-size cliques.
    begin = time.perf_counter()
    n = len(adj)
    order = sorted(range(n), key=lambda v: (-adj[v].bit_count(), v))
    inverse = {old: new for new, old in enumerate(order)}
    mapped = [sum(1 << inverse[w] for w in bit_indices(adj[v])) for v in order]
    nodes = 0
    coloring_prunes = 0
    size_prunes = 0
    def color_classes(mask):
        candidates = mask
        sequence = []
        bounds = []
        colors = 0
        while candidates:
            colors += 1
            independent = candidates
            while independent:
                bit = independent & -independent
                v = bit.bit_length()-1
                sequence.append(v)
                bounds.append(colors)
                candidates &= ~bit
                independent &= ~bit
                independent &= ~mapped[v]
        return sequence, bounds
    def visit(mask, chosen):
        nonlocal nodes, coloring_prunes, size_prunes
        nodes += 1
        required = target-len(chosen)
        if required == 0:
            return chosen
        if mask.bit_count() < required:
            size_prunes += 1
            return None
        vertices, upper = color_classes(mask)
        for position in range(len(vertices)-1, -1, -1):
            if upper[position] < required:
                coloring_prunes += 1
                return None
            v = vertices[position]
            result = visit(mask & mapped[v], chosen+[v])
            if result is not None:
                return result
            mask &= ~(1 << v)
        return None
    found = visit((1 << n)-1, [])
    return {'target_clique_size':target,'found':None if found is None else [order[v] for v in found],
            'complete_search':True,'nodes':nodes,'coloring_prunes':coloring_prunes,
            'size_prunes':size_prunes,'elapsed_seconds':time.perf_counter()-begin}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source',type=Path)
    parser.add_argument('output',type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    cycles, adj, summary = build_graph(args.source,args.output)
    reported = json.loads((args.source/'verification/clique_bitset.json').read_text(encoding='utf8'))
    reported_clique = [cycles.index(tuple(c)) for c in reported['clique']]
    assert len(reported_clique) == 11
    assert all(adj[v] & (1 << w) for v,w in itertools.combinations(reported_clique,2))
    print(json.dumps({'graph':summary,'reported_11_clique_verified':True}),flush=True)
    exact = exclude_clique(adj,12)
    assert exact['found'] is None
    result = {**summary,'reported_11_clique_verified':True,'exact_12_clique_search':exact,
              'proven_maximum_clique':11,
              'scope':'Max clique of pairwise local witness relaxation. Requires candidate completeness and common-side lemma for strategy R7 bound; does not prove 11-cycle strategy exists.'}
    (args.output/'audit_result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(result,indent=2),flush=True)

if __name__ == '__main__':
    main()
