"""Independent solver-free audit. Does not import any Astra source module."""
from itertools import combinations, permutations, product
from collections import Counter
from pathlib import Path
import argparse
import json, time
from functools import lru_cache

HERE = Path(__file__).resolve().parent
SOURCE = None
UNIVERSE = frozenset(range(1,9))

def cycle_key(values):
    t = tuple(values)
    j = t.index(min(t))
    return t[j:] + t[:j]

def directed_cycles(k):
    for s in combinations(range(1,9), k):
        for p in permutations(s[1:]):
            yield (s[0],) + p

def paths(c):
    # Start at the predecessor of each prisoner, so p[1] is the prisoner.
    return [tuple(c[(i + j) % len(c)] for j in (-1,0,1,2,3)) for i in range(len(c))]

@lru_cache(None)
def loss(p):
    return cycle_key(p[1:])

@lru_cache(None)
def support(p):
    return frozenset(p[1:])

@lru_cache(None)
def clash(a,b):
    return a != b and (loss(a) == loss(b) or support(a).isdisjoint(support(b)))

def compatible(a,b):
    return all(not clash(x,y) for x in a for y in b)

@lru_cache(None)
def block(c,skip):
    return frozenset(p for p in paths(c) if p[0] != skip)

FIXED_KEYS = (((1,2,4,5,6),2),((1,3,4,5,6),1),((2,3,4,5,6),3))
FIXED_BLOCKS = {c:block(c,s) for c,s in FIXED_KEYS}
EXTRAS = frozenset(((5,6,1,2,3),(6,1,2,3,4)))
BASE = EXTRAS | frozenset().union(*FIXED_BLOCKS.values())

@lru_cache(None)
def witness_options(p):
    c = cycle_key(p)
    if c in FIXED_BLOCKS:
        return [(next(k for k in FIXED_KEYS if k[0] == c), FIXED_BLOCKS[c])] if p in FIXED_BLOCKS[c] else []
    result=[]
    for skip in c:
        v=block(c,skip)
        if p not in v or v & EXTRAS or not compatible(v,BASE):
            continue
        result.append(((c,skip),v))
    return result

def enumerate_witnesses(c):
    ww=paths(c)
    extra=[p for p in ww if p in EXTRAS]
    needed=6-len(extra)
    other=[p for p in ww if p not in EXTRAS]
    valid=set()
    for required in combinations(other,needed):
        choices=sorted((witness_options(p) for p in required),key=len)
        if any(not ch for ch in choices):
            continue
        def recurse(i,used,keys):
            if i==len(choices):
                valid.add(tuple(sorted(set(keys)-set(FIXED_KEYS))))
                return
            for key,v in choices[i]:
                if compatible(v,used):
                    recurse(i+1,used|v,keys+(key,))
        recurse(0,BASE,())
    return extra,valid

def source_patterns(filename):
    raw=json.loads((SOURCE/'local_coexistence'/filename).read_text(encoding='utf-8'))
    return {tuple(r['cycle']):{tuple(sorted((tuple(c),s) for c,s in pat)) for pat in r['patterns']} for r in raw['cycles']}

def local_six_table():
    c=(1,2,3,4,5,6); ww=paths(c); result=[]
    for absent in [None]+list(c):
        required=[p for p in ww if p[1] != absent]
        choices=[]
        for p in required:
            cyc=cycle_key(p)
            opts=[((cyc,skip),block(cyc,skip)) for skip in cyc if skip != p[0] and compatible(block(cyc,skip),required)]
            choices.append([(None,frozenset())]+opts)
        best=-1; maximizers=set()
        for ch in product(*choices):
            keys=[k for k,_ in ch if k is not None]
            if len(keys)<best:
                continue
            used=frozenset(required)
            ok=True
            for _,rs in ch:
                if not compatible(rs,used):
                    ok=False; break
                used|=rs
            if ok:
                if len(keys)>best:
                    best=len(keys); maximizers.clear()
                maximizers.add(tuple(sorted(keys)))
        result.append({'absent_prisoner':absent,'max_block_derived':best,'maximizer_count':len(maximizers),'maximizers':[[[c,s] for c,s in row] for row in sorted(maximizers)]})
    return result

def extra_max_correct(c):
    ww=paths(c); correct_extras=[p for p in ww if p in EXTRAS]; other=[p for p in ww if p not in EXTRAS]
    options=[[(None,frozenset())]+witness_options(p) for p in other]
    best=0
    for row in product(*options):
        picked=[k for k,_ in row if k is not None]
        if len(picked)<=best:
            continue
        used=BASE; okay=True
        for _,rs in row:
            if not compatible(rs,used):okay=False;break
            used|=rs
        if okay:best=len(picked)
    impossible=[p[1] for p in other if not witness_options(p)]
    return {'cycle':c,'extras':len(correct_extras),'max_block_windows':best,'max_correct':best+len(correct_extras),'individually_impossible':impossible}

def main():
    started=time.perf_counter()
    counts=Counter();records={}; extra_details=[]
    for c in directed_cycles(7):
        ex,patterns=enumerate_witnesses(c)
        counts[f'total_t{len(ex)}']+=1
        counts[f'patterns_t{len(ex)}']+=len(patterns)
        if patterns:
            records[c]=patterns
            counts[f'candidates_t{len(ex)}']+=1
        if ex:extra_details.append(extra_max_correct(c))
    single={c:p for c,p in records.items() if 8 not in c}
    other={c:p for c,p in records.items() if 7 not in c}
    swapped={cycle_key(tuple(8 if x==7 else 7 if x==8 else x for x in c)): {tuple(sorted((cycle_key(tuple(8 if x==7 else 7 if x==8 else x for x in bc)),8 if sk==7 else 7 if sk==8 else sk) for bc,sk in pp)) for pp in patterns} for c,patterns in single.items()}
    size_hist=Counter(len(w) for pats in records.values() for w in pats)
    support_count_hist=Counter()
    for c,pats in records.items():
        outside=7 if 7 in c else 8
        for w in pats:
            ss=[support(p) for bc,sk in w for p in block(bc,sk)]
            assert len(ss)==24 and len(set(ss))==24
            support_count_hist[sum(outside in s for s in ss)]+=1
    report={
        'scope':'Independent local necessary-condition enumeration; does not prove 52-block completion.',
        'stats':dict(counts),
        'candidate_count':len(records),'one_side_candidates':len(single),
        'one_side_witnesses':sum(map(len,single.values())),
        'witness_sizes':dict(size_hist),'outside_support_counts':dict(support_count_hist),
        'all_candidates_contain_1_to_6':all(set(range(1,7)) <= set(c) for c in records),
        'all_candidate_extra_counts_zero':all(not (set(paths(c))&EXTRAS) for c in records),
        'swapped_sides_equal':swapped==other,
        'source_full_candidates_and_patterns_equal':records==source_patterns('local_patterns.json'),
        'source_one_side_candidates_and_patterns_equal':single==source_patterns('local_patterns_one_side.json'),
        'extra_cycle_maxima':extra_details,
        'six_normalization':local_six_table(),
        'elapsed_seconds':time.perf_counter()-started,
    }
    (HERE/'candidate_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (HERE/'independent_patterns.json').write_text(json.dumps([{'cycle':c,'patterns':[[[bc,sk] for bc,sk in pp] for pp in sorted(p)]} for c,p in records.items()],separators=(',',':'))+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('six_normalization','extra_cycle_maxima')},ensure_ascii=False,indent=2))
    print('extra maxima:',[(x['cycle'],x['max_correct']) for x in extra_details])
    print('six normalization:',[(x['absent_prisoner'],x['max_block_derived'],x['maximizer_count']) for x in report['six_normalization']])

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='Astra outputs directory')
    SOURCE = parser.parse_args().source
    main()
