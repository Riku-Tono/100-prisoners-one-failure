"""Audit Astra's source files and three rule tables, without importing them.

Python standard library only. Uses our earlier independent direct simulator.
Usage from outputs:
  python -X utf8 audit_astra_certificates.py ASTRA_OUTPUTS --output audit.json
The companion audit_round8_independent.py must be in the same directory.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

from audit_round8_independent import (
    LABELS, UNIVERSE, all_directed_cycles, canonical,
    direct_simulation, rules_from_json, windows,
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def inspect_table(document):
    # Saved calibration files contain only schema and rules. The scope under
    # audit is explicitly n=8, four actual openings, and seven successes.
    doc = dict(n=8, max_boxes=4, required_successes=7)
    doc.update(document)
    rules, _ = rules_from_json(doc)
    words = [canonical(r[1:]) for r in rules]
    assert len(set(words)) == len(words)
    supports = {frozenset(w) for w in words}
    assert not any(UNIVERSE - s in supports for s in supports)
    groups = defaultdict(set)
    for r in rules:
        groups[canonical(r)].add(r)
    rescued, counts = {}, {}
    for k in range(5, 9):
        rescued[k] = []
        for c in all_directed_cycles(k):
            ok = [r in rules for r in windows(c)]
            if sum(ok) >= k - 1:
                rescued[k].append({
                    "cycle": list(c), "correct_windows": sum(ok),
                    "missing_prisoners": [c[j] for j, v in enumerate(ok) if not v],
                })
        counts[str(k)] = len(rescued[k])
    full = [c for c, rs in groups.items() if len(rs) == 5]
    external = {r for c, rs in groups.items() if len(rs) < 4 for r in rs}
    assert len(rules) == 4 * counts["5"] + len(full) + len(external)
    assert counts["5"] <= 52 and counts["8"] == 0
    assert 2 * counts["6"] <= 3 * len(external)
    assert counts["6"] <= len(external) * (len(external) - 1) // 2
    direct, _ = direct_simulation(doc)
    assert direct["wins"] == 14736 + 6 * counts["5"] + 2 * counts["6"] + counts["7"]
    if "rescued_cycles" in document:
        assert document["rescued_cycles"] == counts
    result = {
        "rules_count": len(rules), "loss_words_distinct": len(set(words)),
        "support_count": len(supports), "complement_support_collisions": 0,
        "rescued_cycles": counts, "group_size_histogram": dict(sorted(Counter(map(len, groups.values())).items())),
        "fully_correct_5cycles": [list(c) for c in sorted(full)],
        "external_rules": [list(r) for r in sorted(external)], "direct": direct,
    }
    if "automorphism" in document:
        values = tuple(document["automorphism"])
        assert sorted(values) == list(LABELS)
        g = dict(zip(LABELS, values))
        power = {x: x for x in LABELS}
        for _ in range(5):
            power = {x: g[power[x]] for x in LABELS}
        assert all(power[x] == x for x in LABELS) and any(g[x] != x for x in LABELS)
        assert {tuple(g[x] for x in r) for r in rules} == rules
        assert len(full) == 2 and len(external) == 0
        remaining = {c for c, rs in groups.items() if len(rs) == 4}
        orbit_sizes = []
        while remaining:
            c = min(remaining)
            orbit = set()
            while c not in orbit:
                orbit.add(c)
                c = canonical(tuple(g[x] for x in c))
            assert orbit <= remaining
            remaining -= orbit
            orbit_sizes.append(len(orbit))
        assert orbit_sizes == [5] * 10
        result["order5_automorphism_verified"] = True
        result["four_rule_cycle_orbits"] = orbit_sizes
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("source", type=Path)
    ap.add_argument("--output", type=Path, default=Path("astra_certificate_audit.json"))
    args = ap.parse_args()
    base = args.source.resolve()
    manifest = json.loads((base / "SHA256SUMS.json").read_text(encoding="utf-8-sig"))
    for name, expected in manifest.items():
        path = (base / name).resolve()
        assert path.is_relative_to(base), name
        assert path.is_file() and sha(path.read_bytes()) == expected, name
    result = {"date": "2026-10-12", "scope": "CF-preserving final-box n8 family",
              "manifest_files_checked": len(manifest), "manifest_mismatches": 0,
              "certificates": {}, "solver_status_checks": []}
    inputs = [
        ("theory_general/order5_symmetric_210rules_n8.json", 15048, 210, (52, 0, 0, 0)),
        ("search/seven_calibration.rules.json", 15051, 208, (52, 0, 3, 0)),
        ("search/six_calibration.rules.json", 15050, 210, (52, 1, 0, 0)),
    ]
    for name, expected_wins, expected_rules, expected_cycles in inputs:
        binary = (base / name).read_bytes()
        checked = inspect_table(json.loads(binary))
        assert checked["direct"]["wins"] == expected_wins
        assert checked["rules_count"] == expected_rules
        assert tuple(checked["rescued_cycles"][str(k)] for k in range(5, 9)) == expected_cycles
        checked["sha256"] = sha(binary)
        result["certificates"][name] = checked
        print(json.dumps({"file": name, "rules": expected_rules, "wins": expected_wins,
                          "CF_loss": checked["direct"]["CF_old_wins_lost"],
                          "R5_R6_R7_R8": expected_cycles}), flush=True)
    for name in ("six_r7ge2", "six_reduced_r7ge2", "seven208_r7ge4", "seven210_r7ge4", "free208_r7ge4", "free210_r7ge4"):
        report = json.loads((base / "search" / (name + ".json")).read_text())
        log = (base / "search" / (name + ".solver.log")).read_text()
        assert report["status"] == "UNKNOWN"
        assert "CpSolverResponse summary:" in log and "status: UNKNOWN" in log
        result["solver_status_checks"].append({"run": name, "status": "UNKNOWN", "log_agrees": True})
    result["status"] = "PASS"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("PASS: source hashes, three exhaustive certificate checks, order5 symmetry, six UNKNOWN logs.")


if __name__ == "__main__":
    main()
