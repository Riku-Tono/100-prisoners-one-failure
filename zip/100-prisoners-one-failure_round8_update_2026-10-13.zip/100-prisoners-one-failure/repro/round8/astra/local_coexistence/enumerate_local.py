import itertools as it
import json, time, pathlib
from collections import Counter, defaultdict

OUT=pathlib.Path(__file__).resolve().parent
N=tuple(range(1,9))
def canon(t):
    t=tuple(t); p=t.index(min(t)); return t[p:]+t[:p]
def cycgen(k):
    for s in it.combinations(N,k):
        for p in it.permutations(s[1:]): yield (s[0],)+p
def windows(c):
    return [tuple(c[(i+j)%len(c)] for j in range(5)) for i in range(len(c))]
def loss(p): return canon(p[1:])
def smask(p): return sum(1<<(x-1) for x in p)
WORDS={w:i for i,w in enumerate(cycgen(4))}
SUPPORTS={s:i for i,s in enumerate(sorted({smask(w) for w in WORDS}))}
def masks(paths):
    wm=sum(1<<WORDS[loss(p)] for p in paths)
    ss={smask(p[1:]) for p in paths}
    sm=sum(1<<SUPPORTS[s] for s in ss)
    cm=sum(1<<SUPPORTS[255^s] for s in ss)
    return wm,sm,cm
BLOCKS=[]; BINDEX={}; RULEBLOCKS=defaultdict(list)
for c in cycgen(5):
    ww=windows(c)
    for skip in c:
        pp=tuple(p for p in ww if p[0]!=skip)
        ix=len(BLOCKS); BINDEX[(c,skip)]=ix
        BLOCKS.append((c,skip,pp,*masks(pp)))
        for p in pp: RULEBLOCKS[p].append(ix)

P=(5,6,1,2,3); Q=(6,1,2,3,4); EXT=(P,Q)
FIXED=[BINDEX[((1,2,4,5,6),2)], BINDEX[((1,3,4,5,6),1)], BINDEX[((2,3,4,5,6),3)]]
FIXPATHS=tuple(p for bi in FIXED for p in BLOCKS[bi][2])+EXT
FWM,FSM,FCM=masks(FIXPATHS)
assert len(FIXPATHS)==14 and FWM.bit_count()==14
ALLOWED=[]
for i,b in enumerate(BLOCKS):
    if i in FIXED: continue
    if not (b[3]&FWM or b[4]&FCM): ALLOWED.append(i)
ALLOWSET=set(ALLOWED)

def enum_patterns(c):
    ww=windows(c); ext=[i for i,p in enumerate(ww) if p in EXT]
    inds=[i for i in range(7) if i not in ext]
    opts={i:[bi for bi in RULEBLOCKS[ww[i]] if bi in ALLOWSET or bi in FIXED] for i in inds}
    patterns=set()
    # Every rescued 7-cycle has at most one absent window. Choosing one ignored
    # nonexternal window includes the all-seven-correct case as well.
    for miss in inds:
        req=[i for i in inds if i!=miss]
        if any(not opts[i] for i in req): continue
        req.sort(key=lambda i:len(opts[i]))
        def dfs(pos,wm,sm,cm,bids):
            if pos==len(req):
                patterns.add(tuple(sorted(set(bids))))
                return
            for bi in opts[req[pos]]:
                if bi in FIXED:
                    dfs(pos+1,wm,sm,cm,bids)
                    continue
                b=BLOCKS[bi]
                if b[3]&wm or b[4]&cm: continue
                dfs(pos+1,wm|b[3],sm|b[4],cm|b[5],bids+(bi,))
        dfs(0,FWM,FSM,FCM,())
    return ext,patterns

def main():
    started=time.perf_counter(); stats=Counter(); records=[]
    for c in cycgen(7):
        ext,pat=enum_patterns(c); t=len(ext)
        stats[f'all_cycles_t{t}']+=1
        stats[f'patterns_t{t}']+=len(pat)
        if pat:
            stats[f'feasible_cycles_t{t}']+=1
            records.append({'cycle':c,'external_count':t,'external_windows':[windows(c)[i] for i in ext],
                            'patterns':[[[BLOCKS[bi][0],BLOCKS[bi][1]] for bi in row] for row in sorted(pat)]})
    result={'scope':'All 5760 directed 7-cycles; exact minimal block witnesses, fixed normalized C6 three blocks and two external rules; loss-word and complement-support compatibility only.',
            'fixed_blocks':[[BLOCKS[bi][0],BLOCKS[bi][1]] for bi in FIXED],
            'external_rules':EXT,'allowed_additional_blocks':len(ALLOWED),'stats':dict(stats),
            'elapsed_seconds':time.perf_counter()-started,'cycles':records}
    (OUT/'local_patterns.json').write_text(json.dumps(result,separators=(',',':')),encoding='utf-8')
    reduced={**result,'scope':result['scope']+' Residual 7/8 relabeling used to place every rescued C7 on {1,...,7}; blocks using 8 remain allowed.',
             'cycles':[r for r in records if 8 not in r['cycle']]}
    reduced['reduced_cycle_count']=len(reduced['cycles'])
    reduced['reduced_pattern_count']=sum(len(r['patterns']) for r in reduced['cycles'])
    (OUT/'local_patterns_one_side.json').write_text(json.dumps(reduced,separators=(',',':')),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='cycles'},indent=2),flush=True)
    print('cycle records',len(records),flush=True)

if __name__=='__main__': main()
