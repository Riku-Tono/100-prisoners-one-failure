import enumerate_local as e
import json,itertools as it,time

def compatible(paths):
    seen={}; sup=set()
    for p in paths:
        w=e.loss(p)
        if w in seen and seen[w]!=p:return False
        s=e.smask(p[1:])
        if 255^s in sup:return False
        seen[w]=p;sup.add(s)
    return True

def main():
    start=time.perf_counter(); c=(1,2,3,4,5,6); ww=e.windows(c); out=[]
    for miss in [None]+list(range(6)):
        req=[p for i,p in enumerate(ww) if i!=miss]
        opts=[[bi for bi in e.RULEBLOCKS[p] if compatible(req+list(e.BLOCKS[bi][2]))] for p in req]
        best=-1; patterns=[]
        for choices in it.product(*[[None]+o for o in opts]):
            picked=[x for x in choices if x is not None]
            if len(picked)<best:continue
            paths=req+[p for bi in picked for p in e.BLOCKS[bi][2]]
            if compatible(paths):
                if len(picked)>best:best=len(picked);patterns=[]
                patterns.append(picked)
        out.append({'missing_prisoner':None if miss is None else ww[miss][1],
                    'correct_windows':len(req),'max_block_derived':best,'maximizers':[
                        [[e.BLOCKS[bi][0],e.BLOCKS[bi][1]] for bi in row] for row in patterns]})
    result={'elapsed_seconds':time.perf_counter()-start,'cases':out}
    (e.OUT/'local_six_normalization.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
