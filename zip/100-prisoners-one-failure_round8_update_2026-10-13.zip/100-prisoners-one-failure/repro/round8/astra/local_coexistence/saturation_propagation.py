import enumerate_local as e
import json,time
from collections import defaultdict,Counter

def bits(x):
    while x:
        b=x&-x;yield b.bit_length()-1;x-=b

ALL=sum(1<<bi for bi in e.ALLOWED)
WDOM=[0]*420;SDOM=[0]*70; SWORDS=[[] for _ in range(70)]
for w,wi in e.WORDS.items():SWORDS[e.SUPPORTS[e.smask(w)]].append(wi)
for bi in e.ALLOWED:
    b=e.BLOCKS[bi]; bb=1<<bi
    for wi in bits(b[3]): WDOM[wi]|=bb
    for si in bits(b[4]): SDOM[si]|=bb
COMP={i:e.SUPPORTS[255^s] for s,i in e.SUPPORTS.items()}
PAIRS=[(i,COMP[i]) for i in range(70) if i<COMP[i]]
BAD={}
for bi in e.ALLOWED:
    b=e.BLOCKS[bi];v=0
    for wi in bits(b[3]):v|=WDOM[wi]
    for si in bits(b[5]):v|=SDOM[si]
    BAD[bi]=v

def prop(pat):
    dom=ALL;occ=e.FWM; ss=e.FSM; forbidden=e.FCM; chosen=set()
    queue=list(pat);steps=0
    while True:
        steps+=1
        while queue:
            bi=queue.pop()
            if bi in chosen:continue
            if not (dom>>bi&1):return None,'forced_block_conflict',steps
            b=e.BLOCKS[bi];occ|=b[3];ss|=b[4];forbidden|=b[5]
            dom&=~BAD[bi];chosen.add(bi)
        if len(chosen)>49:return None,'too_many_forced_blocks',steps
        change=False
        for a,b in PAIRS:
            pa=not(forbidden>>a&1) and all((occ>>wi&1) or (WDOM[wi]&dom) for wi in SWORDS[a])
            pb=not(forbidden>>b&1) and all((occ>>wi&1) or (WDOM[wi]&dom) for wi in SWORDS[b])
            if not pa and not pb:return None,'no_complete_side',steps
            if pa and not pb and not(ss>>a&1):
                ss|=1<<a;forbidden|=1<<b;dom&=~SDOM[b];change=True
            if pb and not pa and not(ss>>b&1):
                ss|=1<<b;forbidden|=1<<a;dom&=~SDOM[a];change=True
        for si in bits(ss):
            for wi in SWORDS[si]:
                if occ>>wi&1:continue
                dd=WDOM[wi]&dom
                if not dd:return None,'uncovered_forced_word',steps
                if dd.bit_count()==1:queue.append(dd.bit_length()-1)
        if not queue and not change:break
    return {'forced_additional_blocks':len(chosen),'remaining_blocks':dom.bit_count(),
            'forced_support_sides':ss.bit_count(),'selected_blocks':sorted(chosen)},None,steps

def main():
    start=time.perf_counter();data=json.loads((e.OUT/'local_patterns.json').read_text(encoding='utf8'))
    out=[];stats=Counter();examples={}
    for ci,c in enumerate(data['cycles']):
        pp=[]
        for pi,p in enumerate(c['patterns']):
            pat=[e.BINDEX[(tuple(cc),skip)] for cc,skip in p]
            result,err,steps=prop(pat)
            stats['checked_patterns']+=1
            if err:
                stats[err]+=1
                if err not in examples:examples[err]={'cycle':c['cycle'],'pattern':p}
            else:
                stats['surviving_patterns']+=1;pp.append(pi)
                stats['forced_sides_'+str(result['forced_support_sides'])]+=1
        if pp:
            out.append({'cycle':c['cycle'],'pattern_indices':pp})
        if ci%100==0:print('cycle',ci,'elapsed',round(time.perf_counter()-start,1),'surviving',len(out),flush=True)
    result={'scope':'Necessary exact-cover propagation for 52 blocks plus P,Q and full 210-rule saturation. No search or completion feasibility decision.',
            'stats':dict(stats),'surviving_cycles':len(out),'elapsed_seconds':time.perf_counter()-start,
            'examples':examples,'cycles':out}
    (e.OUT/'saturation_propagation.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['examples','cycles']},indent=2))

if __name__=='__main__':main()
