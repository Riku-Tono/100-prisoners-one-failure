import enumerate_local as e
import json,time
from collections import defaultdict,Counter

def bits(x):
    while x:
        b=x&-x;yield b.bit_length()-1;x-=b

def main():
    started=time.perf_counter()
    data=json.loads((e.OUT/'local_patterns.json').read_text(encoding='utf8'))
    pats=[];cpids=[];parent=[]
    for ci,c in enumerate(data['cycles']):
        pp=0
        for p in c['patterns']:
            pp|=1<<len(pats);parent.append(ci)
            pats.append(tuple(e.BINDEX[(tuple(cc),skip)] for cc,skip in p))
        cpids.append(pp)
    wpids=defaultdict(int);spids=defaultdict(int);bpids=defaultdict(int)
    for pi,pat in enumerate(pats):
        pb=1<<pi
        for bi in pat:
            bpids[bi]|=pb;b=e.BLOCKS[bi]
            for wi in bits(b[3]):wpids[wi]|=pb
            for si in bits(b[4]):spids[si]|=pb
    bad={}
    for bi,containing in bpids.items():
        b=e.BLOCKS[bi];v=0
        for wi in bits(b[3]):v|=wpids[wi]
        for si in bits(b[5]):v|=spids[si]
        bad[bi]=v&~containing
    allp=(1<<len(pats))-1;adj=[set() for c in data['cycles']]
    pair_patterns=0;ex=[]
    for pi,pat in enumerate(pats):
        v=cpids[parent[pi]]
        for bi in pat:v|=bad[bi]
        ok=allp&~v;pair_patterns+=ok.bit_count()
        for cj,mask in enumerate(cpids):
            if ok&mask:
                adj[parent[pi]].add(cj)
                if len(ex)<5 and parent[pi]<cj:
                    qi=(ok&mask&-(ok&mask)).bit_length()-1
                    ex.append({'cycle1':data['cycles'][parent[pi]]['cycle'],
                               'cycle2':data['cycles'][cj]['cycle'],
                               'blocks1':[[e.BLOCKS[bi][0],e.BLOCKS[bi][1]] for bi in pat],
                               'blocks2':[[e.BLOCKS[bi][0],e.BLOCKS[bi][1]] for bi in pats[qi]]})
    result={'scope':'Compatibility of all minimal local block witnesses under fixed normalized C6; no completion to 52 blocks tested.',
            'pattern_count':len(pats),'compatible_unordered_pattern_pairs':pair_patterns//2,
            'cycle_pairs':sum(map(len,adj))//2,'cycle_degree_distribution':dict(Counter(map(len,adj))),
            'nonisolated_cycles':sum(bool(a) for a in adj),'examples':ex,
            'elapsed_seconds':time.perf_counter()-started,
            'adjacency':[[data['cycles'][j]['cycle'] for j in sorted(a)] for a in adj]}
    (e.OUT/'pair_compatibility.json').write_text(json.dumps(result,separators=(',',':')),encoding='utf8')
    side=[i for i,c in enumerate(data['cycles']) if 8 not in c['cycle']]
    remap={old:new for new,old in enumerate(side)}
    reduced={'scope':result['scope']+' Every rescued C7 normalized onto {1,...,7}.',
             'cycles':[data['cycles'][i]['cycle'] for i in side],
             'adjacency_indices':[[remap[j] for j in sorted(adj[i]) if j in remap] for i in side],
             'compatible_cycle_pairs':sum(len(adj[i]) for i in side)//2,
             'incompatible_cycle_pairs':len(side)*(len(side)-1)//2-sum(len(adj[i]) for i in side)//2}
    (e.OUT/'pair_compatibility_one_side.json').write_text(json.dumps(reduced,separators=(',',':')),encoding='utf8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['adjacency','examples']},indent=2))
    print('examples',json.dumps(ex))

if __name__=='__main__':main()
