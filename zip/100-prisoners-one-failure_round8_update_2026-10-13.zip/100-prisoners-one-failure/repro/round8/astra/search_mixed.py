"""Independent CP-SAT model for 52 rescued five-cycles; bounded runs only.

pip install ortools; python search_mixed.py --help
All inputs are data. No source-package solver code is imported.
"""
import argparse
from collections import defaultdict
from itertools import combinations, permutations
import json
from pathlib import Path
import time
from ortools.sat.python import cp_model
import ortools

L = tuple(range(1, 9))
def canon(t):
    i = t.index(min(t))
    return tuple(t[i:] + t[:i])
def cycles(k):
    for s in combinations(L, k):
        for p in permutations(s[1:]):
            yield (s[0],) + p
def windows(c):
    return [tuple(c[(j+d) % len(c)] for d in range(5)) for j in range(len(c))]
def loss(r):
    return canon(r[1:])
def from_json(path):
    return {tuple([b,a]+h) for a,h,b in json.loads(Path(path).read_text(encoding='utf-8-sig'))['rules']}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mode', choices=['six','seven'], default='six')
    ap.add_argument('--k7', type=int, default=2)
    ap.add_argument('--budget', type=int, choices=[208,210], default=210)
    ap.add_argument('--supports', choices=['free','seven'], default='free')
    ap.add_argument('--seconds', type=float, default=120)
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--hint')
    ap.add_argument('--fix-known', action='store_true')
    ap.add_argument('--local-patterns')
    ap.add_argument('--pair-compatibility')
    ap.add_argument('--same-seven-set', action='store_true')
    ap.add_argument('--out', required=True)
    a=ap.parse_args(); t0=time.perf_counter()
    assert a.seconds>0
    m=cp_model.CpModel()
    C5=list(cycles(5)); allrules=[r for c in C5 for r in windows(c)]
    extras={(5,6,1,2,3),(6,1,2,3,4)} if a.mode=='six' else set()
    forced=[((1,2,4,5,6),2),((1,3,4,5,6),1),((2,3,4,5,6),3)] if a.mode=='six' else []
    fixedrules=extras.copy()
    for c,w in forced: fixedrules.update(r for r in windows(c) if r[0]!=w)
    fixedloss={loss(r):r for r in fixedrules}
    fixedsupp={frozenset(r[1:]) for r in fixedrules}
    allowed_supp={frozenset(s) for s in combinations(L,4)}
    if a.supports=='seven': allowed_supp={s for s in allowed_supp if 8 not in s}
    allowed_supp-={frozenset(L)-s for s in fixedsupp}
    def allowed(r):
        return frozenset(r[1:]) in allowed_supp and (loss(r) not in fixedloss or fixedloss[loss(r)]==r)
    b={}; rule_terms=defaultdict(list); cov=defaultdict(list)
    for c in C5:
        vs=[]
        for w in c:
            rs=[r for r in windows(c) if r[0]!=w]
            if not all(allowed(r) for r in rs): continue
            # The two external rules cannot belong to any rescued five-cycle.
            if a.mode=='six' and any(r in extras for r in rs): continue
            v=m.new_bool_var('b_' + ''.join(map(str,c))+'_'+str(w))
            b[c,w]=v;vs.append(v)
            for r in rs: rule_terms[r].append(v);cov[loss(r)].append(v)
        if vs: m.add_at_most_one(vs)
    m.add(sum(b.values())==52)
    for key in forced: m.add(b[key]==1)
    e={}
    if a.mode=='seven':
        for r in allrules:
            if allowed(r):
                e[r]=m.new_bool_var('e_'+''.join(map(str,r)))
                rule_terms[r].append(e[r]);cov[loss(r)].append(e[r])
        m.add(sum(e.values())<=a.budget-208)
    else:
        assert a.budget==210
        for r in extras: rule_terms[r].append(1);cov[loss(r)].append(1)
    side={s:m.new_bool_var('s_'+''.join(map(str,sorted(s)))) for s in allowed_supp}
    for s in side:
        comp=frozenset(L)-s
        if comp in side:
            if min(s)<min(comp): m.add(side[s]+side[comp]==1)
        else: m.add(side[s]==1)
    for d in cycles(4):
        s=frozenset(d);terms=cov[d]
        if s in side:
            m.add(sum(terms)==side[s]) if a.mode=='six' else m.add(sum(terms)<=side[s])
        elif terms: m.add(sum(terms)==0)
    # At most two of the 210 loss-word slots can be empty.
    if a.mode=='seven':
        for s,v in side.items():
            terms=[q for d in cov if frozenset(d)==s for q in cov[d]]
            m.add(sum(terms)>=4*v)
    x={}
    for r,terms in rule_terms.items():
        if terms:
            v=m.new_bool_var('r_'+''.join(map(str,r))); m.add(v==sum(terms)); x[r]=v
    if a.mode=='seven':
        for c in cycles(6): m.add(sum(x[r] for r in windows(c) if r in x)<=4)
    z={}
    for c in cycles(7):
        terms=[x[r] for r in windows(c) if r in x]
        if len(terms)<6: continue
        v=m.new_bool_var('z_'+''.join(map(str,c)))
        m.add(sum(terms)>=6).only_enforce_if(v)
        m.add(sum(terms)<=5).only_enforce_if(v.Not());z[c]=v
    m.add(sum(z.values())>=a.k7)
    if a.local_patterns:
        assert a.mode=='six'
        records=json.loads(Path(a.local_patterns).read_text(encoding='utf-8'))['cycles']
        local={tuple(rec['cycle']):rec['patterns'] for rec in records}
        for c,v in z.items():
            if c not in local: m.add(v==0);continue
            witnesses=[]
            for pat in local[c]:
                terms=[b[tuple(q),w] for q,w in pat]
                g=m.new_bool_var('')
                for term in terms:m.add_implication(g,term)
                witnesses.append(g)
            m.add_bool_or(witnesses).only_enforce_if(v)
        if a.same_seven_set:
            # Proven local enumeration plus support-count exclusion: all rescued
            # C7 contain 1..6, and the 7-side and 8-side cannot coexist.
            # Swap the two unused labels so every rescued C7 avoids 8.
            assert a.k7>0
            for c,v in z.items():
                if 8 in c:m.add(v==0)
        if a.pair_compatibility:
            data=json.loads(Path(a.pair_compatibility).read_text(encoding='utf-8'))
            adj=data['adjacency']
            eligible=[i for i,r in enumerate(records) if not a.same_seven_set or 8 not in r['cycle']]
            for ii,i in enumerate(eligible):
                neighbors={tuple(c) for c in adj[i]}
                for j in eligible[ii+1:]:
                    if tuple(records[j]['cycle']) not in neighbors:m.add(z[tuple(records[i]['cycle'])]+z[tuple(records[j]['cycle'])]<=1)
    if a.mode=='seven' and a.k7:
        # Any rescued seven-cycle can be labeled (1,...,7); omitted label is 8.
        # Under supports='seven' all rescueable seven-cycles avoid 8.
        m.add(z[tuple(range(1,8))]==1)
    known=from_json(a.hint) if a.hint else None
    if known is not None:
        selected=set()
        for c in C5:
            present=[r for r in windows(c) if r in known]
            if len(present)>=4:
                absent=[r[0] for r in windows(c) if r not in known]
                w=absent[0] if absent else c[0]
                selected.add((c,w))
        for k,v in b.items():
            value=int(k in selected);m.add_hint(v,value)
            if a.fix_known:m.add(v==value)
        base={r for c,w in selected for r in windows(c) if r[0]!=w}
        for r,v in e.items():
            value=int(r in known-base);m.add_hint(v,value)
            if a.fix_known:m.add(v==value)
        for r,v in x.items():
            if a.fix_known:m.add(v==int(r in known))
    build=time.perf_counter()-t0
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=a.seconds
    solver.parameters.num_search_workers=a.workers;solver.parameters.random_seed=a.seed
    solver.parameters.log_search_progress=True
    lines=[];solver.log_callback=lines.append
    print(json.dumps({'event':'built','seconds':build,'b':len(b),'e':len(e),'x':len(x),'z7':len(z)}),flush=True)
    ts=time.perf_counter();status=solver.solve(m);elapsed=time.perf_counter()-ts
    out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    result={'arguments':vars(a),'ortools':ortools.__version__,'status':solver.status_name(status),'solve_seconds':elapsed,'build_seconds':build,'block_variables':len(b),'extra_variables':len(e),'rule_variables':len(x),'seven_cycle_variables':len(z),'response_stats':solver.response_stats()}
    if status in (cp_model.OPTIMAL,cp_model.FEASIBLE):
        rules=sorted(r for r,v in x.items() if solver.value(v))
        cert={'schema':'mixed-n8-v1','rules':[[r[1],list(r[2:]),r[0]] for r in rules]}
        certpath=out.with_suffix('.rules.json');certpath.write_text(json.dumps(cert,indent=2),encoding='utf-8')
        result['certificate']=str(certpath);result['selected_z7']=[c for c,v in z.items() if solver.value(v)]
    out.write_text(json.dumps(result,indent=2),encoding='utf-8')
    out.with_suffix('.solver.log').write_text(''.join(lines),encoding='utf-8')
    print(json.dumps(result),flush=True)

if __name__=='__main__':main()
