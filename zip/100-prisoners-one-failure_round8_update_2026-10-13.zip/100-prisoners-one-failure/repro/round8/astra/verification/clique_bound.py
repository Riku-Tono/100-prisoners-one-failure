"""Bound pairwise-compatible C7 count; does not construct a rule strategy."""
import argparse
import json
from pathlib import Path
import time
from ortools.sat.python import cp_model
import ortools


def main():
    here = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser()
    ap.add_argument('--seconds',type=float,default=60)
    ap.add_argument('--workers',type=int,default=2)
    ap.add_argument('--directory',default=str(here.parent/'local_coexistence'))
    ap.add_argument('--output',default=str(here/'clique_bound.json'))
    args = ap.parse_args()
    assert args.seconds>0
    started = time.perf_counter()
    directory = Path(args.directory)
    local = json.loads((directory/'local_patterns.json').read_text())
    pair = json.loads((directory/'pair_compatibility.json').read_text())
    cycles = [tuple(item['cycle']) for item in local['cycles']]
    index = {c:i for i,c in enumerate(cycles)}
    adjacent = [{index[tuple(c)] for c in row} for row in pair['adjacency']]
    assert len(adjacent)==len(cycles)==936
    assert sum(map(len,adjacent))//2==pair['cycle_pairs']
    assert all(i in adjacent[j] for i,adj in enumerate(adjacent) for j in adj)
    m = cp_model.CpModel()
    x = [m.new_bool_var('x'+str(i)) for i in range(len(cycles))]
    nonedges = 0
    for j in range(len(x)):
        for i in range(j):
            if i not in adjacent[j]:
                m.add(x[i]+x[j]<=1)
                nonedges+=1
    # Produce a valid greedy hint before the bounded exact solve.
    greedy=[]
    available=set(range(len(x)))
    while available:
        chosen=max(available,key=lambda k:len(adjacent[k]&available))
        greedy.append(chosen)
        available &= adjacent[chosen]
    for i,v in enumerate(x): m.add_hint(v,int(i in greedy))
    m.maximize(sum(x))
    build=time.perf_counter()-started
    solver=cp_model.CpSolver()
    solver.parameters.max_time_in_seconds=args.seconds
    solver.parameters.num_search_workers=args.workers
    solver.parameters.log_search_progress=True
    lines=[]
    solver.log_callback=lines.append
    begin=time.perf_counter()
    status=solver.solve(m)
    solve=time.perf_counter()-begin
    result={
        'scope': 'Clique relaxation: pair compatibility of minimal local witnesses only; no common witness selection or completion to 52 blocks.',
        'ortools':ortools.__version__, 'time_limit_seconds':args.seconds,
        'workers':args.workers,'vertices':len(x),'edges':pair['cycle_pairs'],
        'nonedges':nonedges,'build_seconds':build,'solve_seconds':solve,
        'status':solver.status_name(status),'objective':solver.objective_value,
        'best_bound':solver.best_objective_bound,
        'response_stats':solver.response_stats(),
        'greedy_clique': [cycles[i] for i in greedy],
    }
    if status in (cp_model.OPTIMAL,cp_model.FEASIBLE):
        selected=[i for i in range(len(x)) if solver.value(x[i])]
        assert all(j in adjacent[i] for i in selected for j in selected if i!=j)
        result['clique']=[cycles[i] for i in selected]
    output=Path(args.output)
    output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    output.with_suffix('.solver.log').write_text(''.join(lines),encoding='utf-8')
    print(json.dumps(result),flush=True)


if __name__=='__main__': main()
