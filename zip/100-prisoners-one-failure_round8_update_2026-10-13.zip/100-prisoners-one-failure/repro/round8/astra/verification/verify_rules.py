"""Independent final-box strategy verifier. Python standard library only.

Usage: python verify_rules.py INPUT.json [--output AUDIT.json]
Input: {"rules": [[a,[h1,h2,h3],b], ...]} or the bare rule list.
All claims are recomputed from rules; metadata and attached scripts are unused.
"""
import argparse
from collections import Counter, defaultdict
from itertools import combinations, permutations
import hashlib
import json
from pathlib import Path
import time

N = 8
LABELS = tuple(range(1, N + 1))


def canonical_cycle(cycle):
    cycle = tuple(cycle)
    pos = cycle.index(min(cycle))
    return cycle[pos:] + cycle[:pos]


def cycles(length):
    for support in combinations(LABELS, length):
        for tail in permutations(support[1:]):
            yield (support[0],) + tail


def read_rules(path):
    raw = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    return raw["rules"] if isinstance(raw, dict) else raw


def prepare(rules):
    mapping = {}
    for rule in rules:
        a, history, b = rule
        assert len(history) == 3, rule
        assert len(set([b, a] + history)) == 5, rule
        assert all(x in LABELS for x in [b, a] + history), rule
        key = (a, tuple(history))
        assert key not in mapping, ("duplicate observation", rule)
        mapping[key] = b
    return mapping


def correct_windows(cycle, mapping):
    length = len(cycle)
    correct = []
    missing = []
    for i, a in enumerate(cycle):
        history = tuple(cycle[(i + offset) % length] for offset in (1, 2, 3))
        if mapping.get((a, history)) == cycle[(i - 1) % length]:
            correct.append(a)
        else:
            missing.append(a)
    return correct, missing


def permutation_cycles(placement):
    unseen = set(LABELS)
    result = []
    while unseen:
        a = min(unseen)
        cycle = []
        while a in unseen:
            unseen.remove(a)
            cycle.append(a)
            a = placement[a - 1]
        result.append(cycle)
    return result


def direct_successes(placement, mapping):
    successes = 0
    for prisoner in LABELS:
        box = prisoner
        history = []
        for attempt in range(4):
            observed = placement[box - 1]
            if observed == prisoner:
                successes += 1
                break
            history.append(observed)
            if attempt == 2:
                box = mapping.get((prisoner, tuple(history)), observed)
            else:
                box = observed
    return successes


def audit(rules):
    started = time.perf_counter()
    mapping = prepare(rules)
    loss_counts = Counter(canonical_cycle((a,) + tuple(h)) for a, h, b in rules)
    supports = {tuple(sorted((a,) + tuple(h))) for a, h, b in rules}
    complement_collisions = []
    for support in sorted(supports):
        complement = tuple(x for x in LABELS if x not in support)
        if complement in supports and support < complement:
            complement_collisions.append([support, complement])
    block_groups = defaultdict(list)
    for a, h, b in rules:
        block_groups[canonical_cycle((b, a) + tuple(h))].append(a)
    rescued = {}
    for length in range(5, 9):
        values = []
        for cycle in cycles(length):
            correct, missing = correct_windows(cycle, mapping)
            if len(correct) >= length - 1:
                block_ids = [canonical_cycle((cycle[(i-1) % length],) + tuple(cycle[(i+j) % length] for j in (0,1,2,3))) for i,a in enumerate(cycle) if a in correct]
                values.append({"cycle": cycle, "correct_windows": len(correct), "correct_prisoners": correct, "missing_prisoners": missing, "window_block_sizes": [len(block_groups[x]) for x in block_ids]})
        rescued[str(length)] = values
    baseline_by_max = Counter()
    wins_by_max = Counter()
    total_by_max = Counter()
    lost = []
    wins = 0
    success_histogram = Counter()
    for placement in permutations(LABELS):
        cs = permutation_cycles(placement)
        largest = max(map(len, cs))
        cf_win = sum(len(c) for c in cs if len(c) <= 4) >= 7
        successes = direct_successes(placement, mapping)
        actual_win = successes >= 7
        success_histogram[successes] += 1
        total_by_max[largest] += 1
        baseline_by_max[largest] += cf_win
        wins_by_max[largest] += actual_win
        wins += actual_win
        if cf_win and not actual_win:
            lost.append(placement)
    rescued_counts = {k: len(v) for k, v in rescued.items()}
    formula = 14736 + 6 * rescued_counts['5'] + 2 * rescued_counts['6'] + rescued_counts['7']
    outside = [[a, h, b] for a, h, b in rules if len(block_groups[canonical_cycle((b, a) + tuple(h))]) < 4]
    return {
        "verifier": "independent-standard-library-direct-simulation-v1",
        "rules_count": len(rules),
        "distinct_observations": len(mapping),
        "loss_word_duplicates": [{"loss_word": x, "count": count} for x, count in sorted(loss_counts.items()) if count > 1],
        "support_count": len(supports),
        "complement_support_collisions": complement_collisions,
        "rescued_counts": rescued_counts,
        "rescued_cycles": rescued,
        "block_size_histogram": dict(sorted(Counter(map(len, block_groups.values())).items())),
        "rescued5_blocks": [{"cycle": c, "rule_prisoners": sorted(points)} for c, points in sorted(block_groups.items()) if len(points) >= 4],
        "rules_outside_rescued5_blocks": outside,
        "permutations_simulated": sum(total_by_max.values()),
        "wins": wins,
        "formula_wins": formula,
        "formula_matches_simulation": formula == wins,
        "cf_wins": sum(baseline_by_max.values()),
        "cf_old_wins_lost": len(lost),
        "cf_loss_examples": lost[:5],
        "max_cycle_statistics": [{"length": k, "placements": total_by_max[k], "cf_wins": baseline_by_max[k], "strategy_wins": wins_by_max[k]} for k in range(1,9)],
        "success_histogram": dict(sorted(success_histogram.items())),
        "elapsed_seconds": time.perf_counter() - started,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input")
    parser.add_argument("--output")
    args = parser.parse_args()
    result = audit(read_rules(args.input))
    result["input_sha256"] = hashlib.sha256(Path(args.input).read_bytes()).hexdigest()
    output = json.dumps(result, indent=2, ensure_ascii=True) + "\n"
    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("rules_count", "rescued_counts", "wins", "cf_old_wins_lost", "block_size_histogram", "elapsed_seconds")}, ensure_ascii=True))


if __name__ == "__main__":
    main()
