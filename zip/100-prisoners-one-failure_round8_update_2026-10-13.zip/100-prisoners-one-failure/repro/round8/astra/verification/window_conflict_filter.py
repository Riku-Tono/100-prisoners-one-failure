"""Enumerate necessary direct-window compatibility with normalized C6.

This checks conflicts among the actual correct-window rules only, without
requiring any additional 5-cycle blocks. Passing is necessary, not sufficient.
"""
from collections import Counter
import json
from pathlib import Path
import time
from verify_rules import LABELS, canonical_cycle, cycles


def window(cycle, index):
    n = len(cycle)
    return tuple(cycle[(index + j) % n] for j in (-1, 0, 1, 2, 3))


def loss(rule):
    return canonical_cycle(rule[1:])


def support(rule):
    return frozenset(rule[1:])


def conflict(rule, other):
    return rule != other and (loss(rule) == loss(other) or not support(rule) & support(other))


def analyze():
    started = time.perf_counter()
    c6 = (1,2,3,4,5,6)
    required6 = tuple(window(c6, i) for i in range(6) if c6[i] != 2)
    p = (5,6,1,2,3)
    q = (6,1,2,3,4)
    counts = Counter()
    candidates = []
    for c7 in cycles(7):
        windows = tuple(window(c7, i) for i in range(7))
        extras = int(p in windows) + int(q in windows)
        forced_missing = [c7[i] for i,w in enumerate(windows) if any(conflict(w,v) for v in required6)]
        pass_filter = len(forced_missing) <= 1
        counts[(extras, len(forced_missing), pass_filter)] += 1
        if pass_filter:
            candidates.append({"cycle": c7,"extra_windows": extras, "forced_missing_prisoners": forced_missing})
    return {
        "model": "actual-window CF conflict filter only; no block completion or R5=52 requirement",
        "C6": c6, "missing_prisoner6": 2,
        "required6_paths": required6,
        "histogram": [{"extra_windows": a, "forced_missing_count": b,"passes": c,"count": n} for (a,b,c),n in sorted(counts.items())],
        "candidate_count": len(candidates),
        "candidates": candidates,
        "elapsed_seconds": time.perf_counter()-started,
    }


if __name__ == "__main__":
    result = analyze()
    Path(__file__).with_name("normalized6_window_compatibility.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k != "candidates"},indent=2))
