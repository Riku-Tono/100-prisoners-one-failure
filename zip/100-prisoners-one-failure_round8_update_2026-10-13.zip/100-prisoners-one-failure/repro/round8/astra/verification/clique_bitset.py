"""Time-bounded maximum clique by greedy-color branch and bound."""
import json
from pathlib import Path
import time


def main():
    start=time.perf_counter()
    timeout=30.0
    here=Path(__file__).resolve().parent
    local_directory=here.parent/'local_coexistence'
    data=json.loads((local_directory/'local_patterns.json').read_text())
    pair=json.loads((local_directory/'pair_compatibility.json').read_text())
    allcycles=[tuple(d['cycle']) for d in data['cycles']]
    selected=[i for i,c in enumerate(allcycles) if 8 not in c]
    cs=[allcycles[i] for i in selected]
    index={c:i for i,c in enumerate(cs)}
    adj=[sum(1<<index[tuple(c)] for c in pair['adjacency'][i] if tuple(c) in index) for i in selected]
    assert len(cs)==468
    # Check the full graph consists of two isomorphic components under7<->8.
    allindex={c:i for i,c in enumerate(allcycles)}
    def swapped(c):return tuple(8 if x==7 else 7 if x==8 else x for x in c)
    for i,c in enumerate(allcycles):
        assert all((7 in c)==(7 in d) for d in pair['adjacency'][i])
        assert {swapped(tuple(d)) for d in pair['adjacency'][i]} == {tuple(d) for d in pair['adjacency'][allindex[swapped(c)]]}
    # Independent incumbent from this graph alone; no CP-SAT result needed.
    best=[]
    available=(1<<len(cs))-1
    while available:
        remaining=available
        candidates=[]
        while remaining:
            bit=remaining&-remaining
            candidates.append(bit.bit_length()-1)
            remaining^=bit
        chosen=max(candidates,key=lambda v:(adj[v]&available).bit_count())
        best.append(chosen)
        available &= adj[chosen]
    initial_clique_size=len(best)
    assert all(adj[i]>>j&1 for i in best for j in best if i!=j)
    nodes=0
    deadline=time.perf_counter()+timeout
    def color_sort(candidate):
        remaining=candidate
        vertices=[];bounds=[];color=0
        while remaining:
            color+=1
            available=remaining
            while available:
                bit=available&-available
                v=bit.bit_length()-1
                remaining^=bit
                available^=bit
                available &= ~adj[v]
                vertices.append(v);bounds.append(color)
        return vertices,bounds
    def expand(clique,candidate):
        nonlocal best,nodes
        nodes+=1
        if time.perf_counter()>deadline:raise TimeoutError
        vertices,bounds=color_sort(candidate)
        for position in range(len(vertices)-1,-1,-1):
            if len(clique)+bounds[position]<=len(best):return
            v=vertices[position]
            next_candidate=candidate&adj[v]
            if next_candidate:expand(clique+[v],next_candidate)
            elif len(clique)+1>len(best):
                best=clique+[v]
            candidate &= ~(1<<v)
    _,initial_bounds=color_sort((1<<len(cs))-1)
    begun=time.perf_counter()
    try:
        expand([],(1<<len(cs))-1)
        status='OPTIMAL'
        upper=len(best)
    except TimeoutError:
        status='UNKNOWN'
        upper=initial_bounds[-1]
    assert all(adj[i]>>j&1 for i in best for j in best if i!=j)
    result={'scope':'Exact maximum clique for one of two verified isomorphic disconnected components. Pairwise local witness compatibility is only a necessary relaxation of a52block strategy.',
            'status':status,'time_limit_seconds':timeout,
            'search_seconds':time.perf_counter()-begun,'total_seconds':time.perf_counter()-start,
            'nodes':nodes,'component_vertices':len(cs),'clique_size':len(best),
            'initial_greedy_clique_size':initial_clique_size,
            'clique_upper_bound':upper,'initial_greedy_color_bound':initial_bounds[-1],
            'clique':[cs[i] for i in best]}
    (here/'clique_bitset.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result),flush=True)


if __name__=='__main__':main()
