"""All six fixed-five pairs and 144 seven-cycle orbits, all 7 missing windows.
Every order-five invariant family with R5=52 has only block rules.
The independent base quotient run excludes all supports except a seven-label family.
Here normalize that family to labels1..7, without imposing further symmetries.
"""
import itertools as it,json,time,collections,argparse
from pathlib import Path
from order5_quotient import canon,cyc_orbit,word,wordorb,rules,blocks_orbit,exactcover

def main(output, seconds):
    words=sorted({wordorb(canon(p)) for s in it.combinations(range(1,8),4) for p in it.permutations(s)})
    wi={w:i for i,w in enumerate(words)}
    fcycles=[canon(tuple(1+(j*d)%5 for j in range(5))) for d in range(1,5)]
    blocks=[]
    for s in it.combinations(range(1,8),5):
        for tail in it.permutations(s[1:]):
            c=(s[0],)+tail
            if cyc_orbit(c)!=c or c in fcycles:continue
            for skip in range(5):
                rs=rules(c); ors=blocks_orbit(rs[:skip]+rs[skip+1:]);ws=[word(r) for r in ors]
                if len(set(ws))!=20:continue
                wo={wordorb(w) for w in ws};assert len(wo)==4
                blocks.append((sum(1<<wi[w] for w in wo),ors))
    cycles=[(1,)+tail for tail in it.permutations(range(2,8)) if cyc_orbit((1,)+tail)==(1,)+tail]
    assert len(cycles)==144
    allresults=[];witness=[];start=time.monotonic()
    for fi,fj in it.combinations(range(4),2):
        fixedrs=rules(fcycles[fi])+rules(fcycles[fj]);fixedws={word(r):r for r in fixedrs}
        fixedmask=sum(1<<wi[w] for w in {wordorb(w) for w in fixedws})
        target=(1<<42)-1^fixedmask
        base=[(m,rs) for m,rs in blocks if m&target==m]
        for c in cycles:
            for missing in range(7):
                force=set(blocks_orbit([tuple((c+c)[j:j+5]) for j in range(7) if j!=missing]))
                forcews={word(r):r for r in force}
                if len(forcews)!=len(force):res={'status':'RULE_CONFLICT'}
                elif any(w in fixedws and fixedws[w]!=r for w,r in forcews.items()):res={'status':'FIXED_RULE_CONFLICT'}
                else:
                    candidates=[(m,rs) for m,rs in base if all(w not in forcews or forcews[w]==r for r in rs for w in [word(r)])]
                    res=exactcover([m for m,_ in candidates],target,seconds)
                    res['candidates']=len(candidates)
                    if res['solution'] is not None:
                        rr=fixedrs+sum((candidates[i][1] for i in res['solution']),[])
                        witness.append({'fixed_steps':[fi+1,fj+1],'cycle':c,'missing':missing,'rules':[[r[1],list(r[2:]),r[0]] for r in rr]})
                allresults.append({'fixed_steps':[fi+1,fj+1],'cycle':c,'missing_window_path_index':missing,**res})
        print(fi+1,fj+1,dict(collections.Counter(r['status'] for r in allresults)),flush=True)
    out={'scope':'all order5 invariant R5=52 with <=210 rules, after base support quotient exclusion','seconds':time.monotonic()-start,'counts':dict(collections.Counter(r['status'] for r in allresults)),'results':allresults,'witnesses':witness}
    Path(output).write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(out['counts'],out['seconds'],flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--seconds',type=float,default=0.25);ap.add_argument('--output',default=str(Path(__file__).with_name('order5_r7_exhaustive.json')));args=ap.parse_args()
    main(args.output,args.seconds)
