"""Independent exact-cover quotient for order-five invariant R5=52 strategies.
No third-party packages.  Every search has a wall-clock limit.
"""
import itertools as it, json, time, argparse
from pathlib import Path

def canon(c):
    j=c.index(min(c)); return tuple(c[j:]+c[:j])
def act(c): return tuple(1+x%5 if x<=5 else x for x in c)
def cyc_orbit(c): return min(canon(tuple(1+(x-1+k)%5 if x<=5 else x for x in c)) for k in range(5))
def word(r): return canon(r[1:])
def wordorb(w): return cyc_orbit(w)
def supportorb(s): return min(tuple(sorted(1+(x-1+k)%5 if x<=5 else x for x in s)) for k in range(5))
def rules(c): return [c[j:]+c[:j] for j in range(5)]
def blocks_orbit(rs):
    ret=[]
    for k in range(5):
        ret += [tuple(1+(x-1+k)%5 if x<=5 else x for x in r) for r in rs]
    return ret

def exactcover(masks, target, seconds):
    start=time.monotonic(); deadline=start+seconds; nodes=0; dead=set()
    bybit={b:[] for b in range(target.bit_length()) if target>>b&1}
    for i,m in enumerate(masks):
        for b in bybit:
            if m>>b&1: bybit[b].append(i)
    def dfs(left):
        nonlocal nodes
        nodes+=1
        if time.monotonic()>deadline: raise TimeoutError
        if not left:return []
        if left in dead:return None
        best=None
        for b,inds in bybit.items():
            if left>>b&1:
                avail=[i for i in inds if masks[i]&left==masks[i]]
                if not avail:return None
                if best is None or len(avail)<len(best):best=avail
                if len(best)==1:break
        for i in best:
            out=dfs(left^masks[i])
            if out is not None:return [i]+out
        dead.add(left)
        return None
    try:
        sol=dfs(target); status='FEASIBLE' if sol is not None else 'INFEASIBLE'
    except TimeoutError:sol=None; status='UNKNOWN'
    return {'status':status,'seconds':time.monotonic()-start,'nodes':nodes,'solution':sol}

def run(seconds, output):
    words=sorted({wordorb(canon(p)) for s in it.combinations(range(1,9),4) for p in it.permutations(s)})
    wi={w:i for i,w in enumerate(words)}
    sw={w:supportorb(w) for w in words}
    sorbs=sorted(set(sw.values()))
    pairs=sorted({tuple(sorted((s,supportorb(set(range(1,9))-set(s))))) for s in sorbs})
    assert len(words)==84 and len(sorbs)==14 and len(pairs)==7
    fcycles=[canon(tuple(1+(j*d)%5 for j in range(5))) for d in range(1,5)]
    fixed_masks=[]
    for c in fcycles:
        wset={wordorb(word(r)) for r in rules(c)}
        assert len(wset)==1
        fixed_masks.append(sum(1<<wi[w] for w in wset))
    orbblocks={}
    invalid=0
    for s in it.combinations(range(1,9),5):
        for tail in it.permutations(s[1:]):
            c=(s[0],)+tail
            if cyc_orbit(c)==c and c not in fcycles:
                for skip in range(5):
                    rs=rules(c); rs=rs[:skip]+rs[skip+1:]
                    ors=blocks_orbit(rs); ws=[word(r) for r in ors]
                    if len(set(ws))!=20:invalid+=1;continue
                    supports={frozenset(w) for w in ws}
                    if any(frozenset(set(range(1,9))-set(s)) in supports for s in supports):invalid+=1;continue
                    wo={wordorb(w) for w in ws}
                    assert len(wo)==4
                    mask=sum(1<<wi[w] for w in wo)
                    key=(cyc_orbit(c),skip)
                    orbblocks[key]=(mask,ors)
    rows=[]; found=[]
    for fi,fj in it.combinations(range(4),2):
        fixed=fixed_masks[fi]|fixed_masks[fj]
        assert fixed.bit_count()==2
        for choice in it.product(range(2),repeat=7):
            selected={pairs[k][choice[k]] for k in range(7)}
            if supportorb((1,2,3,4)) not in selected:continue
            full=sum(1<<wi[w] for w in words if sw[w] in selected)
            assert full.bit_count()==42
            target=full^fixed
            candidates=[(key,m,rs) for key,(m,rs) in orbblocks.items() if m&target==m]
            result=exactcover([m for _,m,_ in candidates],target,seconds)
            row={'fixed_steps':[fi+1,fj+1],'support_orbits':[list(s) for s in sorted(selected)],'n_candidates':len(candidates),**result}
            print(json.dumps({k:v for k,v in row.items() if k not in ('support_orbits','solution')}),flush=True)
            rows.append(row)
            if result['solution'] is not None:
                rr=rules(fcycles[fi])+rules(fcycles[fj])
                for i in result['solution']:rr+=candidates[i][2]
                found.append({'row_index':len(rows)-1,'rules':[ [r[1],list(r[2:]),r[0]] for r in rr]})
        Path(output).write_text(json.dumps({'quotient_words':len(words),'quotient_blocks':len(orbblocks),'invalid_blocks':invalid,'rows':rows,'found':found},indent=2),encoding='utf-8')
    return rows

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--seconds',type=float,default=0.25);ap.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));args=ap.parse_args()
    run(args.seconds,args.output)
