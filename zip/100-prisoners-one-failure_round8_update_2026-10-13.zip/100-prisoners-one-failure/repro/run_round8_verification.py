"""Recheck the saved Round 8 results with Python 3.10+ standard library.

Run from the repository root: python -X utf8 repro/run_round8_verification.py
Archived source data are kept unchanged. Scripts that write beside themselves
run in a temporary copy. Fresh transcripts/results go to verification/round8.
The general CP-SAT searches are not rerun and optimality is not asserted.
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent.parent
ROUND8 = Path("results/8ラウンド5・6・7巡回の共存条件と競合不等式")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "verification/round8")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    astra = ROOT / "repro/round8/astra"
    archived_codex = ROOT / "repro/round8/codex"
    checks = []
    env = dict(os.environ, PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1")
    with tempfile.TemporaryDirectory(prefix="round8-verification-", dir=output) as temp:
        assert Path(temp).resolve().is_relative_to(output), "Temporary work must stay inside the output directory."
        scratch = Path(temp) / "codex"
        shutil.copytree(archived_codex, scratch, ignore=shutil.ignore_patterns("__pycache__"))
        cert = ROOT / ROUND8 / "Claude/2/best15050_six_cycle_n8.json"
        tasks = [
            ("claude-four-constructions", ROOT / ROUND8 / "Codex/audit_round8_independent.py",
             [ROOT / ROUND8 / "Claude/2/round8_claude_2026-10-12.zip", "--output", output / "claude_certificate_audit.json",
              "--standalone", cert, ROOT / ROUND8 / "Claude/2/best15051_three_stars_n8.json"]),
            ("astra-certificates-and-source-hashes", scratch / "audit_astra_certificates.py",
             [astra, "--output", output / "astra_certificate_audit.json"]),
            ("six-cycle-local-tables", scratch / "round8_lemmas/six_cycle/audit_six_cycle.py", [cert]),
            ("partial-star-classification", scratch / "round8_lemmas/partial_star/audit_partial_stars.py", []),
            ("seven-cycle-candidates", scratch / "astra_audit/candidates/audit_candidates.py", [astra]),
            ("pairwise-graph-and-clique", scratch / "astra_audit/graph/audit_graph.py", [astra, output / "graph"]),
            ("order5-all-branches", scratch / "astra_audit/order5/independent_order5.py", [astra / "theory_general"]),
            ("order5-branch-comparison", scratch / "astra_audit/order5/compare_saved.py", [astra / "theory_general"]),
        ]
        for index, (name, script, arguments) in enumerate(tasks, 1):
            print(f"[{index}/{len(tasks)}] {name}", flush=True)
            began = time.monotonic()
            command = [sys.executable, "-X", "utf8", "-B", str(script), *map(str, arguments)]
            transcript = output / f"{name}.txt"
            with transcript.open("w", encoding="utf-8", newline="\n") as stream:
                completed = subprocess.run(command, cwd=scratch, env=env, stdout=stream,
                                           stderr=subprocess.STDOUT, timeout=300, check=False)
            checks.append({"task": name, "returncode": completed.returncode,
                           "elapsed_seconds": round(time.monotonic() - began, 3),
                           "transcript": transcript.name})
            if completed.returncode != 0:
                print(transcript.read_text(encoding="utf-8"), flush=True)
                raise SystemExit(f"FAILED: {name}")
        artifacts = {
            "round8_lemmas/six_cycle/six_cycle_results.json": "six_cycle_results.json",
            "round8_lemmas/partial_star/results.json": "partial_star_results.json",
            "astra_audit/candidates/candidate_results.json": "candidate_results.json",
            "astra_audit/order5/independent_order5_results.json": "independent_order5_results.json",
            "astra_audit/order5/branch_comparison.json": "order5_branch_comparison.json",
        }
        for relative, destination in artifacts.items():
            shutil.copyfile(scratch / relative, output / destination)

    def read(name):
        return json.loads((output / name).read_text(encoding="utf-8-sig"))

    claude = read("claude_certificate_audit.json")
    assert claude["status"] == "PASS"
    counts = [item["direct"]["wins"] for item in claude["certificates"].values()]
    assert counts == [15049, 15050, 15050, 15051]
    assert all(item["direct"]["CF_old_wins_lost"] == 0 for item in claude["certificates"].values())
    assert read("astra_certificate_audit.json")["status"] == "PASS"
    assert read("six_cycle_results.json")["total_enumerated_local_rule_tables"] == 255879
    partial = read("partial_star_results.json")
    assert (partial["assignments_examined"], partial["six_window_patterns"], partial["seven_window_patterns"]) == (279936, 28, 1)
    candidates = read("candidate_results.json")
    assert (candidates["candidate_count"], candidates["one_side_candidates"], candidates["one_side_witnesses"]) == (936, 468, 7638)
    for key in ("all_candidates_contain_1_to_6", "all_candidate_extra_counts_zero", "swapped_sides_equal",
                "source_full_candidates_and_patterns_equal", "source_one_side_candidates_and_patterns_equal"):
        assert candidates[key], key
    graph = read("graph/audit_result.json")
    assert graph["proven_maximum_clique"] == 11
    branch = read("order5_branch_comparison.json")
    assert branch["all_branch_statuses_identical"]
    assert (branch["base_branch_match"], branch["seven_branch_match"]) == (384, 6048)
    assert branch["source_base_unknown"] == branch["source_seven_unknown"] == 0
    summary = {
        "verification_date_jst": datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).date().isoformat(),
        "python": sys.version, "status": "PASS", "checks_passed": len(checks), "checks": checks,
        "claude_wins": counts, "CF_old_wins_lost": 0,
        "local_rule_tables": 255879, "partial_star_patterns": [28, 1],
        "one_side_candidates": 468, "one_side_witnesses": 7638,
        "maximum_clique_of_local_relaxation": 11, "order5_branches": 6432,
        "general_CP_SAT_searches_rerun": False, "total_win_optimality_proved": False,
        "scope": "Saved CF-preserving final-box n8 constructions and the stated local/symmetric finite analyses."
    }
    (output / "current_checks.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("ALL 8 ROUND 8 CHECKS PASSED", flush=True)


if __name__ == "__main__":
    main()
