"""Certificate audit for a final-box rule table (n=8, m=4).  Self-contained (no search code).
Derives from the rule table alone:
  * validity: one rule per key, target unopened and != CF next box
  * Prop.2 (CF-preservation): loss words pairwise distinct; no two loss supports complementary
  * rescued directed k-cycles for k=5..8 (>= k-1 of k prisoners hold the correct rule)
  * predicted wins 14736 + 6R5 + 2R6 + R7 + R8
  * for each rescued 5-cycle: skipped point w (target of the missing rule) and omitted prisoner o=succ(w)
"""
import json, sys
from itertools import combinations, permutations

L = range(1, 9)
def canon(c):
    c = tuple(c); k = c.index(min(c)); return c[k:] + c[:k]
def dcycles(S):
    S = sorted(S); return [(S[0],) + q for q in permutations(S[1:])]

def audit(rules):
    R = {}
    for a, h, b in rules:
        h = tuple(h); assert len(h) == 3 and len({a, *h, b}) == 5, ("invalid rule", a, h, b)
        assert (a, h) not in R, "duplicate key"; R[(a, h)] = b
    words = {}
    for (a, h), b in R.items():
        D = canon((a,) + h)
        assert D not in words, ("two rules on loss word", D); words[D] = (a, h, b)
    sup = {frozenset(D) for D in words}
    comp = [S for S in sup if frozenset(L) - S in sup]
    assert not comp, ("complementary supports", comp)
    rescued = {}
    for k in (5, 6, 7, 8):
        rescued[k] = []
        for U in combinations(L, k):
            for C in dcycles(U):
                ok = [R.get((C[j], tuple(C[(j + s) % k] for s in (1, 2, 3)))) == C[(j - 1) % k] for j in range(k)]
                if sum(ok) >= k - 1:
                    rescued[k].append((C, ok))
    blocks = []
    for C, ok in rescued[5]:
        miss = [C[j] for j in range(5) if not ok[j]]
        if miss:
            o = miss[0]; w = C[(C.index(o) - 1) % 5]
        else:
            o = w = None
        blocks.append(dict(cycle=list(C), correct_rules=sum(ok), skipped_point=w, omitted_prisoner=o))
    n = {k: len(v) for k, v in rescued.items()}
    used_by_blocks = set()
    for C, ok in rescued[5]:
        for j in range(5):
            if ok[j]: used_by_blocks.add(canon(C[j:] + C[:j])[:0] or canon(tuple(C[(j + s) % 5] for s in range(4))))
    return dict(
        n_rules=len(R), loss_words_distinct=True, complementary_supports=0,
        supports_used=len(sup), prisoners_with_rules=sorted({a for a, _ in R}),
        rescued_counts={str(k): n[k] for k in n},
        predicted_wins=14736 + 6 * n[5] + 2 * n[6] + n[7] + n[8],
        blocks=blocks,
        longer_cycles={str(k): [dict(cycle=list(C), correct_windows=sum(ok), missing_prisoners=[C[j] for j in range(k) if not ok[j]]) for C, ok in rescued[k]] for k in (6, 7, 8)},
        rules_outside_rescued_5cycles=len(R) - sum(b["correct_rules"] for b in blocks),
    )

if __name__ == "__main__":
    d = json.load(open(sys.argv[1]))
    res = audit(d["rules"])
    print(json.dumps({k: v for k, v in res.items() if k != "blocks"}, ensure_ascii=False))
    print("blocks:", len(res["blocks"]))
