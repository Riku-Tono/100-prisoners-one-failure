"""Independent direct simulator (does not import core.py).
Strategy JSON: {"rules": [[prisoner, [h1,h2,h3], target], ...]}  (final-box rules only)
Simulates all 8! placements prisoner by prisoner.
"""
import json, sys
from itertools import permutations
from collections import Counter

def simulate(rules):
    R = {}
    for a, h, b in rules:
        key = (a, tuple(h))
        assert key not in R, "duplicate key"
        assert len(set([a, *h, b])) == 5, "bad rule"
        R[key] = b
    wins = cf_wins = lost = 0
    by_maxlen = Counter()
    for perm in permutations(range(1, 9)):
        box = {b: perm[b - 1] for b in range(1, 9)}
        ok = 0
        for i in range(1, 9):
            opened, seen, nxt, found = set(), [], i, False
            for t in range(4):
                assert nxt not in opened
                opened.add(nxt); v = box[nxt]; seen.append(v)
                if v == i:
                    found = True; break
                nxt = v
                if t == 2 and (i, tuple(seen)) in R:
                    nxt = R[(i, tuple(seen))]
            ok += found
        # cycle structure
        seenp, mx = set(), 0
        for s in range(1, 9):
            if s in seenp: continue
            l, x = 0, s
            while x not in seenp:
                seenp.add(x); x = box[x]; l += 1
            mx = max(mx, l)
        win = ok >= 7
        wins += win
        if mx <= 4:
            cf_wins += 1
            lost += (not win)
        if win: by_maxlen[mx] += 1
    return dict(wins=wins, cf_wins=cf_wins, cf_lost=lost, wins_by_max_cycle_len=dict(sorted(by_maxlen.items())))

if __name__ == "__main__":
    d = json.load(open(sys.argv[1]))
    print(json.dumps(dict(file=sys.argv[1], n_rules=len(d["rules"]), **simulate(d["rules"]))))
